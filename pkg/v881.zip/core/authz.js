/**
 * [需求9] 模块化拆分 · core/auth —— 会话鉴权
 * 负责：Bearer token 解析、会话有效期校验（超期即删会话）、设备绑定校验（防 token 跨设备重放）、
 * 管理员模拟用户识别；失败时通过 x-auth-reason 告知前端具体原因。
 * 通过工厂注入 getDb（数据库连接会被重建，必须每次取最新）与 fail（统一错误响应）。
 */
module.exports = function createAuthz({ getDb, fail }) {
  let authReason = 'expired';

  function authUser(req) {
    const db = getDb();
    const h = req.headers['authorization'] || '';
    const token = h.startsWith('Bearer ') ? h.slice(7) : '';
    if (!token) { authReason = 'expired'; return null; }
    const row = db.prepare('SELECT * FROM sessions WHERE token = ?').get(token);
    if (!row) { authReason = 'expired'; return null; }
    // 会话过期校验：超过有效期即删除会话，强制重新登录（30 天）
    if (row.expires_at && Date.now() > row.expires_at) {
      try { db.prepare('DELETE FROM sessions WHERE token = ?').run(token); } catch (e) {}
      authReason = 'expired';
      return null;
    }
    // 设备绑定校验：绑定 device_id 的会话，请求必须携带一致的 x-device-id
    if (row.device_id) {
      const got = String(req.headers['x-device-id'] || '').trim();
      if (!got || got !== row.device_id) {
        authReason = 'device';
        return null;
      }
    }
    const u = db.prepare('SELECT * FROM users WHERE id = ?').get(row.user_id) || null;
    // v7.8 管理员模拟用户：模拟 token 在 configs 中有 imp_ 标记，附加模拟来源信息
    if (u) {
      const imp = db.prepare('SELECT v FROM configs WHERE k = ?').get('imp_' + token);
      if (imp) { try { u.__imp = JSON.parse(imp.v); } catch (e) { u.__imp = {}; } }
    }
    return u;
  }

  function requireAuth(req, res) {
    const u = authUser(req);
    if (!u) {
      try { res.setHeader('x-auth-reason', authReason); } catch (e) {}
      fail(res, 401, authReason === 'device' ? '登录设备已变更，请重新登录' : '未登录或登录已过期');
      return null;
    }
    return u;
  }

  return {
    authUser,
    requireAuth,
    get authReason() { return authReason; }
  };
};
