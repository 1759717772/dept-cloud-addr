/**
 * [需求9] 模块化拆分 · core/db —— 数据库连接与表结构工具
 * 提供：openDatabase（打开连接并设置 WAL/busy_timeout）、sqlTables（惰性读取真实表名）、
 * safeT（表名白名单校验，[需求6] SQL 加固）、ensureColumn（幂等补列）。
 * 连接对象由 server.js 持有并会在健康检查时重建，因此这里全部通过 getDb() 取最新连接。
 */
module.exports = function createDbTools({ getDb, DatabaseSync }) {
  var _sqlTables = null; // 惰性缓存：首次调用时表结构已建好

  function openDatabase(file) {
    const conn = new DatabaseSync(file);
    try { conn.exec('PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 10000;'); } catch (e) {}
    return conn;
  }

  function sqlTables() {
    if (!_sqlTables) {
      _sqlTables = new Set(getDb().prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(function (r) { return r.name; }));
    }
    return _sqlTables;
  }

  function safeT(t) {
    const name = String(t || '');
    if (!sqlTables().has(name)) throw new Error('非法表名: ' + name);
    return name;
  }

  function ensureColumn(table, col, ddl) {
    const conn = getDb();
    const t = safeT(table);
    const cols = conn.prepare(`PRAGMA table_info(${t})`).all().map((c) => c.name);
    if (!cols.includes(col)) conn.exec(`ALTER TABLE ${t} ADD COLUMN ${col} ${ddl}`);
  }

  function refreshTables() { _sqlTables = null; }

  return { openDatabase, sqlTables, safeT, ensureColumn, refreshTables };
};
