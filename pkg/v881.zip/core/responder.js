/**
 * [需求9] 模块化拆分 · core/responder —— HTTP 响应与请求体工具
 * 统一 JSON 输出（含幂等缓存回放）、CORS、错误响应与请求体读取。
 * 通过工厂注入 idemMap / maxUpload，避免与 server.js 形成循环依赖。
 */
module.exports = function createResponder({ getIdemMap, maxUpload }) {
  function json(res, code, obj) {
    const body = JSON.stringify(obj);
    res.__respBody = body; // 幂等缓存用
    if (res.__idemKey && !res.__idemDone) {
      res.__idemDone = true;
      const map = getIdemMap();
      if (map) map.set(res.__idemKey, { body, exp: Date.now() + 60000 });
    }
    res.writeHead(code, {
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Length': Buffer.byteLength(body),
      'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type,Authorization',
      'Access-Control-Max-Age': '600'
    });
    res.end(body);
  }
  function ok(res, data) { json(res, 200, { ok: true, data }); }
  function fail(res, code, msg) { json(res, code, { ok: false, error: msg }); }
  function readBody(req) {
    return new Promise((resolve, reject) => {
      let size = 0;
      const chunks = [];
      req.on('data', (c) => {
        size += c.length;
        if (size > maxUpload + 1024 * 1024) {
          const e = new Error('请求体过大'); e.code = 'BODY_TOO_LARGE';
          req.pause(); reject(e); return;
        }
        chunks.push(c);
      });
      req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      req.on('error', reject);
    });
  }
  return { json, ok, fail, readBody };
};
