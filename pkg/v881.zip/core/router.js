/**
 * [需求9] 模块化拆分 · core/router —— 精确路由表
 * 目的：把"巨型 if/else 链"逐步替换为可注册、可分发的路由表，新模块只需 register 自己的路径。
 * 约定：handler(req, res, ctx) 可为 async；返回 false 表示未命中，由 server.js 继续走原有分支（平滑迁移）。
 */
module.exports = function createRouter() {
  const table = new Map(); // "METHOD path" -> handler

  function register(method, path, handler) {
    table.set(String(method).toUpperCase() + ' ' + path, handler);
  }
  const get = (p, h) => register('GET', p, h);
  const post = (p, h) => register('POST', p, h);
  const route = (m, p, h) => register(m, p, h);

  async function dispatch(req, res, pathname, ctx) {
    const h = table.get(req.method + ' ' + pathname);
    if (!h) return false;
    await h(req, res, ctx);
    return true;
  }

  return { get, post, route, register, dispatch, size: () => table.size };
};
