/**
 * [需求9] 模块化拆分 · modules/ai —— 专属大模型可用性查询
 * 只回答"当前用户能不能用"：总开关 + 临时授权（全体/指定人）+ 暂停标记，三者同时满足才 allowed。
 */
module.exports = function registerAi(router, deps) {
  const { ok, fail, authUser, isAIUser, db } = deps;
  // 配置读取（原实现是 handler 内局部函数，迁移后模块内自持一份，逻辑完全一致）
  const cfgGet = (k) => { const r = db().prepare('SELECT v FROM configs WHERE k=?').get(k); return r ? r.v : ''; };

  router.get('/api/ai/access', (req, res) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    const master = cfgGet('ai_master') === '1';
    const g = db().prepare("SELECT * FROM ai_grant WHERE deleted_at IS NULL AND (scope='all' OR (scope='user' AND user_id=?)) AND expire_at>? ORDER BY id DESC LIMIT 1").get(u.id, Date.now());
    const adminUser = isAIUser(u);
    ok(res, {
      master,
      is_admin: adminUser,
      granted: !!g,
      paused: g ? Number(g.paused) : 0,
      expire_at: g ? Number(g.expire_at) : 0,
      allowed: master && (adminUser || (!!g && Number(g.paused) === 0))
    });
  });
};
