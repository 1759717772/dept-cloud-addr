/**
 * [需求9] 模块化拆分 · modules/backup —— 备份管理（3 槽轮转）
 * 从 server.js 抽离备份/恢复实现与 /api/backup/* 路由。
 * 因 doRestore 会重建数据库连接，这里通过 getDb/setDb 回调与主进程共享同一连接变量，
 * 不使用模块私有的 db 句柄，避免"恢复后主进程仍持旧连接"的问题。
 */
module.exports = function registerBackup(router, deps) {
  const fs = require('fs');
  const path = require('path');
  const { ok, fail, authUser, requireLevel, getDb, setDb, DatabaseSync } = deps;
  const { BACKUP_DIR, DB_FILE, UPLOAD_DIR, PUBLIC_DIR, ROOT, SLOTS = 3 } = deps.dirs;
  const { nowLocalStr, dirSize, readBody } = deps;
  const db = () => getDb();

  fs.mkdirSync(BACKUP_DIR, { recursive: true });

  function backupSlot() {
    // 读取轮转指针（1/2/3 循环），返回本次使用的槽位并把指针前移
    const pf = path.join(BACKUP_DIR, '.slot');
    let n = 1;
    try { n = parseInt(fs.readFileSync(pf, 'utf8').trim(), 10) || 1; } catch (e) { /* 首次无指针 */ }
    if (n < 1 || n > SLOTS) n = 1;
    fs.writeFileSync(pf, String((n % SLOTS) + 1));
    return n;
  }

  function doBackup(type) {
    const slot = backupSlot();
    const dir = path.join(BACKUP_DIR, 'backup_' + slot);
    fs.rmSync(dir, { recursive: true, force: true });
    fs.mkdirSync(dir, { recursive: true });
    // 数据库：VACUUM INTO 在线原子快照（自动合并 WAL，不影响运行中服务）
    db().exec("VACUUM INTO '" + path.join(dir, 'system.db').replace(/'/g, "''") + "'");
    // 上传文件 + 软件代码
    fs.cpSync(UPLOAD_DIR, path.join(dir, 'uploads'), { recursive: true });
    fs.cpSync(PUBLIC_DIR, path.join(dir, 'public'), { recursive: true });
    fs.copyFileSync(path.join(ROOT, 'server.js'), path.join(dir, 'server.js'));
    const meta = { slot, type, at: nowLocalStr(), size: 0 };
    try { meta.size = dirSize(dir); } catch (e) { /* 忽略 */ }
    fs.writeFileSync(path.join(dir, 'backup.json'), JSON.stringify(meta));
    return meta;
  }

  function doRestore(slot) {
    const dir = path.join(BACKUP_DIR, 'backup_' + slot);
    const dbPath = path.join(dir, 'system.db');
    if (!fs.existsSync(dbPath)) { const e = new Error('槽位 ' + slot + ' 无备份'); e.code = 'NOBACKUP'; throw e; }
    // 恢复前先把当前数据备份为最新一轮，保证可回退
    doBackup('restore-before');
    try { db().close(); } catch (e) { /* 已关闭 */ }
    for (const suf of ['', '-wal', '-shm']) { try { fs.rmSync(DB_FILE + suf, { force: true }); } catch (e) { /* 忽略 */ } }
    fs.copyFileSync(dbPath, DB_FILE);
    const nd = new DatabaseSync(DB_FILE);
    try { nd.exec('PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 10000;'); } catch (e) { /* 忽略 */ }
    setDb(nd); // 主进程连接变量同步切换，后续请求即用新库
    // 上传文件恢复
    fs.rmSync(UPLOAD_DIR, { recursive: true, force: true });
    fs.mkdirSync(UPLOAD_DIR, { recursive: true });
    const up = path.join(dir, 'uploads');
    if (fs.existsSync(up)) fs.cpSync(up, UPLOAD_DIR, { recursive: true });
    return slot;
  }

  function backupList() {
    const arr = [];
    for (let i = 1; i <= SLOTS; i++) {
      const dir = path.join(BACKUP_DIR, 'backup_' + i);
      const mf = path.join(dir, 'backup.json');
      arr.push({ slot: i, has: fs.existsSync(mf), meta: fs.existsSync(mf) ? JSON.parse(fs.readFileSync(mf, 'utf8')) : null });
    }
    return arr;
  }

  // 自动备份定时器：每分钟检查一次，到设定时间（HH:MM）执行，同分钟只执行一次
  let lastAutoBackup = '';
  setInterval(() => {
    try {
      const cfg = db().prepare('SELECT v FROM configs WHERE k=?').get('auto_backup');
      if (!cfg) return;
      const c = JSON.parse(cfg.v || '{}');
      if (!c.enable || !c.time) return;
      const d = new Date();
      const hhmm = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
      if (hhmm === c.time && hhmm !== lastAutoBackup) { lastAutoBackup = hhmm; doBackup('auto'); }
    } catch (e) { /* 忽略瞬时错误 */ }
  }, 60000).unref();

  // ---------- 路由（管理员/运维专用：运维4、管理员5） ----------
  function guard(req, res) {
    const u = authUser(req);
    if (!u) { fail(res, 401, '请先登录'); return null; }
    if (!requireLevel(u, 4, res)) return null;
    return u;
  }

  router.post('/api/backup/now', async (req, res) => {
    if (!guard(req, res)) return;
    try { ok(res, doBackup('manual')); }
    catch (e) { fail(res, 500, '备份失败：' + e.message); }
  });

  router.get('/api/backup/list', async (req, res) => {
    if (!guard(req, res)) return;
    ok(res, backupList());
  });

  router.post('/api/backup/restore', async (req, res) => {
    if (!guard(req, res)) return;
    const b = JSON.parse(await readBody(req));
    const slot = Number(b.slot);
    if (!slot || slot < 1 || slot > SLOTS) { fail(res, 400, '请选择有效的备份槽位（1~3）'); return; }
    try { const s = doRestore(slot); ok(res, { slot: s, restored_at: nowLocalStr() }); }
    catch (e) { fail(res, e.code === 'NOBACKUP' ? 404 : 500, '恢复失败：' + e.message); }
  });

  router.get('/api/backup/schedule', async (req, res) => {
    if (!guard(req, res)) return;
    const cfg = db().prepare('SELECT v FROM configs WHERE k=?').get('auto_backup');
    ok(res, cfg ? JSON.parse(cfg.v) : { enable: false, time: '23:30' });
  });

  router.post('/api/backup/schedule', async (req, res) => {
    if (!guard(req, res)) return;
    const b = JSON.parse(await readBody(req));
    const enable = !!b.enable;
    const time = /^([01]\d|2[0-3]):[0-5]\d$/.test(b.time || '') ? b.time : '23:30';
    db().prepare('INSERT INTO configs (k,v) VALUES (?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v')
      .run('auto_backup', JSON.stringify({ enable, time }));
    ok(res, { enable, time });
  });

  return { backupSlot, doBackup, doRestore, backupList, SLOTS };
};
