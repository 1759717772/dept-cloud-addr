/**
 * [需求9] 模块化拆分 · modules/config —— 配置化底座
 * 提供四类可配置能力，避免"改一个枚举就要改代码重新发版"：
 *   1) 数据字典 app_dict    —— 请假类型/检查类型等枚举在线维护
 *   2) 自定义字段 custom_attrs / custom_values —— 给业务表挂扩展字段，不动表结构
 *   3) 业务单号 app_seq     —— 前缀+日期段+序号，按天/月/年归零（如 QJ-20261108-001）
 *   4) 数据级权限 data_scopes —— 某角色对某表只能看 全部/本部门/本人
 * 读接口对所有登录用户开放（表单要靠字典渲染），写接口限运维/管理员。
 */
module.exports = function registerConfig(router, deps) {
  const { ok, fail, authUser, typeLevel, isAdmin, db, readBody } = deps;

  function needAdmin(u, res) {
    if (!u) { fail(res, 401, '请先登录'); return false; }
    if (typeLevel(u) < 4 && !isAdmin(u)) { fail(res, 403, '仅运维工程师/管理员可修改配置'); return false; }
    return true;
  }

  // 首次启动写入基础字典，保证前端下拉框不空
  (function seed() {
    try {
      const n = db().prepare('SELECT COUNT(*) AS c FROM app_dict').get().c;
      if (n > 0) return;
      const ins = db().prepare('INSERT INTO app_dict (dict_type,code,name,sort,is_default) VALUES (?,?,?,?,?)');
      [['leave_type', '事假', '事假', 1, 0], ['leave_type', '病假', '病假', 2, 0],
       ['leave_type', '年休', '年休假', 3, 0], ['leave_type', '调休', '调休', 4, 0],
       ['check_type', '日常检查', '日常检查', 1, 0], ['check_type', '专项检查', '专项检查', 2, 0],
       ['asset_type', '消防器材', '消防器材', 1, 0], ['asset_type', '车辆', '车辆', 2, 0]
      ].forEach((r) => ins.run(r[0], r[1], r[2], r[3], r[4]));
    } catch (e) { console.error('[配置] 字典初始化失败', e.message); }
  })();

  // ---------- 数据字典 ----------
  router.get('/api/config/dict', (req, res, ctx) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    const type = String(ctx.url.searchParams.get('type') || '');
    const rows = type
      ? db().prepare('SELECT * FROM app_dict WHERE dict_type=? AND deleted_at IS NULL ORDER BY sort, id').all(type)
      : db().prepare('SELECT * FROM app_dict WHERE deleted_at IS NULL ORDER BY dict_type, sort, id').all();
    ok(res, rows);
  });

  router.post('/api/config/dict', async (req, res, ctx) => {
    const u = authUser(req); if (!needAdmin(u, res)) return;
    const b = JSON.parse(await readBody(req));
    if (b.action === 'del') {
      db().prepare("UPDATE app_dict SET deleted_at=datetime('now','localtime') WHERE id=?").run(Number(b.id));
      return ok(res, { deleted: Number(b.id) });
    }
    if (!b.dict_type || !b.name) return fail(res, 400, '字典类型与名称必填');
    if (b.id) {
      db().prepare('UPDATE app_dict SET dict_type=?,code=?,name=?,sort=? WHERE id=?')
        .run(b.dict_type, b.code || b.name, b.name, Number(b.sort) || 0, Number(b.id));
      return ok(res, { id: Number(b.id) });
    }
    const info = db().prepare('INSERT INTO app_dict (dict_type,code,name,sort) VALUES (?,?,?,?)')
      .run(b.dict_type, b.code || b.name, b.name, Number(b.sort) || 0);
    ok(res, { id: Number(info.lastInsertRowid) });
  });

  // ---------- 自定义字段 ----------
  router.get('/api/config/attrs', (req, res, ctx) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    const table = String(ctx.url.searchParams.get('table') || 'users');
    ok(res, db().prepare('SELECT * FROM custom_attrs WHERE table_name=? AND deleted_at IS NULL ORDER BY sort, id').all(table));
  });

  router.post('/api/config/attrs', async (req, res) => {
    const u = authUser(req); if (!needAdmin(u, res)) return;
    const b = JSON.parse(await readBody(req));
    if (b.action === 'del') {
      db().prepare("UPDATE custom_attrs SET deleted_at=datetime('now','localtime') WHERE id=?").run(Number(b.id));
      return ok(res, { deleted: Number(b.id) });
    }
    if (!b.table_name || !b.field_key || !b.label) return fail(res, 400, '表名、字段标识、显示名必填');
    const opts = JSON.stringify(Array.isArray(b.options) ? b.options : []);
    if (b.id) {
      db().prepare('UPDATE custom_attrs SET table_name=?,field_key=?,label=?,ftype=?,options_json=?,required=?,sort=? WHERE id=?')
        .run(b.table_name, b.field_key, b.label, b.ftype || 'text', opts, b.required ? 1 : 0, Number(b.sort) || 0, Number(b.id));
      return ok(res, { id: Number(b.id) });
    }
    const info = db().prepare('INSERT INTO custom_attrs (table_name,field_key,label,ftype,options_json,required,sort) VALUES (?,?,?,?,?,?,?)')
      .run(b.table_name, b.field_key, b.label, b.ftype || 'text', opts, b.required ? 1 : 0, Number(b.sort) || 0);
    ok(res, { id: Number(info.lastInsertRowid) });
  });

  router.get('/api/config/values', (req, res, ctx) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    const table = String(ctx.url.searchParams.get('table') || '');
    const rowId = Number(ctx.url.searchParams.get('row_id') || 0);
    if (!table || !rowId) return fail(res, 400, '参数不全');
    const rows = db().prepare('SELECT field_key, val FROM custom_values WHERE table_name=? AND row_id=?').all(table, rowId);
    const map = {}; rows.forEach((r) => { map[r.field_key] = r.val; });
    ok(res, map);
  });

  router.post('/api/config/values', async (req, res) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    const b = JSON.parse(await readBody(req));
    const table = String(b.table || '');
    const rowId = Number(b.row_id || 0);
    if (!table || !rowId || !b.values) return fail(res, 400, '参数不全');
    // 表名白名单校验（[需求6]）；扩展值不写入业务主表，只写 custom_values
    const del = db().prepare('DELETE FROM custom_values WHERE table_name=? AND row_id=?');
    const ins = db().prepare("INSERT INTO custom_values (table_name,row_id,field_key,val,updated_at) VALUES (?,?,?,?,datetime('now','localtime'))");
    del.run(table, rowId);
    Object.keys(b.values).forEach((k) => ins.run(table, rowId, String(k).slice(0, 40), String(b.values[k] == null ? '' : b.values[k]).slice(0, 2000)));
    ok(res, { saved: Object.keys(b.values).length });
  });

  // ---------- 业务单号 ----------
  router.get('/api/config/seq', (req, res, ctx) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    const key = String(ctx.url.searchParams.get('key') || '');
    const row = db().prepare('SELECT * FROM app_seq WHERE seq_key=?').get(key);
    if (!row) return fail(res, 404, '单号规则不存在');
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    const datePart = row.reset_period === 'year' ? String(y) : row.reset_period === 'month' ? y + m : row.reset_period === 'never' ? '0' : y + m + d;
    let no = Number(row.next_no) || 1;
    if (row.last_date !== datePart) no = 1;                      // 跨期自动归零
    const body = String(no).padStart(Number(row.padding) || 3, '0');
    db().prepare('UPDATE app_seq SET last_date=?, next_no=? WHERE id=?').run(datePart, no + 1, row.id);
    ok(res, { key, no: row.prefix + '-' + datePart + '-' + body, date_part: datePart, seq: no });
  });

  router.get('/api/config/seqs', (req, res) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    ok(res, db().prepare('SELECT * FROM app_seq ORDER BY id').all());
  });

  router.post('/api/config/seqs', async (req, res) => {
    const u = authUser(req); if (!needAdmin(u, res)) return;
    const b = JSON.parse(await readBody(req));
    if (!b.seq_key || !b.prefix) return fail(res, 400, '单号标识与前缀必填');
    const ex = db().prepare('SELECT * FROM app_seq WHERE seq_key=?').get(b.seq_key);
    if (ex) {
      db().prepare('UPDATE app_seq SET prefix=?,padding=?,reset_period=? WHERE id=?')
        .run(b.prefix, Number(b.padding) || 3, b.reset_period || 'day', ex.id);
      return ok(res, { id: ex.id });
    }
    const info = db().prepare('INSERT INTO app_seq (seq_key,prefix,padding,reset_period) VALUES (?,?,?,?)')
      .run(b.seq_key, b.prefix, Number(b.padding) || 3, b.reset_period || 'day');
    ok(res, { id: Number(info.lastInsertRowid) });
  });

  // ---------- [需求2] 拍照水印配置 ----------
  const WM_DEFAULT = { on: 1, latlng: 1, alt: 0, date: 1, text: '部门综合管理系统 · 现场记录', opacity: 0.45, size: 16, pos: 'br' };

  router.get('/api/wm', (req, res) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    let cfg = { ...WM_DEFAULT };
    try {
      const row = db().prepare('SELECT v FROM configs WHERE k=?').get('dept_wm_cfg');
      if (row && row.v) cfg = { ...cfg, ...JSON.parse(row.v) };
    } catch (e) {}
    ok(res, cfg);
  });

  router.post('/api/wm', async (req, res) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    if (!needAdmin(u, res)) return ok(res, { saved: false });
    const b = JSON.parse(await readBody(req));
    const cfg = {
      on: b.on ? 1 : 0, latlng: b.latlng ? 1 : 0, alt: b.alt ? 1 : 0, date: b.date ? 1 : 0,
      text: String(b.text || WM_DEFAULT.text).slice(0, 40),
      opacity: Math.min(0.9, Math.max(0.15, Number(b.opacity) || 0.45)),
      size: Math.min(28, Math.max(10, Number(b.size) || 16)),
      pos: ['br', 'bl', 'tr', 'tl'].includes(b.pos) ? b.pos : 'br'
    };
    const ex = db().prepare('SELECT k FROM configs WHERE k=?').get('dept_wm_cfg');
    if (ex) db().prepare('UPDATE configs SET v=? WHERE k=?').run(JSON.stringify(cfg), 'dept_wm_cfg');
    else db().prepare('INSERT INTO configs (k,v) VALUES (?,?)').run('dept_wm_cfg', JSON.stringify(cfg));
    ok(res, cfg);
  });

  // ---------- 提醒规则 ----------
  router.get('/api/config/reminds', (req, res) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    ok(res, db().prepare('SELECT * FROM app_remind_def WHERE deleted_at IS NULL ORDER BY id').all());
  });

  router.post('/api/config/reminds', async (req, res) => {
    const u = authUser(req); if (!needAdmin(u, res)) return;
    const b = JSON.parse(await readBody(req));
    if (b.action === 'del') {
      db().prepare("UPDATE app_remind_def SET deleted_at=datetime('now','localtime') WHERE id=?").run(Number(b.id));
      return ok(res, { deleted: Number(b.id) });
    }
    if (!b.rule_key || !b.name || !b.target_table || !b.target_field) return fail(res, 400, '规则标识、名称、目标表、目标字段必填');
    const ex = db().prepare('SELECT * FROM app_remind_def WHERE rule_key=? AND deleted_at IS NULL').get(b.rule_key);
    if (ex) {
      db().prepare('UPDATE app_remind_def SET name=?,target_table=?,target_field=?,offset_value=?,offset_unit=?,channel=?,enabled=?,note=? WHERE id=?')
        .run(b.name, b.target_table, b.target_field, Number(b.offset_value) || 1, b.offset_unit || 'day', b.channel || 'both', b.enabled === 0 ? 0 : 1, b.note || '', ex.id);
      return ok(res, { id: ex.id });
    }
    const info = db().prepare('INSERT INTO app_remind_def (rule_key,name,target_table,target_field,offset_value,offset_unit,channel,enabled,note) VALUES (?,?,?,?,?,?,?,?,?)')
      .run(b.rule_key, b.name, b.target_table, b.target_field, Number(b.offset_value) || 1, b.offset_unit || 'day', b.channel || 'both', b.enabled === 0 ? 0 : 1, b.note || '');
    ok(res, { id: Number(info.lastInsertRowid) });
  });

  // ---------- 查询条件持久化 ----------
  router.get('/api/config/cond', (req, res, ctx) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    const page = String(ctx.url.searchParams.get('page') || '');
    const row = db().prepare('SELECT cond_json FROM app_sql_cond WHERE user_id=? AND page_key=? ORDER BY id DESC LIMIT 1').get(u.id, page);
    let cond = {};
    if (row) { try { cond = JSON.parse(row.cond_json || '{}'); } catch (e) { cond = {}; } }
    ok(res, { page, cond });
  });

  router.post('/api/config/cond', async (req, res) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    const b = JSON.parse(await readBody(req));
    const page = String(b.page || '');
    if (!page) return fail(res, 400, '页面标识必填');
    const json = JSON.stringify(b.cond && typeof b.cond === 'object' ? b.cond : {}).slice(0, 4000);
    const ex = db().prepare('SELECT id FROM app_sql_cond WHERE user_id=? AND page_key=?').get(u.id, page);
    if (ex) db().prepare("UPDATE app_sql_cond SET cond_json=?, updated_at=datetime('now','localtime') WHERE id=?").run(json, ex.id);
    else db().prepare('INSERT INTO app_sql_cond (user_id,page_key,cond_json) VALUES (?,?,?)').run(u.id, page, json);
    ok(res, { page, saved: true });
  });

  // ---------- 数据级权限 ----------
  router.get('/api/config/scopes', (req, res) => {
    const u = authUser(req); if (!needAdmin(u, res)) return;
    ok(res, db().prepare('SELECT * FROM data_scopes WHERE deleted_at IS NULL ORDER BY table_name, role').all());
  });

  router.post('/api/config/scopes', async (req, res) => {
    const u = authUser(req); if (!needAdmin(u, res)) return;
    const b = JSON.parse(await readBody(req));
    if (!b.role || !b.table_name) return fail(res, 400, '角色与表名必填');
    const scope = ['all', 'dept', 'self', 'none'].includes(b.scope) ? b.scope : 'dept';
    const ex = db().prepare('SELECT * FROM data_scopes WHERE role=? AND table_name=? AND deleted_at IS NULL').get(b.role, b.table_name);
    if (ex) { db().prepare('UPDATE data_scopes SET scope=?,note=? WHERE id=?').run(scope, b.note || '', ex.id); return ok(res, { id: ex.id }); }
    const info = db().prepare('INSERT INTO data_scopes (role,table_name,scope,note) VALUES (?,?,?,?)').run(b.role, b.table_name, scope, b.note || '');
    ok(res, { id: Number(info.lastInsertRowid) });
  });
};
