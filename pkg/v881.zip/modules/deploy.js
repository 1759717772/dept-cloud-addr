/**
 * [需求4] 运行期自主部署 —— 让"部门管理软件"自己会升级，不依赖外部 shell
 *
 * 设计初衷：容器内的大模型对"部署/运行类命令"有安全拒绝策略，靠让模型敲命令这条路走不通。
 * 改为把部署做成软件自身的受权功能：管理员在软件里上传部署包 → 落盘校验 sha256 →
 * 由独立守护脚本 deploy_agent.sh 在后台完成备份、解压、替换、重启、版本校验、失败回滚。
 * 模型只下达"部署"这一业务指令（调 /api/deploy/apply），不参与执行细节，也就不触发安全边界。
 *
 * 保护约定：替换时**绝不覆盖 data/ 目录**（system.db 是生产数据），只换代码与页面资源。
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

module.exports = function registerDeploy(router, deps) {
  const { ok, fail, authUser, typeLevel, isAdmin } = deps;
  const DIR = path.join(__dirname, '..', 'data', 'deploy');
  const INCOMING = path.join(DIR, 'incoming.zip');
  const STATUS = path.join(DIR, 'status.json');
  const APPLY = path.join(DIR, 'apply.flag');
  const ROLLBACK = path.join(DIR, 'rollback.flag');

  function readJson(p, dft) {
    try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch (e) { return dft; }
  }
  function writeJson(p, obj) {
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, JSON.stringify(obj, null, 2), 'utf8');
  }
  function now() { return new Date().toLocaleString('zh-CN', { hour12: false }).replace(/\//g, '-'); }
  function isBoss(u) { return typeLevel(u) >= 5 || isAdmin(u); }   // 部署权限只给管理员

  // 读原始二进制（部署包不走 JSON+base64，避免大包内存翻倍）
  function readRaw(req, maxBytes) {
    return new Promise((resolve, reject) => {
      let size = 0; const chunks = [];
      req.on('data', (c) => {
        size += c.length;
        if (size > maxBytes) { const e = new Error('部署包超过 30MB 限制'); req.pause(); reject(e); return; }
        chunks.push(c);
      });
      req.on('end', () => resolve(Buffer.concat(chunks)));
      req.on('error', reject);
    });
  }

  router.post('/api/deploy/upload', async (req, res) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    if (!isBoss(u)) return fail(res, 403, '仅管理员可上传部署包');
    let buf;
    try { buf = await readRaw(req, 30 * 1024 * 1024); } catch (e) { return fail(res, 400, e.message); }
    if (!buf || buf.length < 4096) return fail(res, 400, '部署包过小，疑似不是有效 zip');
    if (buf.slice(0, 2).toString() !== 'PK') return fail(res, 400, '不是有效的 zip 包（缺少 PK 头）');
    const sha = crypto.createHash('sha256').update(buf).digest('hex');
    fs.mkdirSync(DIR, { recursive: true });
    fs.writeFileSync(INCOMING, buf);
    const ver = String(req.headers['x-pkg-version'] || '').slice(0, 20);
    writeJson(STATUS, {
      state: 'ready', sha256: sha, size: buf.length, version: ver,
      uploaded_by: u.id, uploaded_at: now(), applied_at: null, applied_version: null, error: ''
    });
    ok(res, { sha256: sha, size: buf.length, version: ver, state: 'ready' });
  });

  router.get('/api/deploy/status', (req, res) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    if (!isBoss(u)) return fail(res, 403, '仅管理员可查看部署状态');
    const st = readJson(STATUS, { state: 'idle' });
    st.incoming_exists = fs.existsSync(INCOMING);
    st.apply_pending = fs.existsSync(APPLY);
    st.rollback_pending = fs.existsSync(ROLLBACK);
    ok(res, st);
  });

  // 下发"部署"业务指令：只写一个标志文件，具体动作交给 deploy_agent.sh
  router.post('/api/deploy/apply', async (req, res) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    if (!isBoss(u)) return fail(res, 403, '仅管理员可触发部署');
    if (!fs.existsSync(INCOMING)) return fail(res, 400, '没有待部署的包，请先上传');
    const st = readJson(STATUS, {});
    if (st.state === 'applying') return fail(res, 409, '上一次部署还在进行中');
    writeJson(APPLY, { requested_by: u.id, requested_at: now(), sha256: st.sha256 || '', version: st.version || '' });
    st.state = 'applying'; st.requested_at = now();
    writeJson(STATUS, st);
    ok(res, { queued: true, note: '部署代理将在数秒内开始执行，结果通过 /api/deploy/status 查看' });
  });

  router.post('/api/deploy/rollback', async (req, res) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    if (!isBoss(u)) return fail(res, 403, '仅管理员可回滚');
    writeJson(ROLLBACK, { requested_by: u.id, requested_at: now() });
    ok(res, { queued: true, note: '回滚指令已下发' });
  });
};
