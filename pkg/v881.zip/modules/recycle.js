/**
 * [需求9] 模块化拆分 · modules/recycle —— 数据回收站
 * 仅班组长以上（typeLevel>=4）可查看回收站；恢复/彻底删除仍留在 server.js 原有分支（含软删校验）。
 */
module.exports = function registerRecycle(router, deps) {
  const { ok, fail, authUser, requireLevel, recycleCounts } = deps;

  router.get('/api/recycle', (req, res) => {
    const u = authUser(req);
    if (!u) return fail(res, 401, '请先登录');
    if (!requireLevel(u, 4, res)) return;
    ok(res, { tables: recycleCounts() });
  });
};
