/**
 * [需求9] 模块化拆分 · modules/schema —— 表结构 JSON 化 + 列表/表单格式分级配置
 *
 * 一、表结构 JSON 化自动建表
 *   管理员提交 {table_key, table_name, fields:[{name,type,pk,notnull,default}]} 即自动建表；
 *   再次提交只做"增量补列"，绝不删列、不改列，避免误伤已有数据。
 *   表名必须符合 ext_ 前缀 + 小写字母数字下划线，类型只允许 SQLite 五类，字段名同样受正则约束，
 *   因此拼进 DDL 的标识符全部来自严格白名单，不存在注入面。
 *
 * 二、列表/表单格式分级配置（用户级 > 角色级 > 默认）
 *   app_view_def 存三层配置：scope_level=user|role|default
 *   读取时按 默认 → 角色（按用户 user_type）→ 本人 逐层覆盖合并，返回最终生效配置。
 *   写入：管理员可写任意层；普通用户只能写自己的 user 层。
 */
module.exports = function registerSchema(router, deps) {
  const { ok, fail, authUser, typeLevel, isAdmin, db, readBody, safeT, ensureColumn, refreshTables } = deps;

  const IDENT = /^[a-z][a-z0-9_]{0,40}$/;
  const EXT_TABLE = /^ext_[a-z0-9_]{2,40}$/;
  const TYPES = { TEXT: 1, INTEGER: 1, REAL: 1, NUMERIC: 1, BLOB: 1 };

  // ---------- 建表 ----------
  (function ensureMeta() {
    try {
      db().exec(`CREATE TABLE IF NOT EXISTS app_tables (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        table_key TEXT UNIQUE NOT NULL,
        table_name TEXT UNIQUE NOT NULL,
        label TEXT DEFAULT '',
        schema_json TEXT NOT NULL DEFAULT '[]',
        created_at TEXT DEFAULT (datetime('now','localtime')),
        updated_at TEXT DEFAULT (datetime('now','localtime')),
        deleted_at TEXT
      )`);
      db().exec(`CREATE TABLE IF NOT EXISTS app_view_def (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        view_key TEXT NOT NULL,
        scope_level TEXT NOT NULL DEFAULT 'default',
        scope_value TEXT DEFAULT '',
        config_json TEXT NOT NULL DEFAULT '{}',
        updated_at TEXT DEFAULT (datetime('now','localtime')),
        UNIQUE(view_key, scope_level, scope_value)
      )`);
    } catch (e) { console.error('[schema] 元表初始化失败', e.message); }
  })();

  function needAdmin(u, res) {
    if (!u) { fail(res, 401, '请先登录'); return false; }
    if (typeLevel(u) < 4 && !isAdmin(u)) { fail(res, 403, '仅运维工程师/管理员可修改配置'); return false; }
    return true;
  }

  // 把 JSON 字段定义编译成 DDL 片段；任何非法标识符/类型直接抛错，不做静默丢弃
  function compileField(f) {
    const name = String(f && f.name || '');
    if (!IDENT.test(name)) throw new Error('字段名非法: ' + name);
    const type = String((f && f.type) || 'TEXT').toUpperCase();
    if (!TYPES[type]) throw new Error('字段类型非法: ' + type + '（仅支持 TEXT/INTEGER/REAL/NUMERIC/BLOB）');
    let sql = name + ' ' + type;
    if (f.pk) sql += ' PRIMARY KEY';
    if (f.notnull) sql += ' NOT NULL';
    if (f.def !== undefined && f.def !== null && f.def !== '') {
      const dv = String(f.def);
      // 默认值只接受字面量：数字、或已转义的单引号字符串/函数关键字
      if (/^-?\d+(\.\d+)?$/.test(dv)) sql += ' DEFAULT ' + dv;
      else if (/^(CURRENT_TIMESTAMP|CURRENT_DATE|CURRENT_TIME|NULL)$/i.test(dv)) sql += ' DEFAULT ' + dv.toUpperCase();
      else sql += " DEFAULT '" + dv.replace(/'/g, "''") + "'";
    }
    return sql;
  }

  router.get('/api/config/table', async (req, res) => {
    const u = authUser(req);
    if (!u) { fail(res, 401, '请先登录'); return; }
    const rows = db().prepare('SELECT * FROM app_tables WHERE deleted_at IS NULL ORDER BY id').all()
      .map((r) => ({ id: r.id, table_key: r.table_key, table_name: r.table_name, label: r.label, fields: JSON.parse(r.schema_json || '[]'), updated_at: r.updated_at }));
    ok(res, rows);
  });

  router.post('/api/config/table', async (req, res) => {
    const u = authUser(req);
    if (!needAdmin(u, res)) return;
    const b = JSON.parse(await readBody(req));
    if (b.action === 'del') {
      const key = String(b.table_key || '');
      db().prepare("UPDATE app_tables SET deleted_at=datetime('now','localtime') WHERE table_key=?").run(key);
      ok(res, { deleted: key, note: '仅从配置台账移除，物理表与数据保留' });
      return;
    }
    const key = String(b.table_key || '').trim();
    const tname = String(b.table_name || '').trim();
    if (!key || !/^[a-z][a-z0-9_]{1,40}$/.test(key)) { fail(res, 400, 'table_key 非法（小写字母开头，可含数字下划线）'); return; }
    if (!EXT_TABLE.test(tname)) { fail(res, 400, 'table_name 必须以 ext_ 开头（如 ext_vehicle_log），避免与系统表冲突'); return; }
    const fields = Array.isArray(b.fields) ? b.fields : [];
    if (!fields.length) { fail(res, 400, '至少需要一个字段'); return; }
    if (b.action === 'preview') {
      try {
        const ddl = 'CREATE TABLE IF NOT EXISTS ' + tname + ' (\n  ' + fields.map(compileField).join(',\n  ') + '\n);';
        ok(res, { ddl });
      } catch (e) { fail(res, 400, e.message); }
      return;
    }
    // 真正建表
    let ddl;
    try { ddl = fields.map(compileField).join(',\n  '); }
    catch (e) { fail(res, 400, e.message); return; }

    const existed = db().prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").get(tname);
    try {
      if (!existed) {
        db().exec('CREATE TABLE ' + tname + ' (\n  ' + ddl + '\n)');
        refreshTables(); // 新表登记进白名单缓存
      } else {
        // 已存在：只补列，不删不改
        for (const f of fields) {
          const name = String(f.name);
          if (!IDENT.test(name)) continue;
          const type = String((f.type || 'TEXT')).toUpperCase();
          if (!TYPES[type]) continue;
          ensureColumn(tname, name, type);
        }
      }
    } catch (e) { fail(res, 500, '建表失败：' + e.message); return; }

    const exists = db().prepare('SELECT id FROM app_tables WHERE table_key=?').get(key);
    const sj = JSON.stringify(fields);
    if (exists) {
      db().prepare("UPDATE app_tables SET table_name=?, label=?, schema_json=?, updated_at=datetime('now','localtime') WHERE table_key=?")
        .run(tname, String(b.label || ''), sj, key);
    } else {
      db().prepare('INSERT INTO app_tables (table_key,table_name,label,schema_json) VALUES (?,?,?,?)')
        .run(key, tname, String(b.label || ''), sj);
    }
    // 回报现场真实列，便于前端核对
    let cols = [];
    try { cols = db().prepare('PRAGMA table_info(' + tname + ')').all().map((c) => ({ name: c.name, type: c.type })); } catch (e) { /* 忽略 */ }
    ok(res, { table_key: key, table_name: tname, created: !existed, columns: cols });
  });

  // ---------- 列表/表单格式分级配置 ----------
  function mergeView(base, over) {
    const out = Object.assign({}, base);
    for (const k of Object.keys(over || {})) {
      if (k === 'cols' && Array.isArray(over.cols)) out.cols = over.cols;
      else if (k === 'fields' && Array.isArray(over.fields)) out.fields = over.fields;
      else out[k] = over[k];
    }
    return out;
  }

  function readLayer(key, level, value) {
    const r = db().prepare('SELECT config_json FROM app_view_def WHERE view_key=? AND scope_level=? AND scope_value=?').get(key, level, value || '');
    if (!r) return null;
    try { return JSON.parse(r.config_json || '{}'); } catch (e) { return null; }
  }

  router.get('/api/config/view', async (req, res, ctx) => {
    const u = authUser(req);
    if (!u) { fail(res, 401, '请先登录'); return; }
    const key = String(new URL(req.url, 'http://x').searchParams.get('key') || '');
    if (!key) { fail(res, 400, '缺少 key'); return; }
    const layers = [];
    let cfg = readLayer(key, 'default', '');
    if (cfg) layers.push('default');
    const role = String(u.user_type || '');
    const roleCfg = role ? readLayer(key, 'role', role) : null;
    if (roleCfg) { cfg = mergeView(cfg || {}, roleCfg); layers.push('role:' + role); }
    const userCfg = readLayer(key, 'user', String(u.id));
    if (userCfg) { cfg = mergeView(cfg || {}, userCfg); layers.push('user'); }
    ok(res, { key, layers, config: cfg || {} });
  });

  router.post('/api/config/view', async (req, res) => {
    const u = authUser(req);
    if (!u) { fail(res, 401, '请先登录'); return; }
    const b = JSON.parse(await readBody(req));
    const key = String(b.key || '').trim();
    if (!key || !/^[a-z][a-z0-9_.]{1,40}$/.test(key)) { fail(res, 400, 'key 非法'); return; }
    let level = String(b.scope_level || 'user');
    let value = String(b.scope_value || '');
    if (level === 'user') { value = String(u.id); } // 用户层只能写自己
    else {
      if (!needAdmin(u, res)) return;
      if (level === 'role' && !value) { fail(res, 400, 'role 层需指定 scope_value（如 banzuzhang）'); return; }
      if (level === 'default') value = '';
    }
    if (!['user', 'role', 'default'].includes(level)) { fail(res, 400, 'scope_level 仅支持 user/role/default'); return; }
    let cfg;
    try { cfg = typeof b.config === 'object' ? b.config : JSON.parse(b.config || '{}'); }
    catch (e) { fail(res, 400, 'config 不是合法 JSON'); return; }
    db().prepare(`INSERT INTO app_view_def (view_key,scope_level,scope_value,config_json,updated_at)
      VALUES (?,?,?,?,datetime('now','localtime'))
      ON CONFLICT(view_key,scope_level,scope_value) DO UPDATE SET config_json=excluded.config_json, updated_at=excluded.updated_at`)
      .run(key, level, value, JSON.stringify(cfg));
    ok(res, { key, scope_level: level, scope_value: value, config: cfg });
  });

  return { IDENT, EXT_TABLE };
};
