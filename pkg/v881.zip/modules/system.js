/**
 * [需求9] 模块化拆分 · modules/system —— 系统级只读接口（版本 / 健康）
 * 说明：版本号是客户端升级与公告牌比对的唯一基准，集中在此，避免散落在 server.js 多处硬编码。
 */
const VERSION = '8.8.1';

module.exports = function registerSystem(router, deps) {
  const { ok, db } = deps;

  router.get('/api/version', (req, res) => {
    ok(res, { version: VERSION, name: '部门综合管理系统' });
  });

  router.get('/api/health', (req, res) => {
    let dbOk = true;
    try { db().prepare('SELECT 1').get(); } catch (e) { dbOk = false; }
    ok(res, { ok: dbOk, version: VERSION, db: dbOk ? 'up' : 'down', ts: new Date().toISOString() });
  });

  return { VERSION };
};
