/**
 * [需求9] 模块化拆分 · modules/util —— 无业务依赖的通用工具集
 * 从 server.js 抽离：口令哈希、模板填充、本地时间、授时、摘要、HTTP POST、
 * 目录大小、脱敏、限流、轻量缓存。全部为纯函数或模块私有状态，不依赖 db/路由/业务闭包，
 * 因此可安全拆分，且 server.js 只需一处解构引用即可保持同名调用不变。
 */
const crypto = require('crypto');
const dgram = require('dgram');
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

// ---------- 口令 ----------
function hashPassword(pwd, salt) {
  return crypto.scryptSync(pwd, salt, 32).toString('hex');
}

// ---------- 字符串 ----------
function fillTemplate(tpl, vars) {
  if (!tpl) return '';
  return String(tpl).replace(/\{([a-z_]+)\}/g, (_, k) => (vars[k] !== undefined && vars[k] !== null ? String(vars[k]) : ''));
}

function sha256hex(k) { return crypto.createHash('sha256').update(String(k)).digest('hex').slice(0, 32); }

// ---------- 时间 ----------
function nowLocalStr() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
}

const NTP_EPOCH = 2208988800;
function ntpTime(host, port, timeout) {
  return new Promise((resolve) => {
    let done = false;
    let timer = null;
    const finish = (v) => { if (!done) { done = true; clearTimeout(timer); try { sock.close(); } catch (e) { /* 已关闭 */ } resolve(v); } };
    const sock = dgram.createSocket('udp4');
    const buf = Buffer.alloc(48);
    buf[0] = 0x1b;
    timer = setTimeout(() => finish(null), timeout || 3000);
    sock.on('message', (msg) => {
      if (msg.length < 48) return finish(null);
      const secs = msg.readUInt32BE(40);
      const frac = msg.readUInt32BE(44);
      finish((secs - NTP_EPOCH) * 1000 + Math.round((frac / 4294967296) * 1000));
    });
    sock.on('error', () => finish(null));
    try { sock.send(buf, 0, 48, port || 123, host, (err) => { if (err) finish(null); }); } catch (e) { finish(null); }
  });
}

function httpTime(url) {
  return new Promise((resolve) => {
    const ctrl = new AbortController();
    const to = setTimeout(() => ctrl.abort(), 4500);
    fetch(url, { method: 'GET', signal: ctrl.signal, redirect: 'follow' })
      .then((r) => { clearTimeout(to); const d = r.headers.get('date'); resolve(d ? Date.parse(d) : null); })
      .catch(() => { clearTimeout(to); resolve(null); });
  });
}

async function syncServerTime() {
  const sources = [
    { name: '百度时间', t: await httpTime('https://www.baidu.com') },
    { name: '谷歌时间', t: await httpTime('https://www.google.com') },
    { name: '国家授时中心', t: await ntpTime('ntp.ntsc.ac.cn', 123, 3000) },
    { name: '阿里云NTP', t: await ntpTime('ntp.aliyun.com', 123, 3000) }
  ];
  const okSrc = sources.filter((s) => s.t && s.t > 0);
  const times = okSrc.map((s) => s.t).sort((a, b) => a - b);
  const mid = times[Math.floor(times.length / 2)] || null;
  return { server_time: mid, sources: sources.map((s) => ({ name: s.name, ok: s.t > 0 })), got: okSrc.length };
}

// ---------- HTTP ----------
function httpPostJson(url, obj, headers, timeoutMs) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const mod = u.protocol === 'https:' ? https : http;
    const data = Buffer.from(JSON.stringify(obj));
    const req = mod.request(u, { method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json', 'Content-Length': data.length }, headers || {}), timeout: timeoutMs || 20000 }, (res) => {
      let b = ''; res.on('data', (c) => { b += c; }); res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { resolve(null); } });
    });
    req.on('error', reject); req.on('timeout', () => { req.destroy(new Error('请求超时')); });
    req.end(data);
  });
}

// ---------- 文件 ----------
function dirSize(dir) {
  let s = 0;
  for (const f of fs.readdirSync(dir)) { const p = path.join(dir, f); const st = fs.statSync(p); s += st.isDirectory() ? dirSize(p) : st.size; }
  return s;
}

// ---------- 脱敏 ----------
function maskPhone2(v) { return v ? String(v).replace(/(\d{3})\d{4}(\d{4})/, '$1****$2') : ''; }
function maskIdCard2(v) { return v ? String(v).replace(/^(.{4}).*(.{4})$/, '$1********$2') : ''; }
function maskField(name, val) {
  const n = String(name || '').toLowerCase();
  if (n.indexOf('mobile') >= 0 || n.indexOf('phone') >= 0 || n.indexOf('电话') >= 0) return maskPhone2(val);
  if (n.indexOf('id_card') >= 0 || n.indexOf('身份证') >= 0) return maskIdCard2(val);
  return val;
}

// ---------- 限流（模块私有状态） ----------
const rateMap = new Map();
function rateLimit(key, limit, windowMs) {
  const now = Date.now();
  let arr = rateMap.get(key) || [];
  arr = arr.filter((t) => now - t < windowMs);
  if (arr.length >= limit) { rateMap.set(key, arr); return false; }
  arr.push(now);
  rateMap.set(key, arr);
  if (rateMap.size > 50000) { for (const k of rateMap.keys()) { rateMap.delete(k); break; } }
  return true;
}

// ---------- 轻量缓存（模块私有状态，server.js 需要直读时通过 cacheStore 引用） ----------
const cacheStore = {};
function cacheGet(key, ttlMs, fn) {
  const c = cacheStore[key];
  if (c && c.exp > Date.now()) return c.val;
  const v = fn();
  if (v) cacheStore[key] = { exp: Date.now() + ttlMs, val: v };
  return v;
}

module.exports = {
  hashPassword, fillTemplate, sha256hex, nowLocalStr,
  ntpTime, httpTime, syncServerTime, httpPostJson, dirSize,
  maskPhone2, maskIdCard2, maskField,
  rateLimit, rateMap, cacheGet, cacheStore
};
