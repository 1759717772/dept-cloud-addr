/* 部门综合管理系统 v3.1 前端逻辑 */
(function () {
  'use strict';
  const $ = (s, el) => (el || document).querySelector(s);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let TOKEN = localStorage.getItem('dept_token') || '';
  let ME = null;

  /* ===== v8.5 多隧道自动切换（毫秒级静默，后台执行不打扰）=====
   * 公告牌含 1 主 + 6 备用隧道地址；每 30 秒探测当前地址，
   * 断联立即静默切到池内首个可用隧道，主隧道恢复后自动切回。 */
  const BOARD_SRCS = [
    'https://1759717772.github.io/dept-cloud-addr/addr.txt',
    'https://raw.githubusercontent.com/1759717772/dept-cloud-addr/main/addr.txt',
    'https://cdn.jsdelivr.net/gh/1759717772/dept-cloud-addr@main/addr.txt'
  ];
  let API_BASE = '';          // '' = 同源（页面加载的隧道）；切换后 = 新隧道地址
  let ADDR_POOL = [];         // 公告牌全部隧道地址（主在前）
  let _addrBusy = false;
  function addrKey(u) { try { const x = new URL(u); return x.origin + x.pathname.replace(/\/+$/, ''); } catch (e) { return String(u).replace(/\/+$/, ''); } }
  function normAddr(u) { u = String(u || '').trim(); if (!/^https?:\/\//.test(u)) return ''; return u.endsWith('/') ? u : u + '/'; }
  async function fetchBoard() {
    for (const s of BOARD_SRCS) {
      try {
        const r = await fetch(s, { cache: 'no-store' });
        if (!r.ok) continue;
        const txt = await r.text();
        const pool = [];
        for (const line of txt.split(/\r?\n/)) {
          const m = line.match(/^(biz|biz2|backup\d*)=(.+)$/);
          if (m && /^https?:\/\//.test((m[2] || '').trim())) pool.push(normAddr(m[2].trim()));
        }
        if (pool.length) return pool;
      } catch (e) { /* 换下一源 */ }
    }
    return [];
  }
  function probeUrl(u, ms) {
    return new Promise((resolve) => {
      const ctl = new AbortController();
      const t = setTimeout(() => { ctl.abort(); resolve(false); }, ms || 5000);
      fetch(u + 'api/version', { cache: 'no-store', signal: ctl.signal, mode: 'cors' })
        .then((r) => resolve(!!r.ok))
        .catch(() => resolve(false))
        .finally(() => clearTimeout(t));
    });
  }
  async function addrProbeCycle() {
    if (_addrBusy) return;
    _addrBusy = true;
    try {
      const cur = API_BASE || (location.origin + '/');
      if (await probeUrl(cur, 5000)) {
        // 当前可用：若正用备用且主隧道（页面加载源）恢复，静默切回
        if (API_BASE && ADDR_POOL.some((a) => addrKey(a) === addrKey(location.origin))) {
          if (await probeUrl(location.origin + '/', 5000)) { API_BASE = ''; console.log('[addr] 已静默切回主隧道'); }
        }
        return;
      }
      // 当前不可用：池内找首个可用（主优先，页面源兜底）
      const cands = [];
      const curK = addrKey(cur);
      for (const a of ADDR_POOL) { const k = addrKey(a); if (k !== curK && !cands.some((x) => addrKey(x) === k)) cands.push(a); }
      if (!cands.some((a) => addrKey(a) === addrKey(location.origin))) cands.push(location.origin + '/');
      for (const a of cands) {
        if (await probeUrl(a, 4000)) { API_BASE = a; console.log('[addr] 已静默切换 → ' + a); return; }
      }
      // 全池不可用：保持现状，30 秒后重试
    } finally { _addrBusy = false; }
  }
  fetchBoard().then((pool) => { if (pool.length) ADDR_POOL = pool; addrProbeCycle(); });
  setInterval(() => { addrProbeCycle(); }, 30000);

  /* ===== v6.4 登录页"录音转写（免登录）"入口 =====
   * 仅 APP 内可用（DeptBridge.openRecorder 调原生录音转写页）；
   * 浏览器访问时给出提示，转写过程全程本地、无需服务器。 */
  function openLocalRecorder() {
    if (window.DeptBridge && typeof DeptBridge.openRecorder === 'function') {
      try { DeptBridge.openRecorder(); }
      catch (e) { alert('无法打开录音转写：' + e.message); }
    } else {
      alert('录音转写为手机 APP 原生功能（免登录、本地生成 Word），请安装并使用「部门综合管理系统」APP，在登录页点击下方按钮进入。');
    }
  }
  window.openLocalRecorder = openLocalRecorder;

  /* ===== v6.1 全机型屏幕比例自适应 =====
   * 登录进入（或任何页面加载）时自动读取本机屏幕分辨率与视口尺寸，
   * 按"长边/短边"比例分类（16:9.5 阔比例 / 16:9 / 18:9 / 19.5:9 / 20:9+ 超修长 / 平板方屏），
   * 将分类写入 <html data-ratio>，CSS 据此差异化排版，杜绝拉伸、溢出与字体过小。 */
  function applyScreenAdapt() {
    var root = document.documentElement;
    var vw = window.innerWidth || document.documentElement.clientWidth || 360;
    var vh = window.innerHeight || document.documentElement.clientHeight || 640;
    var sw = window.screen.width, sh = window.screen.height;
    var dpr = window.devicePixelRatio || 1;
    var longSide = Math.max(sw, sh), shortSide = Math.min(sw, sh);
    var shape = shortSide > 0 ? longSide / shortSide : 1.7;   // 屏幕形状比例（与横竖屏无关）
    var cls = 'ratio-normal';
    if (shape < 1.6) cls = 'ratio-square';                     // 平板/折叠屏：4:3、3:2、16:10
    else if (shape < 1.85) cls = 'ratio-wide';                 // 阔比例：16:9.5(1.684)、16:9(1.778)
    else if (shape < 2.05) cls = 'ratio-normal';               // 修长：18:9(2.0)
    else if (shape < 2.15) cls = 'ratio-long';                 // 19.5:9(2.167)
    else cls = 'ratio-tall';                                   // 超修长：20:9(2.222) 及以上
    var portrait = vh >= vw;
    var ratioStr = (longSide / shortSide).toFixed(2);
    root.setAttribute('data-ratio', cls);
    root.setAttribute('data-orient', portrait ? 'portrait' : 'landscape');
    root.setAttribute('data-shape', ratioStr);
    root.setAttribute('data-dpr', String(dpr));
    root.style.setProperty('--vw', vw + 'px');
    root.style.setProperty('--vh', vh + 'px');
    window.__DEPT_SCREEN__ = { w: sw, h: sh, vw: vw, vh: vh, shape: shape, cls: cls, dpr: dpr };
    var el = document.getElementById('lg-device');
    if (el) {
      var nm = { 'ratio-square': '方屏/平板', 'ratio-wide': '阔比例', 'ratio-normal': '标准比例', 'ratio-long': '修长比例', 'ratio-tall': '超修长比例' }[cls];
      el.textContent = '本机 ' + sw + '×' + sh + ' · 屏幕比例 ' + ratioStr + '（' + nm + '）· 已自动适配';
    }
  }
  applyScreenAdapt();
  var raT = null;
  window.addEventListener('resize', function () { clearTimeout(raT); raT = setTimeout(applyScreenAdapt, 200); });
  window.addEventListener('orientationchange', function () { setTimeout(applyScreenAdapt, 350); });


  /* v8.1 全局 401 兜底：登录过期/断线重连后自动用记住的账号重登，重登成功自动重试原请求 */
  /* v8.5.2 会话设备绑定：取本机设备 ID（壳注入 DeptBridge.getDeviceId 优先；网页端 fallback 本地 UUID），
     登录与每个请求携带，服务端将 token 绑定设备，防止 token 被提取后在其它设备重放 */
  function getDeviceId() {
    try {
      if (window.DeptBridge && typeof window.DeptBridge.getDeviceId === 'function') {
        var d = window.DeptBridge.getDeviceId();
        if (d && String(d).trim().length >= 16) return String(d).trim();
      }
    } catch (e) {}
    try {
      var id = localStorage.getItem('dept_device_id');
      if (!id) {
        id = 'web-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 12);
        localStorage.setItem('dept_device_id', id);
      }
      return id;
    } catch (e) { return ''; }
  }
  let _reLogining = false;
  function gotoLogin(msg) {
    TOKEN = ''; ME = null;
    localStorage.removeItem('dept_token');
    const lv = $('#login-view'); if (lv) { lv.style.display = 'flex'; $('#main-view').classList.remove('show'); }
    const err = $('#lg-err'); if (err) { err.textContent = msg || '请登录'; err.style.display = 'block'; }
    const u = $('#lg-user'); const su = localStorage.getItem('dept_saved_user');
    if (u && su) u.value = su;
    const p = $('#lg-pwd'); const sp = localStorage.getItem('dept_saved_pwd');
    if (p && sp) p.value = sp;
  }
  async function tryAutoRelogin() {
    const u = localStorage.getItem('dept_saved_user'), p = localStorage.getItem('dept_saved_pwd');
    if (!u || !p || _reLogining) return false;
    _reLogining = true;
    try {
      const r = await fetch((API_BASE || '') + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: u, password: p, deviceId: getDeviceId() }) });
      let j = null; try { j = await r.json(); } catch (e) {}
      if (r.ok && j && j.ok) {
        TOKEN = j.data.token; ME = j.data.user;
        localStorage.setItem('dept_token', TOKEN);
        if (typeof v5toast === 'function') v5toast('网络波动已恢复，自动重新登录');
        return true;
      }
      localStorage.removeItem('dept_saved_pwd');
      gotoLogin('登录已过期，请重新登录');
      return false;
    } catch (e) {
      gotoLogin('网络中断，请检查网络后重新登录');
      return false;
    } finally { _reLogining = false; }
  }
  async function api(path, method, body) {
    const opt = { method: method || 'GET', headers: {} };
    if (TOKEN) opt.headers['Authorization'] = 'Bearer ' + TOKEN;
    const dev = getDeviceId(); if (dev) opt.headers['x-device-id'] = dev;
    if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 12000);   // v8.3 全局 12s 超时：断网/慢速不再整页挂起
    opt.signal = ctl.signal;
    let r = null;
    try { r = await fetch((API_BASE || '') + path, opt); }
    catch (e) { clearTimeout(timer); throw new Error(e.name === 'AbortError' ? '连接超时，请检查网络' : '网络异常'); }
    clearTimeout(timer);
    let j = null;
    try { j = await r.json(); } catch (e) { throw new Error('服务器响应异常'); }
    if (!r.ok || !j.ok) {
      if (r.status === 401 && !_reLogining) {
        const reason = (r.headers && r.headers.get) ? (r.headers.get('x-auth-reason') || '') : '';
        if (reason === 'device') { localStorage.removeItem('dept_saved_pwd'); gotoLogin('登录设备已变更，请重新登录'); throw new Error('登录设备已变更，请重新登录'); }
        if (await tryAutoRelogin()) return api(path, method, body);
      }
      throw new Error((j && j.error) || '请求失败(' + r.status + ')');
    }
    return j.data;
  }

  /* ===== 登录 ===== */
  $('#login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const err = $('#lg-err');
    err.style.display = 'none';
    const btn = $('#lg-btn');
    btnLoading(btn, true);
    try {
      const d = await api('/api/login', 'POST', { username: $('#lg-user').value.trim(), password: $('#lg-pwd').value, deviceId: getDeviceId() });
      TOKEN = d.token; ME = d.user;
      localStorage.setItem('dept_token', TOKEN);
      const rem = $('#lg-remember') && $('#lg-remember').checked;
      if (rem) {
        localStorage.setItem('dept_saved_user', $('#lg-user').value.trim());
        localStorage.setItem('dept_saved_pwd', $('#lg-pwd').value);
      } else {
        localStorage.removeItem('dept_saved_user'); localStorage.removeItem('dept_saved_pwd');
      }
      enterApp();
    } catch (ex) { err.textContent = ex.message; err.style.display = 'block'; btnLoading(btn, false); }
  });

  async function logout() {
    try { await api('/api/logout', 'POST'); } catch (e) {}
    TOKEN = ''; ME = null; localStorage.removeItem('dept_token');
    location.reload();
  }

  async function enterApp() {
    if (!ME) ME = await api('/api/me');
    $('#login-view').style.display = 'none';
    $('#main-view').classList.add('show');
    $('#cur-user').textContent = (ME.real_name || ME.username) + '·' + (ME.user_type_name || '');
    // v7.8 管理员模拟用户横幅
    if (ME.impersonating) {
      const b = document.createElement('div');
      b.className = 'imp-banner';
      b.innerHTML = '模拟模式：当前以「' + esc(ME.real_name || ME.username) + '」身份查看（由管理员 ' + esc(ME.impersonating.by_name || '') + ' 发起调试）<button class="btn sm" onclick="app.stopImpersonate()">退出模拟</button>';
      $('#main-view').insertBefore(b, $('#main-view').firstChild);
    }
    switchPage('dash');
    refreshBadge();
    reportDevice();            // v5.0 手机信息上报（屏幕适配）
    startNetWatch();           // v5.0 隐藏网络检测（30秒随机ping）
    refreshDraftBadge();       // v5.0 草稿角标
    setTimeout(sigRemind, 60000); // v5.0 运行1分钟后手写签名核验提示
  }

  /* ===== v4.0 类型与功能矩阵 ===== */
  const LV = { xinren: 0, zaizhi: 1, banzuzhang: 2, bumenlingdao: 3, weihu: 4, admin: 5 };
  const MYLV = () => LV[ME.user_type] !== undefined ? LV[ME.user_type] : 1;
  // 功能码 → 名称（用于新人功能申请）
  const FEATURE_NAMES = {
    leave: '请假', check_record: '检查上报', patrol: '巡逻上报', file_download: '文件下载', file_upload: '文件上传',
    train_signin: '培训签到', form_record: '数据录入', duty: '值班排班', task: '待办任务'
  };
  // 快捷入口按类型过滤
  function navEntries() {
    const lv = MYLV();
    // [页面, 图标(symbol id), 名称, 主题色]
    const all = [
      ['ai', 'i-ai', 'AI工作台', '#7c5cff'], ['contact', 'i-people', '通讯录', '#1e88e5'],
      ['search', 'i-search', '全局检索', '#00acc1'], ['todo', 'i-inbox', '待办中心', '#fb8c00'],
      ['approval', 'i-check', '审批', '#43a047'],   // [需求1] 考勤打卡已整块下线
      ['task', 'i-list', '待办任务', '#8e24aa'], ['hr', 'i-badge', '人事管理', '#3949ab'],
      ['meeting', 'i-doc', '会议纪要', '#00897b'], ['audit', 'i-fact', '审计整改', '#546e7a'],
      ['form', 'i-table', '数据录入', '#5e35b1'],   // [需求1] 值班排班已整块下线
      ['check', 'i-clipboard', '检查管理', '#6d4c41'], ['asset', 'i-fire', '车辆台账', '#d32f2f'],
      ['patrol', 'i-walk', '巡逻上报', '#2e7d32'], ['train', 'i-book', '培训', '#1565c0'],
      ['msg', 'i-chat', '消息通知', '#00838f'], ['file', 'i-folder', '文件', '#f9a825'],
      ['summary', 'i-chart', '年度汇总', '#c0ca33'], ['reward', 'i-award', '奖励处罚', '#f06292'],
      ['archive', 'i-archive', '我的档案', '#78909c'], ['import', 'i-upload', '批量导入', '#26a69a'],
      ['bridge', 'i-gear', '数桥管理', '#7c5cff'], ['oplog', 'i-fact', '审计日志', '#546e7a'],
      ['admin', 'i-gear', '系统管理', '#607d8b']];
    return all.filter(([p]) => {
      if (p === 'ai' && lv < 1) return false;                        // v8.7 AI 工作台全员可用（含数桥/制度/写作专家）
      if (p === 'import' && lv < 4) return false;                  // 批量导入仅运维/管理员可见
      if (lv >= 4) return true;                                    // 运维/管理员全开
      if (lv >= 3) return p !== 'admin' && p !== 'bridge';         // 部门领导：除系统管理/数桥管理
      if (lv >= 2) return !['admin', 'bridge'].includes(p);        // 班组长全开（除系统管理/数桥管理）
      if (lv >= 1) return !['admin', 'bridge', 'hr', 'meeting', 'audit', 'duty', 'check', 'patrol', 'train', 'form'].includes(p);
      return ['contact', 'approval', 'msg', 'file'].includes(p); // [需求1] 新人：通讯录/审批(功能申请)/消息/文件（考勤已下线）
    });
  }

  /* v7.7 矢量图标助手：symbol id → SVG use 片段 */
  function ic(id, cls) {
    return '<svg class="' + (cls || 'ic') + '" aria-hidden="true"><use href="#' + id + '"/></svg>';
  }
  function ico(name) { return ic('i-' + name, 'ic'); }

  /* ===== v4.0 定位与拍照水印工具 ===== */
  const GEO = {
    can: () => typeof navigator !== 'undefined' && !!navigator.geolocation,
    get: () => new Promise((resolve, reject) => {
      if (!GEO.can()) { reject(new Error('当前浏览器不支持定位，请在手机系统设置中允许定位权限')); return; }
      navigator.geolocation.getCurrentPosition(resolve, (err) => {
        reject(new Error(err.code === 1 ? '定位权限被拒绝：请在手机设置中允许本应用使用定位（GPS+网络）' : '定位失败，请检查 GPS/网络信号后重试（' + err.message + '）'));
      }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 });
    }),
    fmt: (p) => {
      if (!p) return '';
      const c = p.coords;
      return '纬度 ' + c.latitude.toFixed(6) + '，经度 ' + c.longitude.toFixed(6) + '（精度 ±' + Math.round(c.accuracy) + ' 米）';
    },
    brief: (p) => (p ? p.coords.latitude.toFixed(6) + ',' + p.coords.longitude.toFixed(6) : '')
  };
  // 现场拍照：调用手机摄像头，合成 时间+经纬度 水印
  /* [需求2] 拍照双版本：水印版（半透明浮层，不遮挡主体）＋ 原始版（供事后核验原图）。
     水印内容/位置/透明度/字号可在「设置 → 拍照水印」调整，存 configs 表的 dept_wm_cfg。 */
  const WM_DEFAULT = { on: 1, latlng: 1, alt: 0, date: 1, text: '部门综合管理系统 · 现场记录', opacity: 0.45, size: 16, pos: 'br' };
  let _wmCache = null;
  function wmCfg() {
    if (_wmCache) return _wmCache;
    try { _wmCache = Object.assign({}, WM_DEFAULT, JSON.parse(localStorage.getItem('wm_cfg') || '{}')); } catch (e) { _wmCache = { ...WM_DEFAULT }; }
    return _wmCache;
  }
  window.wmSet = async () => {
    const c = wmCfg();
    openSheet(`
      <div class="sheet-title">拍照水印<span class="x" onclick="app.closeSheet()">✕</span></div>
      <div class="field"><label><input type="checkbox" id="wm-on" ${c.on ? 'checked' : ''}> 启用水印（关闭后只归档原始版）</label></div>
      <div class="field"><label>水印文字</label><input id="wm-text" value="${esc(c.text)}" maxlength="40"></div>
      <div class="field"><label>显示内容</label>
        <label style="margin-right:12px;"><input type="checkbox" id="wm-latlng" ${c.latlng ? 'checked' : ''}> 经纬度</label>
        <label style="margin-right:12px;"><input type="checkbox" id="wm-date" ${c.date ? 'checked' : ''}> 日期时间</label>
        <label><input type="checkbox" id="wm-alt" ${c.alt ? 'checked' : ''}> 海拔</label>
      </div>
      <div class="field"><label>位置</label><select id="wm-pos">
        <option value="br" ${c.pos === 'br' ? 'selected' : ''}>右下</option>
        <option value="bl" ${c.pos === 'bl' ? 'selected' : ''}>左下</option>
        <option value="tr" ${c.pos === 'tr' ? 'selected' : ''}>右上</option>
        <option value="tl" ${c.pos === 'tl' ? 'selected' : ''}>左上</option>
      </select></div>
      <div class="field"><label>透明度 ${Math.round(c.opacity * 100)}%</label><input id="wm-op" type="range" min="15" max="90" value="${Math.round(c.opacity * 100)}"></div>
      <div class="field"><label>字号 ${c.size}px</label><input id="wm-size" type="range" min="10" max="28" value="${c.size}"></div>
      <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.wmSave()">保存</button></div>`);
  };
  window.wmSave = async () => {
    const cfg = {
      on: $('#wm-on').checked ? 1 : 0, text: $('#wm-text').value.trim() || WM_DEFAULT.text,
      latlng: $('#wm-latlng').checked ? 1 : 0, date: $('#wm-date').checked ? 1 : 0, alt: $('#wm-alt').checked ? 1 : 0,
      pos: $('#wm-pos').value, opacity: (Number($('#wm-op').value) || 45) / 100, size: Number($('#wm-size').value) || 16
    };
    _wmCache = cfg;
    try { localStorage.setItem('wm_cfg', JSON.stringify(cfg)); } catch (e) {}
    try { await api('/api/wm', 'POST', cfg); } catch (e) {}
    closeSheet(); v5toast('水印设置已保存');
  };
  window.wmReset = () => { _wmCache = { ...WM_DEFAULT }; try { localStorage.setItem('wm_cfg', '{}'); } catch (e) {} closeSheet(); v5toast('已恢复默认'); };

  function wmDraw(ctx, W, H, pos, timeStr, cfg) {
    const lines = [];
    if (cfg.text) lines.push(cfg.text);
    if (cfg.date) lines.push('时间：' + timeStr);
    if (cfg.latlng) lines.push('位置：' + (pos ? GEO.fmt(pos) : '定位失败'));
    if (cfg.alt && pos && pos.coords && pos.coords.altitude) lines.push('海拔：' + Math.round(pos.coords.altitude) + '米');
    if (!lines.length) return;
    const fs = Math.max(10, Number(cfg.size) || 16);
    const pad = Math.round(fs * 0.5);
    const lh = Math.round(fs * 1.35);
    ctx.font = fs + 'px "Microsoft YaHei",sans-serif';
    let maxW = 0; lines.forEach((t) => { maxW = Math.max(maxW, ctx.measureText(t).width); });
    const bw = maxW + pad * 2, bh = lines.length * lh + pad * 2;
    const mg = Math.round(W * 0.02);
    const x = cfg.pos === 'bl' || cfg.pos === 'tl' ? mg : W - bw - mg;
    const y = cfg.pos === 'tr' || cfg.pos === 'tl' ? mg : H - bh - mg;
    // 半透明底衬，保证浅色背景上也能读清，同时不遮挡画面主体
    ctx.fillStyle = 'rgba(0,0,0,' + Math.max(0.15, Math.min(0.6, (Number(cfg.opacity) || 0.45) * 0.85)) + ')';
    ctx.beginPath();
    const r = Math.round(fs * 0.5);
    if (ctx.roundRect) { ctx.roundRect(x, y, bw, bh, r); ctx.fill(); } else { ctx.fillRect(x, y, bw, bh); }
    ctx.fillStyle = 'rgba(255,255,255,' + Math.max(0.7, Number(cfg.opacity) || 0.45) + ')';
    lines.forEach((t, i) => ctx.fillText(t, x + pad, y + pad + fs + i * lh));
  }

  function snapPhoto(cb) {
    const inp = document.createElement('input');
    inp.type = 'file';
    inp.accept = 'image/*';
    inp.capture = 'environment';
    inp.id = 'cam-input';
    inp.style.display = 'none';
    document.body.appendChild(inp);
    inp.onchange = () => {
      const f = inp.files && inp.files[0];
      if (!f) { inp.remove(); return; }
      const src = URL.createObjectURL(f);
      const locTask = GEO.get().catch(() => null);
      const img = new Image();
      img.onload = () => {
        locTask.then((pos) => {
          const maxW = 1600;
          const scale = img.width > maxW ? maxW / img.width : 1;
          const W = Math.round(img.width * scale), H = Math.round(img.height * scale);
          const timeStr = new Date().toLocaleString('zh-CN', { hour12: false });

          // 版本 A：原始图（仅缩放，不加水印）——用于事后核验原图
          const c1 = document.createElement('canvas');
          c1.width = W; c1.height = H;
          c1.getContext('2d').drawImage(img, 0, 0, W, H);

          // 版本 B：水印图（半透明浮层，默认右下角，不遮挡主体）
          const c2 = document.createElement('canvas');
          c2.width = W; c2.height = H;
          const ctx2 = c2.getContext('2d');
          ctx2.drawImage(img, 0, 0, W, H);
          const cfg = wmCfg();
          if (cfg.on) wmDraw(ctx2, W, H, pos, timeStr, cfg);

          c1.toBlob((orig) => {
            c2.toBlob((wm) => {
              if (!orig || !wm) { alert('照片处理失败'); inp.remove(); return; }
              if (URL.revokeObjectURL) URL.revokeObjectURL(src);
              inp.remove();
              cb(wm, orig, pos, timeStr);
            }, 'image/jpeg', 0.9);
          }, 'image/jpeg', 0.92);
        });
      };
      img.onerror = () => { alert('照片读取失败'); inp.remove(); };
      img.src = src;
    };
    inp.click();
  }
  /* [需求1] 文件列表缩略图：签名图/照片这类图片文件在列表里直接出小图（原来只显示文件名，签名图"打不开也看不到"）。
     图片接口需要鉴权头，<img> 带不上 header，所以用 fetch 取 blob 再挂 objectURL。 */
  const _thumbCache = {};
  window.fillThumbs = async () => {
    const nodes = Array.from(document.querySelectorAll('.f-thumb[data-id]'));
    for (const el of nodes) {
      if (el.dataset.done === '1') continue;
      const id = el.dataset.id;
      el.dataset.done = '1';
      if (_thumbCache[id]) { el.innerHTML = `<img src="${_thumbCache[id]}" alt="">`; continue; }
      try {
        const r = await fetch((API_BASE || '') + '/api/files/' + id + '/image', { headers: { Authorization: 'Bearer ' + TOKEN, 'x-device-id': getDeviceId() || '' } });
        if (!r.ok) { el.innerHTML = '<span style="font-size:18px;">🖼️</span>'; continue; }
        const blob = await r.blob();
        const url = URL.createObjectURL(blob);
        _thumbCache[id] = url;
        el.innerHTML = `<img src="${url}" alt="">`;
      } catch (e) { el.innerHTML = '<span style="font-size:18px;">🖼️</span>'; }
    }
  };
  const todayStr = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  let checkDraft = { start: null, end: null, photos: [] };
  let patrolDraft = { start: null, end: null };

  /* ===== 导航 ===== */
  const PAGES = ['dash', 'contact', 'approval', 'train', 'msg', 'file', 'more', 'attendance', 'task', 'hr', 'meeting', 'audit', 'duty', 'form', 'admin', 'check', 'patrol', 'draft', 'setup', 'backup', 'summary', 'reward', 'import', 'archive', 'todo', 'asset', 'search', 'ai', 'recycle', 'kb', 'v6dash', 'autorules', 'webhooks', 'bridge', 'oplog', 'importtpl'];
  const MAIN_TABS = ['dash', 'contact', 'approval', 'train', 'msg', 'file', 'draft', 'setup', 'more'];
  /* v8.1 页面栈：返回按钮 + 物理返回键（Android onBackPressed → app.goBack） */
  const VIEWS = { dash: renderDash, contact: renderContact, approval: renderApproval, train: renderTrain, msg: renderMsg, file: renderFile, more: renderMore, attendance: renderAttendance, task: renderTask, hr: renderHR, meeting: renderMeeting, audit: renderAudit, duty: renderDuty, form: renderForm, admin: renderAdmin, check: renderCheck, patrol: renderPatrol, draft: renderDraft, setup: renderSetup, backup: renderBackup, summary: renderSummary, reward: renderReward, import: renderImport, archive: renderArchive, todo: renderTodo, asset: renderAsset, search: renderSearch, ai: renderAI, recycle: renderRecycle, kb: renderKb, v6dash: renderV6Dash, autorules: renderAutoRules, webhooks: renderWebhooks, bridge: renderBridge, oplog: renderOplog, importtpl: renderImportTpl };
  const _pageStack = [];
  let _curPage = null;
  async function switchPageInner(p) {
    _curPage = p;
    PAGES.forEach((x) => { $('#page-' + x).classList.toggle('show', x === p); });
    const tb = MAIN_TABS.includes(p) ? p : 'more';
    document.querySelectorAll('#tabbar .tab').forEach((t) => t.classList.toggle('on', t.dataset.p === tb));
    // [需求1] 页面切换超过 5 秒没出内容就给进度条，避免"点了没反应"的错觉
    const bar = $('#page-bar');
    let barShown = false;
    const barTimer = setTimeout(() => { barShown = true; if (bar) bar.style.display = 'block'; }, 5000);
    try { await (VIEWS[p])(); } catch (e) { /* 单页失败不阻断切页 */ }
    clearTimeout(barTimer);
    if (barShown && bar) bar.style.display = 'none';
    if (window.fillThumbs) setTimeout(() => window.fillThumbs(), 100);
    SPEECH.bindAll();
    const btn = $('#btn-back');
    if (btn) btn.style.display = MAIN_TABS.includes(p) ? 'none' : 'block';
    window.scrollTo(0, 0);
    updScrollProgress();
  }
  function switchPage(p) {
    // v8.7 AI 工作台全员可用；数桥管理仅管理员（lv>=4）；审计日志仅领导及以上（lv>=3）
    if (p === 'bridge' && MYLV() < 4) { v5toast('仅管理员可管理数桥'); return; }
    if (p === 'oplog' && MYLV() < 3) { v5toast('仅领导及以上可查看审计日志'); return; }
    if (p !== _curPage && _curPage) _pageStack.push(_curPage);
    switchPageInner(p);
  }
  function goBack() {
    // v8.2 档案页多层级子栈优先：先退档案内部子视图，再退页面栈
    if (_curPage === 'archive' && window.__arcStack && window.__arcStack.length) {
      window.__arcView = window.__arcStack.pop();
      renderArchive();
      return 'ok';
    }
    const from = _pageStack.pop();
    if (from) { switchPageInner(from); return 'ok'; }
    if (_curPage !== 'dash') { switchPageInner('dash'); return 'ok'; }
    return 'exit';
  }
  window.appGoBack = goBack;
  window.app = window.app || {};
  window.app.goBack = goBack;
  document.querySelectorAll('#tabbar .tab').forEach((t) => t.addEventListener('click', () => switchPage(t.dataset.p)));

  /* v8.1 顶部阅读进度条 */
  function updScrollProgress() {
    const el = $('#scroll-progress'); if (!el) return;
    const doc = document.documentElement;
    const max = doc.scrollHeight - window.innerHeight;
    const cur = window.pageYOffset || doc.scrollTop || 0;
    el.style.width = (max > 0 ? Math.min(100, Math.round(cur / max * 100)) : 0) + '%';
  }
  window.addEventListener('scroll', updScrollProgress, { passive: true });
  window.addEventListener('online', () => { try { if (_curPage && VIEWS[_curPage]) { VIEWS[_curPage](); } } catch (e) {} });

  /* ===== 弹窗（v5.0：所有含表单的弹窗自动具备草稿箱） ===== */
  let CURRENT_DRAFT_KEY = null;
  function openSheet(html, draftKey) {
    $('#sheet').innerHTML = html; $('#mask').classList.add('show');
    const hasForm = !!$('#sheet').querySelector('input, textarea, select');
    if (hasForm) {
      if (!draftKey) {
        const t = $('#sheet').querySelector('.sheet-title');
        draftKey = t ? t.textContent.replace(/[✕×✖]/g, '').trim() : '未命名表单';
        if (!draftKey) draftKey = '未命名表单';
      }
      CURRENT_DRAFT_KEY = draftKey;
      const bar = document.createElement('div');
      bar.className = 'draft-toolbar';
      bar.innerHTML = '<button class="dt-btn" onclick="app.saveDraftNow()">💾 存草稿</button><button class="dt-btn" id="dt-restore" style="display:none" onclick="app.loadDraftNow()">📥 恢复草稿</button><span class="dt-tip" id="dt-tip"></span>';
      $('#sheet').insertBefore(bar, $('#sheet').firstChild);
      api('/api/drafts/' + encodeURIComponent(draftKey)).then((d) => {
        if (d) { const b = $('#dt-restore'); if (b) { b.style.display = ''; } const tip = $('#dt-tip'); if (tip) tip.textContent = '已有草稿'; }
      }).catch(() => {});
    } else { CURRENT_DRAFT_KEY = null; }
    SPEECH.bindAll();
  }
  function closeSheet() {
    const m = $('#mask');
    CURRENT_DRAFT_KEY = null;
    if (!m || !m.classList.contains('show')) return;
    const s = $('#sheet');
    if (s) { s.classList.add('closing'); setTimeout(() => { m.classList.remove('show'); s.classList.remove('closing'); }, 320); }
    else m.classList.remove('show');
  }
  $('#mask').addEventListener('click', (e) => { if (e.target.id === 'mask') closeSheet(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeSheet(); });
  /* ===== v7.9 MosMos 融合：全局语音输入 + 专业术语纠错 + 纪要智能整理 ===== */
  const SPEECH = {
    glossary: [],
    isApp: () => typeof window.DeptBridge !== 'undefined' && typeof window.DeptBridge.startSpeechInput === 'function',
    load: async () => {
      try {
        const ls = localStorage.getItem('dept_glossary');
        if (ls) { try { SPEECH.glossary = JSON.parse(ls); } catch (e) {} }
        const g = await api('/api/speech/glossary/all');
        if (g && g.length !== undefined) { SPEECH.glossary = g; localStorage.setItem('dept_glossary', JSON.stringify(g)); }
      } catch (e) {}
    },
    correct: (text) => {
      let out = String(text || '');
      const hits = [];
      for (const r of SPEECH.glossary || []) {
        const aliases = String(r.alias || '').split('|').map((a) => a.trim()).filter(Boolean);
        for (const a of aliases) {
          if (!a) continue;
          let re;
          try { re = new RegExp(a.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'); } catch (e2) { continue; }
          let cnt = 0;
          out = out.replace(re, () => { cnt++; return r.term; });
          if (cnt) hits.push({ alias: a, term: r.term, count: cnt });
        }
      }
      return { text: out, hits };
    },
    bindAll: () => {
      if (typeof document === 'undefined') return;
      document.querySelectorAll('#sheet textarea, #sheet input[type="text"], #sheet input:not([type])').forEach((el) => SPEECH.bindOne(el));
      document.querySelectorAll('#page-meeting textarea, #page-meeting input[type="text"]').forEach((el) => SPEECH.bindOne(el));
      document.querySelectorAll('#page-admin textarea, #page-admin input[type="text"]').forEach((el) => SPEECH.bindOne(el));
    },
    bindOne: (el) => {
      if (!el || el.dataset.spBound === '1') return;
      if (el.readOnly || el.disabled) return;
      const t = el.getAttribute('type');
      if (t === 'password' || t === 'hidden' || t === 'date' || t === 'datetime-local' || t === 'number' || t === 'file') return;
      el.dataset.spBound = '1';
      const wrap = el.closest('.field');
      if (!wrap) return;
      const btn = document.createElement('button');
      btn.type = 'button'; btn.className = 'sp-mic'; btn.innerHTML = '🎤';
      btn.title = '语音输入：说话转文字填入，专业术语自动纠错（MosMos 式语音直达）';
      btn.onclick = (ev) => { ev.preventDefault(); ev.stopPropagation(); SPEECH.start(el); };
      const label = wrap.querySelector('label');
      if (label) label.appendChild(btn); else wrap.insertBefore(btn, el);
    },
    start: (el) => {
      SPEECH.focusId = (el && el.id) || '';
      if (SPEECH.isApp()) {
        window.DeptBridge.startSpeechInput('app._speechCb');
        v5toast('正在听…请说话（说完了稍候片刻）');
      } else {
        const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SR) { v5toast('请使用「部门综合管理系统」APP 进行语音输入（浏览器预览不支持）'); return; }
        const rec = new SR();
        rec.lang = 'zh-CN'; rec.interimResults = false; rec.maxAlternatives = 1;
        rec.onresult = (e) => { const t = e.results[0][0].transcript; SPEECH.cb(el, t); };
        rec.onerror = () => { v5toast('未识别到语音：请检查浏览器麦克风权限后重试'); };
        try { rec.start(); } catch (e3) { v5toast('语音识别启动失败'); }
      }
    },
    cb: (el, raw) => {
      const r = SPEECH.correct(raw || '');
      const txt = r.text.trim();
      if (!txt) { v5toast('未识别到语音内容：请靠近麦克风清楚说话'); return; }
      if (el) {
        const old = el.value || '';
        const isTa = el.tagName === 'TEXTAREA';
        el.value = old ? old + (isTa ? '\n' : ' ') + txt : txt;
        try { el.focus(); } catch (e) {}
        if (isTa) { try { el.scrollTop = el.scrollHeight; } catch (e2) {} }
      }
      v5toast('语音已填入' + (r.hits.length ? '（纠正 ' + r.hits.length + ' 处专业术语：' + r.hits.slice(0, 3).map((h) => h.term).join('、') + '）' : ''));
    },
    /* 纪要智能整理：本地规则引擎（与后端 genMinutes 同口径）→ 分段要点 + 结构化行动项 */
    digest: (text) => {
      const sents = String(text || '').split(/[。！？!?\n]+/).map((s) => s.trim()).filter((s) => s.length > 1);
      const KEY = /(议题|会议主题|本次会议|会议内容|首先|接着|然后|部署|安排|要求|强调|决定|明确|讨论|汇报)/;
      const TODO = /(要|需|请|务必|尽快|负责|牵头|完成|落实|于.*前|月底前|下周|三天内|一周内|本周)/;
      const summary = []; const act = [];
      let cur = '';
      for (const s of sents) {
        if (s.length > 24 || KEY.test(s)) {
          if (cur) { if (TODO.test(cur)) act.push(cur); else if (cur.length > 8) summary.push(cur); }
          cur = s;
        } else { cur = cur ? cur + '；' + s : s; }
      }
      if (cur) { if (TODO.test(cur)) act.push(cur); else if (cur.length > 8) summary.push(cur); }
      const items = act.slice(0, 12).map((a) => {
        const om = a.match(/(?:由|交|请)?([\u4e00-\u9fa5]{2,4})(?:负责|牵头|落实|跟进|主办|承办)/);
        const dm = a.match(/(\d{1,2}月\d{1,2}日|本?月底|本周|下周|本周末?|下周[内末]?|\d+\s*天[内以]?)/);
        return { action: a, owner: om ? om[1] : '', due: dm ? dm[0] : '', checked: true };
      });
      return { summary: summary.slice(0, 12), items };
    },
    dueToDate: (s) => {
      const today = new Date(); const y = today.getFullYear();
      const m = String(s || '').trim();
      if (/^\d{1,2}月\d{1,2}日$/.test(m)) { const mm = m.split('月'); return y + '-' + String(Number(mm[0])).padStart(2, '0') + '-' + String(Number(mm[1].replace('日', ''))).padStart(2, '0'); }
      if (/月底/.test(m)) return y + '-12-31';
      if (/本周/.test(m)) { const d = new Date(today); d.setDate(d.getDate() + (6 - today.getDay() + 1)); return d.toISOString().slice(0, 10); }
      if (/下周/.test(m)) { const d = new Date(today); d.setDate(d.getDate() + (6 - today.getDay() + 1) + 7); return d.toISOString().slice(0, 10); }
      const dm2 = m.match(/(\d+)\s*天/); if (dm2) { const d = new Date(today); d.setDate(d.getDate() + Number(dm2[1])); return d.toISOString().slice(0, 10); }
      return today.toISOString().slice(0, 10);
    }
  };
  window.app = window.app || {};
  window.app._speechCb = (txt) => { const el = SPEECH.focusId ? document.getElementById(SPEECH.focusId) : null; SPEECH.cb(el, txt); };
  SPEECH.load();


  /* ===== 工作台 ===== */
  /* v7.8 门户卡片元信息（顺序即默认显示顺序） */
  const PORTAL_CARDS = [
    ['stat', '统计卡片'], ['alarm', '预警提醒卡'], ['charts', '数据看板图表'], ['apps', '功能应用广场'], ['duty', '今日值班'], ['notice', '最新通知']
  ];
  function portalCfgOf() {
    let p = { stat: 1, alarm: 1, charts: 1, apps: 1, duty: 1, notice: 1 };
    try { const pc = JSON.parse(localStorage.getItem('dept_portal_cfg') || 'null'); if (pc && pc.cards) p = Object.assign(p, pc.cards); } catch (e) {}
    return p;
  }
  /* v7.8 数据看板图表卡（纯 SVG/div，离线可用，不依赖外部图表库） */
  function chartCardHtml(charts) {
    const maxA = Math.max(1, ...charts.attendance.map((x) => x.c));
    const bars = charts.attendance.map((x) => {
      const h = Math.max(5, Math.round(x.c / maxA * 100));
      return `<div class="ch-col"><div class="ch-bar-i" style="height:${h}%"></div><div class="ch-lb">${x.day}</div><div class="ch-n">${x.c}</div></div>`;
    }).join('');
    const total = Object.values(charts.check).reduce((a, b) => a + b, 0);
    const segs = [['ok', '#16a34a', '合格'], ['basic', '#d97706', '基本合格'], ['bad', '#dc2626', '不合格'], ['issue', '#7c5cff', '发现问题']].filter(([k]) => (charts.check[k] || 0) > 0);
    let acc = 0;
    const ring = segs.map(([k, col, lb]) => {
      const frac = total ? (charts.check[k] || 0) / total : 0;
      const off = acc * 276.46; acc += frac;
      return `<circle cx="60" cy="60" r="44" fill="none" stroke="${col}" stroke-width="14" stroke-dasharray="${(frac * 276.46).toFixed(1)} ${(276.46 - frac * 276.46).toFixed(1)}" stroke-dashoffset="${(-off).toFixed(1)}" transform="rotate(-90 60 60)"></circle>`;
    }).join('');
    const leg = segs.map(([k, col, lb]) => `<div class="ch-leg"><i style="background:${col}"></i>${lb} ${charts.check[k] || 0}</div>`).join('');
    const maxD = Math.max(1, ...charts.depts.map((x) => x.c));
    const deptBars = charts.depts.map((x) => `<div class="ch-drow"><span class="ch-dn">${esc(x.name)}</span><div class="ch-dt"><i style="width:${Math.round(x.c / maxD * 100)}%"></i></div><span class="ch-dc">${x.c}</span></div>`).join('');
    const apprT = Object.values(charts.approval).reduce((a, b) => a + b, 0);
    return `
      <div class="card">
        <h3>${ico('chart')} 数据看板<span class="more muted">近 7 天</span></h3>
        <div class="ch-grid">
          <div class="ch-box"><div class="ch-title">每日打卡人数</div><div class="ch-bars">${bars}</div></div>
          <div class="ch-box"><div class="ch-title">检查结果分布（${total} 条）</div>
            <div class="ch-ring-wrap"><svg viewBox="0 0 120 120" class="ch-ring">${ring}</svg><div class="ch-ring-c">${total}</div></div>
            <div class="ch-legs">${leg || '<div class="muted">暂无检查记录</div>'}</div>
          </div>
        </div>
        <div class="ch-box" style="margin-top:10px"><div class="ch-title">部门人员分布</div>${deptBars || '<div class="muted">暂无部门数据</div>'}</div>
        <div class="ch-box" style="margin-top:10px"><div class="ch-title">审批状态分布（${apprT} 单）</div>
          <div class="ch-legs">${[['pending', '#fb8c00', '待审批'], ['approved', '#43a047', '已通过'], ['rejected', '#dc2626', '已驳回'], ['cancelled', '#9e9e9e', '已撤销']].map(([k, col, lb]) => `<div class="ch-leg"><i style="background:${col}"></i>${lb} ${charts.approval[k] || 0}</div>`).join('')}</div>
        </div>
      </div>`;
  }
  async function renderDash() {
    const el = $('#page-dash');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const [s, tc, msgs, duty] = await Promise.all([   // v8.3 并行聚合，减少串行等待
        api('/api/stats'), api('/api/todos').then((x) => ({ count: x.count })).catch(() => ({ total: 0, overdue: 0, soon: 0 })),
        api('/api/messages'), api('/api/duty')
      ]);
      const lv = MYLV();
      const isAppr = lv >= 2;
      let cw = { count: 0, list: [] };
      if (lv >= 2) { try { cw = (await api('/api/contracts/warnings')) || cw; } catch (e2) {} }
      const today = todayStr();
      const dutyToday = duty.filter((d) => d.day === today);
      // v7.8 门户卡片配置（本地缓存 + 服务器持久化）
      const pcfg = portalCfgOf();
      let charts = null;
      if (pcfg.charts) { try { charts = await api('/api/dashboard/charts'); } catch (e3) {} }
      const statCard = `
        <div class="card"><div class="stat-hero">
          <div class="sh blue"><div class="sh-n">${s.training_count}</div><div class="sh-l">培训 · ${s.training_hours}学时</div>${ic('book','sh-i')}</div>
          <div class="sh ${isAppr ? 'orange' : 'teal'}"><div class="sh-n">${isAppr ? s.approval_pending : s.my_approval_count}</div><div class="sh-l">${isAppr ? '待我审批' : '我的申请'}</div>${ic('check','sh-i')}</div>
          <div class="sh green"><div class="sh-n">${s.my_tasks_open}</div><div class="sh-l">我的待办</div>${ic('list','sh-i')}</div>
          <div class="sh purple"><div class="sh-n">${s.my_unread}</div><div class="sh-l">未读消息</div>${ic('inbox','sh-i')}</div>
          <div class="sh ${tc.overdue ? 'red' : 'orange'}"><div class="sh-n">${tc.overdue}</div><div class="sh-l">超期待办</div>${ic('alarm','sh-i')}</div>
          <div class="sh teal"><div class="sh-n">${s.checked_in ? (s.checked_out ? '✓✓' : '✓') : '—'}</div><div class="sh-l">今日打卡</div>${ic('clock','sh-i')}</div>
          ${lv >= 2 ? `<div class="sh orange"><div class="sh-n">${s.check_record_pending}</div><div class="sh-l">待审检查</div>${ic('fact','sh-i')}</div>
          <div class="sh red"><div class="sh-n">${s.patrol_pending}</div><div class="sh-l">待审巡逻</div>${ic('walk','sh-i')}</div>
          <div class="sh green"><div class="sh-n">${s.onboarding_soon}</div><div class="sh-l">入职临期</div>${ic('person','sh-i')}</div>` : ''}
          ${lv >= 3 ? `<div class="sh purple"><div class="sh-n">${s.contract_confirm_pending}</div><div class="sh-l">合同待调整</div>${ic('contract','sh-i')}</div>` : ''}
        </div></div>`;
      // v8 欢迎横幅：问候 + 角色徽章
      const uname = (ME && ME.real_name) || window.localStorage.getItem('dept_name') || '同事';
      const roleBadge = MYLV() === 0 ? '<span class="wh-badge">新人模式</span>' : MYLV() === 1 ? '<span class="wh-badge">普通用户</span>' : MYLV() === 2 ? '<span class="wh-badge">部门负责人</span>' : '<span class="wh-badge">系统管理员</span>';
      const greet = (() => { const h = new Date().getHours(); return h < 6 ? '夜深了' : h < 12 ? '早上好' : h < 14 ? '中午好' : h < 18 ? '下午好' : '晚上好'; })();
      const welcomeHero = `<div class="welcome-hero"><div class="wh-t">${greet}，${esc(uname)}</div><div class="wh-s">今天是 ${todayStr()} · ${new Date().toLocaleDateString('zh-CN',{weekday:'long'})}，祝你工作顺利。数据已与 OIT 保持自动同步。</div><div class="wh-badges">${roleBadge}<span class="wh-badge">${isAppr ? '审批权限' : '员工视图'}</span></div></div>`;
      const alarmCards = [
        tc.overdue ? `<div class="card warn"><h3>${ico('alarm')} 待办超期提醒</h3><div class="d">当前有 <b>${tc.overdue}</b> 项待办已超期（审批 / 检查审核 / 限期整改 / 会议任务）。请前往 <span class="more" onclick="switchPage('todo')">待办中心 ›</span> 处理，超期未处理将自动交办。</div></div>` : '',
        lv >= 3 && s.contract_confirm_pending > 0 ? `<div class="card warn"><h3>${ico('alarm')} 劳动合同确认提醒</h3><div class="d">${s.contract_confirm_pending} 名新人已确认签订劳动合同，尚未调整人员类型；超过 15 天将自动提升为「在职人员」。请前往 人事管理 → 人员类型 处理。</div></div>` : '',
        lv >= 2 && cw.count > 0 ? `<div class="card warn"><h3>${ico('contract')} 劳动合同 30 天签约预警（${cw.count}）</h3>${cw.list.map((w) => `<div class="list-item" style="cursor:pointer" onclick="switchPage('hr')"><div class="ic">${ico('contract')}</div><div class="body"><div class="t">${esc(w.real_name)} <span class="badge unread">已入职 ${w.days} 天</span></div><div class="d">${esc(w.work_no || '—')}${w.position ? ' · ' + esc(w.position) : ''} · 入职 ${esc(w.hire)} · 未签订劳动合同</div></div></div>`).join('')}<div class="d" style="margin-top:4px;">点击条目前往 人事管理 处理签约；满 30 天仍未签约将自动发送全员提醒（每人一次，不会重复）。</div></div>` : ''
      ].filter(Boolean).join('');
      const appsCard = `
        <div class="card">
          <h3>功能应用${MYLV() === 0 ? '<span class="more" style="color:#b45309">新人模式：仅可查看，操作功能需申请</span>' : ''}</h3>
          <div class="app-grid">
            ${navEntries().map(([p, id, n, c]) => `<div class="app-item" onclick="switchPage('${p}')"><div class="ai" style="background:linear-gradient(135deg,${c},${c}bb)">${ic(id, 'aic')}</div><div class="an">${n}</div></div>`).join('')}
          </div>
        </div>`;
      const dutyCard = dutyToday.length ? `<div class="card"><h3>今日值班</h3>${dutyToday.map((d) => `<div class="list-item"><div class="ic">${ico('clock')}</div><div class="body"><div class="t">${esc(d.user_name)}${d.shift ? ' · ' + esc(d.shift) : ''}</div><div class="d">${esc(d.duty || '值班')}${d.phone ? ' · ' + esc(d.phone) : ''}</div></div></div>`).join('')}</div>` : '';
      const noticeCard = `
        <div class="card">
          <h3>最新通知${msgs.length ? '<span class="more" onclick="switchPage(\'msg\')">全部 ›</span>' : ''}</h3>
          ${msgs.slice(0, 3).map((m) => `
            <div class="list-item">
              <div class="ic">${ico('megaphone')}</div>
              <div class="body">
                <div class="t">${esc(m.title)} ${!m.my_read ? '<span class="badge unread">未读</span>' : ''}</div>
                <div class="d">${esc(m.sender_name)} · ${m.created_at} · 已读 ${m.read_count}/${s.user_count}</div>
              </div>
            </div>`).join('') || '<div class="empty">暂无通知</div>'}
        </div>`;
      const body = [];
      if (pcfg.stat) body.push(welcomeHero + statCard);
      if (pcfg.alarm && alarmCards) body.push(alarmCards);
      if (pcfg.charts && charts) body.push(chartCardHtml(charts));
      if (pcfg.apps) body.push(appsCard);
      if (pcfg.duty && dutyCard) body.push(dutyCard);
      if (pcfg.notice) body.push(noticeCard);
      el.innerHTML = `
        <div class="dash-head"><div class="dash-title">工作台</div><button class="btn sm ghost" onclick="app.portalCfg()">${ico('gear')} 门户设置</button></div>
        ${body.join('') || '<div class="empty">工作台暂无可显示内容，请点击上方「门户设置」开启卡片</div>'}`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  /* ===== 通讯录（员工档案）===== */
  function contactSkeleton() {
    const row = () => `<div class="list-item"><div class="skel" style="width:40px;height:40px;border-radius:12px;flex-shrink:0;"></div>
      <div class="body"><div class="skel" style="height:14px;width:55%;"></div><div class="skel" style="height:11px;width:38%;margin-top:7px;"></div></div>
      <div class="skel" style="width:52px;height:26px;border-radius:8px;flex-shrink:0;"></div></div>`;
    return `<div class="card"><h3><div class="skel" style="height:14px;width:80px;"></div></h3>${row()}${row()}${row()}</div>
      <div class="card"><h3><div class="skel" style="height:14px;width:70px;"></div></h3>${row()}${row()}</div>`;
  }
  async function renderContact() {
    const el = $('#page-contact');
    el.innerHTML = contactSkeleton();
    try {
      const rows = await api('/api/profiles');
      const depts = await api('/api/depts');
      const groups = {};
      rows.forEach((r) => { const dn = depts.find((d) => d.id === r.dept_id)?.name || '未分配部门'; (groups[dn] = groups[dn] || []).push(r); });
      el.innerHTML = `
        <div class="actions"><button class="btn sm ghost" onclick="app.editMyProfile()">编辑我的档案</button></div>
        ${Object.entries(groups).map(([dn, list]) => `
          <div class="card"><h3>${esc(dn)}（${list.length}）</h3>
            ${list.map((r) => `<div class="list-item">
              <div class="ic">${r.photo ? '<img class="avatar" src="/api/users/' + r.id + '/photo" alt="">' : '👤'}</div>
              <div class="body">
                <div class="t">${esc(r.real_name)}${r.position ? ' · ' + esc(r.position) : ''}${r.role === 'admin' ? ' <span class="badge info">管理员</span>' : r.role === 'leader' ? ' <span class="badge ok">负责人</span>' : ''}</div>
                <div class="d">${r.phone ? esc(r.phone) + ' · ' : ''}入职 ${r.hire_date || '—'}</div>
              </div>
              <div class="act"><button class="btn sm ghost" onclick="app.contactDetail(${r.id})">详情</button>${(ME.role === 'admin' || r.id === ME.id) ? '<button class="btn sm ghost" onclick="app.editProfile(' + r.id + ')">编辑</button>' : ''}</div>
            </div>`).join('')}
          </div>`).join('') || '<div class="empty">暂无员工</div>'}`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  /* ===== [需求9] 配置中心：数据字典 / 业务单号 / 数据级权限 / 自定义字段 / 提醒规则 ===== */
  window.cfgDict = async () => {
    try {
      const rows = await api('/api/config/dict');
      const g = {}; rows.forEach((r) => { (g[r.dict_type] = g[r.dict_type] || []).push(r); });
      openSheet(`
        <div class="sheet-title">数据字典<span class="x" onclick="app.closeSheet()">✕</span></div>
        ${Object.keys(g).map((t) => `<div class="card" style="margin:6px 0;padding:8px 10px;">
          <div style="font-weight:600;font-size:13px;">${esc(t)}</div>
          ${g[t].map((x) => `<div style="display:flex;justify-content:space-between;align-items:center;padding:3px 0;font-size:13px;">
            <span>${esc(x.name)} <span class="muted" style="font-size:11px;">${esc(x.code)}</span></span>
            <button class="btn sm danger" onclick="cfgDictDel(${x.id})">删</button></div>`).join('')}
        </div>`).join('') || '<div class="empty">暂无字典项</div>'}
        <div class="field"><label>字典类型</label><input id="dc-type" placeholder="如 leave_type"></div>
        <div class="field"><label>名称</label><input id="dc-name" placeholder="如 探亲假"></div>
        <div class="field"><label>排序</label><input id="dc-sort" type="number" value="0"></div>
        <div class="sheet-actions"><button class="btn" onclick="cfgDictAdd()">新增字典项</button></div>`);
    } catch (e) { v5toast(e.message); }
  };
  window.cfgDictAdd = async () => {
    const dict_type = ($('#dc-type') || {}).value || '', name = ($('#dc-name') || {}).value || '';
    if (!dict_type.trim() || !name.trim()) return v5toast('类型与名称都要填');
    try { await api('/api/config/dict', 'POST', { dict_type: dict_type.trim(), name: name.trim(), code: name.trim(), sort: Number($('#dc-sort').value) || 0 }); v5toast('已新增'); cfgDict(); } catch (e) { v5toast(e.message); }
  };
  window.cfgDictDel = async (id) => {
    if (!confirm('确认删除该字典项？')) return;
    try { await api('/api/config/dict', 'POST', { action: 'del', id }); cfgDict(); } catch (e) { v5toast(e.message); }
  };
  window.cfgSeq = async () => {
    try {
      const rows = await api('/api/config/seqs');
      openSheet(`
        <div class="sheet-title">业务单号规则<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="muted" style="font-size:12px;margin-bottom:6px;">格式：前缀-日期段-序号，按天/月/年归零，如 QJ-20261108-001</div>
        ${rows.map((r) => `<div class="list-item"><div class="body">
          <div class="t">${esc(r.seq_key)} <span class="badge info">${esc(r.prefix)}-…-${String(r.next_no).padStart(r.padding, '0')}</span></div>
          <div class="d">归零：${{ day: '每天', month: '每月', year: '每年', never: '不归零' }[r.reset_period] || r.reset_period} · 位宽 ${r.padding}</div></div>
          <div class="act"><button class="btn sm ghost" onclick="cfgSeqTest('${esc(r.seq_key)}')">试取号</button></div></div>`).join('') || '<div class="empty">暂未配置单号规则</div>'}
        <div class="field"><label>标识</label><input id="sq-key" placeholder="如 leave_qj"></div>
        <div class="field"><label>前缀</label><input id="sq-prefix" placeholder="如 QJ"></div>
        <div class="field"><label>位宽</label><input id="sq-pad" type="number" value="3"></div>
        <div class="field"><label>归零周期</label><select id="sq-reset"><option value="day">每天</option><option value="month">每月</option><option value="year">每年</option><option value="never">不归零</option></select></div>
        <div class="sheet-actions"><button class="btn" onclick="cfgSeqAdd()">保存规则</button></div>`);
    } catch (e) { v5toast(e.message); }
  };
  window.cfgSeqAdd = async () => {
    const seq_key = $('#sq-key').value.trim(), prefix = $('#sq-prefix').value.trim();
    if (!seq_key || !prefix) return v5toast('标识与前缀都要填');
    try { await api('/api/config/seqs', 'POST', { seq_key, prefix, padding: Number($('#sq-pad').value) || 3, reset_period: $('#sq-reset').value }); v5toast('已保存'); cfgSeq(); } catch (e) { v5toast(e.message); }
  };
  window.cfgSeqTest = async (key) => {
    try { const d = await api('/api/config/seq?key=' + encodeURIComponent(key)); alert('生成单号：' + d.no); } catch (e) { v5toast(e.message); }
  };
  window.cfgScope = async () => {
    try {
      const rows = await api('/api/config/scopes');
      openSheet(`
        <div class="sheet-title">数据级权限<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="muted" style="font-size:12px;margin-bottom:6px;">某角色对某业务表的可见范围</div>
        ${rows.map((r) => `<div class="list-item"><div class="body">
          <div class="t">${esc(r.role)} → ${esc(r.table_name)} <span class="badge ${r.scope === 'all' ? 'warn' : 'info'}">${{ all: '全部', dept: '本部门', self: '本人', none: '不可见' }[r.scope] || r.scope}</span></div>
          <div class="d">${esc(r.note || '')}</div></div></div>`).join('') || '<div class="empty">暂无规则</div>'}
        <div class="field"><label>角色</label><select id="sc-role"><option value="xinren">新人</option><option value="zaizhi">在职人员</option><option value="banzuzhang">班组长</option><option value="bumenlingdao">部门领导</option></select></div>
        <div class="field"><label>表名</label><input id="sc-table" placeholder="如 leaves"></div>
        <div class="field"><label>可见范围</label><select id="sc-scope"><option value="self">本人</option><option value="dept">本部门</option><option value="all">全部</option><option value="none">不可见</option></select></div>
        <div class="field"><label>说明</label><input id="sc-note"></div>
        <div class="sheet-actions"><button class="btn" onclick="cfgScopeAdd()">保存规则</button></div>`);
    } catch (e) { v5toast(e.message); }
  };
  window.cfgScopeAdd = async () => {
    const table_name = $('#sc-table').value.trim();
    if (!table_name) return v5toast('请填写表名');
    try { await api('/api/config/scopes', 'POST', { role: $('#sc-role').value, table_name, scope: $('#sc-scope').value, note: $('#sc-note').value }); v5toast('已保存'); cfgScope(); } catch (e) { v5toast(e.message); }
  };
  window.cfgAttr = async () => {
    try {
      const rows = await api('/api/config/attrs?table=users');
      openSheet(`
        <div class="sheet-title">自定义字段（人员档案）<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="muted" style="font-size:12px;margin-bottom:6px;">给人员档案挂扩展字段，不动数据库结构</div>
        ${rows.map((r) => `<div class="list-item"><div class="body">
          <div class="t">${esc(r.label)} <span class="muted" style="font-size:11px;">${esc(r.field_key)}</span> <span class="badge gray">${esc(r.ftype)}</span></div>
          <div class="d">${r.required ? '必填 · ' : ''}排序 ${r.sort}</div></div>
          <div class="act"><button class="btn sm danger" onclick="cfgAttrDel(${r.id})">删</button></div></div>`).join('') || '<div class="empty">暂无自定义字段</div>'}
        <div class="field"><label>字段标识</label><input id="at-key" placeholder="如 fire_cert"></div>
        <div class="field"><label>显示名</label><input id="at-label" placeholder="如 消防设施操作员证号"></div>
        <div class="field"><label>类型</label><select id="at-ftype"><option value="text">文本</option><option value="number">数字</option><option value="date">日期</option><option value="select">下拉</option><option value="textarea">多行文本</option></select></div>
        <div class="sheet-actions"><button class="btn" onclick="cfgAttrAdd()">新增字段</button></div>`);
    } catch (e) { v5toast(e.message); }
  };
  window.cfgAttrAdd = async () => {
    const field_key = $('#at-key').value.trim(), label = $('#at-label').value.trim();
    if (!field_key || !label) return v5toast('标识与显示名都要填');
    try { await api('/api/config/attrs', 'POST', { table_name: 'users', field_key, label, ftype: $('#at-ftype').value }); v5toast('已新增'); cfgAttr(); } catch (e) { v5toast(e.message); }
  };
  window.cfgAttrDel = async (id) => {
    if (!confirm('确认删除该字段？')) return;
    try { await api('/api/config/attrs', 'POST', { action: 'del', id }); cfgAttr(); } catch (e) { v5toast(e.message); }
  };
  window.cfgRemind = async () => {
    try {
      const rows = await api('/api/config/reminds');
      openSheet(`
        <div class="sheet-title">提醒规则<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="muted" style="font-size:12px;margin-bottom:6px;">按业务表日期字段提前提醒，可走站内/钉钉</div>
        ${rows.map((r) => `<div class="list-item"><div class="body">
          <div class="t">${esc(r.name)} <span class="badge ${r.enabled ? 'ok' : 'gray'}">${r.enabled ? '启用' : '停用'}</span></div>
          <div class="d">${esc(r.target_table)}.${esc(r.target_field)} 提前 ${r.offset_value} ${{ day: '天', hour: '小时' }[r.offset_unit] || r.offset_unit} · ${{ both: '双通道', dd: '钉钉', inapp: '站内' }[r.channel] || r.channel}</div></div></div>`).join('') || '<div class="empty">暂无提醒规则</div>'}
        <div class="field"><label>规则标识</label><input id="rm-key" placeholder="如 leave_due"></div>
        <div class="field"><label>名称</label><input id="rm-name" placeholder="如 请假到期提醒"></div>
        <div class="field"><label>目标表</label><input id="rm-table" placeholder="如 leaves"></div>
        <div class="field"><label>目标字段</label><input id="rm-field" placeholder="如 end_date"></div>
        <div class="field"><label>提前</label><input id="rm-val" type="number" value="1"><select id="rm-unit"><option value="day">天</option><option value="hour">小时</option></select></div>
        <div class="sheet-actions"><button class="btn" onclick="cfgRemindAdd()">保存规则</button></div>`);
    } catch (e) { v5toast(e.message); }
  };
  window.cfgRemindAdd = async () => {
    const b = { rule_key: $('#rm-key').value.trim(), name: $('#rm-name').value.trim(), target_table: $('#rm-table').value.trim(), target_field: $('#rm-field').value.trim(), offset_value: Number($('#rm-val').value) || 1, offset_unit: $('#rm-unit').value, channel: 'both' };
    if (!b.rule_key || !b.name || !b.target_table || !b.target_field) return v5toast('四项都要填');
    try { await api('/api/config/reminds', 'POST', b); v5toast('已保存'); cfgRemind(); } catch (e) { v5toast(e.message); }
  };
  /* [需求9] 表结构 JSON 化：提交字段定义即自动建表，已存在的表只补列 */
  window.cfgTable = async () => {
    try {
      const rows = await api('/api/config/table');
      openSheet(`
        <div class="sheet-title">表结构（JSON 自动建表）<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="muted" style="font-size:12px;line-height:1.7;margin-bottom:8px;">表名须以 <b>ext_</b> 开头，避免与系统表冲突；类型仅支持 TEXT/INTEGER/REAL/NUMERIC/BLOB。已存在的表只补新列，不删列、不改列。</div>
        ${rows.map((r) => `<div class="list-item"><div class="body">
          <div class="t">${esc(r.label || r.table_key)} <span class="badge info">${esc(r.table_name)}</span></div>
          <div class="d">${r.fields.map((f) => esc(f.name) + ':' + esc(f.type) + (f.notnull ? '(必填)' : '')).join(' · ')}</div></div>
          <div class="act"><button class="btn sm danger" onclick="cfgTableDel('${esc(r.table_key)}')">移除</button></div></div>`).join('') || '<div class="empty">尚未通过 JSON 建表</div>'}
        <div class="field"><label>标识（table_key）</label><input id="tb-key" placeholder="如 vehicle_log"></div>
        <div class="field"><label>物理表名</label><input id="tb-name" placeholder="ext_vehicle_log"></div>
        <div class="field"><label>中文名</label><input id="tb-label" placeholder="车辆里程登记"></div>
        <div class="field"><label>字段定义（JSON 数组）</label><textarea id="tb-fields" rows="4" placeholder='[{"name":"plate","type":"TEXT","notnull":true},{"name":"km","type":"INTEGER","def":0}]'></textarea></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="cfgTablePreview()">预览建表语句</button><button class="btn" onclick="cfgTableSave()">建表 / 补列</button></div>`);
    } catch (e) { v5toast(e.message); }
  };
  window.cfgTableFields = () => {
    const raw = ($('#tb-fields') || {}).value || '';
    try { const f = JSON.parse(raw); if (!Array.isArray(f) || !f.length) throw new Error('需为数组且至少一个字段'); return f; }
    catch (e) { v5toast('字段定义 JSON 有误：' + e.message); return null; }
  };
  window.cfgTablePreview = async () => {
    const fields = cfgTableFields(); if (!fields) return;
    try {
      const d = await api('/api/config/table', 'POST', { table_key: ($('#tb-key').value || '').trim(), table_name: ($('#tb-name').value || '').trim(), fields, action: 'preview' });
      alert(d.ddl);
    } catch (e) { v5toast(e.message); }
  };
  window.cfgTableSave = async () => {
    const fields = cfgTableFields(); if (!fields) return;
    const key = ($('#tb-key').value || '').trim(), name = ($('#tb-name').value || '').trim();
    if (!key || !name) return v5toast('标识与表名都要填');
    try {
      const d = await api('/api/config/table', 'POST', { table_key: key, table_name: name, label: ($('#tb-label').value || '').trim(), fields });
      v5toast((d.created ? '已建表：' : '已补列：') + name + '（' + d.columns.length + ' 列）'); cfgTable();
    } catch (e) { v5toast(e.message); }
  };
  window.cfgTableDel = async (key) => {
    if (!confirm('仅从配置台账移除（物理表与数据保留），确认？')) return;
    try { await api('/api/config/table', 'POST', { action: 'del', table_key: key }); cfgTable(); } catch (e) { v5toast(e.message); }
  };
  /* [需求9] 列表/表单格式分级配置：用户级 > 角色级 > 默认 */
  window.cfgView = async () => {
    const key = prompt('要查看/配置哪个视图？例如 leaves.list', 'leaves.list');
    if (key === null) return;
    try {
      const d = await api('/api/config/view?key=' + encodeURIComponent(key.trim()));
      openSheet(`
        <div class="sheet-title">列表 / 表单格式（${esc(key.trim())}）<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="muted" style="font-size:12px;line-height:1.7;margin-bottom:8px;">生效来源：${d.layers.length ? d.layers.map((l) => '<span class="badge info">' + esc(l) + '</span>').join(' ') : '未配置（走系统内置）'}；优先级：用户级 &gt; 角色级 &gt; 默认。</div>
        <div class="field"><label>当前生效配置</label><textarea rows="6" readonly>${esc(JSON.stringify(d.config, null, 2))}</textarea></div>
        <div class="field"><label>写入层级</label><select id="vw-level"><option value="default">默认（全体）</option><option value="role">角色（按人员类型）</option><option value="user">仅本人</option></select></div>
        <div class="field"><label>角色值（仅角色层需要）</label><input id="vw-role" placeholder="如 banzuzhang"></div>
        <div class="field"><label>配置 JSON</label><textarea id="vw-cfg" rows="6" placeholder='{"cols":[{"key":"name","label":"姓名"}],"page_size":30}'></textarea></div>
        <div class="sheet-actions"><button class="btn" onclick="cfgViewSave('${esc(key.trim())}')">保存</button></div>`);
    } catch (e) { v5toast(e.message); }
  };
  window.cfgViewSave = async (key) => {
    let cfg;
    try { cfg = JSON.parse(($('#vw-cfg') || {}).value || '{}'); } catch (e) { return v5toast('配置 JSON 有误'); }
    const scope_level = $('#vw-level').value;
    try {
      await api('/api/config/view', 'POST', { key, scope_level, scope_value: scope_level === 'role' ? ($('#vw-role').value || '').trim() : '', config: cfg });
      v5toast('已保存'); cfgViewByKey(key);
    } catch (e) { v5toast(e.message); }
  };
  window.cfgViewByKey = async (key) => {
    try {
      const d = await api('/api/config/view?key=' + encodeURIComponent(key));
      alert('生效来源：' + (d.layers.join(' > ') || '内置') + '\n\n' + JSON.stringify(d.config, null, 2));
    } catch (e) { v5toast(e.message); }
  };
  /* [需求10] 会议纪要开关 / 导出 / 视频地址（会后录制导出） */
  window.mtRecall = async (id, on) => {
    try { await api('/api/meetings/' + id + '/recall', 'POST', { on }); v5toast(on ? '已开启会后纪要' : '已关闭会后纪要'); renderMeeting(); } catch (e) { v5toast(e.message); }
  };
  window.mtExport = async (id) => {
    try {
      const r = await fetch((API_BASE || '') + '/api/meetings/' + id + '/export', { headers: { Authorization: 'Bearer ' + TOKEN, 'x-device-id': getDeviceId() || '' } });
      if (!r.ok) throw new Error('导出失败（HTTP ' + r.status + '）');
      const blob = await r.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = 'meeting-' + id + '.txt';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 3000);
      v5toast('纪要已导出');
    } catch (e) { v5toast(e.message); }
  };
  window.mtVideo = async (id) => {
    openSheet(`
      <div class="sheet-title">会议视频<span class="x" onclick="app.closeSheet()">✕</span></div>
      <div class="muted" style="font-size:12px;margin-bottom:8px;">会中可开启录制（生成在本机的 webm 文件，事后上传到文件库并把链接填到这里）；只有发起人或管理员能填写。</div>
      <div class="field"><label>视频地址（http/https）</label><input id="mtv-url" placeholder="https://…/meeting-video.webm"></div>
      <div class="sheet-actions">
        <button class="btn ghost" onclick="app.mtRecord()">● 本机录制</button>
        <button class="btn" onclick="app.mtVideoSave(${id})">保存地址</button>
      </div>`);
  };
  window.mtVideoSave = async (id) => {
    const url = $('#mtv-url').value.trim();
    if (!/^https?:\/\//.test(url)) return v5toast('请填写 http/https 开头的地址');
    try { await api('/api/meetings/' + id + '/video', 'POST', { url }); v5toast('已保存，会议状态置为已结束'); closeSheet(); renderMeeting(); } catch (e) { v5toast(e.message); }
  };
  window.mtRecord = async () => {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
      const rec = new MediaRecorder(stream);
      const chunks = [];
      rec.ondataavailable = (e) => { if (e.data.size) chunks.push(e.data); };
      rec.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/webm' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob); a.download = 'meeting-' + Date.now() + '.webm';
        document.body.appendChild(a); a.click(); a.remove();
        stream.getTracks().forEach((t) => t.stop());
        v5toast('录制结束，文件已保存到本机');
      };
      rec.start();
      v5toast('开始录制，停止请点浏览器「停止共享」');
      stream.getVideoTracks()[0].onended = () => rec.state !== 'inactive' && rec.stop();
    } catch (e) { v5toast('录制失败：' + e.message); }
  };
  window.app = {
    editMyProfile: () => {
      api('/api/profiles/me').then((pf) => {
        openSheet(`
          <div class="sheet-title">编辑我的档案<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="field"><label>岗位</label><input id="pf-position" value="${esc(pf.position || '')}" placeholder="如：安保质控员"></div>
          <div class="field"><label>联系电话</label><input id="pf-phone" value="${esc(pf.phone || '')}"></div>
          <div class="field"><label>入职日期</label><input id="pf-hire" type="date" value="${esc(pf.hire_date || '')}"></div>
          <div class="field"><label>证件号码</label><input id="pf-idn" value="${esc(pf.id_number || '')}"></div>
          <div class="field"><label>备注</label><textarea id="pf-remark" rows="3">${esc(pf.remark || '')}</textarea></div>
          <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveProfile(${ME.id})">保存</button></div>`);
      });
    },
    editProfile: (id) => {
      api('/api/profiles').then((rows) => {
        const r = rows.find((x) => x.id === id);
        openSheet(`
          <div class="sheet-title">编辑档案：${esc(r.real_name)}<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="field"><label>岗位</label><input id="pf-position" value="${esc(r.position || '')}"></div>
          <div class="field"><label>联系电话</label><input id="pf-phone" value="${esc(r.phone || '')}"></div>
          <div class="field"><label>入职日期</label><input id="pf-hire" type="date" value="${esc(r.hire_date || '')}"></div>
          <div class="field"><label>证件号码</label><input id="pf-idn" value="${esc(r.id_number || '')}"></div>
          <div class="field"><label>备注</label><textarea id="pf-remark" rows="3">${esc(r.remark || '')}</textarea></div>
          <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveProfile(${id})">保存</button></div>`);
      });
    },
    saveProfile: async (id) => {
      try {
        await api('/api/profiles/' + id, 'PUT', {
          position: $('#pf-position').value.trim(), phone: $('#pf-phone').value.trim(),
          hire_date: $('#pf-hire').value, id_number: $('#pf-idn').value.trim(), remark: $('#pf-remark').value.trim()
        });
        closeSheet(); renderContact();
      } catch (e) { alert(e.message); }
    },
    contactDetail: (id) => {
      api('/api/profiles').then((rows) => {
        const r = rows.find((x) => x.id === id);
        openSheet(`
          <div class="sheet-title">${esc(r.real_name)}<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="detail-row"><div class="k">用户名</div><div class="v">${esc(r.username)}</div></div>
          <div class="detail-row"><div class="k">部门</div><div class="v">${esc(r.dept_name || '未分配')}</div></div>
          <div class="detail-row"><div class="k">岗位</div><div class="v">${esc(r.position || '—')}</div></div>
          <div class="detail-row"><div class="k">电话</div><div class="v">${esc(r.phone || '—')}</div></div>
          <div class="detail-row"><div class="k">入职日期</div><div class="v">${esc(r.hire_date || '—')}</div></div>
          <div class="detail-row"><div class="k">证件号</div><div class="v">${esc(r.id_number || '—')}</div></div>
          <div class="detail-row"><div class="k">备注</div><div class="v">${esc(r.remark || '—')}</div></div>
          <div style="display:flex;gap:8px;margin-top:14px;">
            <button class="btn" style="flex:1;" onclick="app.openArchiveFor('${esc(r.work_no || r.id)}')">📋 查看完整档案</button>
            <button class="btn ghost" style="flex:1;" onclick="app.closeSheet()">关闭</button>
          </div>`);
      });
    },
    /* v7.8 工作台门户卡片配置（借鉴云网OA企业门户） */
    portalCfg: async () => {
      let p = { stat: 1, alarm: 1, charts: 1, apps: 1, duty: 1, notice: 1 };
      try { const pc = await api('/api/portal/cfg'); if (pc && pc.cards) p = Object.assign(p, pc.cards); } catch (e) {}
      const list = PORTAL_CARDS;
      openSheet(`
        <div class="sheet-title">门户设置（自定义工作台）<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="muted" style="margin-bottom:8px;">勾选要显示的卡片，并用 ↑ ↓ 调整顺序后保存；未勾选的卡片在工作台隐藏。</div>
        <div id="pc-list">${list.map(([k, n], i) => `
          <div class="pc-row" data-k="${k}">
            <label class="pc-check"><input type="checkbox" data-k="${k}" ${p[k] ? 'checked' : ''}>${n}</label>
            <div class="pc-ops"><button class="btn sm ghost" onclick="app.pcMove(${i}, -1)">↑</button><button class="btn sm ghost" onclick="app.pcMove(${i}, 1)">↓</button></div>
          </div>`).join('')}</div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.savePortalCfg()">保存</button></div>`);
    },
    pcMove: (i, dir) => {
      const rows = Array.from(document.querySelectorAll('#pc-list .pc-row'));
      const j = i + dir;
      if (j < 0 || j >= rows.length) return;
      const a = rows[i], b = rows[j];
      a.parentNode.insertBefore(b, a);
      // 重写 onclick 索引
      Array.from(document.querySelectorAll('#pc-list .pc-row')).forEach((r, k) => {
        const ops = r.querySelectorAll('.pc-ops .btn');
        ops[0].setAttribute('onclick', 'app.pcMove(' + k + ',-1)');
        ops[1].setAttribute('onclick', 'app.pcMove(' + k + ',1)');
      });
    },
    savePortalCfg: async () => {
      const order = Array.from(document.querySelectorAll('#pc-list .pc-row')).map((r) => r.dataset.k);
      const cards = {};
      order.forEach((k) => { cards[k] = (document.querySelector('#pc-list input[data-k="' + k + '"]') || {}).checked ? 1 : 0; });
      try {
        await api('/api/portal/cfg', 'PUT', { cfg: { cards } });
        localStorage.setItem('dept_portal_cfg', JSON.stringify({ cards }));
        closeSheet(); renderDash(); v5toast('门户配置已保存');
      } catch (e) { alert(e.message); }
    },
    /* v7.8 管理员模拟用户（流程试跑） */
    startImpersonate: async () => {
      const sel = $('#imp-user');
      if (!sel || !sel.value) { v5toast('请先选择要模拟的用户'); return; }
      try {
        const d = await api('/api/admin/impersonate', 'POST', { user_id: Number(sel.value) });
        sessionStorage.setItem('dept_imp_back', TOKEN);
        TOKEN = d.token; ME = d.user;
        localStorage.setItem('dept_token', TOKEN);
        location.reload();
      } catch (e) { alert(e.message); }
    },
    stopImpersonate: async () => {
      try { await api('/api/admin/impersonate/stop', 'POST'); } catch (e) {}
      const back = sessionStorage.getItem('dept_imp_back') || '';
      sessionStorage.removeItem('dept_imp_back');
      TOKEN = back; localStorage.setItem('dept_token', back);
      location.reload();
    },
    /* v7.8 审批超时天数配置 */
    saveTimeoutCfg: async () => {
      const inp = $('#cfg-timeout-days');
      const days = inp ? Number(inp.value) : 0;
      if (!days || days < 1 || days > 90) { v5toast('请输入 1~90 之间的天数'); return; }
      try { await api('/api/admin/config', 'PUT', { key: 'approval_timeout_days', val: { days } }); v5toast('已保存：审批超过 ' + days + ' 天未处理将自动交办（每分钟扫描一次）'); } catch (e) { alert(e.message); }
    },
    closeSheet: () => closeSheet()
  };

  /* ===== 审批中心 ===== */
  const APPTYPES = {
    '请假申请': ['起止时间', '请假事由'],
    '加班申请': ['加班日期', '加班时段', '加班事由'],
    '公出申请': ['目的地', '起止时间', '公出事由'],
    '培训申请': ['培训名称', '培训分类', '培训日期', '培训地点', '预估费用'],
    '物资申请': ['物资名称', '数量', '用途', '需求日期'],
    '转正申请': ['员工姓名', '转正日期', '试用期表现'],
    '调岗申请': ['员工姓名', '原部门/岗位', '新部门/岗位', '生效日期', '调岗原因']
  };
  const APPLY_TYPES_DEFINED = 1; // 占位：新人类型在 newApproval 内动态判断
  function chainBadge(x) {
    if (x.status === 'pending') {
      const cur = x.pending_level_name ? '待「' + x.pending_level_name + '」审批' : '';
      const done = (x.chain || []).slice(0, x.level).map((n) => n + '✓').join(' → ');
      return (done ? done + ' → ' : '') + cur;
    }
    return '';
  }
  async function renderApproval() {
    const el = $('#page-approval');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const list = await api('/api/approvals');
      const lv = MYLV();
      const isAppr = lv >= 2;
      const pending = isAppr ? list.filter((x) => x.status === 'pending') : [];
      const badge = (st) => ({ pending: '<span class="badge warn">待审批</span>', approved: '<span class="badge ok">已批准</span>', rejected: '<span class="badge bad">已驳回</span>', cancelled: '<span class="badge gray">已撤销</span>', completed: '<span class="badge ok">已完成</span>' }[st] || st);
      el.innerHTML = `
        <div class="actions"><button class="btn sm" onclick="app.newApproval()">＋ 发起申请${lv === 0 ? '（功能申请）' : ''}</button></div>
        ${pending.length ? `<div class="card"><h3>待我审批（${pending.length}）</h3>
          ${pending.map((x) => `<div class="list-item">
            <div class="ic">⏳</div>
            <div class="body"><div class="t">${esc(x.title)} <span class="badge info">${esc(x.type)}</span></div><div class="d">${esc(x.user_name)} · ${x.created_at} · 审批链：${chainBadge(x) || esc((x.chain || []).join(' → '))}</div></div>
            <div class="act"><button class="btn sm ok" onclick="app.approveAp(${x.id},'approve')">批准</button> <button class="btn sm danger" onclick="app.approveAp(${x.id},'reject')">驳回</button> <button class="btn sm ghost" onclick="app.apDetail(${x.id})">详情</button></div>
          </div>`).join('')}</div>` : ''}
        <div class="card"><h3>我的申请（${list.filter((x) => x.user_id === ME.id).length}）</h3>
          ${list.filter((x) => x.user_id === ME.id).map((x) => `<div class="list-item">
            <div class="ic">📨</div>
            <div class="body"><div class="t">${esc(x.title)} ${badge(x.status)}</div><div class="d">${esc(x.type)} · ${x.created_at}${chainBadge(x) ? ' · ' + chainBadge(x) : ''}</div></div>
            <div class="act">
              ${x.status === 'pending' ? '<button class="btn sm danger" onclick="app.cancelAp(' + x.id + ')">撤销</button>' : ''}
              <button class="btn sm ghost" onclick="app.apDetail(${x.id})">详情</button>
            </div>
          </div>`).join('') || '<div class="empty">暂无申请，点击“发起申请”</div>'}
        </div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  window.app = Object.assign(window.app || {}, {
    newApproval: () => {
      const isXinren = MYLV() === 0;
      const types = isXinren ? ['功能申请'] : Object.keys(APPTYPES);
      openSheet(`
        <div class="sheet-title">发起审批申请<span class="x" onclick="app.closeSheet()">✕</span></div>
        ${isXinren ? '<div class="card" style="padding:10px;font-size:13px;color:#b45309;">新人模式：可发起「功能申请」，审批通过后自动开通对应功能（文件下载/文件上传/请假/检查上报/巡逻上报/数据录入等）。</div>' : ''}
        <div class="field"><label>审批类型 *</label><select id="ap-type">${types.map((t) => '<option>' + t + '</option>').join('')}</select></div>
        <div class="field"><label>标题 *</label><input id="ap-title" placeholder="${isXinren ? '如：申请开通文件下载权限' : '如：5月20日加班申请'}"></div>
        <div class="field" id="ap-feature-field" style="display:none;"><label>功能名称 *</label><select id="ap-feature">${Object.entries(FEATURE_NAMES).map(([k, n]) => '<option value="' + k + '">' + n + '</option>').join('')}</select></div>
        <div class="field"><label>说明 / 事由</label><textarea id="ap-note" rows="3" placeholder="补充说明"></textarea></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.submitApproval()">提交</button></div>`);
      const sel = $('#ap-type');
      const onType = () => { $('#ap-feature-field').style.display = sel.value === '功能申请' ? '' : 'none'; };
      sel.addEventListener('change', onType); onType();
    },
    submitApproval: async () => {
      const type = $('#ap-type').value;
      const title = $('#ap-title').value.trim();
      const note = $('#ap-note').value.trim();
      if (!title) { alert('请填写标题'); return; }
      const form = { '补充说明': note };
      if (type === '功能申请') {
        const feature = $('#ap-feature').value;
        form['功能名称'] = FEATURE_NAMES[feature] || feature;
        form['feature'] = feature;
      }
      try {
        await api('/api/approvals', 'POST', { type, title, form });
        closeSheet(); renderApproval();
      } catch (e) { alert(e.message); }
    },
    approveAp: async (id, action) => {
      const note = action === 'reject' ? (prompt('请填写驳回原因：') || '') : '';
      if (action === 'reject' && !note) { alert('驳回需填写原因'); return; }
      try { await api('/api/approvals/' + id + '/approve', 'POST', { action, note }); renderApproval(); } catch (e) { alert(e.message); }
    },
    cancelAp: async (id) => {
      if (!confirm('确认撤销该申请？')) return;
      try { await api('/api/approvals/' + id + '/cancel', 'POST'); renderApproval(); } catch (e) { alert(e.message); }
    },
    apDetail: (id) => {
      api('/api/approvals').then((list) => {
        const x = list.find((v) => v.id === id);
        const form = (() => { try { return JSON.parse(x.form_json || '{}'); } catch (e) { return {}; } })();
        openSheet(`
          <div class="sheet-title">${esc(x.title)}<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="detail-row"><div class="k">类型</div><div class="v">${esc(x.type)}</div></div>
          <div class="detail-row"><div class="k">申请人</div><div class="v">${esc(x.user_name)} · ${x.created_at}</div></div>
          <div class="detail-row"><div class="k">审批链</div><div class="v">${esc((x.chain || []).join(' → ') || '—')}${x.status === 'pending' && x.pending_level_name ? '（当前待「' + esc(x.pending_level_name) + '」）' : ''}</div></div>
          ${Object.entries(form).map(([k, v]) => `<div class="detail-row"><div class="k">${esc(k)}</div><div class="v">${esc(v)}</div></div>`).join('')}
          <div class="detail-row"><div class="k">状态</div><div class="v">${esc(x.status)}</div></div>
          ${x.approver_name ? `<div class="detail-row"><div class="k">最近审批</div><div class="v">${esc(x.approver_name)} · ${esc(x.approve_note || '无意见')} · ${esc(x.approve_at || '')}</div></div>` : ''}`);
      });
    }
  });

  /* ===== 培训 ===== */
  let trainTab = 'rec';
  let trainRecTab = 'all';
  async function renderTrain() {
    const el = $('#page-train');
    const row = () => `<div class="list-item"><div class="skel" style="width:36px;height:36px;border-radius:10px;flex-shrink:0;"></div>
      <div class="body"><div class="skel" style="height:14px;width:62%;"></div><div class="skel" style="height:11px;width:44%;margin-top:7px;"></div></div></div>`;
    el.innerHTML = `<div class="sub-tabs"><div class="skel" style="height:26px;flex:1;border-radius:8px;"></div><div class="skel" style="height:26px;flex:1;border-radius:8px;"></div><div class="skel" style="height:26px;flex:1;border-radius:8px;"></div></div>
      <div class="card">${row()}${row()}${row()}${row()}</div>`;
    try {
      const list = await api('/api/trainings');
      const cats = await api('/api/training-categories');
      const plans = await api('/api/training-plans');
      const trainers = await api('/api/trainers');
      window.__trainCache = { recs: [], courses: list, plans, trainers };
      const my = await api('/api/my-training');
      const isAppr = MYLV() >= 2;
      let recs = [], stat = null;
      try {
        const qs = trainRecTab !== 'all' ? ('?service=' + encodeURIComponent(trainRecTab === 'neibei' ? '内培' : '外培')) : '';
        recs = await api('/api/train/records' + qs);
        if (window.__trainCache) window.__trainCache.recs = recs;
      } catch (e) { recs = []; }
      try { stat = (await api('/api/train/stats')).stat; } catch (e) { stat = null; }
      const s = stat || { neibei: 0, waibei: 0, neibei_hours: 0, waibei_hours: 0, waibei_fee: 0, month_n: 0, month_hours: 0, people: 0 };
      el.innerHTML = `
        <div class="sub-tabs">
          <div class="sub-tab${trainTab === 'rec' ? ' on' : ''}" onclick="app.trainTab('rec')">培训记录</div>
          <div class="sub-tab${trainTab === 'course' ? ' on' : ''}" onclick="app.trainTab('course')">课程培训</div>
          <div class="sub-tab${trainTab === 'plan' ? ' on' : ''}" onclick="app.trainTab('plan')">培训计划</div>
          <div class="sub-tab${trainTab === 'trainer' ? ' on' : ''}" onclick="app.trainTab('trainer')">教员资质</div>
          <div class="sub-tab${trainTab === 'my' ? ' on' : ''}" onclick="app.trainTab('my')">个人档案</div>
        </div>
        <div class="sub-panel${trainTab === 'rec' ? ' show' : ''}" id="train-rec">
          <div class="train-stat-row">
            <div class="ts-box nb"><div class="ts-n">${s.neibei} <em>人次</em></div><div class="ts-l">内培 · ${s.neibei_hours} 学时</div></div>
            <div class="ts-box wb"><div class="ts-n">${s.waibei} <em>人次</em></div><div class="ts-l">外培 · ${s.waibei_hours} 学时</div></div>
            <div class="ts-box"><div class="ts-n">${s.waibei_fee}</div><div class="ts-l">外培费用（元）</div></div>
            <div class="ts-box"><div class="ts-n">${s.month_n} <em>人次</em></div><div class="ts-l">本月 · ${s.month_hours} 学时</div></div>
          </div>
          <div class="actions">
            <button class="btn sm" onclick="app.openTrainForm('single')">✍️ 按人录培训</button>
            <button class="btn sm" onclick="app.openTrainForm('batch')">👥 一键录多人</button>
            ${isAppr ? '<button class="btn sm ghost" onclick="app.openAssessForm()">📊 录考核</button>' : ''}
          </div>
          <div class="train-filter">
            <span class="chip${trainRecTab === 'all' ? ' on' : ''}" onclick="app.trainRecFilter('all')">全部</span>
            <span class="chip nb${trainRecTab === 'neibei' ? ' on' : ''}" onclick="app.trainRecFilter('neibei')">内培</span>
            <span class="chip wb${trainRecTab === 'waibei' ? ' on' : ''}" onclick="app.trainRecFilter('waibei')">外培</span>
            <input id="tr-kw" placeholder="搜课程/人员/证书/教员" style="flex:1;min-width:110px;padding:7px 10px;border:1px solid #d0d7de;border-radius:8px;font-size:13px;" onkeydown="if(event.key==='Enter')app.trainSearch()">
            <button class="btn sm ghost" onclick="app.trainSearch()">搜索</button>
          </div>
          <div class="card"><h3>培训记录明细（${recs.length}）<span style="font-size:11px;color:#9ca3af;font-weight:400;"> 一人一条 · 对齐 OIT train_list</span></h3>
            ${recs.map((t) => `
              <div class="list-item tr-item" onclick="app.openRecDetail(${t.id})">
                <div class="ic">${t.train_service === '外培' ? '🏛️' : '🏢'}</div>
                <div class="body">
                  <div class="t">${esc(t.class_info || '未填课程')} <span class="badge ${t.train_service === '外培' ? 'warn' : 'info'}">${esc(t.train_service || '内培')}</span>${t.train_type_name ? '<span class="badge gray">' + esc(t.train_type_name) + '</span>' : ''}${t.train_method === 'A' ? '<span class="badge gray">集中</span>' : (t.train_method === 'B' ? '<span class="badge gray">视频</span>' : '')}</div>
                  <div class="d">${esc(t.emp_name || t.emp_id)} · ${t.beg_date || '日期待填'}${t.end_date ? ' ~ ' + t.end_date : ''} · ${t.hours || 0} 学时${Number(t.fee) ? ' · 💰 ' + t.fee + ' 元' : ''}</div>
                  <div class="d" style="color:#555;">${t.mark_grade ? '📝 成绩 ' + esc(t.mark_grade) : ''}${t.certificate_no ? ' · 🎓 证书 ' + esc(t.certificate_no) : ''}${t.teacher_name ? ' · 🎤 教员 ' + esc(t.teacher_name) : ''}${t.corp_operate ? ' · ' + esc(t.corp_operate) : ''}${t.lmt_service_date ? ' · 服务期至 ' + t.lmt_service_date : ''}</div>
                  ${t.note_info ? '<div class="d" style="color:#9ca3af;">' + esc(t.note_info) + '</div>' : ''}
                </div>
                <div class="act">${isAppr ? '<button class="btn sm danger" onclick="event.stopPropagation();app.delTrainRec(' + t.id + ')">删</button>' : ''}<span class="ai-arrow" style="color:#cbd5e1;font-size:16px;">›</span></div>
              </div>`).join('') || '<div class="empty">暂无培训记录<br><span style="font-size:12px;">点「✍️ 按人录培训」录单人 / 「👥 一键录多人」一次录多人（支持外培费用、证书、服务期）</span></div>'}
          </div>
        </div>
        <div class="sub-panel${trainTab === 'course' ? ' show' : ''}" id="train-course">
          <div class="actions">
            <button class="btn sm" onclick="app.addTrain()">＋ 新增课程培训</button>
            ${isAppr ? '<button class="btn sm ghost" onclick="app.manageCats()">分类管理</button>' : ''}
            <button class="btn sm ghost" onclick="app.trainStat()">培训统计</button>
          </div>
          <div class="card"><h3>课程培训（${list.length}）</h3>
            ${list.map((t) => `
              <div class="list-item tr-item" onclick="app.openCourseDetail(${t.id})">
                <div class="ic">📚</div>
                <div class="body">
                  <div class="t">${esc(t.title)} <span class="badge info">${esc(t.category)}</span></div>
                  <div class="d">${esc(t.trainer || '未填讲师')} · ${t.train_date} · ${t.hours} 学时</div>
                </div>
                <div class="act">
                  ${isAppr ? '<button class="btn sm ghost" onclick="event.stopPropagation();app.editTrain(' + t.id + ')">编辑</button> <button class="btn sm danger" onclick="event.stopPropagation();app.delTrain(' + t.id + ')">删</button>' : ''}
                  <span class="ai-arrow" style="color:#cbd5e1;font-size:16px;">›</span>
                </div>
              </div>`).join('') || '<div class="empty">暂无课程培训记录</div>'}
          </div>
        </div>
        <div class="sub-panel${trainTab === 'plan' ? ' show' : ''}" id="train-plan">
          <div class="actions">${isAppr ? '<button class="btn sm" onclick="app.addPlan()">＋ 新增计划</button>' : ''}</div>
          <div class="card"><h3>培训计划（${plans.length}）</h3>
            ${plans.map((p) => `
              <div class="list-item tr-item" onclick="app.openPlanDetail(${p.id})">
                <div class="ic">🗓️</div>
                <div class="body">
                  <div class="t">${esc(p.title)} <span class="badge ${p.status === 'done' ? 'ok' : p.status === 'cancelled' ? 'gray' : 'info'}">${p.status === 'done' ? '已完成' : p.status === 'cancelled' ? '已取消' : '计划中'}</span></div>
                  <div class="d">${esc(p.category)} · ${p.plan_date || '日期待定'} · ${p.hours} 学时 · ${esc(p.target || '')}</div>
                </div>
                <div class="act">
                  ${isAppr ? '<button class="btn sm ghost" onclick="event.stopPropagation();app.editPlan(' + p.id + ')">编辑</button> <button class="btn sm danger" onclick="event.stopPropagation();app.delPlan(' + p.id + ')">删</button>' : ''}
                  <span class="ai-arrow" style="color:#cbd5e1;font-size:16px;">›</span>
                </div>
              </div>`).join('') || '<div class="empty">暂无培训计划</div>'}
          </div>
        </div>
        <div class="sub-panel${trainTab === 'trainer' ? ' show' : ''}" id="train-trainer">
          <div class="actions">${isAppr ? '<button class="btn sm" onclick="app.addTrainer()">＋ 新增教员</button>' : ''}</div>
          <div class="card"><h3>教员资质（${trainers.length}）</h3>
            ${trainers.map((t) => {
              const exp = t.expire_date ? new Date(t.expire_date) : null;
              const soon = exp && (exp - new Date()) < 90 * 86400000;
              return `
              <div class="list-item tr-item" onclick="app.openTrainerDetail('${esc(t.id)}')">
                <div class="ic">🎓</div>
                <div class="body">
                  <div class="t">${esc(t.name)}${t.is_outer === 'Y' ? ' <span class="badge warn">外聘</span>' : (t.is_outer === 'N' ? ' <span class="badge info">内部</span>' : '')}${soon ? ' <span class="badge bad">证件将到期</span>' : ''}</div>
                  <div class="d">${esc(t.category || '未分类')}${t.cert_no ? ' · 证书 ' + esc(t.cert_no) : ''}${t.expire_date ? ' · 有效期至 ' + t.expire_date : (t.corporate_name ? ' · ' + esc(t.corporate_name) : '')}</div>
                </div>
                <div class="act">
                  ${isAppr ? '<button class="btn sm ghost" onclick="event.stopPropagation();app.editTrainer(' + t.id + ')">编辑</button> <button class="btn sm danger" onclick="event.stopPropagation();app.delTrainer(' + t.id + ')">删</button>' : ''}
                  <span class="ai-arrow" style="color:#cbd5e1;font-size:16px;">›</span>
                </div>
              </div>`;}).join('') || '<div class="empty">暂无教员档案（OIT 采集器导入后自动出现）</div>'}
          </div>
        </div>
        <div class="sub-panel${trainTab === 'my' ? ' show' : ''}" id="train-my">
          <div class="card" style="text-align:center;padding:22px 14px;">
            <div style="font-size:15px;font-weight:600;margin-bottom:8px;">📋 个人档案（OIT 对标）</div>
            <div class="muted" style="font-size:13px;line-height:1.8;">聚合每人 <b>工作</b>（考勤/请假/值班/待办）、<b>培训</b>（内外培学时/证书）、<b>考核</b>、<b>检查</b>（检查/整改）四类记录，对齐 OIT 员工主页签</div>
            <div style="margin-top:14px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap;">
              <button class="btn" onclick="app.openArchiveFor('')">查看我的完整档案</button>
              ${isAppr ? '<button class="btn ghost" onclick="app.openArchivePick()">查看他人档案</button>' : ''}
            </div>
          </div>
        </div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  window.app = Object.assign(window.app || {}, {
    /* v8.3 文件分类/多选/回收站 */
    fileFolder: (f) => { window.FILE_FOLDER = f; window.FILE_SEL = []; renderFile(); },
    fileSel: (id, on) => {
      let s = window.FILE_SEL || [];
      s = on ? (s.includes(id) ? s : s.concat(id)) : s.filter((x) => x !== id);
      window.FILE_SEL = s; renderFile();
    },
    fileSelClear: () => { window.FILE_SEL = []; renderFile(); },
    fileNewFolder: async () => {
      const n = prompt('新文件夹名称（用于分类存放文件，如：手册 / 运行文件 / 规章制度 / 培训资料）：');
      if (!n) return;
      try { await api('/api/files/folders', 'POST', { name: n.trim() }); window.FILE_FOLDER = 'all'; renderFile(); } catch (e) { alert(e.message); }
    },
    fileMoveSel: async () => {
      const ids = window.FILE_SEL || [];
      if (!ids.length) return;
      const folders = await api('/api/files/folders');
      const opts = folders.map((f0) => `<option value="${f0.id}">${esc(f0.name)}</option>`).join('') + '<option value="">未分类</option>';
      openSheet(`<div class="sheet-title">批量移动 ${ids.length} 个文件<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>移动到分类</label><select id="mv-folder">${opts}</select></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.doMoveSel()">移动</button></div>`);
    },
    doMoveSel: async () => {
      const fid = $('#mv-folder').value;
      try { await api('/api/files/batch', 'POST', { ids: window.FILE_SEL, action: 'move', folder_id: fid }); window.FILE_SEL = []; closeSheet(); renderFile(); v5toast('已移动'); } catch (e) { v5toast(e.message); }
    },
    fileDelSel: async () => {
      const ids = window.FILE_SEL || [];
      if (!ids.length) return;
      if (!confirm('将 ' + ids.length + ' 个文件移入回收站（可恢复，超半年自动彻底清理）？')) return;
      try { await api('/api/files/batch', 'POST', { ids, action: 'delete' }); window.FILE_SEL = []; renderFile(); v5toast('已移入回收站'); } catch (e) { v5toast(e.message); }
    },
    fileDel: async (id, name) => {
      if (!confirm('将「' + name + '」移入回收站？可在回收站恢复（超半年自动彻底清理）。')) return;
      try { await api('/api/files/' + id, 'DELETE'); renderFile(); v5toast('已移入回收站'); } catch (e) { v5toast(e.message); }
    },
    fileRestore: async (id) => {
      try { await api('/api/files/' + id + '/restore', 'POST', {}); renderFile(); v5toast('已恢复'); } catch (e) { v5toast(e.message); }
    },
    filePurge: async (id) => {
      if (!confirm('彻底删除该文件？不可恢复。')) return;
      try { await api('/api/files/' + id + '/purge', 'DELETE'); renderFile(); v5toast('已彻底删除'); } catch (e) { v5toast(e.message); }
    },
    trainTab: (t) => { trainTab = t; renderTrain(); },
    /* v8.2 OIT 层级：记录/课程/计划/教员 → 详情表单（弹层，含关联跳转） */
    openRecDetail: (id) => {
      const t = (window.__trainCache && window.__trainCache.recs || []).find((x) => String(x.id) === String(id));
      if (!t) return;
      const rows = [
        ['员工', (t.emp_name || '') + '（工号 ' + (t.emp_id || '') + '）'],
        ['培训类别', t.train_service === '外培' ? '委外培训（外培）' : '内部培训（内培）'],
        ['课程名称', t.class_info],
        ['培训类型', t.train_type_name || t.train_type || ''],
        ['培训方式', t.train_method === 'A' ? '集中培训' : t.train_method === 'B' ? '视频培训' : t.train_method || ''],
        ['参训日期', (t.beg_date || '待填') + (t.end_date && t.end_date !== t.beg_date ? ' 至 ' + t.end_date : '')],
        ['天数/学时', (t.days ? t.days + ' 天 · ' : '') + (t.hours || 0) + ' 学时'],
        ['费用(元)', t.fee || ''],
        ['考核成绩', t.mark_grade || ''],
        ['培训效果', t.train_effect || ''],
        ['证书编号', t.certificate_no || ''],
        ['服务期至', t.lmt_service_date || ''],
        ['授课教员', t.teacher_name || ''],
        ['承办机构', t.corp_organize || ''],
        ['协作机构', t.corp_operate || ''],
        ['备注', t.note_info || '']
      ];
      openSheet(`<div style="padding:18px 0 6px;"><div class="sheet-title" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">${t.train_service === '外培' ? '🏛️' : '🏢'} 培训记录详情 <span class="badge ${t.train_service === '外培' ? 'warn' : 'info'}">${esc(t.train_service || '内培')}</span></div>
        <div class="muted" style="font-size:12px;margin:4px 0 10px;">${esc(t.emp_name || '')} · ${t.beg_date || ''} · ${t.hours || 0} 学时</div>
        ${rows.map(([k, v]) => infoRow(k, v)).join('')}
        <div style="display:flex;gap:8px;margin-top:14px;">
          <button class="btn" style="flex:1;" onclick="closeSheet();app.openArchiveFor('${esc(t.emp_id || '')}','${esc(t.emp_name || '')}')">👤 查看此人档案</button>
          <button class="btn ghost" style="flex:1;" onclick="app.closeSheet()">关闭</button>
        </div></div>`);
    },
    openCourseDetail: (id) => {
      const t = (window.__trainCache && window.__trainCache.courses || []).find((x) => String(x.id) === String(id));
      if (!t) return;
      const rows = [
        ['课程名称', t.title], ['分类', t.category], ['讲师', t.trainer],
        ['培训日期', t.train_date + (t.start_time ? ' ' + t.start_time + (t.end_time ? '~' + t.end_time : '') : '')],
        ['学时', t.hours], ['参训人员', t.participants || ''], ['课程内容', t.content || '']
      ];
      openSheet(`<div style="padding:18px 0 6px;"><div class="sheet-title">📚 课程培训详情</div>
        ${rows.map(([k, v]) => infoRow(k, v)).join('')}
        <button class="btn block" style="margin-top:14px;" onclick="app.closeSheet()">关闭</button></div>`);
    },
    openPlanDetail: (id) => {
      const p = (window.__trainCache && window.__trainCache.plans || []).find((x) => String(x.id) === String(id));
      if (!p) return;
      const rows = [
        ['计划标题', p.title], ['分类', p.category], ['状态', p.status === 'done' ? '已完成' : p.status === 'cancelled' ? '已取消' : '计划中'],
        ['计划日期', p.plan_date], ['学时', p.hours], ['培训对象', p.target], ['负责人', p.creator_name || ''], ['备注', p.remark || p.content || '']
      ];
      openSheet(`<div style="padding:18px 0 6px;"><div class="sheet-title">🗓️ 培训计划详情</div>
        ${rows.map(([k, v]) => infoRow(k, v)).join('')}
        <button class="btn block" style="margin-top:14px;" onclick="app.closeSheet()">关闭</button></div>`);
    },
    openTrainerDetail: (tid) => {
      const t = (window.__trainCache && window.__trainCache.trainers || []).find((x) => String(x.id) === String(tid));
      if (!t) return;
      const rows = [
        ['教员姓名', t.name], ['类型', t.category || ''],
        ['内/外聘', t.is_outer === 'Y' ? '外聘教员' : (t.is_outer === 'N' ? '内部教员' : '')],
        ['擅长领域', t.skill_info || ''], ['所在单位', t.corporate_name || ''],
        ['所属部门', t.dept || ''], ['部门岗位', t.dept_post || ''],
        ['联系电话', t.mobile_no || ''], ['学历', t.culture_degree || ''],
        ['证书编号', t.cert_no || ''], ['证书日期', t.cert_date || ''], ['有效期至', t.expire_date || '长期'],
        ['备注', t.note_info || t.refresh_note || '']
      ];
      openSheet(`<div style="padding:18px 0 6px;"><div class="sheet-title">🎓 教员资质详情</div>
        ${rows.map(([k, v]) => infoRow(k, v)).join('')}
        <button class="btn block" style="margin-top:14px;" onclick="app.closeSheet()">关闭</button></div>`);
    },

    trainRecFilter: (s) => { trainRecTab = s; renderTrain(); },
    trainSearch: () => {
      const kw = ($('#tr-kw') || {}).value || '';
      try {
        api('/api/train/records?kw=' + encodeURIComponent(kw)).then((r) => {
          const recs = Array.isArray(r) ? r : [];
          const host = $('#train-rec');
          if (!host) return;
          const card = host.querySelector('.card');
          if (!card) return;
          const isAppr = MYLV() >= 2;
          card.innerHTML = '<h3>培训记录明细（' + recs.length + '）<span style="font-size:11px;color:#9ca3af;font-weight:400;"> 搜索「' + esc(kw) + '」</span></h3>' +
            (recs.map((t) => `
              <div class="list-item">
                <div class="ic">${t.train_service === '外培' ? '🏛️' : '🏢'}</div>
                <div class="body">
                  <div class="t">${esc(t.class_info || '未填课程')} <span class="badge ${t.train_service === '外培' ? 'warn' : 'info'}">${esc(t.train_service || '内培')}</span>${t.train_type_name ? '<span class="badge gray">' + esc(t.train_type_name) + '</span>' : ''}</div>
                  <div class="d">${esc(t.emp_name || t.emp_id)} · ${t.beg_date || '日期待填'} · ${t.hours || 0} 学时${Number(t.fee) ? ' · 💰 ' + t.fee + ' 元' : ''}</div>
                  <div class="d" style="color:#555;">${t.mark_grade ? '📝 ' + esc(t.mark_grade) : ''}${t.certificate_no ? ' · 🎓 ' + esc(t.certificate_no) : ''}${t.teacher_name ? ' · 🎤 ' + esc(t.teacher_name) : ''}</div>
                </div>
                <div class="act">${isAppr ? '<button class="btn sm danger" onclick="app.delTrainRec(' + t.id + ')">删</button>' : ''}</div>
              </div>`).join('') || '<div class="empty">无匹配记录</div>');
        });
      } catch (e) {}
    },
    openTrainForm: (mode) => {
      api('/api/users').then((users) => {
        const valid = users.filter((x) => !x.deleted_at && x.real_name && (x.user_type || x.role));
        const opts = valid.map((x) => '<option value="' + esc(String(x.work_no || x.id)) + '">' + esc(x.real_name) + (x.dept_name ? '（' + esc(x.dept_name) + '）' : '') + '</option>').join('');
        const modeLabel = mode === 'batch' ? '👥 一键录多人（同一课程同时录多人）' : '✍️ 按人录培训';
        openSheet(`
          <div class="sheet-title">${modeLabel}<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="sheet-scroll">
            <div class="field"><label>培训类别 *（对齐 OIT：内培=内部培训 / 外培=委外培训）</label>
              <select id="tr-service"><option value="内培">内培（内部培训）</option><option value="外培">外培（委外培训，含费用/证书/服务期）</option></select>
            </div>
            ${mode === 'single' ? '<div class="field"><label>参训人员 *</label><select id="tr-emp">' + opts + '</select></div>' : '<div class="field"><label>勾选参训人员 *（可多选）</label><div id="tr-emp-list" class="pick-list">' + valid.map((x) => '<label class="pick-item"><input type="checkbox" value="' + esc(String(x.work_no || x.id)) + '"> <span>' + esc(x.real_name) + '</span><em>' + esc(x.dept_name || '') + '</em></label>').join('') + '</div></div>'}
            <div class="row2">
              <div class="field"><label>培训类型</label><select id="tr-type"><option value="">— 选择 —</option><option value="001">非专业安保人员培训</option><option value="002">服务培训</option><option value="004">专项/季节培训</option><option value="005">岗前培训</option><option value="006">机坪安全运行培训</option></select></div>
              <div class="field"><label>培训方式</label><select id="tr-method"><option value="">— 选择 —</option><option value="A">集中培训</option><option value="B">视频培训</option></select></div>
            </div>
            <div class="field"><label>课程名称 *</label><input id="tr-class" placeholder="如：跑道侵入防范培训 / 5月非专业安保人员培训-通行管制"></div>
            <div class="row2">
              <div class="field"><label>开始日期</label><input id="tr-beg" type="date"></div>
              <div class="field"><label>结束日期</label><input id="tr-end" type="date"></div>
            </div>
            <div class="row2">
              <div class="field"><label>学时 *</label><input id="tr-hours" type="number" step="0.5" placeholder="如 4"></div>
              <div class="field"><label>培训天数</label><input id="tr-days" type="number" step="1" placeholder="0"></div>
            </div>
            <div class="row2">
              <div class="field"><label>费用（元，外培填写）</label><input id="tr-fee" type="number" step="0.01" placeholder="0"></div>
              <div class="field"><label>培训效果</label><select id="tr-effect"><option value="">—</option><option value="A">优秀</option><option value="B">良好</option><option value="C">合格</option><option value="D">不合格</option></select></div>
            </div>
            <div class="row2">
              <div class="field"><label>成绩</label><input id="tr-grade" placeholder="如 92 或 B6:88/C6.1:96"></div>
              <div class="field"><label>证书编号</label><input id="tr-cert" placeholder="如 JPAQ-2026-001"></div>
            </div>
            <div class="row2">
              <div class="field"><label>服务期至（外培）</label><input id="tr-lmt" type="date"></div>
              <div class="field"><label>教员</label><input id="tr-teacher" placeholder="姓名"></div>
            </div>
            <div class="row2">
              <div class="field"><label>组织单位</label><input id="tr-org" placeholder="如 消防护卫部"></div>
              <div class="field"><label>承办机构（外培）</label><input id="tr-opr" placeholder="如 民航安全培训中心"></div>
            </div>
            <div class="field"><label>备注</label><textarea id="tr-note" rows="2" placeholder="培训内容/考勤情况等"></textarea></div>
          </div>
          <div class="sheet-actions">
            <button class="btn ghost" onclick="app.closeSheet()">取消</button>
            <button class="btn" onclick="app.saveTrainForm('${mode}')">保存${mode === 'batch' ? '（多人）' : ''}</button>
          </div>`);
        const today = todayStr();
        if ($('#tr-beg')) $('#tr-beg').value = today;
        if ($('#tr-lmt') && $('#tr-service').value === '内培') $('#tr-lmt').style.display = 'none';
        $('#tr-service').addEventListener('change', () => {
          const lmt = $('#tr-lmt');
          if (lmt) lmt.parentElement.style.display = $('#tr-service').value === '外培' ? '' : 'none';
        });
      });
    },
    saveTrainForm: async (mode) => {
      try {
        const empIds = mode === 'batch'
          ? Array.from(document.querySelectorAll('#tr-emp-list input:checked')).map((i) => i.value)
          : [$('#tr-emp').value];
        if (!empIds.length) return alert(mode === 'batch' ? '请至少勾选一名参训人员' : '请选择参训人员');
        const cls = ($('#tr-class').value || '').trim();
        if (!cls) return alert('请填写课程名称');
        const body = {
          emp_ids: empIds,
          train_service: $('#tr-service').value,
          train_type: $('#tr-type').value,
          train_method: $('#tr-method').value,
          class_info: cls,
          beg_date: $('#tr-beg').value,
          end_date: $('#tr-end').value,
          hours: $('#tr-hours').value || 0,
          days: $('#tr-days').value || 0,
          fee: $('#tr-fee').value || 0,
          mark_grade: ($('#tr-grade').value || '').trim(),
          train_effect: $('#tr-effect').value,
          certificate_no: ($('#tr-cert').value || '').trim(),
          lmt_service_date: $('#tr-lmt').value || '',
          teacher_name: ($('#tr-teacher').value || '').trim(),
          corp_organize: ($('#tr-org').value || '').trim(),
          corp_operate: ($('#tr-opr').value || '').trim(),
          note_info: ($('#tr-note').value || '').trim()
        };
        const r = await api('/api/train/records', 'POST', body);
        v5toast('已录入 ' + r.added + ' 人培训记录');
        closeSheet(); renderTrain();
      } catch (e) { alert(e.message); }
    },
    delTrainRec: async (id) => {
      if (!confirm('删除该培训记录？')) return;
      try { await api('/api/train/record/' + id, 'DELETE'); renderTrain(); } catch (e) { alert(e.message); }
    },
    openAssessForm: () => {
      api('/api/users').then((users) => {
        const valid = users.filter((x) => !x.deleted_at && x.real_name && (x.user_type || x.role));
        const opts = valid.map((x) => '<option value="' + esc(String(x.work_no || x.id)) + '">' + esc(x.real_name) + '</option>').join('');
        openSheet(`
          <div class="sheet-title">📊 录考核记录（对齐 OIT eas）<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="sheet-scroll">
            <div class="field"><label>被考核人员 *</label><select id="as-emp">${opts}</select></div>
            <div class="row2">
              <div class="field"><label>考核名称/批次 *</label><input id="as-name" placeholder="如 2026年三季度安保考核"></div>
              <div class="field"><label>考核项目</label><input id="as-item" placeholder="如 理论考核/实操"></div>
            </div>
            <div class="row2">
              <div class="field"><label>分数</label><input id="as-mark" type="number" step="0.5" placeholder="0-100"></div>
              <div class="field"><label>等级</label><select id="as-grade"><option value="">—</option><option value="优秀">优秀</option><option value="良好">良好</option><option value="合格">合格</option><option value="不合格">不合格</option></select></div>
            </div>
            <div class="row2">
              <div class="field"><label>考核日期</label><input id="as-date" type="date"></div>
              <div class="field"><label>考核人</label><input id="as-assessor" placeholder="姓名"></div>
            </div>
            <div class="field"><label>备注</label><textarea id="as-note" rows="2"></textarea></div>
          </div>
          <div class="sheet-actions">
            <button class="btn ghost" onclick="app.closeSheet()">取消</button>
            <button class="btn" onclick="app.saveAssessForm()">保存</button>
          </div>`);
        $('#as-date').value = todayStr();
        $('#as-assessor').value = ME.real_name || '';
      });
    },
    saveAssessForm: async () => {
      try {
        const name = ($('#as-name').value || '').trim();
        if (!name) return alert('请填写考核名称');
        await api('/api/assess-records', 'POST', {
          emp_id: $('#as-emp').value,
          assess_name: name,
          item_name: ($('#as-item').value || '').trim(),
          mark: $('#as-mark').value || 0,
          grade: $('#as-grade').value,
          assess_date: $('#as-date').value || todayStr(),
          assessor_name: ($('#as-assessor').value || '').trim(),
          note_info: ($('#as-note').value || '').trim()
        });
        v5toast('考核记录已保存');
        closeSheet();
      } catch (e) { alert(e.message); }
    },
    openArchiveFor: (workNo, name) => {
      window.__archiveEmp = workNo || name || String(ME.work_no || ME.id);
      window.__arcView = 'overview';
      window.__arcStack = [];
      window.__arcData = null;
      window.__arcDetail = null;
      try { closeSheet(); } catch (e) {}
      switchPage('archive');
    },
    openArchivePick: () => {
      api('/api/users').then((users) => {
        const valid = users.filter((x) => !x.deleted_at && x.real_name && (x.user_type || x.role));
        openSheet(`
          <div class="sheet-title">选择员工查看档案<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="field"><label>员工</label><select id="pk-emp">${valid.map((x) => '<option value="' + esc(String(x.work_no || x.id)) + '">' + esc(x.real_name) + '（' + esc(x.dept_name || '') + '）</option>').join('')}</select></div>
          <div class="sheet-actions">
            <button class="btn ghost" onclick="app.closeSheet()">取消</button>
            <button class="btn" onclick="app.pickArchiveGo()">查看档案</button>
          </div>`);
      });
    },
    pickArchiveGo: () => {
      const v = $('#pk-emp').value;
      closeSheet(); app.openArchiveFor(v);
    },
    /* [需求1] 档案页越权时提供"看自己"的出口 */
    openMyArchive: () => { window.__archiveEmp = String(ME.work_no || ME.id); window.__arcData = null; window.__arcView = 'overview'; renderArchive(); },
    archiveEmpSearch: () => {
      const v = ($('#arc-emp') || {}).value || '';
      if (!v) return alert('请输入工号/编号');
      window.__archiveEmp = v;
      renderArchive();
    },
    arcPage: (p, key) => { window.__arcPage[key] = p; renderArchive(); },
    addTrain: () => {
      api('/api/training-categories').then((c) => {
        openSheet(`
          <div class="sheet-title">新增培训记录<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="field"><label>培训标题 *</label><input id="t-title"></div>
          <div class="row2">
            <div class="field"><label>培训分类 *</label><select id="t-cat">${c.map((x) => '<option>' + esc(x.name) + '</option>').join('')}</select></div>
            <div class="field"><label>日期 *</label><input id="t-date" type="date"></div>
          </div>
          <div class="row2">
            <div class="field"><label>讲师</label><input id="t-trainer"></div>
            <div class="field"><label>学时</label><input id="t-hours" type="number" step="0.5"></div>
          </div>
          <div class="row2">
            <div class="field"><label>开始时间</label><input id="t-start" type="time"></div>
            <div class="field"><label>结束时间</label><input id="t-end" type="time"></div>
          </div>
          <div class="field"><label>参训人员</label><input id="t-participants" placeholder="多人用顿号分隔"></div>
          <div class="field"><label>培训内容</label><textarea id="t-content" rows="3"></textarea></div>
          <div class="sheet-actions">
            <button class="btn ghost" onclick="app.closeSheet()">取消</button>
            <button class="btn" onclick="app.saveTrain()">保存</button>
          </div>`);
        $('#t-date').value = todayStr();
      });
    },
    saveTrain: async () => {
      try {
        await api('/api/trainings', 'POST', {
          title: $('#t-title').value.trim(), category: $('#t-cat').value, train_date: $('#t-date').value,
          trainer: $('#t-trainer').value.trim(), hours: $('#t-hours').value, participants: $('#t-participants').value.trim(), content: $('#t-content').value.trim(),
          start_time: ($('#t-start').value || '').trim(), end_time: ($('#t-end').value || '').trim()
        });
        closeSheet(); renderTrain();
      } catch (e) { alert(e.message); }
    },
    editTrain: (id) => {
      api('/api/trainings').then((list) => {
        const t = list.find((x) => x.id === id);
        api('/api/training-categories').then((c) => {
          openSheet(`
            <div class="sheet-title">编辑培训记录<span class="x" onclick="app.closeSheet()">✕</span></div>
            <div class="field"><label>培训标题 *</label><input id="t-title" value="${esc(t.title)}"></div>
            <div class="row2">
              <div class="field"><label>培训分类 *</label><select id="t-cat">${c.map((x) => '<option' + (x.name === t.category ? ' selected' : '') + '>' + esc(x.name) + '</option>').join('')}</select></div>
              <div class="field"><label>日期 *</label><input id="t-date" type="date" value="${esc(t.train_date)}"></div>
            </div>
            <div class="row2">
              <div class="field"><label>讲师</label><input id="t-trainer" value="${esc(t.trainer)}"></div>
              <div class="field"><label>学时</label><input id="t-hours" type="number" step="0.5" value="${esc(t.hours)}"></div>
            </div>
            <div class="field"><label>参训人员</label><input id="t-participants" value="${esc(t.participants)}"></div>
            <div class="field"><label>培训内容</label><textarea id="t-content" rows="3">${esc(t.content)}</textarea></div>
            <div class="sheet-actions">
              <button class="btn ghost" onclick="app.closeSheet()">取消</button>
              <button class="btn" onclick="app.updateTrain(${id})">保存</button>
            </div>`);
        });
      });
    },
    updateTrain: async (id) => {
      try {
        await api('/api/trainings/' + id, 'PUT', {
          title: $('#t-title').value.trim(), category: $('#t-cat').value, train_date: $('#t-date').value,
          trainer: $('#t-trainer').value.trim(), hours: $('#t-hours').value, participants: $('#t-participants').value.trim(), content: $('#t-content').value.trim()
        });
        closeSheet(); renderTrain();
      } catch (e) { alert(e.message); }
    },
    delTrain: async (id) => {
      if (!confirm('确定删除该培训记录？')) return;
      try { await api('/api/trainings/' + id, 'DELETE'); renderTrain(); } catch (e) { alert(e.message); }
    },
    trainDetail: async (id) => {
      const list = await api('/api/trainings');
      const t = list.find((x) => x.id === id);
      const signins = await api('/api/trainings/' + id + '/signins');
      const scores = await api('/api/trainings/' + id + '/scores');
      const isAppr = MYLV() >= 2;
      const mySigned = signins.some((s) => s.user_id === ME.id);
      const users = await api('/api/users');
      openSheet(`
        <div class="sheet-title">培训详情<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="detail-row"><div class="k">标题</div><div class="v">${esc(t.title)}</div></div>
        <div class="detail-row"><div class="k">分类</div><div class="v">${esc(t.category)}</div></div>
        <div class="detail-row"><div class="k">讲师</div><div class="v">${esc(t.trainer)}</div></div>
        <div class="detail-row"><div class="k">日期</div><div class="v">${esc(t.train_date)}</div></div>
        <div class="detail-row"><div class="k">学时</div><div class="v">${t.hours} 小时</div></div>
        <div class="detail-row"><div class="k">参训人员</div><div class="v">${esc(t.participants || '—')}</div></div>
        <div class="detail-row"><div class="k">内容</div><div class="v"><pre class="msg-content">${esc(t.content || '—')}</pre></div></div>
        <div class="detail-row"><div class="k">签到（${signins.length}）</div><div class="v">${signins.map((s) => esc(s.user_name)).join('、') || '暂无'}</div></div>
        <div class="detail-row"><div class="k">考核</div><div class="v">${scores.map((s) => esc(s.user_name) + ' ' + (s.score == null ? '' : s.score + '分') + (s.result ? '·' + esc(s.result) : '')).join('　') || '暂无'}</div></div>
        <div class="sheet-actions">
          ${!mySigned ? '<button class="btn" onclick="app.signTrain(' + id + ')">我来签到</button>' : ''}
          ${isAppr ? '<button class="btn ghost" onclick="app.scoreTrain(' + id + ')">录入考核</button>' : ''}
          <button class="btn ghost" onclick="app.closeSheet()">关闭</button>
        </div>`);
    },
    signTrain: async (id) => {
      try { await api('/api/trainings/' + id + '/signin', 'POST'); alert('签到成功，学时已计入个人档案'); closeSheet(); renderTrain(); } catch (e) { alert(e.message); }
    },
    scoreTrain: async (id) => {
      const users = await api('/api/users');
      openSheet(`
        <div class="sheet-title">录入考核成绩<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>参训人员 *</label><select id="sc-user">${users.map((x) => '<option value="' + x.id + '">' + esc(x.real_name) + '</option>').join('')}</select></div>
        <div class="row2">
          <div class="field"><label>成绩（分）</label><input id="sc-score" type="number" min="0" max="100" placeholder="如 92"></div>
          <div class="field"><label>结果</label><select id="sc-result"><option value="">—</option><option>合格</option><option>不合格</option></select></div>
        </div>
        <div class="field"><label>备注</label><input id="sc-note"></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveScore(${id})">保存</button></div>`);
    },
    saveScore: async (id) => {
      try {
        await api('/api/trainings/' + id + '/scores', 'POST', {
          user_id: Number($('#sc-user').value), score: $('#sc-score').value ? Number($('#sc-score').value) : null,
          result: $('#sc-result').value, note: $('#sc-note').value.trim()
        });
        closeSheet(); renderTrain();
      } catch (e) { alert(e.message); }
    },
    manageCats: () => {
      api('/api/training-categories').then((c) => {
        openSheet(`
          <div class="sheet-title">培训分类管理<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div style="display:flex;gap:8px;margin-bottom:12px;">
            <input id="nc-name" style="flex:1;padding:9px 12px;border:1px solid var(--line);border-radius:10px;" placeholder="新分类名称">
            <button class="btn sm" onclick="app.addCat()">添加</button>
          </div>
          ${c.map((x) => `<div class="list-item"><div class="body"><div class="t">${esc(x.name)}</div></div></div>`).join('')}`);
      });
    },
    addCat: async () => {
      const n = $('#nc-name').value.trim();
      if (!n) return;
      try { await api('/api/training-categories', 'POST', { name: n }); app.manageCats(); } catch (e) { alert(e.message); }
    },
    trainStat: () => {
      api('/api/trainings').then((list) => {
        const byCat = {};
        let total = 0;
        list.forEach((t) => { byCat[t.category] = (byCat[t.category] || 0) + Number(t.hours || 0); total += Number(t.hours || 0); });
        const rows = Object.entries(byCat).sort((a, b) => b[1] - a[1]);
        openSheet(`
          <div class="sheet-title">培训统计<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="stat-grid">
            <div class="stat"><div class="num">${list.length}</div><div class="lbl">培训场次</div></div>
            <div class="stat"><div class="num">${total}</div><div class="lbl">总学时</div></div>
          </div>
          ${rows.map(([c, h]) => `<div class="detail-row"><div class="k">${esc(c)}</div><div class="v">${h} 学时</div></div>`).join('') || '<div class="empty">暂无数据</div>'}`);
      });
    },
    addPlan: () => {
      api('/api/training-categories').then((c) => {
        openSheet(`
          <div class="sheet-title">新增培训计划<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="field"><label>计划标题 *</label><input id="pl-title"></div>
          <div class="row2">
            <div class="field"><label>分类 *</label><select id="pl-cat">${c.map((x) => '<option>' + esc(x.name) + '</option>').join('')}</select></div>
            <div class="field"><label>计划日期</label><input id="pl-date" type="date"></div>
          </div>
          <div class="row2">
            <div class="field"><label>计划学时</label><input id="pl-hours" type="number" step="0.5"></div>
            <div class="field"><label>状态</label><select id="pl-status"><option value="planned">计划中</option><option value="done">已完成</option><option value="cancelled">已取消</option></select></div>
          </div>
          <div class="field"><label>培训对象</label><input id="pl-target"></div>
          <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.savePlan()">保存</button></div>`);
      });
    },
    savePlan: async () => {
      try {
        await api('/api/training-plans', 'POST', {
          title: $('#pl-title').value.trim(), category: $('#pl-cat').value, plan_date: $('#pl-date').value,
          hours: $('#pl-hours').value, target: $('#pl-target').value.trim(), status: $('#pl-status').value
        });
        closeSheet(); renderTrain();
      } catch (e) { alert(e.message); }
    },
    editPlan: (id) => {
      api('/api/training-plans').then((list) => {
        const p = list.find((x) => x.id === id);
        api('/api/training-categories').then((c) => {
          openSheet(`
            <div class="sheet-title">编辑培训计划<span class="x" onclick="app.closeSheet()">✕</span></div>
            <div class="field"><label>计划标题 *</label><input id="pl-title" value="${esc(p.title)}"></div>
            <div class="row2">
              <div class="field"><label>分类 *</label><select id="pl-cat">${c.map((x) => '<option' + (x.name === p.category ? ' selected' : '') + '>' + esc(x.name) + '</option>').join('')}</select></div>
              <div class="field"><label>计划日期</label><input id="pl-date" type="date" value="${esc(p.plan_date)}"></div>
            </div>
            <div class="row2">
              <div class="field"><label>计划学时</label><input id="pl-hours" type="number" step="0.5" value="${esc(p.hours)}"></div>
              <div class="field"><label>状态</label><select id="pl-status">${['planned', 'done', 'cancelled'].map((s) => '<option value="' + s + '"' + (p.status === s ? ' selected' : '') + '>' + ({ planned: '计划中', done: '已完成', cancelled: '已取消' }[s]) + '</option>').join('')}</select></div>
            </div>
            <div class="field"><label>培训对象</label><input id="pl-target" value="${esc(p.target)}"></div>
            <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.updatePlan(${id})">保存</button></div>`);
        });
      });
    },
    updatePlan: async (id) => {
      try {
        await api('/api/training-plans/' + id, 'PUT', {
          title: $('#pl-title').value.trim(), category: $('#pl-cat').value, plan_date: $('#pl-date').value,
          hours: $('#pl-hours').value, target: $('#pl-target').value.trim(), status: $('#pl-status').value
        });
        closeSheet(); renderTrain();
      } catch (e) { alert(e.message); }
    },
    delPlan: async (id) => {
      if (!confirm('确定删除该计划？')) return;
      try { await api('/api/training-plans/' + id, 'DELETE'); renderTrain(); } catch (e) { alert(e.message); }
    },
    addTrainer: () => {
      openSheet(`
        <div class="sheet-title">新增教员档案<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>姓名 *</label><input id="tr-name"></div>
        <div class="field"><label>资质类别</label><input id="tr-cat" placeholder="如：非专业安保教员"></div>
        <div class="row2">
          <div class="field"><label>证书编号</label><input id="tr-cert"></div>
          <div class="field"><label>发证日期</label><input id="tr-cdate" type="date"></div>
        </div>
        <div class="row2">
          <div class="field"><label>有效期至</label><input id="tr-edate" type="date"></div>
        </div>
        <div class="field"><label>复训记录</label><textarea id="tr-refresh" rows="2"></textarea></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveTrainer()">保存</button></div>`);
    },
    saveTrainer: async () => {
      try {
        await api('/api/trainers', 'POST', {
          name: $('#tr-name').value.trim(), category: $('#tr-cat').value.trim(), cert_no: $('#tr-cert').value.trim(),
          cert_date: $('#tr-cdate').value, expire_date: $('#tr-edate').value, refresh_note: $('#tr-refresh').value.trim()
        });
        closeSheet(); renderTrain();
      } catch (e) { alert(e.message); }
    },
    editTrainer: (id) => {
      api('/api/trainers').then((list) => {
        const t = list.find((x) => String(x.id) === String(id));
        if (!t) { alert('未找到该教员档案'); return; }
        openSheet(`
          <div class="sheet-title">编辑教员档案<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="field"><label>姓名 *</label><input id="tr-name" value="${esc(t.name)}"></div>
          <div class="field"><label>资质类别</label><input id="tr-cat" value="${esc(t.category)}"></div>
          <div class="row2">
            <div class="field"><label>证书编号</label><input id="tr-cert" value="${esc(t.cert_no)}"></div>
            <div class="field"><label>发证日期</label><input id="tr-cdate" type="date" value="${esc(t.cert_date)}"></div>
          </div>
          <div class="row2">
            <div class="field"><label>有效期至</label><input id="tr-edate" type="date" value="${esc(t.expire_date)}"></div>
          </div>
          <div class="field"><label>复训记录</label><textarea id="tr-refresh" rows="2">${esc(t.refresh_note)}</textarea></div>
          <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.updateTrainer(${id})">保存</button></div>`);
      });
    },
    updateTrainer: async (id) => {
      try {
        await api('/api/trainers/' + id, 'PUT', {
          name: $('#tr-name').value.trim(), category: $('#tr-cat').value.trim(), cert_no: $('#tr-cert').value.trim(),
          cert_date: $('#tr-cdate').value, expire_date: $('#tr-edate').value, refresh_note: $('#tr-refresh').value.trim()
        });
        closeSheet(); renderTrain();
      } catch (e) { alert(e.message); }
    },
    delTrainer: async (id) => {
      if (!confirm('确定删除该教员档案？')) return;
      try { await api('/api/trainers/' + id, 'DELETE'); renderTrain(); } catch (e) { alert(e.message); }
    }
  });

  /* ===== 消息（阅后识别）===== */
  async function renderMsg() {
    const el = $('#page-msg');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const list = await api('/api/messages');
      const canSend = MYLV() >= 2;
      const isAdmin = MYLV() >= 5;
      el.innerHTML = `
        <div class="actions">
          ${canSend ? '<button class="btn sm" onclick="app.sendMsg()">＋ 发布通知</button>' : ''}
        </div>
        <div class="card"><h3>通知消息（阅后识别 ${list.filter((m) => !m.my_read).length} 条未读）</h3>
          ${list.map((m) => {
            const created = Date.parse(String(m.created_at).replace(' ', 'T'));
            const canRecall = (m.sender_id === ME.id || isAdmin) && (Date.now() - created) <= 20000;
            const secs = Math.max(0, Math.ceil((20000 - (Date.now() - created)) / 1000));
            return `<div class="list-item">
            <div class="ic">📢</div>
            <div class="body">
              <div class="t">${esc(m.title)} ${!m.my_read ? '<span class="badge unread">未读</span>' : '<span class="badge ok">已读</span>'} ${m.recalled ? '<span class="badge gray">已撤回</span>' : ''}</div>
              <div class="d">${esc(m.sender_name)} · ${m.created_at} · ${m.send_type === 'single' ? '单发' : '群发'}${m.send_type === 'single' && isAdmin ? '· 定向' : ''}</div>
            </div>
            <div class="act">
              ${canRecall ? `<button class="btn sm ghost recall-btn" onclick="app.recallMsg(${m.id})">撤回(${secs}s)</button>` : ''}
              <button class="btn sm ghost" onclick="app.openMsg(${m.id})">${m.my_read ? '查看' : '阅读'}</button>
              ${isAdmin ? '<button class="btn sm danger" onclick="app.delMsg(' + m.id + ')">删</button>' : ''}
            </div>
          </div>`;}).join('') || '<div class="empty">暂无消息</div>'}
        </div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  window.app = Object.assign(window.app || {}, {
    sendMsg: () => {
      openSheet(`
        <div class="sheet-title">发布通知<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>发送方式</label><select id="m-type"><option value="all">群发（全体人员）</option><option value="single">单发（指定人员）</option></select></div>
        <div class="field" id="m-target-wrap" style="display:none"><label>接收人</label><select id="m-target"></select></div>
        <div class="field"><label>标题 *</label><input id="m-title"></div>
        <div class="field"><label>内容</label><textarea id="m-content" rows="4"></textarea></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.pubMsg()">发布</button></div>`, '发布通知');
      api('/api/profiles').then((cs) => {
        const t = $('#m-target');
        if (t) t.innerHTML = cs.map((c) => `<option value="${c.id}">${esc(c.real_name || c.username)}${c.dept_id ? '' : ''}</option>`).join('');
      }).catch(() => {});
      const mt = $('#m-type');
      if (mt) mt.onchange = () => { const w = $('#m-target-wrap'); if (w) w.style.display = mt.value === 'single' ? '' : 'none'; };
    },
    pubMsg: async () => {
      try {
        const mt = $('#m-type');
        const single = mt && mt.value === 'single';
        await api('/api/messages', 'POST', { title: $('#m-title').value.trim(), content: $('#m-content').value.trim(), send_type: single ? 'single' : 'all', target_user_id: single ? Number($('#m-target').value) : null });
        closeSheet(); renderMsg(); refreshBadge();
      } catch (e) { alert(e.message); }
    },
    recallMsg: async (id) => {
      try { await api('/api/messages/' + id + '/recall', 'POST'); renderMsg(); refreshBadge(); } catch (e) { alert(e.message); }
    },
    openMsg: async (id) => {
      const list = await api('/api/messages');
      const m = list.find((x) => x.id === id);
      if (!m) return;
      const isAdmin = MYLV() >= 5;
      const body = !isAdmin ? '<div class="msg-content" style="color:#b45309">🔒 消息内容仅管理员可见（阅后识别）</div>' : `<pre class="msg-content">${esc(m.content || '（无正文）')}</pre>`;
      openSheet(`
        <div class="sheet-title">${esc(m.title)}${m.recalled ? ' <span class="badge gray">已撤回</span>' : ''}<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="muted" style="margin-bottom:8px;">${esc(m.sender_name)} · ${m.created_at} · ${m.send_type === 'single' ? '单发' : '群发'} · 已读 ${m.read_count} 人</div>
        ${body}`);
      if (!m.my_read) { await api('/api/messages/' + id + '/read', 'POST'); renderMsg(); refreshBadge(); }
    },
    delMsg: async (id) => {
      if (!confirm('删除该通知？')) return;
      try { await api('/api/messages/' + id, 'DELETE'); renderMsg(); refreshBadge(); } catch (e) { alert(e.message); }
    }
  });

  /* ===== 文件（v5.1：在线阅读/权限分级/压缩包解压） ===== */
  const FILE_ICON = (name) => {
    const n = String(name).toLowerCase();
    if (n.endsWith('.pdf')) return '📕';
    if (n.endsWith('.doc') || n.endsWith('.docx')) return '📘';
    if (n.endsWith('.xls') || n.endsWith('.xlsx')) return '📗';
    if (n.endsWith('.ppt') || n.endsWith('.pptx')) return '📙';
    if (n.endsWith('.zip') || n.endsWith('.rar') || n.endsWith('.7z') || n.endsWith('.tar') || n.endsWith('.gz')) return '📦';
    if (/\.(png|jpe?g|gif|webp|bmp)$/.test(n)) return '🖼';
    if (n.endsWith('.txt') || n.endsWith('.md') || n.endsWith('.csv') || n.endsWith('.json')) return '📄';
    return '📄';
  };


  /* ===== v5.7 全局检索 / 业务问答（本地自然语言解析，数据不出内网）===== */
  async function renderSearch() {
    const el = $('#page-search');
    const q = (document.getElementById('sq') || {}).value || '';
    el.innerHTML = `
      <div class="search-bar"><input id="sq" placeholder="自然语言检索，如：上个月的围界检查 / 今年的培训 / 张三的请假 / 待整改的问题" value="${esc(q)}" onkeydown="if(event.key==='Enter')app.doSearch()"><button class="btn" onclick="app.doSearch()">检索</button></div>
      ${q ? '' : `<div class="card"><h3>试试这样问</h3>
        <div class="chips">
          <span class="chip" onclick="app.q('上个月的围界检查')">上个月的围界检查</span>
          <span class="chip" onclick="app.q('今年的培训')">今年的培训</span>
          <span class="chip" onclick="app.q('待整改的问题')">待整改的问题</span>
          <span class="chip" onclick="app.q('近7天的审批')">近7天的审批</span>
          <span class="chip" onclick="app.q('本月的会议')">本月的会议</span>
          <span class="chip" onclick="app.q('车辆台账')">车辆台账</span>
          <span class="chip" onclick="app.q('统计今年的奖惩')">统计今年的奖惩</span>
          <span class="chip" onclick="app.q('生成上月工作报告')">生成上月工作报告</span>
          <span class="chip" onclick="app.q('本月的待办建议')">本月的待办建议</span>
        </div></div>`}
      <div id="sq-result"></div>`;
    if (q) app.doSearch();
  }


  /* ===== v5.11 AI 智能体工作台 + v8.1 AI 对话助手/智能录入（对标 Cordys CRM Skills·MaxKB 智能体）===== */
  let aiChatLog = [];
  async function renderAI() {
    const el = $('#page-ai');
    // v8.7 AI 工作台全员可用（专家团：通用/数据/制度/写作）
    if (typeof window.aiExpert === 'undefined') window.aiExpert = 'general';
    el.innerHTML = `
      <div class="card" style="background:linear-gradient(135deg,#1667d9,#4a8df5);color:#fff;border:none;padding:16px;">
        <div style="font-size:20px;font-weight:700;">🤖 AI 工作台</div>
        <div style="font-size:13px;opacity:.92;margin-top:4px;">专家团协作 · 对话问数据 · 知识库出处可溯 · 敏感任务本地处理 · 全过程留痕</div>
      </div>
      <!-- v8.7 专家团（对标 OneBox 多智能体专家团） -->
      <div class="sub-tabs" style="margin-top:10px;">
        <div class="sub-tab${window.aiExpert === 'general' ? ' on' : ''}" onclick="app.aiExpert('general')">💬 通用</div>
        <div class="sub-tab${window.aiExpert === 'data' ? ' on' : ''}" onclick="app.aiExpert('data')">📊 数据专家</div>
        <div class="sub-tab${window.aiExpert === 'kb' ? ' on' : ''}" onclick="app.aiExpert('kb')">📚 制度专家</div>
        <div class="sub-tab${window.aiExpert === 'write' ? ' on' : ''}" onclick="app.aiExpert('write')">✍️ 写作专家</div>
      </div>
      <div class="muted" style="font-size:12px;padding:4px 6px;" id="ai-expert-hint">${window.aiExpert === 'general' ? '通用助手：查档案、培训统计、最近检查、待办概览；说「录培训/录检查」可智能录入。' : (window.aiExpert === 'data' ? '数据专家：自然语言直接查库（受控取数），例如「今年培训统计」「最近检查记录」「本月待办任务」，敏感字段自动脱敏、全程留痕。' : (window.aiExpert === 'kb' ? '制度专家：从知识库文档中检索作答，命中片段标注出处，可回原文核对。' : '写作专家：按业务数据与知识库素材生成报告/纪要结构建议，可让数据专家先取数。'))}</div>
      <!-- AI 对话助手 -->
      <div class="card"><h3><svg class="lg-ic"><use href="#i-chat"/></svg> AI 对话助手</h3>
        <div id="ai-chat" style="max-height:340px;overflow-y:auto;padding:4px 2px;">${aiChatLog.map((m) => aiChatBubble(m)).join('') || '<div class="muted" style="font-size:13px;padding:6px;">还没有对话，试试下面：<br>· 查马福轩的档案<br>· 培训统计<br>· 录培训：张海亮 消防演练 2026-05-20 4学时</div>'}</div>
        <div style="display:flex;gap:8px;margin-top:8px;">
          <input id="ai-chat-q" placeholder="输入问题或录入指令…" style="flex:1;padding:11px 12px;border:1px solid #d0d7de;border-radius:8px;font-size:15px;background:#fff;" onkeydown="if(event.key==='Enter')app.aiChatSend()">
          <button class="btn" style="border-radius:8px;" onclick="app.aiChatSend()">发送</button>
          <button class="btn" style="border-radius:8px;background:#f3f4f6;color:#374151;" onclick="app.aiChatVoice()">🎤</button>
        </div>
        <div id="ai-parse" style="margin-top:8px;"></div>
      </div>
      <!-- 原有：自然语言取数 -->
      <div style="display:flex;gap:8px;padding:12px 2px 6px;">
        <input id="ai-q" placeholder="问一句，例如：本周哪些整改还没闭环？" style="flex:1;padding:11px 12px;border:1px solid #d0d7de;border-radius:8px;font-size:15px;background:#fff;" onkeydown="if(event.key==='Enter')app.aiAsk()">
        <button class="btn" style="border-radius:8px;" onclick="app.aiAsk()">取数</button>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:6px;padding:4px 2px 10px;">
        ${['本周检查闭环情况','哪些整改超期','哪些任务超期','哪些培训快到期','今天谁值班','今年培训统计','生成本月工作报告','待办概览'].map((c) => `<span class="chip" style="background:#eef4ff;color:#1667d9;" onclick="app.aiQuick('${c}')">${c}</span>`).join('')}
      </div>
      <div id="ai-result"></div>
      <div class="card"><h3><svg class="lg-ic"><use href="#i-alarm"/></svg> 场景预警顾问<span style="font-weight:400;font-size:12px;color:#9ca3af;">（危险在哪 · 卡在谁手上 · 先催哪一件）</span></h3><div id="ai-alerts"><div class="muted">加载中…</div></div></div>
      <div class="card"><h3><svg class="lg-ic"><use href="#i-clock"/></svg> 问询与动作留痕</h3><div id="ai-history"><div class="muted">加载中…</div></div></div>
      ${MYLV() >= 3 ? `<div class="card" style="border-left:3px solid #7c5cff;"><h3><svg class="lg-ic"><use href="#i-gear"/></svg> 大模型接入（管理员）</h3>
        <div id="ai-setup"><div class="muted">加载中…</div></div></div>` : ''}`;
    app.aiLoadAlerts();
    app.aiLoadHistory();
    if (MYLV() >= 3) app.aiLoadSetup();
  }
  function aiChatBubble(m) {
    const srcTag = m.src === 'bridge' ? '数桥取数' : (m.src === 'kb' ? '知识库' : (m.src === 'write' ? '写作专家' : (m.src === 'llm' ? '大模型' : '本地引擎')));
    return `<div style="margin:6px 0;display:flex;${m.me ? 'justify-content:flex-end;' : ''}"><div style="max-width:92%;padding:9px 12px;border-radius:12px;font-size:14px;white-space:pre-wrap;${m.me ? 'background:#1667d9;color:#fff;' : 'background:#f3f4f6;color:#1f2937;'}">${esc(m.t)}${m.sensitive ? '<div style="font-size:11px;color:#b45309;margin-top:3px;">🔒 安全会话：敏感内容本地处理，未外发</div>' : ''}${m.src ? `<div style="font-size:11px;opacity:.65;margin-top:3px;">来源：${srcTag}</div>` : ''}${m.extra || ''}</div></div>`;
  }
  // v8.7 数桥取数结果表格渲染
  function aiBridgeTable(d) {
    if (!d || !d.rows || !d.rows.length) return '';
    const cols = Object.keys(d.rows[0]);
    return `<div class="card" style="border-left:3px solid #7c5cff;margin-top:8px;"><h3 style="font-size:14px;">📊 数桥受控取数（${d.count} 行 · 脱敏后返回）</h3>
      <div style="overflow-x:auto;margin-top:6px;"><table style="border-collapse:collapse;width:100%;font-size:12px;"><thead><tr>${cols.map((c) => `<th style="border:1px solid #d0d7de;padding:5px 7px;background:#f3f4f6;text-align:left;white-space:nowrap;">${esc(c.replace(/^[a-z_]+\./, ''))}</th>`).join('')}</tr></thead><tbody>${d.rows.slice(0, 12).map((r) => `<tr>${cols.map((c) => `<td style="border:1px solid #e5e7eb;padding:5px 7px;white-space:nowrap;">${esc(r[c] == null ? '' : String(r[c]))}</td>`).join('')}</tr>`).join('')}</tbody></table></div>
      ${d.plan && d.plan.sql ? `<div class="muted" style="font-size:11px;margin-top:6px;">受控 SQL：<code style="word-break:break-all;">${esc(d.plan.sql)}</code></div>` : ''}</div>`;
  }
  // v8.7 知识库出处卡片
  function aiKbHits(d) {
    if (!d || !d.hits || !d.hits.length) return '';
    return `<div class="card" style="border-left:3px solid #16a34a;margin-top:8px;"><h3 style="font-size:14px;">📚 知识库出处（${d.hits.length} 条，可回原文核对）</h3>
      ${d.summary ? `<div class="d" style="font-size:13px;padding:4px 0 8px;">${esc(d.summary)}</div>` : ''}
      ${d.hits.map((h) => `<div style="padding:6px 0;border-top:1px dashed #e5e7eb;"><div style="font-size:13px;color:#1667d9;font-weight:600;">${esc(h.title)} <span class="badge" style="background:#eef4ff;color:#1667d9;font-size:11px;">${esc(h.category || '')}</span></div><div style="font-size:12px;color:#4b5563;margin-top:3px;">${esc(h.snippet)}</div>${h.file_name ? `<div style="font-size:11px;color:#9ca3af;margin-top:3px;">📄 ${esc(h.file_name)}</div>` : ''}</div>`).join('')}</div>`;
  }

  /* ===== v8.7 数桥管理（OneBox「数桥」对标：语义层词典 + 数据授权 + 数据资产）===== */
  let bridgeTab = 'assets';
  async function renderBridge() {
    const el = $('#page-bridge');
    if (MYLV() < 4) { el.innerHTML = '<div class="card" style="padding:40px;text-align:center;color:#9ca3af;font-size:14px;">仅管理员可管理数桥</div>'; return; }
    el.innerHTML = `
      <div class="card" style="background:linear-gradient(135deg,#5b21b6,#7c3aed);color:#fff;border:none;padding:16px;">
        <div style="font-size:20px;font-weight:700;">🌉 数桥 · 受控取数</div>
        <div style="font-size:13px;opacity:.92;margin-top:4px;">自然语言 → 受控 SQL → 授权校验 → 脱敏返回 → 全程留痕（对标 OneBox 数桥，数据不导出）</div>
      </div>
      <div class="sub-tabs" style="margin-top:10px;">
        <div class="sub-tab${bridgeTab === 'assets' ? ' on' : ''}" onclick="app.bridgeTab('assets')">数据资产</div>
        <div class="sub-tab${bridgeTab === 'semantics' ? ' on' : ''}" onclick="app.bridgeTab('semantics')">语义层</div>
        <div class="sub-tab${bridgeTab === 'grants' ? ' on' : ''}" onclick="app.bridgeTab('grants')">数据授权</div>
      </div>
      <div id="bridge-panel"><div class="muted">加载中…</div></div>`;
    app.bridgeLoad();
  }
  async function bridgeLoad() {
    const el = document.getElementById('bridge-panel');
    if (!el) return;
    try {
      if (bridgeTab === 'assets') {
        const tables = await api('/api/bridge/tables') || [];
        el.innerHTML = `<div class="card"><h3>可查询数据资产（${tables.length} 张表 · 白名单受控）</h3>
          ${tables.map((t) => `<div class="list-item">
            <div class="ic">🗄️</div>
            <div class="body">
              <div class="t">${esc(t.label)} <span class="muted" style="font-size:12px;">${esc(t.table)}</span> ${t.grants && t.grants.length ? '<span class="badge ok">已授权' + t.grants.length + ' 条</span>' : '<span class="badge gray">未授权</span>'}</div>
              <div class="d">可查字段：${(t.fields || []).map((f) => esc(f)).join('、')}</div>
              ${t.semantics && t.semantics.length ? `<div class="d" style="color:#7c3aed;">语义映射：${t.semantics.map((s) => esc(s.biz_term) + '→' + esc(s.column_label || s.column_name)).join('、')}</div>` : ''}
            </div>
          </div>`).join('') || '<div class="empty">暂无数据资产</div>'}
          <div class="muted" style="font-size:12px;padding:4px 6px;">行级授权按「数据授权」配置；敏感字段（手机号/身份证等）自动脱敏；每次取数写入操作审计。未授权表的取数将被拒绝。</div></div>`;
      } else if (bridgeTab === 'semantics') {
        const list = await api('/api/bridge/fields') || [];
        el.innerHTML = `<div class="card"><h3>语义层词典（业务词 → 库表字段）</h3>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:8px;font-size:14px;margin-bottom:10px;">
            <div>业务词<input id="sf-term" placeholder="如：学时" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
            <div>表名<input id="sf-table" placeholder="如：train_records" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
            <div>字段<input id="sf-col" placeholder="如：hours" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
            <div>显示名<input id="sf-label" placeholder="如：学时" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
            <div>备注<input id="sf-note" placeholder="可选" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
          </div>
          <div style="margin-bottom:12px;display:flex;gap:8px;align-items:center;"><button class="btn sm" onclick="app.bridgeAddField()">＋ 添加映射</button><span class="muted" style="font-size:12px;">映射后问「学时统计」可直接定位到 train_records.hours</span></div>
          ${list.map((s) => `<div class="list-item">
            <div class="ic">🧠</div>
            <div class="body">
              <div class="t">${esc(s.biz_term)} <span class="muted" style="font-size:12px;">→ ${esc(s.table_name)}.${esc(s.column_name)}</span> ${s.mask ? '<span class="badge warn">脱敏</span>' : ''}</div>
              <div class="d">显示名：${esc(s.column_label || '')}${s.note ? ' · 备注：' + esc(s.note) : ''}</div>
            </div>
            <div class="act"><button class="btn sm danger" onclick="app.bridgeDelField(${s.id})">删</button></div>
          </div>`).join('') || '<div class="empty">暂无映射，添加后数桥可精确理解业务词</div>'}</div>`;
      } else {
        const tables = await api('/api/bridge/tables') || [];
        const allGrants = [];
        tables.forEach((t) => (t.grants || []).forEach((g) => allGrants.push(Object.assign({ table: t.table, table_label: t.label }, g))));
        el.innerHTML = `<div class="card"><h3>数据授权（角色 × 表 × 行范围）</h3>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:8px;font-size:14px;margin-bottom:10px;">
            <div>角色<select id="gr-role" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"><option>admin</option><option>leader</option><option>all</option></select></div>
            <div>数据表<select id="gr-table" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;">${tables.map((t) => `<option value="${t.table}">${esc(t.label)}（${t.table}）</option>`).join('')}</select></div>
            <div>行范围<select id="gr-scope" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"><option value="all">全部行</option><option value="mine">仅本人数据</option><option value="dept">仅本部门</option></select></div>
          </div>
          <div style="margin-bottom:12px;"><button class="btn sm" onclick="app.bridgeAddGrant()">＋ 添加授权</button> <span class="muted" style="font-size:12px;">行范围：mine=只看本人记录；dept=看本部门；all=全部（需谨慎）</span></div>
          ${allGrants.map((g) => `<div class="list-item">
            <div class="ic">🔐</div>
            <div class="body">
              <div class="t">${esc(g.table_label || g.table)} <span class="badge" style="background:#eef4ff;color:#1667d9;">${esc(g.role)}</span></div>
              <div class="d">行范围：${g.row_scope === 'all' ? '全部' : (g.row_scope === 'mine' ? '仅本人' : '本部门')} ${g.column_name && g.column_name !== '*' ? ' · 字段：' + esc(g.column_name) : ''}</div>
            </div>
            <div class="act"><button class="btn sm danger" onclick="app.bridgeDelGrant(${g.id})">撤销</button></div>
          </div>`).join('') || '<div class="empty">暂无授权配置，未授权表默认拒绝取数</div>'}</div>`;
      }
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  /* ===== v8.7 操作审计 + 用量统计（OneBox「组织/授权/审计」+「知识沉淀与运营」对标）===== */
  let oplogDays = 7;
  async function renderOplog() {
    const el = $('#page-oplog');
    if (MYLV() < 3) { el.innerHTML = '<div class="card" style="padding:40px;text-align:center;color:#9ca3af;font-size:14px;">仅领导及以上可查看审计日志</div>'; return; }
    el.innerHTML = `
      <div class="card" style="background:linear-gradient(135deg,#374151,#6b7280);color:#fff;border:none;padding:16px;">
        <div style="font-size:20px;font-weight:700;">🛡 操作审计与用量</div>
        <div style="font-size:13px;opacity:.92;margin-top:4px;">谁 · 何时 · 做了什么 · 结果如何 —— 全量留痕可检索；AI 用量按人/类型统计（对标 OneBox 审计日志 + 知识沉淀运营）</div>
      </div>
      <div id="oplog-stats"><div class="muted">加载中…</div></div>
      <div class="card"><h3><svg class="lg-ic"><use href="#i-search"/></svg> 审计日志检索</h3>
        <div style="display:flex;gap:8px;">
          <input id="oplog-q" placeholder="按操作者/动作/对象关键词检索…" style="flex:1;padding:10px 12px;border:1px solid #d0d7de;border-radius:8px;font-size:14px;" onkeydown="if(event.key==='Enter')app.oplogSearch()">
          <button class="btn" style="border-radius:8px;" onclick="app.oplogSearch()">检索</button>
        </div>
        <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap;">
          ${[1, 7, 30, 90].map((d) => `<span class="chip${oplogDays === d ? '' : ''}" style="${oplogDays === d ? 'background:#374151;color:#fff;' : 'background:#f3f4f6;color:#374151;'}" onclick="app.oplogDays(${d})">近${d}天</span>`).join('')}
        </div>
        <div id="oplog-list"><div class="muted">加载中…</div></div>
      </div>`;
    app.oplogSearch();
  }
  async function oplogSearch() {
    const el = document.getElementById('oplog-list');
    const st = document.getElementById('oplog-stats');
    if (!el || !st) return;
    const q = (document.getElementById('oplog-q') ? document.getElementById('oplog-q').value.trim() : '');
    try {
      const list = await api('/api/audit/logs?days=' + oplogDays + (q ? '&q=' + encodeURIComponent(q) : '')) || [];
      el.innerHTML = `<h3 style="font-size:15px;">审计记录（${list.length} 条${q ? ' · 关键词「' + esc(q) + '」' : ''}）</h3>
        ${list.map((a) => `<div class="list-item">
          <div class="ic">${a.result === 'fail' || a.result === 'deny' ? '⛔' : '✓'}</div>
          <div class="body">
            <div class="t">${esc(a.action)} ${a.result && a.result !== 'ok' ? '<span class="badge bad">' + esc(a.result) + '</span>' : '<span class="badge ok">成功</span>'}</div>
            <div class="d">${esc(a.user_name || a.user_id || '')} · ${esc(a.created_at || '')}${a.target ? ' · 对象：' + esc(a.target) : ''}</div>
            ${a.detail ? `<div class="d" style="color:#6b7280;">${esc(a.detail)}</div>` : ''}
          </div>
        </div>`).join('') || '<div class="empty">无审计记录</div>'}
        <div class="muted" style="font-size:12px;padding:4px 6px;">记录范围：登录、数桥取数、AI 会话、审批操作、配置变更、语义层/授权维护等；支持按操作者/动作/对象检索。</div>`;
      const d = await api('/api/ai/stats?days=' + Math.max(oplogDays, 30)) || {};
      st.innerHTML = `<div class="stat-grid">
        <div class="stat"><div class="num">${d.total || 0}</div><div class="lbl">AI 调用合计</div></div>
        <div class="stat"><div class="num">${d.audit_actions || 0}</div><div class="lbl">审计动作</div></div>
      </div>
      ${d.by_kind && d.by_kind.length ? `<div class="card" style="margin-top:8px;"><h3 style="font-size:15px;">📊 AI 用量 · 按类型（近${Math.max(oplogDays, 30)}天）</h3>${d.by_kind.map((k) => `<div style="display:flex;justify-content:space-between;padding:5px 2px;border-bottom:1px dashed #e5e7eb;font-size:13px;"><span>${esc(k.kind || '')}</span><span style="color:#1667d9;font-weight:600;">${k.c}</span></div>`).join('')}</div>` : ''}
      ${d.by_user && d.by_user.length ? `<div class="card" style="margin-top:8px;"><h3 style="font-size:15px;">👤 AI 用量 · 按用户</h3>${d.by_user.map((u) => `<div style="display:flex;justify-content:space-between;padding:5px 2px;border-bottom:1px dashed #e5e7eb;font-size:13px;"><span>${esc(u.un || '')}</span><span style="color:#1667d9;font-weight:600;">${u.c}</span></div>`).join('')}</div>` : ''}`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; st.innerHTML = ''; }
  }

  /* ===== v5.6 统一待办中心（聚合审批/检查审核/限期整改/会议任务）===== */
  async function renderTodo() {
    const el = $('#page-todo');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const { todos, count, advice } = await api('/api/todos');
      el.innerHTML = `
        <div class="stat-grid">
          <div class="stat"><div class="num">${count.total}</div><div class="lbl">全部待办</div></div>
          <div class="stat"><div class="num" style="${count.overdue ? 'color:#e74c3c;' : ''}">${count.overdue}</div><div class="lbl">已超期</div></div>
          <div class="stat"><div class="num" style="${count.soon ? 'color:#b45309;' : ''}">${count.soon}</div><div class="lbl">48h内到期</div></div>
        </div>
        ${advice && advice.length ? `<div class="card" style="border-left:3px solid #f59e0b;"><h3><svg class="lg-ic"><use href="#i-dash"/></svg> 工作流建议</h3>${advice.map((a) => `<div class="d">${esc(a)}</div>`).join('')}<div style="margin-top:8px;"><button class="btn" style="font-size:13px;padding:5px 12px;" onclick="app.actAdvice()">📌 采纳为任务</button></div></div>` : ''}
        <div class="card"><h3>待办清单（${todos.length}）</h3>
          ${todos.map((t) => `<div class="list-item" style="${t.overdue ? 'border-left:3px solid #e74c3c;' : (t.soon ? 'border-left:3px solid #f59e0b;' : '')}">
            <div class="ic">${t.icon || '📥'}</div>
            <div class="body">
              <div class="t">${esc(t.title)} ${t.overdue ? `<span class="badge bad">超期${t.overdue_days}天</span>` : (t.soon ? '<span class="badge warn">临期</span>' : '')}</div>
              <div class="d">${t.type ? esc(t.type) + ' · ' : ''}${t.who ? '发起人：' + esc(t.who) + ' · ' : ''}${t.at ? '时间：' + esc(t.at) + ' · ' : ''}${t.level_name ? '需「' + esc(t.level_name) + '」处理' : ''}</div>
            </div>
            <div class="act"><button class="btn sm" onclick="app.todoGo('${t.kind}',${t.id})">${esc(t.act)}</button></div>
          </div>`).join('') || '<div class="empty">暂无待办，所有流程均处理完毕</div>'}
        </div>
        <div class="muted" style="font-size:12px;padding:4px 6px;">说明：待办按「已超期 → 临期 → 时间先后」排序；超期项红色标出。审批 48 小时未处理、限期整改到期未提交、会议任务到期未完成均视为超期。</div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  /* ===== v5.6 车辆/设备台账（运行手册第五章：每日早检查 / 周五车场日）===== */
  const VEHICLE_ITEMS = ['启动状况', '灯光信号', '制动系统', '轮胎气压', '油量/电量', '随车器材（水带/灭火器/破拆工具）', '清洁状况'];
  let assetTab = 'list';
  async function renderAsset() {
    const el = $('#page-asset');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const assets = await api('/api/assets');
      const checks = await api('/api/asset-checks');
      const uses = await api('/api/asset-uses');
      const repairs = await api('/api/asset-repairs');
      const lv = MYLV();
      const canMng = lv >= 2;
      const stBadge = (s) => s === '在用' ? '<span class="badge ok">在用</span>' : (s === '维修中' ? '<span class="badge warn">维修中</span>' : (s === '停用' ? '<span class="badge gray">停用</span>' : '<span class="badge bad">报废</span>'));
      el.innerHTML = `
        <div class="sub-tabs">
          <div class="sub-tab${assetTab === 'list' ? ' on' : ''}" onclick="app.assetTab('list')">台账</div>
          <div class="sub-tab${assetTab === 'check' ? ' on' : ''}" onclick="app.assetTab('check')">每日检查</div>
          <div class="sub-tab${assetTab === 'use' ? ' on' : ''}" onclick="app.assetTab('use')">使用登记</div>
          <div class="sub-tab${assetTab === 'repair' ? ' on' : ''}" onclick="app.assetTab('repair')">维修保养</div>
        </div>
        <div class="sub-panel${assetTab === 'list' ? ' show' : ''}">
          ${canMng ? '<div class="actions"><button class="btn sm" onclick="app.assetAdd()">＋ 新增台账</button></div>' : '<div class="muted" style="font-size:13px;padding:4px 6px;">台账管理（新增/编辑）需班组长及以上权限，全员可查看。</div>'}
          <div class="card"><h3>车辆/设备台账（${assets.length}）</h3>
            ${assets.map((a) => `<div class="list-item">
              <div class="ic">${a.category === '车辆' ? '🚒' : (a.category === '消防装备' ? '🧯' : '🛠️')}</div>
              <div class="body">
                <div class="t">${esc(a.name)} ${a.no ? '<span class="muted" style="font-size:12px;">(' + esc(a.no) + ')</span>' : ''} ${stBadge(a.status)}${a.in_use ? ' <span class="badge warn">使用中</span>' : ''}</div>
                <div class="d">${esc(a.category || '')}${a.model ? ' · ' + esc(a.model) : ''}${a.owner ? ' · 责任人：' + esc(a.owner) : ''}${a.check_count ? ' · 已检查 ' + a.check_count + ' 次' : ''}</div>
              </div>
              <div class="act">
                <button class="btn sm ghost" onclick="app.assetCheck(${a.id})">检查</button>
                <button class="btn sm ghost" onclick="app.assetUse(${a.id})">登记使用</button>
                ${canMng ? '<button class="btn sm ghost" onclick="app.assetEdit(' + a.id + ')">编辑</button>' : ''}
                ${lv >= 4 ? '<button class="btn sm danger" onclick="app.assetDel(' + a.id + ')">删</button>' : ''}
              </div>
            </div>`).join('') || '<div class="empty">暂无台账，请班组长及以上人员在「＋ 新增台账」中录入</div>'}
          </div>
        </div>
        <div class="sub-panel${assetTab === 'check' ? ' show' : ''}">
          <div class="actions"><button class="btn sm" onclick="app.assetCheckNew()">＋ 每日检查</button></div>
          <div class="card"><h3>检查记录（依据手册：每日 10:00—10:30 早检查）</h3>
            ${checks.map((c) => `<div class="list-item">
              <div class="ic">🔍</div>
              <div class="body">
                <div class="t">${esc(c.asset_name)} · ${c.check_date} ${c.start_time ? c.start_time + '—' + (c.end_time || '') : ''} ${c.result === '正常' ? '<span class="badge ok">正常</span>' : '<span class="badge bad">异常</span>'}</div>
                <div class="d">检查人：${esc(c.checker_name)} ${c.summary ? ' · ' + esc(c.summary) : ''}</div>
              </div>
            </div>`).join('') || '<div class="empty">暂无检查记录</div>'}
          </div>
        </div>
        <div class="sub-panel${assetTab === 'use' ? ' show' : ''}">
          <div class="card"><h3>使用登记（${uses.filter(x => x.status === '使用中').length} 项使用中）</h3>
            ${uses.map((x) => `<div class="list-item">
              <div class="ic">🚗</div>
              <div class="body">
                <div class="t">${esc(x.asset_name)} · ${esc(x.user_name)} ${x.status === '使用中' ? '<span class="badge warn">使用中</span>' : '<span class="badge ok">已归还</span>'}</div>
                <div class="d">用途：${esc(x.purpose || '—')} · ${x.start_time ? '开始 ' + esc(x.start_time) : ''}${x.end_time ? ' · 归还 ' + esc(x.end_time) : ''}</div>
              </div>
              <div class="act">${x.status === '使用中' ? '<button class="btn sm ghost" onclick="app.assetReturn(' + x.id + ')">归还</button>' : ''}</div>
            </div>`).join('') || '<div class="empty">暂无使用记录，从台账点「登记使用」即可</div>'}
          </div>
        </div>
        <div class="sub-panel${assetTab === 'repair' ? ' show' : ''}">
          ${canMng ? '<div class="actions"><button class="btn sm" onclick="app.assetRepairNew()">＋ 报修</button></div>' : ''}
          <div class="card"><h3>维修保养记录</h3>
            ${repairs.map((r) => `<div class="list-item">
              <div class="ic">🔧</div>
              <div class="body">
                <div class="t">${esc(r.asset_name)} ${r.status === '维修中' ? '<span class="badge warn">维修中</span>' : '<span class="badge ok">已完成</span>'}</div>
                <div class="d">${esc(r.content)} · 报修：${esc(r.reporter_name)}${r.start_date ? ' · ' + esc(r.start_date) : ''}${r.end_date ? ' — ' + esc(r.end_date) : ''}</div>
              </div>
              <div class="act">${r.status === '维修中' && canMng ? '<button class="btn sm ok" onclick="app.assetRepairClose(' + r.id + ')">完工</button>' : ''}</div>
            </div>`).join('') || '<div class="empty">暂无维修记录</div>'}
          </div>
        </div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  async function renderFile() {
    const el = $('#page-file');
    const q = (document.getElementById('file-q') || {}).value || '';
    const cur = window.FILE_FOLDER || 'all';
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const folders = await api('/api/files/folders');
      window.__folders = folders;
      const qs = cur !== 'all' && cur !== 'trash' ? '?folder=' + cur : '';
      const q2 = q ? (qs ? '&' : '?') + 'q=' + encodeURIComponent(q) : '';
      const list = await api('/api/files' + qs + q2);
      const trash = cur === 'trash' ? await api('/api/files/trash') : [];
      const canUp = MYLV() >= 1 || (ME.grants || []).includes('file_upload');
      const canDl = MYLV() >= 1 || (ME.grants || []).includes('file_download');
      const isMg = MYLV() >= 4;
      const sel = window.FILE_SEL || [];
      const LEVELS = { 0: '全员可见', 1: '在职及以上', 2: '班组长及以上', 3: '部门领导及以上', 5: '仅管理员' };
      const fname = (id) => { const f0 = folders.find((x) => String(x.id) === String(id)); return f0 ? f0.name : (String(id) === '_sig' ? '签名档案' : '未分类'); };
      const folderChips = '<div class="file-tabs">' +
        '<span class="file-tab' + (cur === 'all' ? ' on' : '') + '" onclick="app.fileFolder(\'all\')">全部</span>' +
        folders.map((f0) => '<span class="file-tab' + (cur === String(f0.id) ? ' on' : '') + '" onclick="app.fileFolder(\'' + f0.id + '\')">' + esc(f0.name) + '<i>' + f0.cnt + '</i></span>').join('') +
        (isMg ? '<span class="file-tab' + (cur === 'trash' ? ' on' : '') + ' t-trash" onclick="app.fileFolder(\'trash\')">回收站</span>' : '') +
        '</div>';
      const isImg = (f) => /\.(jpg|jpeg|png|gif|webp|bmp)$/i.test(String(f.name || ''));
      const row = (f, extra) => '<div class="list-item">' + extra + (isImg(f) ? '<span class="f-thumb" data-id="' + f.id + '"></span>' : '') + '<div class="body"><div class="t">' + esc(f.name) + '</div><div class="d">' + fmtSize(f.size) + ' · ' + esc(f.uploader_name) + ' · ' + (f.created_at || '') + (f.deleted_at ? ' · 删除于 ' + f.deleted_at : '') + ' · <span class="badge gray">' + fname(f.folder_id) + '</span></div></div></div>';
      el.innerHTML = `
        <div class="actions">
          ${canUp ? '<button class="btn sm" onclick="app.uploadFile()">＋ 上传文件</button>' : '<div class="muted" style="font-size:13px;">新人暂无上传权限，可在「审批-发起申请」申请「文件上传」</div>'}
          ${isMg ? '<button class="btn sm ghost" onclick="app.fileNewFolder()">＋ 新建文件夹</button>' : ''}
          ${MYLV() >= 2 ? '<button class="btn sm ghost" onclick="app.filePermReqs()">📄 权限审批</button>' : ''}
        </div>
        ${folderChips}
        <div class="search-bar"><input id="file-q" placeholder="搜索：文件名 / 上传人 / 类型(.pdf,.jpg) / 日期" value="${esc(q)}" onkeydown="if(event.key==='Enter')app.fileSearch()"><button class="btn sm" onclick="app.fileSearch()">搜索</button>${q ? '<button class="btn sm ghost" onclick="app.fileClear()">清空</button>' : ''}</div>
        <div class="card"><h3>${cur === 'trash' ? '回收站（删除超过半年自动彻底清理）' : (cur === 'all' ? '共享文件（' + list.length + '）' : '「' + fname(cur) + '」（' + list.length + '）')}${q ? '<span class="muted" style="font-size:12px;"> 检索“' + esc(q) + '”</span>' : ''}<span class="more" onclick="app.fileHelp()">权限说明</span></h3>
          ${cur === 'trash'
            ? (trash.map((f) => '<div class="list-item"><div class="ic">' + FILE_ICON(f.name) + '</div><div class="body"><div class="t">' + esc(f.name) + '</div><div class="d">' + fmtSize(f.size) + ' · ' + esc(f.uploader_name) + ' · 删除于 ' + f.deleted_at + '</div></div><div class="act"><button class="btn sm ghost" onclick="app.fileRestore(' + f.id + ')">恢复</button><button class="btn sm danger" onclick="app.filePurge(' + f.id + ')">彻底删除</button></div></div>').join('') || '<div class="empty">回收站为空</div>')
            : (list.map((f) => {
              const secBadges = ((f.readonly || f.no_download) ? '<span class="badge warn">🔒仅读</span>' : '') + (f.watermark ? '<span class="badge warn">💧水印</span>' : '') + (f.read_apply ? '<span class="badge warn">读需申请</span>' : '') + (f.download_apply ? '<span class="badge warn">下需审批</span>' : '');
              const canDlRow = canDl && !(f.readonly || f.no_download);
              const canSec = MYLV() >= 5;
              return '<div class="list-item"><div class="ic"><label class="fck"><input type="checkbox" ' + (sel.includes(f.id) ? 'checked' : '') + ' onchange="app.fileSel(' + f.id + ', this.checked)"></label>' + FILE_ICON(f.name) + '</div><div class="body"><div class="t">' + esc(f.name) + '</div><div class="d">' + fmtSize(f.size) + ' · ' + esc(f.uploader_name) + ' · ' + (f.created_at || '') + ' · <span class="badge gray">' + fname(f.folder_id) + '</span>' + (f.share_flag ? ' · 共享' : ' · 仅本人') + secBadges + (f.size < 100 ? ' <span class="badge bad">已损坏</span>' : '') + '</div></div><div class="act">' + (f.size < 100 ? '' : '<button class="btn sm ghost" onclick="app.openFile(' + f.id + ',\'' + esc(f.name).replace(/'/g, "\\'") + '\')">阅读</button>') + (f.size < 100 ? '' : (canDlRow ? '<button class="btn sm ghost" onclick="app.downFile(' + f.id + ',\'' + esc(f.name).replace(/'/g, "\\'") + '\')">下载</button>' : '')) + (canSec ? '<button class="btn sm ghost" onclick="app.fileSecure(' + f.id + ',\'' + esc(f.name).replace(/'/g, "\\'") + '\')">安全设置</button>' : '') + (f.size >= 100 && CONV2PDF_EXT(f.name) ? '<button class="btn sm okbtn" onclick="app.convert2pdf(' + f.id + ',\'' + esc(f.name).replace(/'/g, "\\'") + '\')">转PDF</button>' : '') + ((isMg || f.uploader_id === ME.id) ? '<button class="btn sm danger" onclick="app.fileDel(' + f.id + ',\'' + esc(f.name).replace(/'/g, "\\'") + '\')">删除</button>' : '') + '</div></div>';
            }).join('') || '<div class="empty">暂无文件，点击“上传文件”分享资料</div>')}
        </div>
        ${cur !== 'trash' && sel.length ? '<div class="batch-bar">已选 <b>' + sel.length + '</b> 项 <button class="btn sm" onclick="app.fileMoveSel()">移动到分类</button> <button class="btn sm danger" onclick="app.fileDelSel()">批量删除</button> <button class="btn sm ghost" onclick="app.fileSelClear()">取消选择</button></div>' : ''}`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }
  /* ===== v8.6.0 文件安全工具：水印 / PDF.js 加载 / 防截图拍照守卫 ===== */
  function WM_HTML() {
    const txt = esc(((ME && ME.real_name) || '') + ' ' + ((ME && (ME.id_card || ME.work_no)) || ''));
    if (!txt.trim()) return '';
    return '<div class="wm-layer" style="position:absolute;inset:0;pointer-events:none;z-index:5;overflow:hidden;">' +
      Array.from({ length: 22 }).map((_, i) => '<div style="position:absolute;top:' + ((i * 17) % 88) + '%;left:' + ((i * 31) % 78) + '%;transform:rotate(-28deg);white-space:nowrap;color:rgba(31,58,147,.12);font-size:13px;font-weight:600;letter-spacing:1px;">' + txt + '</div>').join('') + '</div>';
  }
  function loadPdfJs() {
    if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
    return new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.min.js';
      s.onload = () => { window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js'; res(window.pdfjsLib); };
      s.onerror = () => rej(new Error('PDF 引擎加载失败（需外网访问 jsdelivr CDN，请检查网络）'));
      document.head.appendChild(s);
    });
  }
  function guardBind(wm) {
    guardUnbind();
    if (!wm) return;
    window.__guardOn = true;
    window.__gKey = (e) => {
      if ((e.key === 'PrintScreen') || (e.ctrlKey && ['s', 'p', 'c', 'x'].includes(e.key.toLowerCase())) || (e.metaKey && ['s', 'p', 'c'].includes(e.key.toLowerCase()))) {
        e.preventDefault(); e.stopPropagation();
        try { v5toast('当前页面受保护：禁止截图 / 打印 / 复制'); } catch (err) { alert('当前页面受保护：禁止截图 / 打印 / 复制'); }
      }
    };
    window.__gVis = () => { if (document.hidden && window.__guardOn) { try { v5toast('检测到离开受保护页面，请勿对文件进行截图或拍照'); } catch (err) {} } };
    window.__gCtx = (e) => { if (window.__guardOn) { e.preventDefault(); try { v5toast('当前页面受保护：禁止右键复制'); } catch (err) {} } };
    window.__gDrag = (e) => { if (window.__guardOn) e.preventDefault(); };
    window.__gCopy = (e) => { if (window.__guardOn) { e.preventDefault(); try { v5toast('当前页面受保护：禁止复制'); } catch (err) {} } };
    document.addEventListener('keydown', window.__gKey, true);
    document.addEventListener('visibilitychange', window.__gVis);
    document.addEventListener('contextmenu', window.__gCtx, true);
    document.addEventListener('dragstart', window.__gDrag, true);
    document.addEventListener('copy', window.__gCopy, true);
  }
  function guardUnbind() {
    window.__guardOn = false;
    if (window.__gKey) document.removeEventListener('keydown', window.__gKey, true);
    if (window.__gVis) document.removeEventListener('visibilitychange', window.__gVis);
    if (window.__gCtx) document.removeEventListener('contextmenu', window.__gCtx, true);
    if (window.__gDrag) document.removeEventListener('dragstart', window.__gDrag, true);
    if (window.__gCopy) document.removeEventListener('copy', window.__gCopy, true);
    window.__gKey = window.__gVis = window.__gCtx = window.__gDrag = window.__gCopy = null;
  }
  function fmtSize(n) {
    if (n >= 1048576) return (n / 1048576).toFixed(1) + ' MB';
    if (n >= 1024) return (n / 1024).toFixed(1) + ' KB';
    return n + ' B';
  }
  const CONV2PDF_EXT = (name) => {
    const ext = String(name).split('.').pop().toLowerCase();
    return ['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'md', 'csv', 'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'].includes(ext);
  };

  window.app = Object.assign(window.app || {}, {
    uploadFile: async () => {
      // 防呆：上传前先确认手写签名有效（资料上传需签字认可）
      let sig = null;
      try { sig = await api('/api/signature'); } catch (e) {}
      if (!sig || !sig.valid || !sig.file_id) {
        openSheet(`<div class="sheet-title">上传需签字认可<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="setup-tip">上传资料必须先完成手写签名授权（每季度核验一次），上传时将附带您的签名作为认可凭证。</div>
          <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.openSignPad()">去签名授权</button></div>`);
        return;
      }
      openSheet(`
        <div class="sheet-title">上传文件（≤20MB）<span class="x" onclick="app.closeSheet()">✕</span></div>
        <input type="file" id="up-file" style="width:100%;padding:10px;border:1px solid var(--line);border-radius:10px;background:#fafbfd;">
        <div class="field" style="margin-top:10px;"><label>存入分类（新建文件夹后自动归类，便于检索）</label>
          <select id="up-folder"><option value="">未分类</option>${(window.__folders || []).map((f0) => `<option value="${f0.id}">${esc(f0.name)}</option>`).join('')}<option value="new">＋ 新建分类…</option></select>
        </div>
        <div class="field" style="${MYLV() >= 4 ? '' : 'display:none;'}" id="up-folder-new-wrap"><label>新分类名称</label><input id="up-folder-new" placeholder="如：手册 / 运行文件 / 规章制度"></div>
        <div class="field"><label>可见范围（按人员类型分级）</label>
          <select id="up-level"><option value="0">全员可见</option><option value="1">在职及以上</option><option value="2">班组长及以上</option><option value="3">部门领导及以上</option><option value="5">仅管理员</option></select>
        </div>
        <div class="field"><label>是否共享</label><select id="up-share"><option value="1">共享（其他可见人员可阅读/下载）</option><option value="0">仅本人可见</option></select></div>
        <div class="setup-tip" style="background:#fff7e6;color:#8a5a00;">📌 资料上传需签字认可：请确认资料内容真实、有效，上传后系统将附带您的签名作为认可凭证（签名单独存档，仅管理/运维可见）。</div>
        <div class="chk" style="padding:10px 0;"><input type="checkbox" id="up-agree"><label class="ck-label">我已核对资料内容，同意签字认可并上传（附件上传人：${esc(ME.real_name || ME.username)}）</label></div>
        <div class="muted" style="margin-top:4px;" id="up-info">支持 Word / Excel / PDF / 图片 / 压缩包(ZIP) 等</div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.doUpload()">签字并上传</button></div>`, '上传文件');
    },
    doUpload: async () => {
      const f = $('#up-file').files[0];
      if (!f) { alert('请选择文件'); return; }
      if (f.size > 20 * 1024 * 1024) { alert('文件超过 20MB'); return; }
      if (!$('#up-agree') || !$('#up-agree').checked) { alert('请先勾选「我已核对资料内容，同意签字认可并上传」'); return; }
      $('#up-info').textContent = '正在上传…';
      try {
        const b64 = await fileToBase64(f);
        const lv = Number($('#up-level').value || 0);
        const share = $('#up-share').value === '1' ? 1 : 0;
        const fid = $('#up-folder').value;
        const payload = { name: f.name, data: b64, min_level: lv, share_flag: share };
        if (fid && fid !== 'new') payload.folder_id = fid;
        if (fid === 'new') {
          const nn = ($('#up-folder-new').value || '').trim();
          if (!nn) { alert('请输入新分类名称'); return; }
          payload.folder_new = nn;
        }
        await api('/api/files/upload', 'POST', payload);
        closeSheet(); renderFile();
      } catch (e) { $('#up-info').textContent = '上传失败：' + e.message; }
    },
    downFile: async (id, name) => {
      try {
        const meta = await api('/api/files/' + id);
        const perm = meta.perm || {};
        if (!perm.can_download) {
          if (perm.download_apply_open) { app.filePermReqSheet(id, name, 'download', meta); return; }
          if (perm.no_download || perm.readonly) { v5toast('该文件已设置「仅限在线阅读」，禁止下载'); return; }
          v5toast('您暂无该文件的下载权限'); return;
        }
        const blob = await fetch((API_BASE || '') + '/api/files/' + id + '/download', { headers: { Authorization: 'Bearer ' + TOKEN } }).then((r) => { if (!r.ok) throw new Error('下载被拒绝'); return r.blob(); });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = name;
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 5000);
      } catch (e) { alert(e.message); }
    },
    /* v6.3 文件转可编辑高精度 PDF（Office→矢量；图片→OCR双层） */
    convert2pdf: async (id, name) => {
      if (!confirm('将「' + name + '」转换为 PDF：\n· Office/文本 → 矢量可编辑 PDF\n· 图片 → 高精度扫描件 + OCR 文字层（可搜索）\n转换耗时视文件大小而定，请稍候。')) return;
      try {
        const blob = await fetch((API_BASE || '') + '/api/files/' + id + '/download', { headers: { Authorization: 'Bearer ' + TOKEN } }).then((r) => { if (!r.ok) throw new Error('文件读取失败'); return r.blob(); });
        const b64 = await new Promise((res) => { const rd = new FileReader(); rd.onloadend = () => res(String(rd.result).split(',')[1]); rd.readAsDataURL(blob); });
        v5toast('正在转换…请稍候');
        const r = await api('/api/files/convert2pdf', 'POST', { name, data: b64 });
        v5toast('转换完成：' + (r.mode || ''));
        renderFile();
      } catch (e) { v5toast('转换失败：' + e.message); }
    },
    fileHelp: () => {
      openSheet(`
        <div class="sheet-title">文件权限与阅读说明<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="setup-tip">文件按人员类型分级可见：全员 / 在职及以上 / 班组长及以上 / 部门领导及以上 / 仅管理员。您只能看到权限范围内（或自己上传）的文件；新人默认可在线阅读、无下载权限（需申请）。</div>
        <div class="setup-tip">管理员可对重要文件设置安全属性：🔒 仅限在线阅读（禁下载）、🚫 禁止下载、💧 阅读水印＋防截图/拍照提示、📄 阅读需申请（1名班组长及以上批准）、⬇ 下载需审批（至少2名班组长批准）、仅限指定用户可见。</div>
        <div class="setup-tip">在线阅读支持：PDF（内置阅读器，支持断点续读：关闭后下次打开自动回到最后阅读页）、图片、文本、ZIP 压缩包。受保护文件阅读时将叠加当前用户姓名＋证件编号水印，并提示禁止截图/拍照/复制。</div>`);
    },
    /* ===== v8.6.0 文件安全：管理员设置 / 权限申请与审批 / PDF 阅读器 / 水印防截 ===== */
    fileSecure: async (id, name) => {
      try {
        const meta = await api('/api/files/' + id);
        const users = await api('/api/users');
        const selIds = (() => { try { return JSON.parse(meta.visible_json || '[]').map(Number); } catch (e) { return []; } })();
        window.__SEC = { id, users, sel: selIds };
        const badgeUsers = selIds.map((uid0) => { const us = users.find((x) => String(x.id) === String(uid0)); return { id: uid0, nm: us ? us.real_name : ('用户' + uid0) }; });
        openSheet(`
          <div class="sheet-title">安全设置：${esc(name)}<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="setup-tip" style="background:#eef4ff;color:#1f3a93;">仅管理员可设置。保存后实时生效：下载/预览/列表按此控制；阅读与下载申请审批流独立。</div>
          <div class="chk" style="padding:8px 0;"><input type="checkbox" id="sc-readonly" ${meta.readonly ? 'checked' : ''}><label class="ck-label">🔒 仅限在线阅读（禁止下载/转存/导出）</label></div>
          <div class="chk" style="padding:8px 0;"><input type="checkbox" id="sc-nodl" ${meta.no_download ? 'checked' : ''}><label class="ck-label">🚫 禁止下载（可在线阅读）</label></div>
          <div class="chk" style="padding:8px 0;"><input type="checkbox" id="sc-wm" ${meta.watermark ? 'checked' : ''}><label class="ck-label">💧 阅读水印（当前用户姓名＋证件编号）＋防截图/拍照提示</label></div>
          <div class="chk" style="padding:8px 0;"><input type="checkbox" id="sc-readapply" ${meta.read_apply ? 'checked' : ''}><label class="ck-label">📄 阅读需申请（班组长及以上 1 名批准）</label></div>
          <div class="chk" style="padding:8px 0;"><input type="checkbox" id="sc-dlapply" ${meta.download_apply ? 'checked' : ''}><label class="ck-label">⬇ 下载需审批（至少 2 名班组长批准）</label></div>
          <div class="field" style="margin-top:10px;"><label>仅指定用户可见（留空＝按可见范围级别；名单外人员列表不可见）</label>
            <div id="sc-vusers" style="display:flex;flex-wrap:wrap;gap:6px;max-height:110px;overflow:auto;border:1px solid var(--line);border-radius:10px;padding:8px;margin-top:6px;">
              ${badgeUsers.map((b0) => '<span class="badge" style="background:#eef4ff;">' + esc(b0.nm) + ' <a style="color:#e5484d;text-decoration:none;" onclick="app.secDelUser(' + b0.id + ')">✕</a></span>').join('')}
              <input id="sc-user-q" placeholder="输入姓名/工号搜索添加" style="flex:1;min-width:120px;border:0;outline:0;font-size:13px;">
            </div>
            <div id="sc-user-opts" class="muted" style="font-size:12px;margin-top:4px;"></div>
          </div>
          <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.fileSecureSave(${id})">保存设置</button></div>`, '安全设置');
        const q = $('#sc-user-q');
        const upd = () => {
          const k = (q.value || '').trim().toLowerCase();
          const opts = users.filter((x) => (x.real_name || '').toLowerCase().includes(k) || String(x.work_no || '').toLowerCase().includes(k) || String(x.username || '').toLowerCase().includes(k));
          $('#sc-user-opts').innerHTML = opts.slice(0, 10).map((x) => '<span class="badge" style="background:#f0f4f8;cursor:pointer;" onclick="app.secAddUser(' + x.id + ',\'' + esc(x.real_name).replace(/'/g, "\\'") + '\')">＋ ' + esc(x.real_name) + '（' + esc(x.work_no || x.username || '') + '）</span>').join('') || '<span>无匹配用户</span>';
        };
        q.oninput = upd; q.onfocus = upd; upd();
      } catch (e) { alert(e.message); }
    },
    secAddUser: (uid, uname) => {
      const s = window.__SEC || { sel: [] };
      if (!s.sel.includes(uid)) s.sel.push(uid);
      const box = $('#sc-vusers');
      if (box) box.insertAdjacentHTML('beforeend', '<span class="badge" style="background:#eef4ff;">' + esc(uname) + ' <a style="color:#e5484d;text-decoration:none;" onclick="app.secDelUser(' + uid + ')">✕</a></span>');
      const opts = $('#sc-user-opts'); if (opts) opts.innerHTML = '';
    },
    secDelUser: (uid) => {
      const s = window.__SEC || { sel: [] };
      s.sel = s.sel.filter((x) => x !== uid);
      const box = $('#sc-vusers'); if (box) {
        const q = box.querySelector('#sc-user-q');
        const kids = box.querySelectorAll('span.badge'); kids.forEach((k) => k.remove());
        if (q) { const inp = q; box.insertBefore(inp, box.firstChild); } // 保留搜索框
        renderFile(); // 刷新无碍
      }
    },
    fileSecureSave: async (id) => {
      const s = window.__SEC || { sel: [] };
      try {
        await api('/api/files/' + id + '/secure', 'PUT', {
          readonly: ($('#sc-readonly').checked ? 1 : 0),
          no_download: ($('#sc-nodl').checked ? 1 : 0),
          watermark: ($('#sc-wm').checked ? 1 : 0),
          read_apply: ($('#sc-readapply').checked ? 1 : 0),
          download_apply: ($('#sc-dlapply').checked ? 1 : 0),
          visible_users: s.sel
        });
        closeSheet(); renderFile(); v5toast('安全设置已保存并生效');
      } catch (e) { alert(e.message); }
    },
    filePermReqSheet: (id, name, action, meta) => {
      const perm = meta.perm || {};
      const st = action === 'read' ? perm.read_status : perm.download_status;
      openSheet(`
        <div class="sheet-title">${action === 'read' ? '阅读' : '下载'}权限申请：${esc(name)}<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="setup-tip">${action === 'read' ? '该文件阅读需班组长及以上审批（1 名批准即可）' : '该文件下载需至少 2 名班组长批准（2 名同意后自动开通）'}</div>
        ${st ? '<div class="setup-tip" style="background:#fff7e6;">当前申请状态：' + ({ pending: '⏳ 审批中', approved: '✅ 已批准', rejected: '❌ 已驳回（可重新提交）' }[st] || st) + '</div>' : ''}
        <div class="field"><label>申请理由（必填）</label><input id="pr-reason" placeholder="如：工作需要查阅该文件，请批准"></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.filePermApply(${id},'${action}')">提交申请</button></div>`, '权限申请');
    },
    filePermApply: async (id, action) => {
      const reason = (($('#pr-reason') || {}).value || '').trim();
      if (!reason) { alert('请填写申请理由'); return; }
      try {
        const r = await api('/api/files/perm-req', 'POST', { file_id: id, action, reason });
        v5toast(r.message || '申请已提交'); closeSheet();
      } catch (e) { alert(e.message); }
    },
    filePermReqs: async () => {
      try {
        const rows = await api('/api/files/perm-reqs?scope=all');
        openSheet(`
          <div class="sheet-title">文件权限审批（班组长及以上）<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="setup-tip">阅读申请：1 名班组长批准即开通；下载申请：至少 2 名班组长批准后自动开通。任一驳回即拒绝。</div>
          <div style="max-height:60vh;overflow:auto;">
          ${rows.map((r) => '<div class="list-item"><div class="ic">' + (r.action === 'read' ? '📄' : '⬇') + '</div><div class="body"><div class="t">' + esc(r.file_name || ('文件#' + r.file_id)) + '</div><div class="d">' + esc(r.user_name || ('用户#' + r.user_id)) + ' · ' + (r.action === 'read' ? '申请阅读' : '申请下载') + ' · 已同意 <b>' + r.approved_count + '/' + r.need + '</b>' + (r.reason ? ' · 理由：' + esc(r.reason) : '') + '</div></div><div class="act"><button class="btn sm okbtn" onclick="app.filePermApprove(' + r.id + ',1)">批准</button><button class="btn sm danger" onclick="app.filePermApprove(' + r.id + ',0)">驳回</button></div></div>').join('') || '<div class="empty">暂无待审批申请</div>'}
          </div>`, '权限审批');
      } catch (e) { alert(e.message); }
    },
    filePermApprove: async (rid, ok) => {
      try {
        const r = await api('/api/files/perm-req/' + rid + '/approve', 'POST', { approve: ok ? 1 : 0 });
        v5toast(r.message); app.filePermReqs();
      } catch (e) { alert(e.message); }
    },
    /* PDF 阅读器：PDF.js 渲染 + 水印层 + 断点续读 + 防截图/拍照提示 */
    pdfReader: async (id, name, meta) => {
      const wm = !!(meta.perm && meta.perm.watermark);
      openSheet(`
        <div class="sheet-title">${esc(name)}${wm ? ' <span class="badge warn">💧受保护·防截图</span>' : ''}<span class="x" onclick="app.closeFileReader()">✕</span></div>
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
          <button class="btn sm ghost" onclick="app.pdfNav(-1)">‹ 上一页</button>
          <span id="pdf-pg" style="font-size:13px;color:var(--sub);">1 / …</span>
          <button class="btn sm ghost" onclick="app.pdfNav(1)">下一页 ›</button>
          <span id="pdf-mark-tip" class="muted" style="font-size:12px;"></span>
        </div>
        <div id="pdf-wrap" style="position:relative;max-height:64vh;overflow:auto;background:#525659;border-radius:10px;padding:10px;">
          <canvas id="pdf-canvas" style="display:block;margin:0 auto;max-width:100%;box-shadow:0 2px 10px rgba(0,0,0,.3);"></canvas>
          ${wm ? WM_HTML() : ''}
        </div>`, name);
      window.__PDF = { id, page: 1, numPages: 0, wm };
      guardBind(wm);
      try {
        const pdfjs = await loadPdfJs();
        const blob = await fetch((API_BASE || '') + '/api/files/' + id + '/raw', { headers: { Authorization: 'Bearer ' + TOKEN } }).then((r) => { if (!r.ok) throw new Error('PDF 读取失败'); return r.blob(); });
        const url = URL.createObjectURL(blob);
        const pdf = await pdfjs.getDocument({ url }).promise;
        window.__PDF.pdf = pdf; window.__PDF.numPages = pdf.numPages;
        let mk = 1; try { mk = (await api('/api/files/' + id + '/readmark')).page || 1; } catch (e) {}
        window.__PDF.page = Math.min(Math.max(1, mk), pdf.numPages);
        await app.pdfRender();
        const tip = $('#pdf-mark-tip');
        if (tip) tip.textContent = mk > 1 ? '已从上次阅读位置继续（第 ' + window.__PDF.page + ' 页）' : '第 1 页 · 阅读位置将自动记忆';
      } catch (e) {
        const w = $('#pdf-wrap'); if (w) w.innerHTML = '<div class="empty" style="color:#fff;">PDF 加载失败：' + esc(e.message) + '</div>';
      }
    },
    pdfNav: (d) => { const P = window.__PDF; if (!P || !P.pdf) return; P.page = Math.min(Math.max(1, P.page + d), P.numPages); app.pdfRender(); },
    pdfRender: async () => {
      const P = window.__PDF; if (!P || !P.pdf) return;
      const cv = $('#pdf-canvas'); if (!cv) return;
      try {
        const pg = await P.pdf.getPage(P.page);
        const scale = Math.min(1.6, 760 / pg.view[2]);
        const vp = pg.getViewport({ scale });
        cv.width = vp.width; cv.height = vp.height;
        cv.style.width = Math.min(vp.width, 900) + 'px';
        await pg.render({ canvasContext: cv.getContext('2d'), viewport: vp }).promise;
        const pgEl = $('#pdf-pg'); if (pgEl) pgEl.textContent = P.page + ' / ' + P.numPages;
        if (P.wm) { const wrap = $('#pdf-wrap'); if (wrap) { const old = wrap.querySelector('.wm-layer'); if (old) old.remove(); wrap.insertAdjacentHTML('beforeend', WM_HTML()); } }
        if (P._t) clearTimeout(P._t);
        P._t = setTimeout(() => { api('/api/files/' + P.id + '/readmark', 'POST', { page: P.page }).catch(() => {}); }, 900);
      } catch (e) {}
    },
    closeFileReader: () => { guardUnbind(); closeSheet(); },
    openFile: async (id, name) => {
      const n = String(name).toLowerCase();
      try {
        const meta = await api('/api/files/' + id);
        if (meta.size < 100) { alert('该文件内容已损坏（可能上传中断），无法打开。请删除后重新上传。'); return; }
        const perm = meta.perm || {};
        if (!perm.can_read) {
          if (perm.read_apply_open) { app.filePermReqSheet(id, name, 'read', meta); return; }
          alert('您暂无该文件的阅读权限（如需要请联系管理员）；仅阅读权限开放时可通过「申请」提交审批。'); return;
        }
        if (n.endsWith('.zip')) { await app.openZip(id, name); return; }
        if (/\.(png|jpe?g|gif|webp|bmp)$/.test(n)) {
          const wm = perm.watermark;
          openSheet(`<div class="sheet-title">${esc(name)}${wm ? ' <span class="badge warn">💧受保护</span>' : ''}<span class="x" onclick="app.closeFileReader()">✕</span></div><div style="position:relative;"><img src="/api/files/${id}/image?token=${encodeURIComponent(TOKEN)}" style="width:100%;border-radius:10px;background:#f5f7fa;">${wm ? WM_HTML() : ''}</div>`);
          guardBind(wm);
          return;
        }
        if (n.endsWith('.pdf')) { await app.pdfReader(id, name, meta); return; }
        if (n.endsWith('.txt') || n.endsWith('.md') || n.endsWith('.csv') || n.endsWith('.json') || n.endsWith('.html') || n.endsWith('.htm')) {
          const wm = perm.watermark;
          openSheet(`<div class="sheet-title">${esc(name)}${wm ? ' <span class="badge warn">💧受保护</span>' : ''}<span class="x" onclick="app.closeFileReader()">✕</span></div><div style="position:relative;"><div style="max-height:60vh;overflow:auto;border:1px solid var(--line);border-radius:10px;padding:12px;background:#fafbfd;"><pre style="white-space:pre-wrap;font-size:13px;">${esc(await (await authedFetch('/api/files/' + id + '/raw')).text())}</pre></div>${wm ? WM_HTML() : ''}</div>`);
          guardBind(wm);
          return;
        }
        openSheet(`<div class="sheet-title">${esc(name)}<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="setup-tip">该文档类型暂不支持在线预览（Word/Excel/PPT 等需办公软件打开）。您可以点击「下载」保存到本机后查看。</div>
          <div class="sheet-actions"><button class="btn" onclick="app.downFile(${id},'${esc(name).replace(/'/g, "\\'")}')">下载查看</button><button class="btn ghost" onclick="app.closeSheet()">关闭</button></div>`);
      } catch (e) { alert(e.message); }
    },
    openZip: async (id, name) => {
      try {
        const list = await api('/api/files/' + id + '/zip-list');
        openSheet(`
          <div class="sheet-title">压缩包内容：${esc(name)}<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="muted" style="margin-bottom:8px;">软件内置解压（ZIP）：共 ${list.length} 个文件，文本/图片可在线预览</div>
          <div style="max-height:56vh;overflow:auto;">
            ${list.map((e) => {
              const en = String(e.name).toLowerCase();
              const prev = en.endsWith('.txt') || en.endsWith('.md') || en.endsWith('.csv') || en.endsWith('.json') || /\.(png|jpe?g|gif|webp)$/.test(en);
              return `<div class="list-item"><div class="ic">${FILE_ICON(e.name)}</div><div class="body"><div class="t">${esc(e.name)}</div><div class="d">${fmtSize(e.size)}${e.comp < e.size ? ' · 压缩 ' + Math.round((1 - e.comp / e.size) * 100) + '%' : ''}</div></div><div class="act">${prev ? '<button class="btn sm ghost" onclick="app.zipPreview(' + id + ',\'' + esc(e.name).replace(/'/g, "\\'") + '\')">预览</button>' : '<button class="btn sm ghost" onclick="app.zipSave(' + id + ',\'' + esc(e.name).replace(/'/g, "\\'") + '\')">解压下载</button>'}</div></div>`;
            }).join('') || '<div class="empty">压缩包内无文件</div>'}
          </div>`);
      } catch (e) { alert(e.message); }
    },
    zipPreview: async (id, path) => {
      try {
        const en = String(path).toLowerCase();
        if (/\.(png|jpe?g|gif|webp)$/.test(en)) {
          openSheet(`<div class="sheet-title">${esc(path)}<span class="x" onclick="app.closeSheet()">✕</span></div><img src="/api/files/${id}/zip-read?path=${encodeURIComponent(path)}&token=${encodeURIComponent(TOKEN)}" style="width:100%;border-radius:10px;">`);
          return;
        }
        const txt = await (await authedFetch('/api/files/' + id + '/zip-read?path=' + encodeURIComponent(path))).text();
        openSheet(`<div class="sheet-title">${esc(path)}<span class="x" onclick="app.closeSheet()">✕</span></div><div style="max-height:60vh;overflow:auto;border:1px solid var(--line);border-radius:10px;padding:12px;background:#fafbfd;"><pre style="white-space:pre-wrap;font-size:13px;">${esc(txt)}</pre></div>`);
      } catch (e) { alert(e.message); }
    },
    zipSave: (id, path) => {
      const a = document.createElement('a');
      a.href = '/api/files/' + id + '/zip-read?path=' + encodeURIComponent(path) + '&token=' + encodeURIComponent(TOKEN);
      a.download = path.split('/').pop();
      document.body.appendChild(a); a.click(); a.remove();
    }
  });
  function authedFetch(path) {
    return fetch((API_BASE || '') + path, { headers: TOKEN ? { Authorization: 'Bearer ' + TOKEN } : {} });
  }
  function fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(String(r.result).split(',')[1]);
      r.onerror = reject;
      r.readAsDataURL(file);
    });
  }

  /* ===== 更多 ===== */
  async function renderMore() {
    const el = $('#page-more');
    const lv = MYLV();
    const isAppr = lv >= 2;
    try {
      const s = await api('/api/stats');
      const entries = [

        ['task', '📋', '待办任务', s.my_tasks_open + ' 项待办'],
        ['hr', '🧑‍💼', '人事管理', isAppr ? '入职/离职/类型' : ''],
        ['meeting', '📝', '会议纪要', s.meeting_count + ' 场 · ' + s.meeting_action_overdue + ' 逾期'],
        ['audit', '🔍', '审计整改', isAppr ? s.issue_open + ' 项待整改' : ''],
        ['check', '🗂️', '检查管理', isAppr ? s.check_record_pending + ' 项待审核' : s.my_check_count + ' 条记录'],
        ['patrol', '🚶', '巡逻上报', isAppr ? s.patrol_pending + ' 项待审核' : s.my_patrol_count + ' 条记录'],

        ['form', '📊', '数据录入', s.form_count + ' 张表单'],
        ['summary', '📈', '年度汇总', '培训/会议/检查/计划完成情况'],
        ['reward', '🏅', '奖励处罚', '表扬与警示记录'],
        ['import', '📥', '批量导入', '仅运维/管理员：人员/计划/会议'],
        ['backup', '💾', '数据备份', '仅运维/管理员：自动/手动备份'],
        ['admin', '⚙️', '系统管理', ''],
        ['v6dash', '📊', '数据看板', '检查闭环/培训完成/预警'],
        ['recycle', '🗑️', '数据回收站', '仅运维/管理员：误删恢复'],
        ['kb', '📚', '部门知识库', '文件资料/版本管理'],
        ['autorules', '⚡', '自动化规则', '仅运维/管理员：自动通知'],
        ['webhooks', '🔗', 'Webhook推送', '仅运维/管理员：事件通知'],
        ['importtpl', '📥', '通用导入', '仅运维/管理员：按模板批量导入']
      ].filter(([p]) => { if (p === 'import' && lv < 4) return false; if (p === 'recycle' && lv < 4) return false; if (p === 'autorules' && lv < 4) return false; if (p === 'webhooks' && lv < 4) return false; if (p === 'importtpl' && lv < 4) return false; if (lv >= 4) return true; if (lv >= 3) return !['admin'].includes(p); if (lv >= 2) return !['admin'].includes(p); if (lv >= 1) return !['admin', 'hr', 'meeting', 'audit', 'duty', 'check', 'patrol', 'form'].includes(p); return false; });   // [需求1] 考勤/值班下线后新人无可见功能
      el.innerHTML = `
        <div class="card"><h3><svg class="lg-ic"><use href="#i-doc"/></svg> 打印 / 导出（P0-3）</h3>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <button class="btn" style="flex:1 1 130px;" onclick="app.printA4()">🖨️ A4 打印当前页</button>
            <button class="btn ghost" style="flex:1 1 130px;" onclick="app.exportCSV()">📊 导出当前页 CSV</button>
          </div>
          <div style="font-size:12px;color:#9ca3af;margin-top:6px;">自动识别当前页面的数据表格，套用 A4 版式（标题/日期/单位/页边距）打印；CSV 可直接用 Excel 打开。</div>
        </div>
        <div class="card">
          <div class="grid">
            ${entries.map(([p, ic, n, d]) => `<div class="grid-item" onclick="switchPage('${p}')"><div class="gi">${ic}</div><div class="gn">${n}</div>${d ? '<div class="gd">' + d + '</div>' : ''}</div>`).join('')}
          </div>
        </div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  /* ===== v6.0 数据看板（检查闭环/培训完成/预警/跨表聚合） ===== */
  async function renderV6Dash() {
    const el = $('#page-v6dash');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const d = await api('/api/dashboard');
      const rate = (n) => n + '%';
      el.innerHTML = `
        <div class="card"><h3>核心指标（借鉴简道云工作台看板）</h3>
          <div class="stat-grid" style="grid-template-columns:repeat(3,1fr);">
            <div class="stat"><div class="num">${d.check.rate}%</div><div class="lbl">检查闭环率</div></div>
            <div class="stat"><div class="num">${d.training.rate}%</div><div class="lbl">培训完成率</div></div>
            <div class="stat"><div class="num">${d.patrol.missed}</div><div class="lbl">今日漏巡</div></div>
            <div class="stat"><div class="num">${d.assets.warn}</div><div class="lbl">资产预警</div></div>
            <div class="stat"><div class="num">${d.approval.pending}</div><div class="lbl">审批积压</div></div>
            <div class="stat"><div class="num">${d.issue.overdue}</div><div class="lbl">整改超期</div></div>
            <div class="stat"><div class="num">${d.plan.soon}</div><div class="lbl">临期培训</div></div>
            <div class="stat"><div class="num">${d.unread}</div><div class="lbl">未读消息</div></div>
            <div class="stat"><div class="num">${d.patrol.dutyToday}</div><div class="lbl">今日排班</div></div>
          </div>
        </div>
        <div class="card"><h3>预警提示</h3>
          ${(d.issue.overdue ? `<div class="list-item"><div class="body"><div class="t"><span class="badge warn">超期</span> 整改超期 ${d.issue.overdue} 项，请立即处理</div><div class="d">入口：检查管理-整改问题</div></div></div>` : '')}
          ${(d.assets.warn ? `<div class="list-item"><div class="body"><div class="t"><span class="badge warn">预警</span> 资产报废/维保到期 ${d.assets.warn} 项</div><div class="d">入口：车辆台账</div></div></div>` : '')}
          ${(d.plan.soon ? `<div class="list-item"><div class="body"><div class="t"><span class="badge warn">提醒</span> 7 天内待开展培训 ${d.plan.soon} 项</div><div class="d">入口：培训计划</div></div></div>` : '')}
          ${(d.patrol.missed ? `<div class="list-item"><div class="body"><div class="t"><span class="badge warn">缺勤</span> 今日应巡未巡 ${d.patrol.missed} 人次</div><div class="d">入口：值班排班/巡逻上报</div></div></div>` : '')}
          ${(!d.issue.overdue && !d.assets.warn && !d.plan.soon && !d.patrol.missed) ? '<div class="empty">暂无预警，运行平稳 ✓</div>' : ''}
        </div>
        <div class="card"><h3>说明</h3>
          <div class="muted">· 检查闭环率＝已闭环问题 / 全部问题；培训完成率＝今年有签到培训 / 今年全部培训。</div>
          <div class="muted">· 预警数据由系统自动统计，整改超期问题会自动生成「整改超期告警」全员消息（每项仅提醒一次）。</div>
        </div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  /* ===== v6.0 数据回收站（软删恢复/彻底删除） ===== */
  async function renderRecycle() {
    const el = $('#page-recycle');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const d = await api('/api/recycle');
      if (!d.tables.length) { el.innerHTML = '<div class="card"><h3>数据回收站</h3><div class="empty">回收站为空——删除的业务数据会先进入这里，30 天后自动彻底清除，期间可随时恢复。</div></div>'; return; }
      el.innerHTML = `<div class="card"><h3>数据回收站（${d.tables.length} 类待恢复数据）</h3>
        <div class="muted" style="margin-bottom:8px;">删除数据保留 30 天，期间可恢复；超过 30 天自动彻底清除。</div>
        ${d.tables.map((t) => `<div class="list-item" style="cursor:pointer;" onclick="app.openRecycle('${t.table}','${esc(t.label)}')"><div class="body"><div class="t">${esc(t.label)}（${t.count} 条）</div><div class="d">点击查看并恢复/彻底删除</div></div><div class="arrow">›</div></div>`).join('')}
      </div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }
  window.app = window.app || {};
  app.openRecycle = async function (table, label) {
    try {
      const d = await api('/api/recycle/list?table=' + encodeURIComponent(table));
      const rows = d.rows || [];
      openSheet(`<div class="sheet-title">回收站 · ${label}（${rows.length} 条）<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div style="max-height:62vh;overflow:auto;">
        ${rows.map((r) => `<div class="list-item"><div class="body"><div class="t">${esc(r.title || r.id)}</div><div class="d">删除时间：${esc(r.deleted_at || '')}</div></div>
          <button class="btn sm" onclick="app.recycleOp('${table}',${r.id},'restore',this)">恢复</button>
          <button class="btn sm danger" onclick="app.recycleOp('${table}',${r.id},'purge',this)">彻底删除</button></div>`).join('') || '<div class="empty">该分类暂无删除数据</div>'}
        </div>`);
    } catch (e) { alert('加载失败：' + e.message); }
  };
  app.recycleOp = async function (table, id, op, btn) {
    if (op === 'purge' && !confirm('彻底删除后不可恢复，确认删除？')) return;
    try { await api('/api/recycle/' + op, 'POST', { table, id }); btn.closest('.list-item').remove(); renderRecycle(); } catch (e) { alert('操作失败：' + e.message); }
  };

  /* ===== v6.0 部门知识库（文件资料/版本管理/回收） ===== */
  async function renderKb(initCat, initQ) {
    const el = $('#page-kb');
    el.innerHTML = '<div class="muted">加载中…</div>';
    const cat = initCat || ''; const q = initQ || '';
    try {
      const [cats, docs] = await Promise.all([api('/api/kb/cats'), api('/api/kb/docs?cat=' + encodeURIComponent(cat) + '&q=' + encodeURIComponent(q))]);
      el.innerHTML = `<div class="card"><h3>部门知识库 <button class="btn sm" style="float:right;" onclick="app.kbUpload()">＋ 上传资料</button></h3>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px;">
          <button class="btn sm ${!cat ? 'on' : ''}" onclick="app.kbGo('','')">全部</button>
          ${cats.map((c) => `<button class="btn sm ${cat === c.category ? 'on' : ''}" onclick="app.kbGo('${esc(c.category)}','')">${esc(c.category)}（${c.c}）</button>`).join('')}
        </div>
        <input id="kb-q" class="inp" placeholder="搜索标题/分类" value="${esc(q)}" style="width:100%;box-sizing:border-box;margin-bottom:8px;" onkeydown="if(event.key==='Enter')app.kbGo('${esc(cat)}',this.value)">
        ${docs.map((d) => `<div class="list-item"><div class="body"><div class="t">${esc(d.title)} <span class="badge">v${d.ver}</span></div><div class="d">${esc(d.category)} · ${esc(d.uploader_name || '')} · ${d.created_at}</div></div>
          <a class="btn sm" href="/api/kb/files/${d.id}/download?token=${encodeURIComponent(TOKEN)}" target="_blank">下载</a>
          <button class="btn sm ghost" onclick="app.kbDel(${d.id},this)">删除</button></div>`).join('') || '<div class="empty">暂无资料，点击右上角上传</div>'}
      </div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }
  app.kbGo = function (cat, q) { switchPage('kb'); renderKb(cat, q); };
  app.kbDel = async function (id, btn) {
    if (!confirm('移入回收站（知识库内可直接恢复）？')) return;
    try { await api('/api/kb/docs/' + id, 'DELETE'); btn.closest('.list-item').remove(); } catch (e) { alert('删除失败：' + e.message); }
  };
  app.kbUpload = function () {
    openSheet(`<div class="sheet-title">上传知识库资料<span class="x" onclick="app.closeSheet()">✕</span></div>
      <label class="lbl">标题（默认取文件名）</label><input id="kb-title" class="inp" placeholder="资料标题">
      <label class="lbl">分类</label><input id="kb-cat" class="inp" placeholder="如：制度文件/培训教材/检查标准（输入新分类或沿用现有）">
      <label class="lbl">可见范围</label><select id="kb-scope" class="inp"><option value="dept">本部门</option><option value="all">全员</option></select>
      <label class="lbl">选择文件（≤20MB）</label><input id="kb-file" class="inp" type="file">
      <button class="btn block" id="kb-upload-btn" onclick="app.kbUploadGo()">上传</button>`);
  };
  app.kbUploadGo = async function () {
    const f = $('#kb-file').files[0];
    if (!f) { alert('请选择文件'); return; }
    const btn = $('#kb-upload-btn'); btn.textContent = '上传中…'; btn.disabled = true;
    try {
      const b64 = await new Promise((res, rej) => { const rd = new FileReader(); rd.onload = () => res(String(rd.result).split(',')[1]); rd.onerror = rej; rd.readAsDataURL(f); });
      const up = await api('/api/files/upload', 'POST', { name: f.name, data: b64, min_level: 0, share_flag: 1 });
      await api('/api/kb/docs', 'POST', { title: $('#kb-title').value || f.name, category: $('#kb-cat').value || '其他', file_path: up.stored_name, file_name: f.name, file_size: f.size, scope: $('#kb-scope').value });
      closeSheet(); renderKb();
    } catch (e) { btn.textContent = '上传'; btn.disabled = false; alert('上传失败：' + e.message); }
  };

  /* ===== v6.0 自动化规则引擎 ===== */
  async function renderAutoRules() {
    const el = $('#page-autorules');
    try {
      const d = await api('/api/auto-rules');
      const tips = { issue_created: '检查问题登记后，自动向责任人发送整改通知', issue_overdue: '整改超期后，自动升级并全员告警', training_soon: '培训计划 7 天内到期时，全员提醒' };
      el.innerHTML = `<div class="card"><h3>自动化规则 <button class="btn sm" style="float:right;" onclick="app.ruleAdd()">＋ 新增</button></h3>
        <div class="muted" style="margin-bottom:8px;">规则启用后由系统自动执行，不发重复提醒；借鉴简道云智能助手。</div>
        ${d.map((r) => `<div class="list-item"><div class="body"><div class="t">${esc(r.name)} <span class="badge ${r.enabled ? 'ok' : ''}">${r.enabled ? '启用' : '停用'}</span></div><div class="d">${esc(tips[r.trigger_type] || r.trigger_type)}</div></div>
          <label class="switch" style="flex-shrink:0;margin:0 2px;" title="${r.enabled ? '点击停用' : '点击启用'}"><input type="checkbox" ${r.enabled ? 'checked' : ''} onchange="app.ruleToggle(${r.id}, this.checked)"><span class="track"></span></label></div>`).join('') || '<div class="empty">暂无规则</div>'}
      </div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }
  app.ruleToggle = async function (id, on) { try { await api('/api/auto-rules/' + id + '/toggle', 'POST', { enabled: on }); renderAutoRules(); } catch (e) { alert('操作失败：' + e.message); renderAutoRules(); } };
  app.ruleAdd = function () {
    openSheet(`<div class="sheet-title">新增自动化规则<span class="x" onclick="app.closeSheet()">✕</span></div>
      <label class="lbl">规则名称</label><input id="rl-name" class="inp" placeholder="如：检查隐患自动整改">
      <label class="lbl">触发类型</label><select id="rl-type" class="inp">
        <option value="issue_created">检查问题登记 → 自动通知责任人</option>
        <option value="issue_overdue">整改超期 → 升级+全员告警</option>
        <option value="training_soon">培训临期 → 全员提醒</option></select>
      <button class="btn block" onclick="app.ruleAddGo()">保存规则</button>`);
  };
  app.ruleAddGo = async function () {
    const name = $('#rl-name').value; const type = $('#rl-type').value;
    if (!name) { alert('请填写规则名称'); return; }
    try { await api('/api/auto-rules', 'POST', { name, trigger_type: type, enabled: true }); closeSheet(); renderAutoRules(); } catch (e) { alert('保存失败：' + e.message); }
  };

  /* ===== v6.0 Webhook 事件推送 ===== */
  async function renderWebhooks() {
    const el = $('#page-webhooks');
    try {
      const d = await api('/api/webhooks');
      el.innerHTML = `<div class="card"><h3>Webhook 推送 <button class="btn sm" style="float:right;" onclick="app.webhookAdd()">＋ 新增</button></h3>
        <div class="muted" style="margin-bottom:8px;">将系统事件推送到外部服务（如企业微信机器人/内部接口），借鉴简道云数据接口。</div>
        ${d.map((w) => `<div class="list-item"><div class="body"><div class="t">${esc(w.name)} <span class="badge ${w.enabled ? 'ok' : ''}">${w.enabled ? '启用' : '停用'}</span></div><div class="d">${esc(w.url)}<br>事件：${esc((JSON.parse(w.events_json || '[]') || []).join('、') || '全部')}</div></div>
          <label class="switch" style="flex-shrink:0;margin:0 2px;" title="${w.enabled ? '点击停用' : '点击启用'}"><input type="checkbox" ${w.enabled ? 'checked' : ''} onchange="app.webhookToggle(${w.id}, this.checked)"><span class="track"></span></label></div>`).join('') || '<div class="empty">暂无 Webhook</div>'}
      </div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }
  app.webhookToggle = async function (id, on) { try { await api('/api/webhooks/' + id + '/toggle', 'POST', { enabled: on }); renderWebhooks(); } catch (e) { alert('操作失败：' + e.message); renderWebhooks(); } };
  app.webhookAdd = function () {
    openSheet(`<div class="sheet-title">新增 Webhook<span class="x" onclick="app.closeSheet()">✕</span></div>
      <label class="lbl">名称</label><input id="wh-name" class="inp" placeholder="如：企业微信群机器人">
      <label class="lbl">回调地址 URL</label><input id="wh-url" class="inp" placeholder="https://...">
      <label class="lbl">事件（逗号分隔，留空=全部）</label><input id="wh-events" class="inp" placeholder="issue_created,issue_overdue,approval_rejected">
      <button class="btn block" onclick="app.webhookAddGo()">保存</button>`);
  };
  app.webhookAddGo = async function () {
    const name = $('#wh-name').value; const url = $('#wh-url').value;
    if (!name || !url) { alert('名称与地址必填'); return; }
    const events = $('#wh-events').value.split(/[,，]/).map((s) => s.trim()).filter(Boolean);
    try { await api('/api/webhooks', 'POST', { name, url, events, enabled: true }); closeSheet(); renderWebhooks(); } catch (e) { alert('保存失败：' + e.message); }
  };

  /* ===== v6.0 通用导入（按模板） ===== */
  async function renderImportTpl() {
    const el = $('#page-importtpl');
    try {
      const d = await api('/api/import/templates');
      el.innerHTML = `<div class="card"><h3>通用导入（按模板批量录入）</h3>
        <div class="muted" style="margin-bottom:8px;">选择业务类型，粘贴 JSON 数组批量导入；字段与下表一致，空字段自动跳过。</div>
        ${d.map((t) => `<div class="list-item"><div class="body"><div class="t">${esc(t.label)}</div><div class="d">字段：${esc(t.fields.join('、'))}</div></div>
          <button class="btn sm" onclick="app.importPick('${t.type}','${esc(t.label)}','${esc(t.fields.join('，'))}')">导入</button></div>`).join('')}
      </div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }
  app.importPick = function (type, label, fields) {
    openSheet(`<div class="sheet-title">${label}<span class="x" onclick="app.closeSheet()">✕</span></div>
      <div class="muted" style="margin-bottom:8px;">字段：${fields}<br>示例：[{"title":"消防安全培训","train_date":"2026-10-25","hours":4}]</div>
      <textarea id="imp-json" class="inp" rows="8" style="width:100%;box-sizing:border-box;" placeholder='[{"title":"...","train_date":"2026-10-25"}]'></textarea>
      <button class="btn block" onclick="app.importGo('${type}')">批量导入</button>`);
  };
  app.importGo = async function (type) {
    let rows; try { rows = JSON.parse($('#imp-json').value); } catch (e) { alert('JSON 格式错误：' + e.message); return; }
    if (!Array.isArray(rows)) { alert('请输入 JSON 数组'); return; }
    try { const d = await api('/api/import/generic', 'POST', { type, rows }); alert('导入完成：成功 ' + d.ok + ' 条，跳过 ' + d.skip + ' 条'); closeSheet(); } catch (e) { alert('导入失败：' + e.message); }
  };

  /* ===== v5.4 年度汇总 ===== */
  async function renderSummary() {
    const el = $('#page-summary');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const d = await api('/api/summary/annual');
      const escL = (x) => (x || []).map((v) => esc(v));
      el.innerHTML = `
        <div class="card"><h3>${d.year} 年度汇总（${d.from} 至 ${d.today}）</h3>
          <div class="stat-grid" style="grid-template-columns:repeat(3,1fr);">
            <div class="stat"><div class="num">${d.trainings.count}</div><div class="lbl">培训（${d.trainings.persons}人次）</div></div>
            <div class="stat"><div class="num">${d.meetings.count}</div><div class="lbl">会议</div></div>
            <div class="stat"><div class="num">${d.checks.total}</div><div class="lbl">检查（${d.patrols}巡逻）</div></div>
            <div class="stat"><div class="num">${d.tasks.done}/${d.tasks.total}</div><div class="lbl">待办完成</div></div>
            <div class="stat"><div class="num">${d.rewards.reward}</div><div class="lbl">奖励</div></div>
            <div class="stat"><div class="num">${d.rewards.punish}</div><div class="lbl">处罚</div></div>
          </div>
        </div>
        <div class="card"><h3>培训情况（${d.trainings.count} 次 · ${d.trainings.persons} 人次）</h3>
          ${d.trainings.list.map((t) => `<div class="list-item"><div class="body"><div class="t">${esc(t.title)}（${esc(t.category)}）</div><div class="d">${t.date} · 参加：${esc(t.participants || '未登记')}</div></div></div>`).join('') || '<div class="empty">年初至今暂无培训记录</div>'}
        </div>
        <div class="card"><h3>培训计划完成情况（${d.trainingPlans.done}/${d.trainingPlans.total}）</h3>
          ${d.trainingPlans.remaining ? `<div class="muted" style="margin-bottom:6px;">未完成 ${d.trainingPlans.remaining} 项：</div>` + d.trainingPlans.list.map((t) => `<div class="list-item"><div class="body"><div class="t">${esc(t.title)}（${esc(t.category)}）</div><div class="d">计划日期 ${t.date || '未定'} · <span class="badge warn">未完成</span></div></div></div>`).join('') : '<div class="empty">培训计划已全部完成或暂无计划</div>'}
        </div>
        <div class="card"><h3>会议与决策落实（${d.meetings.count} 次会 · 行动项 ${d.meetings.actions} 项）</h3>
          <div class="muted">已完成 ${d.meetings.actionsDone} 项 · 未完成 ${d.meetings.actions - d.meetings.actionsDone} 项 · 逾期 ${d.meetings.actionsOverdue} 项（逾期项可在「会议纪要-行动项」中跟进）</div>
        </div>
        <div class="card"><h3>检查计划完成情况（${d.checkPlans.done}/${d.checkPlans.total}）</h3>
          ${d.checkPlans.list.map((c) => `<div class="list-item"><div class="body"><div class="t">${c.year}年 ${esc(c.name)}（${esc(c.check_type)}）</div><div class="d">检查项 ${c.items} 项 · 已完成 ${c.done} · 剩余 ${c.remaining} ${c.status === '已完成' ? '<span class="badge ok">已完成</span>' : '<span class="badge warn">未完成</span>'}</div></div></div>`).join('') || '<div class="empty">暂无检查计划</div>'}
        </div>
        <div class="card"><h3>检查执行（共 ${d.checks.total} 次）</h3>
          ${d.checks.byType.map((c) => `<div class="list-item"><div class="body"><div class="t">${esc(c.check_type)}</div><div class="d">${c.c} 次</div></div></div>`).join('') || '<div class="empty">暂无检查记录</div>'}
        </div>
        <div class="muted" style="padding:4px 2px 12px;">数据口径：培训次数/人次按培训记录统计；检查按审核通过记录统计；计划完成率按已通过检查数覆盖计划检查项估算。</div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  /* ===== v5.4 奖励处罚 ===== */
  async function renderReward() {
    const el = $('#page-reward');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const rows = await api('/api/rewards');
      const canAdd = MYLV() >= 2;
      const isAdm = ME.role === 'admin';
      el.innerHTML = `
        <div class="actions">${canAdd ? '<button class="btn sm" onclick="app.addReward()">＋ 录入奖惩</button>' : '<div class="muted" style="font-size:13px;">仅班组长及以上可录入奖励/处罚</div>'}</div>
        <div class="card"><h3>奖励与处罚记录（${rows.length}）</h3>
          ${rows.map((r) => `<div class="list-item">
            <div class="ic">${r.type === 'reward' ? '🏆' : '⚠️'}</div>
            <div class="body">
              <div class="t">${r.type === 'reward' ? '<span class="badge ok">奖励</span>' : '<span class="badge bad">处罚</span>'} ${esc(r.title)}</div>
              <div class="d">${esc(r.user_name || '未指定人员')} · ${r.rdate}${r.category ? ' · 情形：' + esc(r.category) : ''}${r.reason ? ' · ' + esc(r.reason) : ''} · 录入：${esc(r.creator_name || '')}</div>
            </div>
            <div class="act">${isAdm ? '<button class="btn sm danger" onclick="app.delReward(' + r.id + ')">删</button>' : ''}</div>
          </div>`).join('') || '<div class="empty">暂无奖惩记录</div>'}
        </div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  /* ===== v5.4 批量导入（仅运维/管理员） ===== */
  async function renderImport() {
    const el = $('#page-import');
    const lv = MYLV();
    if (lv < 4) { el.innerHTML = '<div class="empty">权限不足：仅运维工程师/管理员可使用批量导入</div>'; return; }
    el.innerHTML = `
      <div class="card"><h3>批量导入（仅运维/管理员可见）</h3>
        <div class="field"><label>导入类型</label>
          <select id="imp-type">
            <option value="users">人员批量导入（CSV：姓名,工作证编号,部门,类型[新人/在职/班组长/部门领导/运维工程师]）</option>
            <option value="check_plans">检查计划批量导入（CSV：年度,名称,类型,周期[,检查项分号分隔]）</option>
            <option value="training_plans">培训计划批量导入（CSV：名称,类别[,计划日期,目标,学时]）</option>
            <option value="meetings">会议内容批量导入（CSV：标题,类型,日期[,主持人,参会人,纪要]）</option>
          </select>
        </div>
        <div class="field"><label>导入内容（每行一条，逗号分隔）</label>
          <textarea id="imp-rows" rows="8" placeholder="例如培训计划：&#10;应急演练,消防,2026-11-05,全员,2&#10;安保培训,安保,2026-11-12,新入职,1"></textarea>
        </div>
        <div class="muted" style="margin-bottom:8px;" id="imp-tip">逐行校验：格式错误的行会跳过并在结果中列出，不阻断其他行导入。</div>
        <div class="sheet-actions" style="padding:0;"><button class="btn" onclick="app.doImport()">开始批量导入</button></div>
        <div id="imp-result" style="margin-top:10px;"></div>
      </div>
      <div class="card" style="margin-top:14px;"><h3><svg class="lg-ic"><use href="#i-note"/></svg> 人员档案导入（含照片，对齐 OIT 导出）</h3>
        <div class="setup-tip">将 OIT 系统导出的人员档案整理为 <b>人员档案.csv</b>（列头见模板），照片按 <b>工作证编号</b> 命名放入 <b>photos/</b> 文件夹（如 photos/9001.jpg），连同 CSV 一起打包成 ZIP 后一次上传导入。已存在的人员按工作证编号自动更新档案，不重复新增。</div>
        <div class="field"><label>CSV 列头（与模板一致）</label>
          <div class="muted" style="font-size:12px;">姓名,工作证编号,部门,人员类型,性别,民族,出生日期,手机号,身份证号,政治面貌,学历,入职日期,职务</div></div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:10px 0;">
          <button class="btn" onclick="app.dlPersonnelTpl()">下载 CSV 模板</button>
          <input type="file" id="personnel-zip" accept=".zip" style="flex:1;min-width:200px;">
          <button class="btn primary" onclick="app.doPersonnelImport()">上传导入</button>
        </div>
        <div class="muted" style="font-size:12px;">支持格式：ZIP 内含 人员档案.csv + photos/ 目录（照片 jpg/png/webp，文件名=工作证编号）；仅运维/管理员可用。</div>
        <div id="personnel-result" style="margin-top:10px;"></div>
      </div>`;
  }

  window.app = Object.assign(window.app || {}, {
    dlPersonnelTpl: () => { window.open('/api/import/personnel-template'); },
    doPersonnelImport: async () => {
      const r = $('#personnel-result');
      const inp = $('#personnel-zip');
      if (!inp.files || !inp.files[0]) { r.innerHTML = '<div class="setup-tip" style="background:#fde8e8;">请先选择 ZIP 压缩包</div>'; return; }
      const f = inp.files[0];
      if (!f.name.toLowerCase().endsWith('.zip')) { r.innerHTML = '<div class="setup-tip" style="background:#fde8e8;">仅支持 .zip 压缩包</div>'; return; }
      r.innerHTML = '<div class="muted">正在解析并导入…（ZIP 较大时请稍候）</div>';
      try {
        const b64 = await new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(String(fr.result).split(',')[1] || ''); fr.onerror = rej; fr.readAsDataURL(f); });
        const d = await api('/api/import/personnel', 'POST', { zipBase64: b64 });
        r.innerHTML = '<div class="setup-tip" style="background:#e8f6ee;">导入完成：成功 ' + d.ok + ' 行，失败 ' + d.err + ' 行，照片 ' + d.photos + ' 张' + (d.errList && d.errList.length ? '<br>' + d.errList.map(esc).join('<br>') : '') + '</div>';
        inp.value = '';
      } catch (e) { r.innerHTML = '<div class="setup-tip" style="background:#fde8e8;">导入失败：' + esc(e.message) + '</div>'; }
    },
    addReward: async () => {
      let users = [];
      try { users = await api('/api/users'); } catch (e) {}
      const options = users.map((x) => `<option value="${x.id}">${esc(x.real_name)}（${esc(x.work_no)}）</option>`).join('');
      openSheet(`
        <div class="sheet-title">录入奖励/处罚<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>类型</label><select id="rw-type" onchange="app.rwCat()"><option value="reward">🏆 奖励</option><option value="punish">⚠️ 处罚</option></select></div>
        <div class="field"><label>情形类别 *</label><select id="rw-cat">
          <optgroup label="奖励情形（运行手册第十章）">
            <option>灭火救援英勇处置，避免重大损失</option><option>执勤战备/业务训练/技能比武表现突出</option><option>及时发现重大安全隐患，避免不安全事件</option><option>合理化建议被采纳实施取得成效</option><option>严格落实规章，长期履职表现优秀</option><option>其他应予奖励情形</option>
          </optgroup>
          <optgroup label="惩戒情形（运行手册第十章）">
            <option>值班擅离职守/脱岗/睡岗</option><option>出动行动迟缓，影响响应时间</option><option>车辆/装备检查不到位，未发现故障隐患</option><option>无故不参加训练/演练</option><option>训练考核多次不合格，补训补考仍不达标</option><option>违反保密守则，泄密风险</option><option>外出/休假不履行报备审批手续</option><option>检查记录/台账弄虚作假</option><option>应急处置不服从指挥/贻误处置时机</option><option>其他违反手册/机场规章制度行为</option>
          </optgroup>
        </select></div>
        <div class="field"><label>人员（选择系统人员，或留空填写姓名）</label><select id="rw-user"><option value="">— 不选择（下方填姓名）—</option>${options}</select><input id="rw-name" placeholder="外部姓名（未选人员时填写）" style="margin-top:6px;"></div>
        <div class="field"><label>标题 *</label><input id="rw-title" placeholder="如：月度优秀检查员"></div>
        <div class="field"><label>原因/说明</label><input id="rw-reason" placeholder="如：10月检查完成率高"></div>
        <div class="field"><label>日期 *</label><input id="rw-date" type="date" value="${todayStr()}"></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveReward()">保存</button></div>`);
    },
    saveReward: async () => {
      const title = $('#rw-title').value.trim();
      const rdate = $('#rw-date').value;
      if (!title) { alert('请填写标题'); return; }
      if (!rdate) { alert('请选择日期'); return; }
      try {
        await api('/api/rewards', 'POST', { type: $('#rw-type').value, category: $('#rw-cat').value, user_id: Number($('#rw-user').value || 0) || undefined, user_name: ($('#rw-user').value ? '' : ($('#rw-name').value || '').trim()), title, reason: $('#rw-reason').value.trim(), rdate });
        closeSheet(); renderReward();
      } catch (e) { alert(e.message); }
    },
    rwCat: () => {
      const rwCat = $('#rw-cat');
      if (!rwCat) return;
      const opts = rwCat.innerHTML;
      if ($('#rw-type').value === 'reward') {
        rwCat.innerHTML = '<optgroup label="奖励情形（运行手册第十章）"><option>灭火救援英勇处置，避免重大损失</option><option>执勤战备/业务训练/技能比武表现突出</option><option>及时发现重大安全隐患，避免不安全事件</option><option>合理化建议被采纳实施取得成效</option><option>严格落实规章，长期履职表现优秀</option><option>其他应予奖励情形</option></optgroup>';
      } else {
        rwCat.innerHTML = '<optgroup label="惩戒情形（运行手册第十章）"><option>值班擅离职守/脱岗/睡岗</option><option>出动行动迟缓，影响响应时间</option><option>车辆/装备检查不到位，未发现故障隐患</option><option>无故不参加训练/演练</option><option>训练考核多次不合格，补训补考仍不达标</option><option>违反保密守则，泄密风险</option><option>外出/休假不履行报备审批手续</option><option>检查记录/台账弄虚作假</option><option>应急处置不服从指挥/贻误处置时机</option><option>其他违反手册/机场规章制度行为</option></optgroup>';
      }
    },
    delReward: async (id) => {
      if (!confirm('删除该奖惩记录？')) return;
      try { await api('/api/rewards/' + id, 'DELETE'); renderReward(); } catch (e) { alert(e.message); }
    },
    doImport: async () => {
      const type = $('#imp-type').value;
      const rows = $('#imp-rows').value.split(/\n+/).map((x) => x.trim()).filter(Boolean);
      if (!rows.length) { alert('请粘贴导入内容'); return; }
      $('#imp-tip').textContent = '正在导入…';
      try {
        const r = await api('/api/import/batch', 'POST', { type, rows });
        const html = `<div class="setup-tip">导入完成：成功 ${r.data.ok} 行，失败 ${r.data.err} 行${r.data.errList && r.data.errList.length ? '<br>' + r.data.errList.map(esc).join('<br>') : ''}</div>`;
        $('#imp-result').innerHTML = html;
        $('#imp-tip').textContent = '逐行校验：格式错误的行会跳过并在结果中列出，不阻断其他行导入。';
        $('#imp-rows').value = '';
      } catch (e) { $('#imp-result').innerHTML = '<div class="setup-tip" style="background:#fde8e8;">导入失败：' + esc(e.message) + '</div>'; }
    }
  });

  /* ===== v5.9 数据备份（仅运维/管理员；3 槽轮转，第 4 轮覆盖第 1 轮） ===== */
  async function renderBackup() {
    const el = $('#page-backup');
    const lv = MYLV();
    if (lv < 4) { el.innerHTML = '<div class="empty">权限不足：仅运维工程师/管理员可使用数据备份</div>'; return; }
    const load = async () => {
      const [list, cfg] = await Promise.all([api('/api/backup/list'), api('/api/backup/schedule')]);
      return { list, cfg };
    };
    let d;
    try { d = await load(); } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; return; }
    const slotHtml = d.list.map((s) => `
      <div class="backup-slot">
        <div class="bs-h">备份槽位 ${s.slot}</div>
        ${s.has ? `<div class="bs-meta">${esc(s.meta.type === 'auto' ? '自动备份' : s.meta.type === 'restore-before' ? '恢复前自动备份' : '手动备份')} · ${esc(s.meta.at)}</div>
        <div class="bs-size">大小 ${(s.meta.size / 1024 / 1024).toFixed(2)} MB</div>
        <button class="btn" onclick="app.restoreBackup(${s.slot})" style="margin-top:8px;">从该备份恢复</button>` : '<div class="bs-meta muted">暂无备份</div>'}
      </div>`).join('');
    el.innerHTML = `
      <div class="card">
        <h3><svg class="lg-ic"><use href="#i-archive"/></svg> 数据备份</h3>
        <div class="setup-tip">备份内容：数据库 + 上传文件 + 软件代码，单独存放于服务器 <b>data/backups/</b> 目录。共 3 个备份槽位轮转：每完成 1 轮备份占用 1 个槽位，<b>第 4 轮自动覆盖第 1 轮</b>，始终保留最近 3 份。</div>
        <div style="margin:14px 0;"><button class="btn primary" onclick="app.backupNow()">立即备份</button>
        <span id="bk-result"></span></div>
        <div style="margin:14px 0;padding:10px;background:#f7f9fc;border-radius:10px;">
          <div class="field" style="margin:0;"><label>自动备份</label>
            <select id="bk-enable" onchange="app.saveBkCfg()"><option value="0">关闭</option><option value="1" ${d.cfg.enable ? 'selected' : ''}>开启</option></select>
            <label style="margin-left:10px;">每日时间</label>
            <input type="time" id="bk-time" value="${esc(d.cfg.time || '23:30')}" onchange="app.saveBkCfg()" style="padding:6px;border:1px solid #ddd;border-radius:8px;">
            <span id="bk-cfg-result" style="margin-left:8px;"></span>
          </div>
          <div class="muted" style="font-size:12px;margin-top:6px;">开启后每天到设定时间自动备份一次；备份后自动轮转到下一槽位。</div>
        </div>
        <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;">${slotHtml}</div>
      </div>`;
  }
  window.app = Object.assign(window.app || {}, {
    backupNow: async () => {
      const r = $('#bk-result');
      r.innerHTML = '备份中…';
      try { const m = await api('/api/backup/now', 'POST'); r.innerHTML = '✅ 备份完成：槽位 ' + m.slot + '（' + esc(m.at) + '）'; renderBackup(); }
      catch (e) { r.innerHTML = '❌ ' + esc(e.message); }
    },
    saveBkCfg: async () => {
      const r = $('#bk-cfg-result');
      try { const c = await api('/api/backup/schedule', 'POST', { enable: $('#bk-enable').value === '1', time: $('#bk-time').value }); r.innerHTML = '✅ 已保存：' + (c.enable ? '每日 ' + c.time + ' 自动备份' : '自动备份已关闭'); }
      catch (e) { r.innerHTML = '❌ ' + esc(e.message); }
    },
    restoreBackup: async (slot) => {
      if (!confirm('从槽位 ' + slot + ' 恢复将覆盖当前数据库和上传文件。\n恢复前系统会自动先备份当前数据（最新一轮），可回退。\n确定继续吗？')) return;
      const r = $('#bk-result');
      r.innerHTML = '恢复中（自动备份当前 → 覆盖数据）…';
      try { const m = await api('/api/backup/restore', 'POST', { slot }); r.innerHTML = '✅ 已从槽位 ' + m.slot + ' 恢复（' + esc(m.restored_at) + '），页面已刷新'; setTimeout(() => location.reload(), 800); }
      catch (e) { r.innerHTML = '❌ ' + esc(e.message); }
    }
  });

  /* ===== v8.2 个人档案（OIT 多层级下钻：总览 → 分类明细 → 单条详情） ===== */
  window.__arcView = 'overview';
  window.__arcStack = [];
  window.__arcData = null;
  window.__arcDetail = null;
  /* v8.3 通用分页：所有明细列表每页 10 条，按日期倒序展示，支持翻页 */
  window.__arcPage = {};
  function paginateList(arr, key) {
    const sz = 10;
    const pages = Math.max(1, Math.ceil(arr.length / sz));
    const pg = Math.min(Math.max(1, (window.__arcPage[key] || 1)), pages);
    window.__arcPage[key] = pg;
    return { page: pg, pages, offset: (pg - 1) * sz, rows: arr.slice((pg - 1) * sz, pg * sz) };
  }
  function pagerHTML(key, pages, page) {
    if (pages <= 1) return '';
    return `<div class="arc-pager">
      <button class="btn sm ghost" onclick="app.arcPage(${page - 1},'${key}')" ${page <= 1 ? 'disabled' : ''}>‹ 上一页</button>
      <span class="arc-pg">第 ${page} / ${pages} 页 · 每页 10 条</span>
      <button class="btn sm ghost" onclick="app.arcPage(${page + 1},'${key}')" ${page >= pages ? 'disabled' : ''}>下一页 ›</button>
    </div>`;
  }
  async function renderArchive() {
    const el = $('#page-archive');
    const empId = window.__archiveEmp || String(ME.work_no || ME.id);
    const view = window.__arcView || 'overview';
    if (!window.__arcData || window.__arcData._emp !== empId) {
      el.innerHTML = '<div class="muted" style="padding:30px;text-align:center;">加载中…</div>';
      try {
        const d = await api('/api/emp/archive?emp_id=' + encodeURIComponent(empId));
        d._emp = empId;
        window.__arcData = d;
      } catch (e) {
        // [需求1] 个人档案权限：越权不是"加载失败"这种含糊提示，直接说清谁能看、怎么申请
        const msg = String(e.message || '');
        if (/无权|403|仅|权限|不可见/.test(msg)) {
          el.innerHTML = `<div class="card"><h3>暂无查看权限</h3>
            <div class="d">${esc(msg)}</div>
            <div class="muted" style="font-size:12px;margin-top:8px;line-height:1.7;">个人完整档案含身份证、学历、合同等敏感信息，默认仅本人、班组长及以上可查；跨班组查看需对方班组班组长或部门管理员授权。</div>
            <div style="margin-top:12px;"><button class="btn sm" onclick="app.openMyArchive()">查看我自己的档案</button></div></div>`;
        } else {
          el.innerHTML = '<div class="empty">加载失败：' + esc(msg) + '</div>';
        }
        return;
      }
    }
    const d = window.__arcData;
    if (view === 'overview') el.innerHTML = arcOverview(d);
    else if (view === 'train-list') el.innerHTML = arcTrainList(d);
    else if (view === 'train-detail') el.innerHTML = arcTrainDetail(d);
    else if (view === 'assess-list') el.innerHTML = arcAssessList(d);
    else if (view === 'work-list') el.innerHTML = arcWorkList(d);
    else if (view === 'check-list') el.innerHTML = arcCheckList(d);
    else if (view === 'cards-list') el.innerHTML = arcCardsList(d);
    else if (view === 'moves-list') el.innerHTML = arcMovesList(d);
    else if (view === 'rewards-list') el.innerHTML = arcRewardsList(d);
    else if (view === 'more-list') el.innerHTML = arcMoreList(d);
    else { el.innerHTML = arcOverview(d); }
  }
  function arcHead(u, sub) {
    return `<div class="arc-head">
      <div class="arc-avatar">${esc((u.name || '?').slice(0, 1))}</div>
      <div>
        <div class="arc-name">${esc(u.name)} <span class="badge ${u.user_type === 'bumenlingdao' ? 'warn' : u.user_type === 'banzuzhang' ? 'info' : 'gray'}">${esc(u.user_type === 'bumenlingdao' ? '部门领导' : u.user_type === 'banzuzhang' ? '班组长' : u.user_type === 'weihu' ? '运维' : u.user_type === 'xinren' ? '新人' : '在职')}</span></div>
        <div class="arc-meta">${esc(u.dept_name || '未分组')} · 工号 ${esc(u.work_no)}${sub ? ' · ' + esc(sub) : ''}</div>
      </div>
    </div>`;
  }
  function arcEntry(ic, title, desc, cnt, onClick) {
    return `<div class="arc-entry" onclick="${onClick}">
      <div class="ae-ic">${ic}</div>
      <div class="ae-body">
        <div class="ae-t">${title}</div>
        <div class="ae-d">${desc}</div>
      </div>
      ${cnt !== null ? '<div class="ae-cnt">' + cnt + '</div>' : ''}
      <div class="ae-arrow">›</div>
    </div>`;
  }
  function infoRow(k, v) {
    // [需求6] 档案字段多为用户填写内容（部门/职务/学历/备注等），必须转义后再进 DOM
    const empty = '<span class="muted">—</span>';
    const val = (v === undefined || v === null || v === '') ? empty : esc(v);
    return `<div class="info-row"><span class="ik">${esc(k)}</span><span class="iv">${val}</span></div>`;
  }
  /* —— 二级：档案总览（个人信息 + 分类入口） —— */
  function arcOverview(d) {
    const u = d.user, w = d.work, t = d.train, a = d.assess, c = d.check, sum = t.sum;
    const utypeName = u.user_type === 'bumenlingdao' ? '部门领导' : u.user_type === 'banzuzhang' ? '班组长' : u.user_type === 'weihu' ? '运维' : u.user_type === 'xinren' ? '新人' : '在职';
    return `
    ${arcHead(u, (u.hire_date ? '入职 ' + u.hire_date : '') + (u.created_at ? ' · 入档 ' + u.created_at.slice(0, 10) : ''))}
    <div class="arc-sum-row">
      <div class="arc-sum nb"><div class="n">${sum.total}</div><div class="l">培训次数</div></div>
      <div class="arc-sum"><div class="n">${sum.hours}</div><div class="l">累计学时</div></div>
      <div class="arc-sum wb"><div class="n">${sum.waibei}</div><div class="l">外培次数</div></div>
      <div class="arc-sum"><div class="n">${sum.cert}</div><div class="l">持证数</div></div>
      <div class="arc-sum"><div class="n">${a.sum}</div><div class="l">考核记录</div></div>
      <div class="arc-sum"><div class="n">${c.sum}</div><div class="l">检查/整改</div></div>
    </div>
    <div class="card">
      <h3><svg class="lg-ic"><use href="#i-person"/></svg> 个人信息</h3>
      ${infoRow('人员类型', utypeName)}
      ${infoRow('所属部门', u.dept_name || '未分组')}
      ${infoRow('岗位/职务', u.job_title || '')}
      ${infoRow('工号（工作证编号）', u.work_no)}
      ${infoRow('入职日期', u.hire_date)}
      ${infoRow('性别', u.gender === 'A' ? '男' : u.gender === 'B' ? '女' : u.gender)}
      ${infoRow('民族', u.nation)}
      ${infoRow('出生日期', u.birth_date)}
      ${infoRow('政治面貌', u.political_status)}
      ${infoRow('学历', u.education)}
      ${infoRow('联系电话', u.mobile)}
      ${infoRow('劳动合同', u.contract_signed ? '已签订' + (u.contract_signed_at ? '（' + u.contract_signed_at.slice(0, 10) + '）' : '') : '未签订')}
    </div>
    <div class="arc-entry-grp">
      ${arcEntry('🎓', '培训档案', '内培' + sum.neibei + ' / 外培' + sum.waibei + ' · 累计 ' + sum.hours + ' 学时 · 费用 ' + sum.fee + ' 元', sum.total, "app.openArcView('train-list')")}
      ${arcEntry('📊', '考核档案', '考核记录与等级成绩', a.sum, "app.openArcView('assess-list')")}
      ${arcEntry('📁', '工作记录', '考勤 ' + w.attend_days + ' 天 · 请假 ' + w.leaves + ' · 值班 ' + w.duty + ' · 待办 ' + w.tasks_open, null, "app.openArcView('work-list')")}
      ${arcEntry('🔍', '检查与整改', '作为检查人 ' + c.checks.length + ' 次 · 整改责任 ' + c.issues.length + ' 项', c.sum, "app.openArcView('check-list')")}
      ${arcEntry('📇', '卡证档案', '证件/卡证 ' + (d.cards || []).length + ' 张', (d.cards || []).length, "app.openArcView('cards-list')")}
      ${arcEntry('🔄', '异动记录', '调岗调职/岗位异动 ' + (d.moves || []).length + ' 条', (d.moves || []).length, "app.openArcView('moves-list')")}
      ${arcEntry('🏅', '奖惩记录', '奖励 ' + (d.rewards || []).filter((x) => x.kind === '奖励').length + ' · 处分 ' + (d.rewards || []).filter((x) => x.kind !== '奖励').length, (d.rewards || []).length, "app.openArcView('rewards-list')")}
      ${arcEntry('📄', '更多人事资料', '合同/社保/经历/技能/家庭/体检/工伤/宿舍', (d.hr || []).reduce((s, x) => s + Number(x.count || 0), 0), "app.openArcView('more-list')")}
    </div>`;
  }
  /* —— 三级：卡证明细（OIT emp_card） —— */
  function arcCardsList(d) {
    const u = d.user;
    const list = d.cards || [];
    const today = new Date().toISOString().slice(0, 10);
    const pg = paginateList(list, 'cards-list');
    const rows = pg.rows.map((x, i) => `<div class="arc-item" onclick="app.openArcSheetByKind('cards', ${pg.offset + i})">
        <div class="ai-ic">🪪</div>
        <div class="ai-body">
          <div class="ai-t">${esc(x.card_type || '证件')} · ${esc(x.card_no)} <span class="badge ${x.invalid_date && x.invalid_date < today ? 'bad' : 'ok'}">${x.invalid_date && x.invalid_date < today ? '已过期' : '有效'}</span></div>
          <div class="ai-d">${esc(x.granter || '—')} · 发证 ${x.grant_date || '—'}${x.invalid_date ? ' · 至 ' + x.invalid_date : ''}</div>
        </div>
        <div class="ai-arrow">›</div>
      </div>`).join('') || '<div class="empty">暂无卡证记录</div>';
    return `
    <div class="arc-sub-head" onclick="app.arcBack()"><span class="arc-back">‹</span> 卡证档案 · ${esc(u.name)}</div>
    ${arcHead(u)}
    <div class="arc-entry-grp">
      ${rows}
    </div>
    ${pagerHTML('cards-list', pg.pages, pg.page)}`;
  }
/* —— 三级：异动明细（OIT emp_post_move） —— */
  function arcMovesList(d) {
    const u = d.user;
    const list = d.moves || [];
    const pg = paginateList(list, 'moves-list');
    const rows = pg.rows.map((x, i) => `<div class="arc-item" onclick="app.openArcSheetByKind('moves', ${pg.offset + i})">
        <div class="ai-ic">🔄</div>
        <div class="ai-body">
          <div class="ai-t">${esc(x.move_type || '岗位异动')} · ${x.move_date || ''}</div>
          <div class="ai-d">${esc(x.o_dept || '—')} → ${esc(x.dept || '—')}${x.o_post ? '（' + esc(x.o_post) + ' → ' + esc(x.dept_post || '') + '）' : ''}</div>
        </div>
        <div class="ai-arrow">›</div>
      </div>`).join('') || '<div class="empty">暂无异动记录</div>';
    return `
    <div class="arc-sub-head" onclick="app.arcBack()"><span class="arc-back">‹</span> 异动记录 · ${esc(u.name)}</div>
    ${arcHead(u)}
    <div class="arc-entry-grp">
      ${rows}
    </div>
    ${pagerHTML('moves-list', pg.pages, pg.page)}`;
  }
/* —— 三级：奖惩明细（OIT emp_punishment / emp_prize） —— */
  function arcRewardsList(d) {
    const u = d.user;
    const list = d.rewards || [];
    const pg = paginateList(list, 'rewards-list');
    const rows = pg.rows.map((x, i) => `<div class="arc-item" onclick="app.openArcSheetByKind('rewards', ${pg.offset + i})">
        <div class="ai-ic">${x.kind === '奖励' ? '🏅' : '⚠️'}</div>
        <div class="ai-body">
          <div class="ai-t">${esc(x.r_type || x.kind)} <span class="badge ${x.kind === '奖励' ? 'ok' : 'bad'}">${esc(x.kind)}</span></div>
          <div class="ai-d">${x.r_date || ''} · ${esc(x.cause || '')}</div>
        </div>
        <div class="ai-arrow">›</div>
      </div>`).join('') || '<div class="empty">暂无奖惩记录</div>';
    return `
    <div class="arc-sub-head" onclick="app.arcBack()"><span class="arc-back">‹</span> 奖惩记录 · ${esc(u.name)}</div>
    ${arcHead(u)}
    <div class="arc-entry-grp">
      ${rows}
    </div>
    ${pagerHTML('rewards-list', pg.pages, pg.page)}`;
  }
  /* —— 三级：更多人事资料（OIT emp_contract/insurance/work_his/study_his/technical/family/med_check/job_hurt/dorm_use）
     OIT 演示库多为 0 行：按类别模板显示空态，正式库导入后自动带出数据 —— */
  function arcMoreList(d) {
    const u = d.user;
    const ics = { contract: '📃', insurance: '🛡️', work_his: '💼', study_his: '🎓', technical: '🪪', family: '👨‍👩‍👧', med_check: '🩺', job_hurt: '🩹', dorm: '🏠' };
    const list = d.hr || [];
    return `
    <div class="arc-sub-head" onclick="app.arcBack()"><span class="arc-back">‹</span> 更多人事资料 · ${esc(u.name)}</div>
    ${arcHead(u)}
    <div class="arc-note-tip">以下资料对应 OIT 人事子表，当前演示库暂无数据，正式库通过采集器导入后自动显示</div>
    <div class="arc-entry-grp">
      ${list.map((x) => `<div class="arc-item">
        <div class="ai-ic">${ics[x.code] || '📄'}</div>
        <div class="ai-body">
          <div class="ai-t">${esc(x.name)} <span class="badge gray">${esc(x.oit_table || '')}</span></div>
          <div class="ai-d">${Number(x.count) > 0 ? '已有 ' + x.count + ' 条' : '暂无记录 · 待导入'}</div>
        </div>
        <div class="ai-cnt">${x.count || 0}</div>
      </div>`).join('') || '<div class="empty">暂无更多人事资料</div>'}
    </div>`;
  }
  /* —— 三级：培训明细列表（内外培筛选 + 全部记录，点行进详情） —— */
  function arcTrainList(d) {
    const u = d.user, t = d.train, sum = t.sum;
    const f = window.__arcTrainFilter || '全部';
    const list = t.list.filter((x) => f === '全部' || x.train_service === f);
    const chips = ['全部', '内培', '外培'].map((k) => `<span class="chip ${f === k ? 'on' : ''}" onclick="app.arcTrainFilter('${k}')">${k}</span>`).join('');
    const pg = paginateList(list, 'train-list');
    const rows = pg.rows.map((x, i) => `
      <div class="arc-item" onclick="app.openArcDetail(${pg.offset + i})">
        <div class="ai-ic">${x.train_service === '外培' ? '🏛️' : '🏢'}</div>
        <div class="ai-body">
          <div class="ai-t">${esc(x.class_info || '未填课程')} <span class="badge ${x.train_service === '外培' ? 'warn' : 'info'}">${esc(x.train_service || '内培')}</span></div>
          <div class="ai-d">参训 ${x.beg_date || '待填'}${x.end_date && x.end_date !== x.beg_date ? ' ~ ' + x.end_date : ''} · ${x.hours || 0} 学时${x.mark_grade ? ' · 📝 ' + esc(x.mark_grade.slice(0, 30)) : ''}</div>
        </div>
        <div class="ai-arrow">›</div>
      </div>`).join('') || '<div class="empty">暂无' + f + '培训记录</div>';
    return `
    <div class="arc-sub-head" onclick="app.arcBack()"><span class="arc-back">‹</span> 培训档案 · ${esc(u.name)}</div>
    ${arcHead(u, (u.hire_date ? '入职 ' + u.hire_date : ''))}
    <div class="arc-sum-row">
      <div class="arc-sum nb"><div class="n">${sum.total}</div><div class="l">总次数</div></div>
      <div class="arc-sum"><div class="n">${sum.hours}</div><div class="l">累计学时</div></div>
      <div class="arc-sum wb"><div class="n">${sum.waibei}</div><div class="l">外培</div></div>
      <div class="arc-sum"><div class="n">${sum.cert}</div><div class="l">持证</div></div>
      <div class="arc-sum"><div class="n">${sum.fee}</div><div class="l">费用(元)</div></div>
      <div class="arc-sum"><div class="n">${sum.neibei}</div><div class="l">内培</div></div>
    </div>
    <div class="arc-filter">${chips}</div>
    ${rows}
    ${pagerHTML('train-list', pg.pages, pg.page)}
    <div style="height:24px;"></div>`;
  }
  /* —— 四级：单条培训详情（OIT 培训记录表单样式） —— */
  function arcTrainDetail(d) {
    const u = d.user, t = d.train;
    const x = t.list[window.__arcDetail];
    if (!x) return '<div class="empty">记录不存在</div>' + arcTrainList(d);
    const TRAIN_T = { '001': '非专业安保人员培训', '002': '服务培训', '004': '专项/季节培训', '005': '岗前培训', '006': '机坪安全运行培训' };
    const TRAIN_M = { A: '集中培训', B: '视频培训' };
    const rows = [
      ['培训类别', x.train_service === '外培' ? '委外培训（外培）' : '内部培训（内培）'],
      ['课程名称', x.class_info],
      ['培训类型', TRAIN_T[x.train_type] || x.train_type || ''],
      ['培训方式', TRAIN_M[x.train_method] || x.train_method || ''],
      ['参训日期', (x.beg_date || '待填') + (x.end_date && x.end_date !== x.beg_date ? ' 至 ' + x.end_date : '')],
      ['培训天数', x.days ? x.days + ' 天' : ''],
      ['培训学时', x.hours ? x.hours + ' 学时' : ''],
      ['费用(元)', x.fee ? x.fee : ''],
      ['考核成绩', x.mark_grade || ''],
      ['培训效果', x.train_effect || ''],
      ['证书编号', x.certificate_no || ''],
      ['服务期至', x.lmt_service_date || ''],
      ['授课教员', x.teacher_name || ''],
      ['承办机构', x.corp_organize || ''],
      ['协作机构', x.corp_operate || ''],
      ['备注', x.note_info || '']
    ];
    return `
    <div class="arc-sub-head" onclick="app.arcBack()"><span class="arc-back">‹</span> 培训详情 · ${esc(u.name)}</div>
    ${arcHead(u, (u.hire_date ? '入职 ' + u.hire_date : ''))}
    <div class="card">
      <h3>${x.train_service === '外培' ? '🏛️' : '🏢'} ${esc(x.class_info || '培训记录')} <span class="badge ${x.train_service === '外培' ? 'warn' : 'info'}">${esc(x.train_service || '内培')}</span></h3>
      ${rows.map(([k, v]) => infoRow(k, v)).join('')}
    </div>
    <button class="btn block" onclick="app.arcBack()">‹ 返回培训列表</button>`;
  }
  /* —— 三级：考核列表 —— */
  function arcAssessList(d) {
    const u = d.user, a = d.assess;
    const pg = paginateList(a.list || [], 'assess-list');
    const rows = pg.rows.map((x) => `
      <div class="arc-item">
        <div class="ai-ic">📝</div>
        <div class="ai-body">
          <div class="ai-t">${esc(x.assess_name || '考核')}${x.item_name ? ' · ' + esc(x.item_name) : ''} ${x.grade ? '<span class="badge ' + (x.grade === '优秀' ? 'ok' : x.grade === '不合格' ? 'bad' : 'info') + '">' + esc(x.grade) + '</span>' : ''}</div>
          <div class="ai-d">${x.assess_date || ''} · 得分 ${x.mark || '—'}${x.assessor_name ? ' · 考核人 ' + esc(x.assessor_name) : ''}</div>
        </div>
      </div>`).join('') || '<div class="empty">暂无考核记录</div>';
    return `
    <div class="arc-sub-head" onclick="app.arcBack()"><span class="arc-back">‹</span> 考核档案 · ${esc(u.name)}</div>
    ${arcHead(u, (u.hire_date ? '入职 ' + u.hire_date : ''))}
    ${rows}
    ${pagerHTML('assess-list', pg.pages, pg.page)}
    <div style="height:24px;"></div>`;
  }
  /* —— 三级：工作记录明细（考勤/请假/值班/任务） —— */
  function arcWorkList(d) {
    const u = d.user, w = d.work;
    const grp = (title, rows, empty) => `<div class="card"><h3>${title}<span class="wk-badge">${rows.length}</span></h3>` + (rows.map((x) => x).join('') || '<div class="empty">' + empty + '</div>') + '</div>';
    const lv = w.leave_list.map((x) => `<div class="arc-item"><div class="ai-ic">🏖️</div><div class="ai-body"><div class="ai-t">${esc(x.type || '请假')} ${esc(x.reason || '')}</div><div class="ai-d">${esc(x.start_time || '').slice(0, 10)} ~ ${esc(x.end_time || '').slice(0, 10)} · <span class="badge ok">已批准</span></div></div></div>`);
    const tk = w.task_list.map((x) => `<div class="arc-item"><div class="ai-ic">✅</div><div class="ai-body"><div class="ai-t">${esc(x.title)} <span class="badge ${x.status === 'done' ? 'ok' : 'warn'}">${x.status === 'done' ? '已办' : '待办'}</span></div><div class="ai-d">${x.due_date ? '限期 ' + esc(x.due_date) : ''}${x.created_at ? ' · 创建 ' + esc(x.created_at.slice(0, 10)) : ''}</div></div></div>`);
    return `
    <div class="arc-sub-head" onclick="app.arcBack()"><span class="arc-back">‹</span> 工作记录 · ${esc(u.name)}</div>
    ${arcHead(u, (u.hire_date ? '入职 ' + u.hire_date : ''))}
    <div class="card"><h3>概要<span class="wk-badge">${Number(w.attend_days) + Number(w.leaves) + Number(w.duty) + Number(w.tasks_done) + Number(w.tasks_open)}</span></h3>
      <div class="arc-item"><div class="ai-ic">📊</div><div class="ai-body"><div class="ai-t">考勤打卡 <b>${w.attend_days}</b> 天 · 请假 <b>${w.leaves}</b> 次 · 值班 <b>${w.duty}</b> 次</div><div class="ai-d">任务 已办 <b>${w.tasks_done}</b> / 待办 <b>${w.tasks_open}</b>（明细请进入对应功能查看）</div></div></div></div>
    ${grp('🏖️ 请假（已批准 ' + w.leaves + '）', lv, '暂无请假记录')}
    ${grp('✅ 任务（已办 ' + w.tasks_done + ' / 待办 ' + w.tasks_open + '）', tk, '暂无任务记录')}
    <div style="height:24px;"></div>`;
  }
  /* —— 三级：检查与整改 —— */
  function arcCheckList(d) {
    const u = d.user, c = d.check;
    const checksPg = paginateList(c.checks || [], 'check-list');
    const issuesPg = paginateList(c.issues || [], 'issue-list');
    const crows = checksPg.rows.map((x) => `<div class="arc-item"><div class="ai-ic">🔎</div><div class="ai-body"><div class="ai-t">${esc(x.check_type || '检查')} ${x.result === 'ok' ? '<span class="badge ok">合格</span>' : '<span class="badge bad">发现问题</span>'}</div><div class="ai-d">${x.check_date}${x.area ? ' · ' + esc(x.area) : ''}${x.summary ? ' · ' + esc(x.summary.slice(0, 50)) : ''}</div></div></div>`).join('') || '<div class="empty">暂无检查记录</div>';
    const irows = issuesPg.rows.map((x) => `<div class="arc-item"><div class="ai-ic">⚠️</div><div class="ai-body"><div class="ai-t">${esc(x.content)} <span class="badge ${x.status === 'accepted' ? 'ok' : x.status === 'open' ? 'bad' : 'warn'}">${ISSUE_ST[x.status] || x.status}</span></div><div class="ai-d">${x.rectify_deadline ? '限期 ' + x.rectify_deadline : ''}${x.notice_no ? ' · 通知 ' + esc(x.notice_no) : ''}</div></div></div>`).join('') || '<div class="empty">暂无整改记录</div>';
    return `
    <div class="arc-sub-head" onclick="app.arcBack()"><span class="arc-back">‹</span> 检查与整改 · ${esc(u.name)}</div>
    ${arcHead(u, (u.hire_date ? '入职 ' + u.hire_date : ''))}
    <div class="card"><h3><svg class="lg-ic"><use href="#i-search"/></svg> 检查记录<span class="wk-badge">${(c.checks || []).length}</span></h3>${crows}</div>
    ${pagerHTML('check-list', checksPg.pages, checksPg.page)}
    <div class="card"><h3><svg class="lg-ic"><use href="#i-alarm"/></svg> 整改问题<span class="wk-badge">${(c.issues || []).length}</span></h3>${irows}</div>
    ${pagerHTML('issue-list', issuesPg.pages, issuesPg.page)}
    ${!c.checks.length && !c.issues.length ? '<div class="empty">暂无检查/整改记录</div>' : ''}
    <div style="height:24px;"></div>`;
  }
  window.app.openArcView = (v) => { window.__arcStack.push(window.__arcView); window.__arcView = v; renderArchive(); };
  window.app.arcBack = () => { if (window.__arcStack.length) { window.__arcView = window.__arcStack.pop(); renderArchive(); } };
  window.app.arcTrainFilter = (k) => { window.__arcTrainFilter = k; window.__arcPage['train-list'] = 1; renderArchive(); };
  window.app.openArcSheet = (t, rows) => {
    openSheet('<div style="padding:18px 0 6px;"><div class="sheet-title">' + esc(t || '详情') + ' 详情</div>' + rows.map(([k, v]) => infoRow(k, v)).join('') + '<button class="btn block" style="margin-top:14px;" onclick="app.closeSheet()">关闭</button></div>');
  };
  window.app.openArcSheetByKind = (kind, idx) => {
    const d = window.__arcData; if (!d) return;
    const rowsOf = {
      cards: (x) => [['证件编号', x.card_no], ['证件类型', x.card_type], ['发证机构', x.granter], ['发证日期', x.grant_date], ['失效日期', x.invalid_date || '长期'], ['状态', x.state === '0' ? '有效' : x.state], ['备注', x.note_info]],
      moves: (x) => [['异动类型', x.move_type], ['异动日期', x.move_date], ['原部门', x.o_dept], ['调入部门', x.dept], ['原岗位', x.o_post], ['新岗位', x.dept_post], ['备注', x.note_info]],
      rewards: (x) => [['类别', x.kind], ['类型', x.r_type], ['日期', x.r_date], ['事由', x.cause], ['批准人', x.agree_emp], ['金额(元)', x.amount], ['备注', x.note_info]]
    };
    const list = (d[kind] || [])[idx];
    if (!list) return;
    const title = kind === 'cards' ? '卡证' : kind === 'moves' ? '异动' : '奖惩';
    openSheet('<div style="padding:18px 0 6px;"><div class="sheet-title">' + title + ' 详情</div>' + rowsOf[kind](list).map(([k, v]) => infoRow(k, v)).join('') + '<button class="btn block" style="margin-top:14px;" onclick="app.closeSheet()">关闭</button></div>');
  };
  window.app.openArcDetail = (i) => { window.__arcDetail = i; window.__arcStack.push(window.__arcView); window.__arcView = 'train-detail'; renderArchive(); };
  window.app.reloadArchive = () => { window.__arcData = null; renderArchive(); };

  /* ===== 考勤 ===== */
  /* [需求1] 考勤打卡与值班排班已按用户要求整块下线：入口全部摘除，直达链接也明确告知停用。 */
  async function renderAttendance() {
    const el = $('#page-attendance');
    if (el) el.innerHTML = '<div class="empty">考勤打卡模块已停用（按部门要求下线），如需记录出勤请在「检查/巡逻」或「数据录入」中登记。</div>';
  }
  async function renderAttendanceLegacy() {
    const el = $('#page-attendance');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const month = new Date().toISOString().slice(0, 7);
      const mine = await api('/api/attendance?month=' + month);
      const s = await api('/api/stats');
      const isAppr = MYLV() >= 2;
      const all = isAppr ? await api('/api/attendance/all?month=' + month) : [];
      const days = mine.length;
      const checked = mine.filter((x) => x.check_in).length;
      el.innerHTML = `
        <div class="card" style="text-align:center;padding:22px 14px;">
          <div class="muted" style="margin-bottom:12px;">${new Date().toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' })}</div>
          <div class="stat-grid">
            <div class="stat"><div class="num">${s.checked_in ? (s.checked_out ? '已签退' : '已签到') : '未签到'}</div><div class="lbl">今日状态</div></div>
            <div class="stat"><div class="num">${days}</div><div class="lbl">本月打卡天数</div></div>
            <div class="stat"><div class="num">${mine.filter((x) => x.check_in && x.check_out).length}</div><div class="lbl">完整打卡</div></div>
          </div>
          <div style="display:flex;gap:10px;justify-content:center;">
            <button class="btn" ${s.checked_in ? 'disabled' : ''} onclick="app.punch('in')">上班打卡</button>
            <button class="btn ghost" ${!s.checked_in || s.checked_out ? 'disabled' : ''} onclick="app.punch('out')">下班打卡</button>
          </div>
        </div>
        <div class="card"><h3>本月记录</h3>
          ${mine.map((x) => `<div class="list-item"><div class="ic">🗓️</div><div class="body"><div class="t">${x.day}</div><div class="d">上班 ${x.check_in || '—'} · 下班 ${x.check_out || '—'}</div></div></div>`).join('') || '<div class="empty">本月暂无打卡记录</div>'}
        </div>
        ${isAppr ? `<div class="card"><h3>全员打卡（${month}）</h3>
          ${all.length ? all.map((x) => `<div class="list-item"><div class="ic">👤</div><div class="body"><div class="t">${esc(x.user_name)} <span class="badge info">${esc(x.dept_name || '')}</span></div><div class="d">${x.day} · 上班 ${x.check_in || '—'} · 下班 ${x.check_out || '—'}</div></div></div>`).join('') : '<div class="empty">本月暂无打卡数据</div>'}
        </div>` : ''}`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  window.app = Object.assign(window.app || {}, {
    punch: async (action) => {
      try {
        await api('/api/attendance', 'POST', { action });
        renderAttendance();
      } catch (e) { alert(e.message); }
    }
  });

  /* ===== 待办任务 ===== */
  async function renderTask() {
    const el = $('#page-task');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const rows = await api('/api/tasks');
      const users = await api('/api/users');
      const mine = rows.filter((x) => x.assignee_id === ME.id);
      const created = rows.filter((x) => x.creator_id === ME.id && x.assignee_id !== ME.id);
      const pr = (p) => ({ high: '<span class="badge bad">高</span>', normal: '', low: '<span class="badge gray">低</span>' }[p] || '');
      el.innerHTML = `
        <div class="actions"><button class="btn sm" onclick="app.newTask()">＋ 新建任务</button></div>
        <div class="card"><h3>分配给我的（${mine.length}）</h3>
          ${mine.map((x) => `<div class="list-item">
            <div class="ic">${x.status === 'done' ? '✅' : '📋'}</div>
            <div class="body">
              <div class="t">${esc(x.title)} ${pr(x.priority)} ${x.meeting_title ? '<span class="badge info">📋会议决策</span>' : ''} ${x.status === 'done' ? '<span class="badge ok">已完成</span>' : x.due_date && x.due_date < new Date().toISOString().slice(0, 10) ? '<span class="badge bad">已逾期</span>' : '<span class="badge info">进行中</span>'}</div>
              <div class="d">${x.meeting_title ? '来源会议：' + esc(x.meeting_title) + ' · ' : ''}创建：${esc(x.creator_name)} · 截止 ${x.due_date || '无'}</div>
            </div>
            <div class="act">${x.status !== 'done' ? '<button class="btn sm ok" onclick="app.taskAction(' + x.id + ',\'done\')">完成</button>' : '<button class="btn sm ghost" onclick="app.taskAction(' + x.id + ',\'reopen\')">重开</button>'}</div>
          </div>`).join('') || '<div class="empty">暂无待办</div>'}
        </div>
        <div class="card"><h3>我创建的（${created.length}）</h3>
          ${created.map((x) => `<div class="list-item">
            <div class="ic">👤</div>
            <div class="body">
              <div class="t">${esc(x.title)} ${x.status === 'done' ? '<span class="badge ok">已完成</span>' : ''}</div>
              <div class="d">派给 ${esc(x.assignee_name || '未指派')} · 截止 ${x.due_date || '无'}</div>
            </div>
            <div class="act">${x.status !== 'done' ? '<button class="btn sm ok" onclick="app.taskAction(' + x.id + ',\'done\')">标记完成</button>' : ''} <button class="btn sm danger" onclick="app.delTask(${x.id})">删</button></div>
          </div>`).join('') || '<div class="empty">暂无创建的任务</div>'}
        </div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  window.app = Object.assign(window.app || {}, {
    newTask: () => {
      api('/api/users').then((users) => {
        openSheet(`
          <div class="sheet-title">新建任务<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="field"><label>任务标题 *</label><input id="tk-title"></div>
          <div class="field"><label>内容</label><textarea id="tk-content" rows="3"></textarea></div>
          <div class="row2">
            <div class="field"><label>指派给</label><select id="tk-assignee"><option value="">不指派</option>${users.map((x) => '<option value="' + x.id + '">' + esc(x.real_name) + '</option>').join('')}</select></div>
            <div class="field"><label>优先级</label><select id="tk-priority"><option value="normal">普通</option><option value="high">高</option><option value="low">低</option></select></div>
          </div>
          <div class="field"><label>截止日期</label><input id="tk-due" type="date"></div>
          <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveTask()">创建</button></div>`);
      });
    },
    saveTask: async () => {
      try {
        await api('/api/tasks', 'POST', {
          title: $('#tk-title').value.trim(), content: $('#tk-content').value.trim(),
          assignee_id: $('#tk-assignee').value ? Number($('#tk-assignee').value) : null,
          due_date: $('#tk-due').value, priority: $('#tk-priority').value
        });
        closeSheet(); renderTask();
      } catch (e) { alert(e.message); }
    },
    taskAction: async (id, action) => {
      try { await api('/api/tasks/' + id, 'PUT', { action }); renderTask(); } catch (e) { alert(e.message); }
    },
    delTask: async (id) => {
      if (!confirm('删除该任务？')) return;
      try { await api('/api/tasks/' + id, 'DELETE'); renderTask(); } catch (e) { alert(e.message); }
    }
  });

  /* ===== 人事管理（入职/离职）===== */
  let hrTab = 'in';
  let ivQR = null;
  let ivEditId = null;
  async function renderHR() {
    const el = $('#page-hr');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const ons = await api('/api/onboardings');
      const offs = await api('/api/offboardings');
      const lv = MYLV();
      const isAppr = lv >= 2;
      const canType = lv >= 3;
      const users = canType ? await api('/api/users') : [];
      const ivs = isAppr ? await api('/api/interviews') : [];
      const today = todayStr();
      el.innerHTML = `
        <div class="sub-tabs">
          <div class="sub-tab${hrTab === 'in' ? ' on' : ''}" onclick="app.hrTab('in')">入职追踪</div>
          <div class="sub-tab${hrTab === 'out' ? ' on' : ''}" onclick="app.hrTab('out')">离职追踪</div>
          ${isAppr ? `<div class="sub-tab${hrTab === 'iv' ? ' on' : ''}" onclick="app.hrTab('iv')">招聘面试</div>` : ''}
          ${canType ? `<div class="sub-tab${hrTab === 'type' ? ' on' : ''}" onclick="app.hrTab('type')">人员类型</div>` : ''}
        </div>
        <div class="sub-panel${hrTab === 'in' ? ' show' : ''}" id="hr-in">
          <div class="actions">${isAppr ? '<button class="btn sm" onclick="app.addOnboarding()">＋ 新增入职</button>' : ''}
            <button class="btn sm ghost" onclick="switchPage('approval')">转正/调岗申请 ›</button>
          </div>
          <div class="card"><h3>入职追踪（${ons.length}）</h3>
            ${ons.filter((x) => x.status === 'onboarding').map((x) => {
              const pct = Math.round(x.ready / 3 * 100);
              const soon = x.days_left !== null && x.days_left <= 3 && x.ready < 3;
              return `
              <div class="list-item">
                <div class="ic">🧑‍💼</div>
                <div class="body">
                  <div class="t">${esc(x.name)}${x.position ? ' · ' + esc(x.position) : ''}${soon ? ' <span class="badge bad">临期</span>' : ''}</div>
                  <div class="d">入职 ${x.entry_date}${x.days_left !== null ? '（剩 ' + x.days_left + ' 天）' : ''} · offer ${esc(x.offer_status)} · 背调 ${esc(x.bg_check)}</div>
                  <div class="progress-bar"><i style="width:${pct}%"></i></div>
                  <div class="chk ${x.computer_ready ? 'done' : ''}"><input type="checkbox" ${x.computer_ready ? 'checked' : ''} onchange="app.onbReady(${x.id},'computer_ready',this.checked)"><span class="ck-label">电脑设备</span></div>
                  <div class="chk ${x.account_ready ? 'done' : ''}"><input type="checkbox" ${x.account_ready ? 'checked' : ''} onchange="app.onbReady(${x.id},'account_ready',this.checked)"><span class="ck-label">账号开通</span></div>
                  <div class="chk ${x.train_ready ? 'done' : ''}"><input type="checkbox" ${x.train_ready ? 'checked' : ''} onchange="app.onbReady(${x.id},'train_ready',this.checked)"><span class="ck-label">入职培训</span></div>
                </div>
                <div class="act">
                  ${x.ready === 3 ? '<button class="btn sm ok" onclick="app.onbAction(' + x.id + ',\'onboard\')">已入职</button>' : ''}
                  <button class="btn sm danger" onclick="app.onbAction(${x.id},'cancel')">取消</button>
                </div>
              </div>`;}).join('') || '<div class="empty">暂无进行中的入职</div>'}
          </div>
          <div class="card"><h3>已完成 / 已取消</h3>
            ${ons.filter((x) => x.status !== 'onboarding').map((x) => `<div class="list-item"><div class="ic">${x.status === 'onboarded' ? '✅' : '🚫'}</div><div class="body"><div class="t">${esc(x.name)} <span class="badge ${x.status === 'onboarded' ? 'ok' : 'gray'}">${x.status === 'onboarded' ? '已入职' : '已取消'}</span></div><div class="d">入职 ${x.entry_date} · ${esc(x.position || '')}</div></div></div>`).join('') || '<div class="empty">暂无</div>'}
          </div>
        </div>
        <div class="sub-panel${hrTab === 'out' ? ' show' : ''}" id="hr-out">
          <div class="actions">${isAppr ? '<button class="btn sm" onclick="app.addOffboarding()">＋ 新增离职</button>' : ''}</div>
          <div class="card"><h3>离职追踪（${offs.length}）</h3>
            ${offs.filter((x) => x.status === 'offboarding').map((x) => {
              const pct = Math.round(x.ready / 4 * 100);
              return `
              <div class="list-item">
                <div class="ic">🚪</div>
                <div class="body">
                  <div class="t">${esc(x.name)} ${x.ready === 4 ? '<span class="badge ok">清单已清</span>' : ''}</div>
                  <div class="d">离职 ${x.leave_date} · 交接人 ${esc(x.handover_person || '—')}</div>
                  <div class="progress-bar"><i style="width:${pct}%"></i></div>
                  <div class="chk ${x.project_handover ? 'done' : ''}"><input type="checkbox" ${x.project_handover ? 'checked' : ''} onchange="app.offReady(${x.id},'project_handover',this.checked)"><span class="ck-label">项目/文档交接</span></div>
                  <div class="chk ${x.permission_reclaim ? 'done' : ''}"><input type="checkbox" ${x.permission_reclaim ? 'checked' : ''} onchange="app.offReady(${x.id},'permission_reclaim',this.checked)"><span class="ck-label">权限回收</span></div>
                  <div class="chk ${x.device_return ? 'done' : ''}"><input type="checkbox" ${x.device_return ? 'checked' : ''} onchange="app.offReady(${x.id},'device_return',this.checked)"><span class="ck-label">设备归还</span></div>
                  <div class="chk ${x.social_insurance ? 'done' : ''}"><input type="checkbox" ${x.social_insurance ? 'checked' : ''} onchange="app.offReady(${x.id},'social_insurance',this.checked)"><span class="ck-label">社保停缴</span></div>
                  ${x.doc_link ? `<div class="d">交接文档：<a href="${esc(x.doc_link)}" target="_blank">${esc(x.doc_link)}</a></div>` : ''}
                </div>
                <div class="act">
                  ${x.ready === 4 ? '<button class="btn sm ok" onclick="app.offAction(' + x.id + ',\'done\')">完成离职</button>' : ''}
                  <button class="btn sm danger" onclick="app.offAction(${x.id},'cancel')">取消</button>
                </div>
              </div>`;}).join('') || '<div class="empty">暂无进行中的离职</div>'}
          </div>
          <div class="card"><h3>已完成 / 已取消</h3>
            ${offs.filter((x) => x.status !== 'offboarding').map((x) => `<div class="list-item"><div class="ic">✅</div><div class="body"><div class="t">${esc(x.name)} <span class="badge ${x.status === 'done' ? 'ok' : 'gray'}">${x.status === 'done' ? '已完成' : '已取消'}</span></div><div class="d">离职 ${x.leave_date}</div></div></div>`).join('') || '<div class="empty">暂无</div>'}
          </div>
        </div>
        ${isAppr ? `<div class="sub-panel${hrTab === 'iv' ? ' show' : ''}" id="hr-iv">
          <div class="actions">
            <button class="btn sm" onclick="app.addInterview()">＋ 新增面试</button>
            <button class="btn sm" onclick="app.genInterviewQR()">📱 生成扫码填写二维码</button>
            <button class="btn sm ghost" onclick="app.openIVCfg()">表单设置</button>
          </div>
          <div class="card"><h3>招聘面试（${ivs.length}）</h3>
            ${ivs.map((x) => `
              <div class="list-item">
                <div class="ic">🎯</div>
                <div class="body">
                  <div class="t">${esc(x.candidate)}${x.result && x.result !== '待面试' ? ' <span class="badge ' + (x.result === '通过' || x.result === '已入职' ? 'ok' : (x.result === '淘汰' ? 'bad' : 'warn')) + '">' + esc(x.result) + '</span>' : ''}${x.offer_status !== '未发送' ? ' <span class="badge gray">offer ' + esc(x.offer_status) + '</span>' : ''}</div>
                  <div class="d">应聘 ${esc(x.position || '—')}${x.dept && x.dept !== '扫码填写' ? ' · ' + esc(x.dept) : ''}${x.interview_date ? ' · 面试 ' + x.interview_date : ''}${x.interviewer && x.interviewer !== '扫码填写' ? ' · ' + esc(x.interviewer) : ''}</div>
                  ${x.note ? `<div class="d" style="font-size:12px;color:#9ca3af;">${esc(x.note.slice(0, 120))}</div>` : ''}
                </div>
                <div class="act">
                  ${x.result === '通过' ? '<button class="btn sm ok" onclick="app.ivToOnb(' + x.id + ')">转入职</button>' : ''}
                  <button class="btn sm ghost" onclick="app.editInterview(${x.id})">编辑</button>
                  <button class="btn sm danger" onclick="app.ivDel(${x.id})">删除</button>
                </div>
              </div>`).join('') || '<div class="empty">暂无面试记录（可点「生成扫码填写二维码」让应聘者扫码自助填写）</div>'}
          </div>
          ${ivQR ? `<div class="card"><h3>扫码填写二维码（30 分钟内有效）</h3>
            <div style="text-align:center;padding:8px 0;">
              <img src="https://api.qrserver.com/v1/create-qr-code/?size=240x240&margin=8&data=${encodeURIComponent(ivQR.url)}" alt="面试登记二维码" style="width:200px;height:200px;border-radius:10px;border:1px solid #e5e7eb;">
            </div>
            <div class="d" style="font-size:12px;color:#6B7280;text-align:center;margin-bottom:4px;">用手机扫码填写，提交后自动进入本列表</div>
            <div class="d" style="font-size:12px;color:#9ca3af;text-align:center;word-break:break-all;">${esc(ivQR.url)}</div>
            <div style="display:flex;gap:8px;margin-top:8px;">
              <button class="btn sm ghost" style="flex:1" onclick="navigator.clipboard && navigator.clipboard.writeText('${esc(ivQR.url)}').then(()=>alert('链接已复制'))">复制链接</button>
              <button class="btn sm ghost" style="flex:1" onclick="app.ivQR=null;renderHR()">收起</button>
            </div>
          </div>` : ''}
        </div>` : ''}
        ${canType ? `<div class="sub-panel${hrTab === 'type' ? ' show' : ''}" id="hr-type">
          <div class="card"><h3>人员类型管理（${users.length}）</h3>
            <div class="d" style="font-size:12px;color:#6B7280;margin-bottom:8px;">新人确认签劳动合同后请在此调整类型；超过 15 天系统自动提升为「在职人员」。</div>
            ${users.map((x) => `<div class="list-item">
              <div class="ic">👤</div>
              <div class="body"><div class="t">${esc(x.real_name)}${typeBadge(x.user_type)}${x.user_type === 'xinren' && x.contract_signed ? ' <span class="badge warn">已签合同</span>' : ''}</div>
              <div class="d">${esc(x.work_no || x.username)} · ${x.user_type === 'xinren' && !x.contract_signed ? '未确认劳动合同' : x.contract_signed_at ? '签合同 ' + esc(x.contract_signed_at) : ''}</div></div>
              <div class="act">
                ${x.user_type === 'xinren' && !x.contract_signed ? '<button class="btn sm ok" onclick="app.confirmContract(' + x.id + ')">确认签合同</button>' : ''}
                <button class="btn sm ghost" onclick="app.setType(${x.id})">调整类型</button>
              </div>
            </div>`).join('')}
          </div>
        </div>` : ''}`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  // v6.1 招聘面试：直接把扫码二维码卡片注入面板（不依赖 renderHR 条件渲染时序，确保点击后立即出现）
  function injectQRCard() {
    const data = window.__ivQR || ivQR;
    if (!data || !data.url) return;
    const panel = document.getElementById('hr-iv');
    if (!panel) return;
    if (document.getElementById('ivqr-card')) return; // 已存在不重复
    const div = document.createElement('div');
    div.className = 'card';
    div.id = 'ivqr-card';
    div.innerHTML = `
      <h3>扫码填写二维码（30 分钟内有效）</h3>
      <div style="text-align:center;padding:8px 0;">
        <img src="https://api.qrserver.com/v1/create-qr-code/?size=240x240&margin=8&data=${encodeURIComponent(data.url)}" alt="面试登记二维码" style="width:200px;height:200px;border-radius:10px;border:1px solid #e5e7eb;">
      </div>
      <div class="d" style="font-size:12px;color:#6B7280;text-align:center;margin-bottom:4px;">用手机扫码填写，提交后自动进入本列表</div>
      <div class="d" style="font-size:12px;color:#9ca3af;text-align:center;word-break:break-all;">${esc(data.url)}</div>
      <div style="display:flex;gap:8px;margin-top:8px;">
        <button class="btn sm ghost" style="flex:1" onclick="navigator.clipboard && navigator.clipboard.writeText(window.__ivQR.url).then(()=>alert('链接已复制'))">复制链接</button>
        <button class="btn sm ghost" style="flex:1" onclick="document.getElementById('ivqr-card') && document.getElementById('ivqr-card').remove()">收起</button>
      </div>`;
    panel.appendChild(div);
  }

  window.app = Object.assign(window.app || {}, {
    hrTab: (t) => { hrTab = t; renderHR(); },
    // ===== v6.1 招聘面试：新增/编辑/删除/转入职/扫码/表单设置 =====
    addInterview: () => {
      ivEditId = null;
      openSheet(`
        <div class="sheet-title">新增面试记录<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>候选人姓名 *</label><input id="iv-name"></div>
        <div class="field"><label>应聘岗位 *</label><input id="iv-pos"></div>
        <div class="row2">
          <div class="field"><label>部门</label><input id="iv-dept"></div>
          <div class="field"><label>面试官</label><input id="iv-ivr"></div>
        </div>
        <div class="row2">
          <div class="field"><label>面试日期</label><input id="iv-date" type="date"></div>
          <div class="field"><label>面试结果</label><select id="iv-result"><option>待面试</option><option>通过</option><option>淘汰</option><option>待定</option></select></div>
        </div>
        <div class="field"><label>offer 状态</label><select id="iv-offer"><option>未发送</option><option>待发送</option><option>已发送</option><option>已接受</option><option>已拒绝</option></select></div>
        <div class="field"><label>备注</label><input id="iv-note"></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveInterview()">保存</button></div>`);
    },
    editInterview: (id) => {
      api('/api/interviews').then((ivs) => {
        const x = (ivs || []).find((r) => r.id === id);
        if (!x) return alert('记录不存在');
        ivEditId = id;
        openSheet(`
          <div class="sheet-title">编辑面试记录<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="field"><label>候选人姓名 *</label><input id="iv-name" value="${esc(x.candidate)}"></div>
          <div class="field"><label>应聘岗位 *</label><input id="iv-pos" value="${esc(x.position)}"></div>
          <div class="row2">
            <div class="field"><label>部门</label><input id="iv-dept" value="${esc(x.dept)}"></div>
            <div class="field"><label>面试官</label><input id="iv-ivr" value="${esc(x.interviewer)}"></div>
          </div>
          <div class="row2">
            <div class="field"><label>面试日期</label><input id="iv-date" type="date" value="${esc(x.interview_date)}"></div>
            <div class="field"><label>面试结果</label><select id="iv-result">${['待面试', '通过', '淘汰', '待定'].map((o) => `<option${o === x.result ? ' selected' : ''}>${o}</option>`).join('')}</select></div>
          </div>
          <div class="field"><label>offer 状态</label><select id="iv-offer">${['未发送', '待发送', '已发送', '已接受', '已拒绝'].map((o) => `<option${o === x.offer_status ? ' selected' : ''}>${o}</option>`).join('')}</select></div>
          <div class="field"><label>备注</label><input id="iv-note" value="${esc(x.note)}"></div>
          <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveInterview()">保存</button></div>`);
      });
    },
    saveInterview: async () => {
      try {
        const body = {
          candidate: $('#iv-name').value.trim(), position: $('#iv-pos').value.trim(), dept: $('#iv-dept').value.trim(),
          interviewer: $('#iv-ivr').value.trim(), interview_date: $('#iv-date').value, result: $('#iv-result').value,
          offer_status: $('#iv-offer').value, note: $('#iv-note').value.trim()
        };
        if (ivEditId) await api('/api/interviews/' + ivEditId, 'PUT', body);
        else await api('/api/interviews', 'POST', body);
        closeSheet(); renderHR();
      } catch (e) { alert(e.message); }
    },
    ivDel: async (id) => {
      if (!confirm('确定删除该面试记录？（可到数据回收站恢复）')) return;
      try { await api('/api/interviews/' + id, 'DELETE'); renderHR(); } catch (e) { alert(e.message); }
    },
    ivToOnb: async (id) => {
      const d = prompt('转入职登记的入职日期（YYYY-MM-DD，可留空）：');
      if (d === null) return;
      try {
        await api('/api/interviews/' + id, 'PUT', { action: 'to-onboarding', entry_date: d || '' });
        alert('已转入职登记，请到「入职追踪」查看并完善准备事项'); renderHR();
      } catch (e) { alert(e.message); }
    },
    genInterviewQR: async () => {
      try {
        const r = await api('/api/interviews/qr', 'POST');
        window.__qrr = r; // 调试：暴露 api 原始返回
        ivQR = r;
        window.__ivQR = ivQR; // 暴露全局：便于复制/调试/二次验证
        renderHR(); // 全量重渲染
        injectQRCard(); // 直接注入二维码卡片（防渲染竞态，确保立即可见）
        alert('二维码已生成，请候选人扫码填写（30 分钟内有效）');
      } catch (e) { alert(e.message); }
    },
    openIVCfg: () => {
      api('/api/iv/cfg').then((r) => {
        const cfg = r || {};
        const json = JSON.stringify(cfg.fields && cfg.fields.length ? cfg.fields : [{ key: 'candidate', label: '姓名', type: 'text', required: true }], null, 1);
        openSheet(`
          <div class="sheet-title">扫码表单设置<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="field"><label>表单标题</label><input id="ivc-title" value="${esc(cfg.title || '招聘面试登记')}"></div>
          <div class="field"><label>字段配置（JSON：key/label/type/required/options）</label>
            <textarea id="ivc-fields" rows="12" style="font-family:monospace;font-size:12px;">${esc(json)}</textarea>
          </div>
          <div class="d" style="font-size:12px;color:#6B7280;margin-bottom:8px;">示例字段：{"key":"candidate","label":"姓名","type":"text","required":true}；type 支持 text/select/date/textarea；options 为下拉选项数组。可参考 OIT 人员档案字段：姓名、性别、民族、出生日期、手机号、身份证号、政治面貌、学历、毕业院校、职务等。</div>
          <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveIVCfg()">保存</button></div>`);
      }).catch((e) => alert(e.message));
    },
    saveIVCfg: async () => {
      let fields;
      try { fields = JSON.parse($('#ivc-fields').value); } catch (e) { return alert('字段配置不是合法 JSON，请检查格式'); }
      try {
        await api('/api/iv/cfg', 'PUT', { title: $('#ivc-title').value.trim() || '招聘面试登记', fields, note: '' });
        closeSheet(); alert('表单设置已保存');
      } catch (e) { alert(e.message); }
    },
    addOnboarding: () => {
      openSheet(`
        <div class="sheet-title">新增入职记录<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>姓名 *</label><input id="ob-name"></div>
        <div class="field"><label>工号（登录账号，留空自动生成）</label><input id="ob-no" placeholder="如 SHF023099"></div>
        <div class="row2">
          <div class="field"><label>岗位</label><input id="ob-pos"></div>
          <div class="field"><label>部门</label><input id="ob-dept"></div>
        </div>
        <div class="row2">
          <div class="field"><label>入职日期 *</label><input id="ob-date" type="date"></div>
          <div class="field"><label>offer 状态</label><select id="ob-offer"><option>待发送</option><option>已发送</option><option>已接受</option><option>已拒绝</option></select></div>
        </div>
        <div class="field"><label>背调状态</label><select id="ob-bg"><option>未开始</option><option>进行中</option><option>已完成</option></select></div>
        <div class="field"><label>备注</label><input id="ob-note"></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveOnboarding()">保存</button></div>`);
    },
    saveOnboarding: async () => {
      try {
        await api('/api/onboardings', 'POST', {
          name: $('#ob-name').value.trim(), work_no: $('#ob-no').value.trim(), position: $('#ob-pos').value.trim(), dept: $('#ob-dept').value.trim(),
          entry_date: $('#ob-date').value, offer_status: $('#ob-offer').value, bg_check: $('#ob-bg').value, note: $('#ob-note').value.trim()
        });
        closeSheet(); renderHR();
      } catch (e) { alert(e.message); }
    },
    onbReady: async (id, field, checked) => {
      try {
        const patch = { action: 'mark-ready' };
        patch[field] = checked;
        await api('/api/onboardings/' + id, 'PUT', patch);
        renderHR();
      } catch (e) { alert(e.message); }
    },
    onbAction: async (id, action) => {
      if (action === 'cancel' && !confirm('确认取消该入职记录？')) return;
      if (action === 'onboard' && !confirm('确认标记为已入职？')) return;
      try { await api('/api/onboardings/' + id, 'PUT', { action }); renderHR(); } catch (e) { alert(e.message); }
    },
    addOffboarding: () => {
      openSheet(`
        <div class="sheet-title">新增离职记录<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="row2">
          <div class="field"><label>姓名 *</label><input id="of-name"></div>
          <div class="field"><label>离职日期 *</label><input id="of-date" type="date"></div>
        </div>
        <div class="row2">
          <div class="field"><label>交接人</label><input id="of-hand"></div>
        </div>
        <div class="field"><label>交接文档链接</label><input id="of-doc" placeholder="飞书/网盘文档链接"></div>
        <div class="field"><label>备注</label><input id="of-note"></div>
        <div class="muted">交接文档建议包含：负责项目清单、各系统账号权限、进行中事项、常用联系人</div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveOffboarding()">保存</button></div>`);
    },
    saveOffboarding: async () => {
      try {
        await api('/api/offboardings', 'POST', {
          name: $('#of-name').value.trim(), leave_date: $('#of-date').value, handover_person: $('#of-hand').value.trim(),
          doc_link: $('#of-doc').value.trim(), note: $('#of-note').value.trim()
        });
        closeSheet(); renderHR();
      } catch (e) { alert(e.message); }
    },
    offReady: async (id, field, checked) => {
      try {
        const patch = { action: 'mark-ready' };
        patch[field] = checked;
        await api('/api/offboardings/' + id, 'PUT', patch);
        renderHR();
      } catch (e) { alert(e.message); }
    },
    offAction: async (id, action) => {
      if (action === 'cancel' && !confirm('确认取消该离职记录？')) return;
      if (action === 'done' && !confirm('确认完成离职流程？')) return;
      try { await api('/api/offboardings/' + id, 'PUT', { action }); renderHR(); } catch (e) { alert(e.message); }
    }
  });

  /* ===== 会议纪要 ===== */
  const MTYPE_TIPS = {
    '班子例会': '模板：上周完成 → 本周计划 → 行动项 → 风险与支持 → 异议 → 下次会议',
    '调度推进': '模板：决策(通过/待定/否决) → 行动项 → 异议追溯 → 遗留问题 → 下次会议',
    '复盘研判': '模板：事件回顾 → 做对的 → 出问题的 → 下次要试的 → 行动项'
  };
  const MTYPE_TEMPLATE = {
    '班子例会': '【上周完成】\n\n【本周计划】\n\n【风险与所需支持】\n\n【下次会议时间】',
    '调度推进': '【决策】\n\n【遗留问题】\n\n【下次会议时间】',
    '复盘研判': '【事件回顾】\n\n【做得好的】\n\n【问题与教训】\n\n【下次要尝试的】'
  };
  async function renderMeeting() {
    const el = $('#page-meeting');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const list = await api('/api/meetings');
      const today = todayStr();
      const typeBadge = (t) => ({ '班子例会': 'info', '调度推进': 'warn', '复盘研判': 'ok' }[t] || 'gray');
      const canCreateMt = MYLV() >= 2 || ME.role === 'admin';
      let audios = [];
      if (MYLV() >= 1) { try { audios = (await api('/api/audio/list')) || []; } catch (e2) {} }
      const recSupported = !!window.DeptBridge || !!navigator.mediaDevices;
      const stTxt = { transcribing: '转写中…', done: '已转写', failed: '失败', uploaded: '待转写' };
      el.innerHTML = `
        <div class="actions">${canCreateMt ? '<button class="btn sm" onclick="app.addMeeting()">＋ 新建会议纪要</button>' : '<div class="muted" style="font-size:13px;">仅班组长及以上可新建会议纪要；您可查看自己相关会议与决策任务</div>'}</div>
        <div class="card"><h3><svg class="lg-ic"><use href="#i-mic"/></svg> 会议录音转文字<span style="font-weight:400;font-size:12px;color:#9ca3af;">（离线转写，数据不出单位内网）</span></h3>
          <div class="field" style="margin:8px 0;">
            <button class="btn" id="rec-btn" onclick="app.toggleRec()">● 开始录音</button>
            <button class="btn ghost" onclick="document.getElementById('audio-file').click()">📁 上传音频文件</button>
            <input type="file" id="audio-file" accept="audio/*" style="display:none" onchange="app.audioUpload(this.files[0])">
            <span id="rec-timer" class="muted" style="margin-left:8px;"></span>
          </div>
          ${recSupported ? '<div class="muted" style="font-size:12px;line-height:1.7;">在 APP 内使用原生麦克风录音（需授予麦克风权限）；录音停止后自动上传转写。支持 wav/mp3/m4a/aac/ogg/webm，单条 ≤20MB。<br>🔒 录音仅存本部门服务器，不上传第三方；仅本人与班组长以上可听，可随时删除（回收站 30 天后彻底清除）。</div>' : '<div class="muted" style="font-size:12px;">当前环境不支持麦克风录音，请使用「上传音频文件」。</div>'}
          ${audios.length ? `<div style="margin-top:6px;">${audios.map((a) => `
            <div class="list-item">
              <div class="ic">🎙</div>
              <div class="body">
                <div class="t">${esc(a.title)} <span class="badge ${a.status === 'done' ? 'ok' : a.status === 'failed' ? 'danger' : 'unread'}">${stTxt[a.status] || a.status}</span>${a.duration ? ' · ' + Math.round(a.duration / 60) + '分' + (a.duration % 60) + '秒' : ''}</div>
                <div class="d">${esc(a.created_at || '')} · ${(a.size / 1024 / 1024).toFixed(1)}MB</div>
              </div>
              <div class="act"><button class="btn sm ghost" onclick="app.audioDetail(${a.id})">转写/纪要</button> <button class="btn sm danger" onclick="app.audioDel(${a.id})">删</button></div>
            </div>`).join('')}</div>` : '<div class="empty">暂无录音，点击「开始录音」或上传音频文件</div>'}
        </div>
        <div class="card"><h3>会议纪要（${list.length}）</h3>
          ${list.map((mt) => `
            <div class="list-item">
              <div class="ic">📝</div>
              <div class="body">
                <div class="t">${esc(mt.title)} <span class="badge ${typeBadge(mt.mtype)}">${esc(mt.mtype)}</span></div>
                <div class="d">${esc(mt.meet_start || mt.meet_date || '时间待定')}${mt.duration_min ? ' · ' + mt.duration_min + '分钟' : ' · 不限时长'} · ${{ all: '全员', team: '本班组', users: '指定人员' }[mt.scope] || '指定人员'} · 纪要${mt.recorder_on ? '开' : '关'} · 行动项 ${mt.open_action_count}/${mt.action_count}</div>
              </div>
              <div class="act">
                <button class="btn sm ghost" onclick="app.meetingDetail(${mt.id})">查看/行动项</button>
                <button class="btn sm ghost" onclick="app.mtExport(${mt.id})">导出纪要</button>
                <button class="btn sm ghost" onclick="app.mtRecall(${mt.id}, ${mt.recorder_on ? 0 : 1})">纪要${mt.recorder_on ? '关' : '开'}</button>
                <button class="btn sm ghost" onclick="app.mtVideo(${mt.id})">视频</button> ${(ME.role === 'admin' || mt.created_by === ME.id) ? '<button class="btn sm danger" onclick="app.delMeeting(' + mt.id + ')">删</button>' : ''}</div>
            </div>`).join('') || '<div class="empty">暂无会议纪要，点击“新建会议纪要”</div>'}
        </div>
        <div class="card"><h3>行动项三要素（提醒）</h3>
          <div class="muted">每条行动项必须写全：做什么（动词开头）＋ 谁负责（明确到人/科室）＋ 截止日期（绝对日期，不用“尽快/近期”）<br>决策时强制记录异议：谁有不同意见、为什么，便于日后追溯。</div>
        </div>`;
      // 原生录音回调：停止后分片回传 base64，收集完整后自动上传
      window.__recChunks = []; window.__recChunkTotal = 0; window.__recChunkDur = 0;
      window.__recChunk = (i, total, part, dur) => {
        if (total === 0) { v5toast('录音回传失败，请重试'); return; }
        window.__recChunks[i] = part; window.__recChunkTotal = total;
        if (dur) window.__recChunkDur = dur;
        if (i === total - 1) {
          const b64 = window.__recChunks.join('');
          window.__recChunks = [];
          app.uploadAudioB64(b64, window.__recChunkDur);
        }
      };
      window.__recErr = (m) => { v5toast('录音异常：' + m); };
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  window.app = Object.assign(window.app || {}, {
    /* ===== v6.3 会议录音转文字 ===== */
    __recOn: false,
    __recMedia: null, __recChunks: [], __recTimer: null, __recSec: 0,
    toggleRec: async () => {
      // [需求6] 录音隐私说明：仅首次录音前弹一次确认（授什么权、录了存哪、谁能听、怎么删）
      if (!app.__recOn && localStorage.getItem('rec_privacy_ok') !== '1') {
        const okk = confirm('【录音隐私说明】\n\n1. 用途：仅用于把会议/现场口述转成文字与纪要，不做其他用途。\n2. 权限：需要麦克风权限；拒绝授权只影响录音，不影响其他功能。\n3. 存储：录音与转写文本保存在部门内部服务器，按文件可见级别（默认仅本人与班组长以上）受控。\n4. 删除：可在「会议-录音/纪要」列表点「删」随时删除，删除后进入回收站 30 天再彻底清除。\n5. 不外传：录音不会上传到任何第三方平台，语音识别在本部门服务内完成。\n\n点击「确定」表示已知悉并同意开始录音。');
        if (!okk) return;
        localStorage.setItem('rec_privacy_ok', '1');
      }
      if (app.__recOn) {
        // 停止
        if (window.DeptBridge) {
          try { window.DeptBridge.stopRecord('__recDone'); } catch (e) { v5toast('停止录音失败'); }
        } else if (app.__recMedia) {
          app.__recMedia.stop();
          const blob = new Blob(app.__recChunks, { type: app.__recMedia.mimeType || 'audio/webm' });
          const b64 = await new Promise((res) => { const rd = new FileReader(); rd.onloadend = () => res(String(rd.result).split(',')[1]); rd.readAsDataURL(blob); });
          app.uploadAudioB64(b64, app.__recSec);
        }
        app.__recOn = false;
        clearInterval(app.__recTimer);
        const b = $('#rec-btn'); if (b) b.textContent = '● 开始录音'; b.style.background = '';
        const t = $('#rec-timer'); if (t) t.textContent = '';
        return;
      }
      // 开始：优先原生 bridge，其次 getUserMedia
      if (window.DeptBridge) {
        try { window.DeptBridge.startRecord(); app.__recOn = true; }
        catch (e) { v5toast('无法启动录音：' + e.message); return; }
      } else if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          const st = await navigator.mediaDevices.getUserMedia({ audio: true });
          app.__recMedia = new MediaRecorder(st);
          app.__recChunks = [];
          app.__recMedia.ondataavailable = (e) => { if (e.data && e.data.size) app.__recChunks.push(e.data); };
          app.__recMedia.start();
          app.__recOn = true;
        } catch (e) { v5toast('麦克风不可用（请授权录音或在 APP 内使用）'); return; }
      } else { v5toast('当前环境不支持录音，请使用「上传音频文件」'); return; }
      app.__recSec = 0;
      const b = $('#rec-btn'); if (b) { b.textContent = '⏹ 停止录音'; b.style.background = '#e74c3c'; }
      app.__recTimer = setInterval(() => { app.__recSec++; const t = $('#rec-timer'); if (t) t.textContent = Math.floor(app.__recSec / 60) + ':' + String(app.__recSec % 60).padStart(2, '0'); }, 1000);
      v5toast('开始录音…');
    },
    uploadAudioB64: async (b64, dur) => {
      if (!b64) { v5toast('录音内容为空'); return; }
      const title = prompt('录音名称（默认：会议录音 HH:MM）', '会议录音 ' + new Date().toTimeString().slice(0, 5)) || '会议录音';
      try {
        const r = await api('/api/audio/upload', 'POST', { name: 'rec_' + Date.now() + '.wav', title: title.slice(0, 120), data: b64 });
        v5toast('录音已上传，正在转写…');
        renderMeeting();
      } catch (e) { v5toast(e.message); }
    },
    audioUpload: async (f) => {
      if (!f) return;
      if (f.size > 20 * 1024 * 1024) { v5toast('音频超过 20MB 限制'); return; }
      const b64 = await new Promise((res) => { const rd = new FileReader(); rd.onloadend = () => res(String(rd.result).split(',')[1]); rd.readAsDataURL(f); });
      app.uploadAudioB64(b64, 0);
    },
    audioDetail: async (id) => {
      try {
        const d = await api('/api/audio/' + id);
        openSheet(`
          <div class="sheet-title">🎙 ${esc(d.title)}<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="muted" style="font-size:12px;margin-bottom:8px;">${d.status === 'done' ? '转写完成 · ' + Math.round(d.duration / 60) + '分' + (d.duration % 60) + '秒' : d.status === 'failed' ? '转写失败：' + esc(d.error || '') : '转写中，请稍后刷新查看…'}</div>
          ${d.status === 'done' ? `
            <div class="field"><label>转写全文（点击可复制）</label><textarea rows="6" readonly onclick="this.select();this.setSelectionRange(0,99999)">${esc(d.transcript || '')}</textarea></div>
            ${d.summary ? `<div class="field"><label>纪要要点</label><div style="white-space:pre-wrap;font-size:13px;background:#f8fafc;border-radius:8px;padding:10px;">${esc(d.summary)}</div></div>` : ''}
            ${d.actions ? `<div class="field"><label>待办事项</label><div style="white-space:pre-wrap;font-size:13px;background:#fffbeb;border-radius:8px;padding:10px;">${esc(d.actions)}</div></div>` : ''}
            <div class="sheet-actions"><button class="btn" onclick="app.audioToMeeting(${id})">📝 一键生成会议纪要</button><button class="btn ghost" onclick="app.closeSheet()">关闭</button></div>` : `<div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">关闭</button></div>`}
        `);
      } catch (e) { v5toast(e.message); }
    },
    audioDel: async (id) => {
      if (!confirm('删除该录音记录？')) return;
      try { await api('/api/audio/' + id, 'DELETE'); renderMeeting(); } catch (e) { v5toast(e.message); }
    },
    audioToMeeting: async (id) => {
      const title = prompt('会议纪要标题：', '会议纪要 ' + new Date().toISOString().slice(0, 10)) || '会议纪要';
      try {
        const r = await api('/api/audio/' + id + '/meeting', 'POST', { title: title.slice(0, 100) });
        v5toast('会议纪要已生成');
        app.closeSheet();
        renderMeeting();
      } catch (e) { v5toast(e.message); }
    },
    /* [需求10] 视频会议：预约开会时间、时长（0=不限）、参会范围三选一、指定参会人、会后纪要默认开启 */
    addMeeting: async () => {
      let users = [];
      try { users = (await api('/api/users')) || []; } catch (e) {}
      const lv = MYLV();
      openSheet(`
        <div class="sheet-title">新建会议<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>会议标题 *</label><input id="mt-title" placeholder="如：部门周例会"></div>
        <div class="row2">
          <div class="field"><label>会议类型</label><select id="mt-type" onchange="document.getElementById('mt-tip').textContent=app.mtypeTip(this.value)"><option>班子例会</option><option>调度推进</option><option>复盘研判</option></select></div>
          <div class="field"><label>开会时间（可预约）</label><input id="mt-start" type="datetime-local"></div>
        </div>
        <div class="row2">
          <div class="field"><label>时长（分钟，0=不限）</label><input id="mt-dur" type="number" value="0" min="0"></div>
          <div class="field"><label>主持人</label><input id="mt-host"></div>
        </div>
        <div class="field"><label>参会范围</label>
          <select id="mt-scope">
            <option value="users">指定人员</option>
            ${lv >= 2 ? '<option value="team">本班组（可另指定他人）</option>' : ''}
            ${lv >= 3 ? '<option value="all">全员</option>' : ''}
          </select>
        </div>
        <div class="field"><label>指定参会人（「本班组/全员」时留空即默认）</label>
          <div id="mt-panel" style="max-height:160px;overflow:auto;border:1px solid var(--line);border-radius:8px;padding:6px;">
            ${users.map((x) => `<label style="display:inline-flex;align-items:center;gap:4px;margin:2px 10px 2px 0;font-size:13px;">
              <input type="checkbox" class="mt-p" value="${x.id}"> ${esc(x.real_name || x.username)}</label>`).join('') || '<div class="muted">无可选人员</div>'}
          </div>
        </div>
        <label style="display:flex;align-items:center;gap:6px;margin:8px 0;font-size:13px;">
          <input type="checkbox" id="mt-recorder" checked> 会后生成纪要（默认开启，会中可再切换）
        </label>
        <div class="muted" id="mt-tip" style="font-size:12px;">${MTYPE_TIPS['班子例会']}</div>
        <div class="field" style="margin-top:8px;"><label>纪要正文</label><textarea id="mt-summary" rows="5"></textarea></div>
        <div class="row2" style="margin:6px 0 2px;">
          <button class="btn sm" onclick="app.speechToSummary()">🎤 语音速记</button>
          <button class="btn sm ghost" onclick="app.digestMeeting()">✨ 智能整理（分段+行动项）</button>
        </div>
        <div class="field"><label>异议追溯（谁有不同意见、为什么）</label><textarea id="mt-dissent" rows="2"></textarea></div>
        <div class="field"><label>下次会议时间</label><input id="mt-next" type="datetime-local"></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveMeeting()">保存</button></div>`);
      $('#mt-summary').value = MTYPE_TEMPLATE['班子例会'];
      const now = new Date();
      $('#mt-start').value = now.toISOString().slice(0, 16);
    },
    mtypeTip: (t) => MTYPE_TIPS[t] || '',
    saveMeeting: async () => {
      const type = $('#mt-type').value;
      const panel = Array.from(document.querySelectorAll('.mt-p:checked')).map((x) => Number(x.value));
      const scope = ($('#mt-scope') || {}).value || 'users';
      const start = ($('#mt-start') || {}).value || '';
      try {
        await api('/api/meetings', 'POST', {
          title: $('#mt-title').value.trim(), mtype: type,
          meet_date: start ? start.slice(0, 10) : todayStr(),
          meet_start: start, duration_min: Number($('#mt-dur').value) || 0,
          scope, panel, recorder_on: $('#mt-recorder').checked ? 1 : 0,
          host: $('#mt-host').value.trim(),
          summary: $('#mt-summary').value, dissent: $('#mt-dissent').value.trim(),
          next_time: $('#mt-next').value
        });
        closeSheet(); renderMeeting();
      } catch (e) { alert(e.message); }
    },
    speechToSummary: () => { const el = $('#mt-summary'); if (el) SPEECH.start(el); },
    digestMeeting: () => {
      const raw = $('#mt-summary') ? $('#mt-summary').value : '';
      if (!raw.trim()) { alert('请先录入会议内容（可点「🎤 语音速记」说话输入）'); return; }
      const d = SPEECH.digest(raw);
      const rows = d.items.map((it, i) => `
        <div class="sp-act">
          <label class="sp-chk"><input type="checkbox" id="act-chk-${i}" checked> 行动项 ${i + 1}</label>
          <input id="act-txt-${i}" value="${esc(it.action)}" style="width:100%;box-sizing:border-box;">
          <div class="row2">
            <div class="field"><label>负责人</label><input id="act-owner-${i}" value="${esc(it.owner)}" placeholder="姓名（系统人员）或外部责任人"></div>
            <div class="field"><label>截止日期</label><input id="act-due-${i}" type="date" value="${SPEECH.dueToDate(it.due)}"></div>
          </div>
        </div>`).join('');
      openSheet(`
        <div class="sheet-title">智能整理（分段 + 行动项）<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>整理后纪要要点</label><textarea id="dg-summary" rows="8">${esc(d.summary.join('\n'))}</textarea></div>
        <div class="muted" style="font-size:12px;margin:2px 0 6px;">识别到 ${d.items.length} 条疑似行动项（“谁负责+期限”自动提取），勾选后保存时自动生成会议行动项并转入待办。</div>
        ${rows || '<div class="muted">未识别到行动项，将仅保存整理后的纪要摘要。</div>'}
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveDigestMeeting()">保存纪要并生成行动项</button></div>`);
    },
    saveDigestMeeting: async () => {
      try {
        const title = $('#mt-title') ? $('#mt-title').value.trim() : '';
        if (!title) { alert('请先填写会议标题'); return; }
        const body = {
          title, mtype: $('#mt-type') ? $('#mt-type').value : '例会', meet_date: $('#mt-date') ? $('#mt-date').value : '',
          host: $('#mt-host') ? $('#mt-host').value.trim() : '', attendees: $('#mt-att') ? $('#mt-att').value.trim() : '',
          summary: $('#dg-summary') ? $('#dg-summary').value : '', dissent: $('#mt-dissent') ? $('#mt-dissent').value.trim() : '',
          next_time: $('#mt-next') ? $('#mt-next').value : ''
        };
        const r = await api('/api/meetings', 'POST', body);
        const mid = r.id;
        const n = document.querySelectorAll('#sheet [id^="act-chk-"]').length;
        let cnt = 0;
        for (let i = 0; i < n; i++) {
          const chk = $('#act-chk-' + i);
          if (!chk || !chk.checked) continue;
          const action = ($('#act-txt-' + i) || {}).value || '';
          const owner = ($('#act-owner-' + i) || {}).value || '';
          const due = ($('#act-due-' + i) || {}).value || '';
          if (action && owner && due) { try { await api('/api/meetings/' + mid + '/actions', 'POST', { action: action.trim(), owner: owner.trim(), due_date: due }); cnt++; } catch (e) { console.warn('行动项失败', e); } }
        }
        closeSheet(); renderMeeting();
        v5toast('会议纪要已保存' + (cnt ? '，生成 ' + cnt + ' 条行动项（已转入待办）' : ''));
      } catch (e) { alert(e.message); }
    },
    addGlossary: () => {
      openSheet(`
        <div class="sheet-title">添加语音词条<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>正确专业术语 *</label><input id="gl-term" placeholder="如：消火栓"></div>
        <div class="field"><label>常见误识别词 *（多个用 | 分隔）</label><input id="gl-alias" placeholder="如：消防栓|小火栓"></div>
        <div class="row2">
          <div class="field"><label>分类</label><select id="gl-kind"><option>安保</option><option>消防</option><option>通用</option></select></div>
          <div class="field"><label>说明（可选）</label><input id="gl-note" placeholder="用途说明"></div>
        </div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveGlossary()">保存</button></div>`);
    },
    saveGlossary: async () => {
      const term = ($('#gl-term') || {}).value || ''; const alias = ($('#gl-alias') || {}).value || '';
      if (!term.trim() || !alias.trim()) { alert('请填写术语与误识别词'); return; }
      try {
        await api('/api/speech/glossary', 'POST', { term: term.trim(), alias: alias.trim(), kind: ($('#gl-kind') || {}).value || '通用', note: ($('#gl-note') || {}).value || '' });
        closeSheet(); renderAdmin(); SPEECH.load(); v5toast('词条已添加');
      } catch (e) { alert(e.message); }
    },
    saveCloudCfg: async () => {
      const url = $('#cloud-url').value.trim(), key = $('#cloud-key').value.trim();
      const interval = parseInt($('#cloud-interval').value || '360', 10);
      if (!url || !/^https?:\/\/\S+$/.test(url)) return v5toast('请输入云端地址（http(s):// 开头）', 3000);
      if (key && key.length < 8) return v5toast('同步密钥至少 8 位', 3000);
      try { await api('/api/cloud/config', 'POST', { url, key, interval }); v5toast('云端备份配置已保存 ✓'); renderAdmin(); }
      catch (e) { v5toast('保存失败：' + e.message, 4000); }
    },
    cloudBackupNow: async () => {
      try { const r = await api('/api/cloud/backup', 'POST', {}); v5toast('已备份并推送云端 ✓ 第 ' + r.seq + ' 份 · ' + r.at); renderAdmin(); }
      catch (e) { v5toast('备份失败：' + e.message, 4000); }
    },
    oitImport: async () => {
      const f = document.getElementById('oit-file');
      if (!f || !f.files || !f.files[0]) { v5toast('请先选择 OIT 数据包文件'); return; }
      const fr = new FileReader();
      fr.onload = async () => {
        try {
          const obj = JSON.parse(fr.result);
          const r = await api('/api/oit/import', 'POST', obj);
          v5toast('OIT 导入完成 ✓ 部门+' + r.depts_added + ' · 新增员工+' + r.users_added + ' · 更新' + r.users_updated + (r.admin_skipped ? ' · 跳过' + r.admin_skipped + ' 个保留账号' : ''), 5000);
          renderAdmin();
        } catch (e) { v5toast('导入失败：' + e.message, 4000); }
      };
      fr.readAsText(f.files[0]);
    },
    oitStatus: async () => { try { await api('/api/oit/status'); v5toast('统计已刷新'); renderAdmin(); } catch (e) { v5toast(e.message, 4000); } },
    /* v8.1 公告牌实时探测：读公告牌最新公网地址并实测可达性，不再显示旧配置 */
    probePub: async () => {
      const b = document.getElementById('pub-badge'), d = document.getElementById('pub-detail');
      if (!b) return;
      const SRCS = ['https://1759717772.github.io/dept-cloud-addr/addr.txt', 'https://raw.githubusercontent.com/1759717772/dept-cloud-addr/main/addr.txt', 'https://cdn.jsdelivr.net/gh/1759717772/dept-cloud-addr@main/addr.txt'];
      let txt = '', srcUsed = '';
      for (const s of SRCS) { try { const r = await fetch(s, { cache: 'no-store' }); if (r.ok) { txt = await r.text(); srcUsed = s; break; } } catch (e) {} }
      const biz = (txt.match(/^biz=(.+)$/m) || [])[1] || '';
      const bak = (txt.match(/^backup=(.*)$/m) || [])[1] || '';
      const upd = (txt.match(/^updated=(.*)$/m) || [])[1] || '';
      if (!biz) { b.textContent = '○ 公网地址 公告牌暂无'; b.style.cssText = 'background:#fdecec;color:#dc2626;padding:8px 12px;'; d.textContent = '公告牌未返回有效地址（三源均读取失败），APP 无法自动覆写地址。'; return; }
      b.textContent = '○ 公网地址 实测中…';
      let ok = false, code = 0;
      try { const p = await fetch(biz, { mode: 'no-cors' }); code = p.status || 200; ok = code < 400; } catch (e) { code = 0; }
      b.textContent = ok ? '● 云端业务 在线' : '○ 云端业务 不可达';
      b.style.cssText = ok ? 'background:#e7f9ef;color:#16a34a;padding:8px 12px;' : 'background:#fdecec;color:#dc2626;padding:8px 12px;';
      d.innerHTML = `<div style="display:flex;flex-wrap:wrap;gap:6px;align-items:center;">当前地址：<a href="${esc(biz)}" target="_blank" style="color:#1667d9;word-break:break-all;">${esc(biz)}</a><span class="badge" style="background:${ok ? '#e7f9ef;color:#16a34a' : '#fdecec;color:#dc2626'}">${ok ? '可达' : '不可达（HTTP ' + code + '）'}</span></div>${bak ? `<div class="muted" style="font-size:12px;">备用：${esc(bak)}</div>` : ''}<div class="muted" style="font-size:12px;">公告牌更新：${esc(upd || '-')} · 来源：${esc(srcUsed.split('/')[2] || '-')} · APP 自动读取公告牌覆写地址</div>`;
    },
    cloudExport: async () => {
      // 配套小部件：导出加密本地备份包（含全部业务表；解包需用同步密钥）
      try {
        const opt = { method: 'GET', headers: {} };
        if (TOKEN) opt.headers['Authorization'] = 'Bearer ' + TOKEN;
        const r = await fetch((API_BASE || '') + '/api/cloud/export', opt);
        if (!r.ok) { const j = await r.json().catch(() => null); throw new Error((j && j.error) || '导出失败'); }
        const blob = await r.blob();
        const a = document.createElement('a');
        const u = URL.createObjectURL(blob);
        a.href = u;
        a.download = 'dept-backup-' + new Date().toISOString().slice(0, 10) + '.bin';
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(u), 5000); // 释放内存
        v5toast('已导出加密备份包（请妥善保管同步密钥）', 3500);
      } catch (e) { v5toast('导出失败：' + e.message, 4000); }
    },
    delGlossary: async (id) => {
      if (!confirm('删除该词条？')) return;
      try { await api('/api/speech/glossary/' + id, 'DELETE'); renderAdmin(); SPEECH.load(); } catch (e) { alert(e.message); }
    },
    refreshGlossary: async () => { try { await SPEECH.load(); v5toast('词库已刷新（本地离线可用）'); } catch (e) { v5toast('刷新失败'); } },
    delMeeting: async (id) => {
      if (!confirm('删除该会议及其行动项？')) return;
      try { await api('/api/meetings/' + id, 'DELETE'); renderMeeting(); } catch (e) { alert(e.message); }
    },
    meetingDetail: async (id) => {
      const list = await api('/api/meetings');
      const mt = list.find((x) => x.id === id);
      const acts = await api('/api/meetings/' + id + '/actions');
      const today = todayStr();
      const canEdit = MYLV() >= 2 || mt.created_by === ME.id;
      openSheet(`
        <div class="sheet-title">${esc(mt.title)}<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="detail-row"><div class="k">类型</div><div class="v">${esc(mt.mtype)}</div></div>
        <div class="detail-row"><div class="k">日期</div><div class="v">${esc(mt.meet_date || '—')}</div></div>
        <div class="detail-row"><div class="k">主持</div><div class="v">${esc(mt.host || '—')}</div></div>
        <div class="detail-row"><div class="k">参会</div><div class="v">${esc(mt.attendees || '—')}</div></div>
        <div class="detail-row"><div class="k">纪要</div><div class="v"><pre class="msg-content">${esc(mt.summary || '—')}</pre></div></div>
        ${mt.dissent ? `<div class="detail-row"><div class="k">异议</div><div class="v">${esc(mt.dissent)}</div></div>` : ''}
        ${mt.next_time ? `<div class="detail-row"><div class="k">下次会议</div><div class="v">${esc(mt.next_time)}</div></div>` : ''}
        <div style="margin:12px 0 6px;font-weight:700;font-size:14px;">行动项（${acts.length}）${canEdit ? '<span class="more" style="float:right;font-size:12px;color:var(--main);cursor:pointer;" onclick="app.addAction(' + id + ')">＋ 添加</span>' : ''}</div>
        ${acts.map((a) => `<div class="list-item">
          <div class="ic">${a.status === '已完成' ? '✅' : a.overdue ? '⏰' : '📌'}</div>
          <div class="body">
            <div class="t">${esc(a.action)} ${a.status === '已完成' ? '<span class="badge ok">已完成</span>' : a.overdue ? '<span class="badge bad">已逾期</span>' : '<span class="badge info">' + esc(a.status) + '</span>'}</div>
            <div class="d">负责：${esc(a.assignee_name || a.owner)}${a.assignee_id ? ' <span class="badge ok">已同步待办</span>' : ''} · 截止 ${a.due_date}${a.note ? ' · ' + esc(a.note) : ''}</div>
          </div>
          <div class="act">
            ${a.status === '待开始' ? '<button class="btn sm ghost" onclick="app.actionState(' + a.id + ',\'start\')">进行中</button>' : ''}
            ${a.status !== '已完成' ? '<button class="btn sm ok" onclick="app.actionState(' + a.id + ',\'done\')">完成</button>' : '<button class="btn sm ghost" onclick="app.actionState(' + a.id + ',\'reopen\')">重开</button>'}
            ${canEdit || ME.id === a.assignee_id ? '<button class="btn sm danger" onclick="app.delAction(' + a.id + ')">删</button>' : ''}
          </div>
        </div>`).join('') || '<div class="empty">暂无行动项，点“添加”补充（三要素必全）</div>'}`);
    },
    addAction: async (meetingId) => {
      let users = [];
      try { users = await api('/api/users'); } catch (e) {}
      const TN = { xinren: '新人', zaizhi: '在职', banzuzhang: '班组长', bumenlingdao: '部门领导', weihu: '运维', admin: '管理员' };
      const options = users.filter((x) => x.user_type !== 'xinren').map((x) => `<option value="${x.id}">${esc(x.real_name)}（${esc(x.work_no)}·${esc(TN[x.user_type] || x.user_type)}）</option>`).join('');
      openSheet(`
        <div class="sheet-title">添加行动项<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>做什么（动词开头）*</label><input id="ac-act" placeholder="如：排查测试环境"></div>
        <div class="field"><label>负责人（选择系统人员，自动生成其待办任务）*</label>
          <select id="ac-assignee"><option value="">— 请选择人员（自动转待办任务）—</option>${options}</select>
          <input id="ac-owner" placeholder="或填写外部责任人（科室/协作单位）" style="margin-top:6px;"></div>
        <div class="field"><label>截止日期 *</label><input id="ac-due" type="date"></div>
        <div class="field"><label>备注</label><input id="ac-note"></div>
        <div class="muted">选择系统人员后，该决策将自动变成「待办任务」出现在负责人手机端，有人负责、有截止、可追踪；不填截止日期将拒绝保存（拒绝“尽快/近期”等模糊词）</div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveAction(${meetingId})">保存</button></div>`);
    },
    saveAction: async (meetingId) => {
      const act = $('#ac-act').value.trim();
      const assigneeId = $('#ac-assignee') ? Number($('#ac-assignee').value || 0) : 0;
      const owner = ($('#ac-owner').value || '').trim() || (assigneeId ? '' : '');
      const due = $('#ac-due').value;
      if (!act) { alert('请填写行动内容'); return; }
      if (!owner && !assigneeId) { alert('请选择负责人（系统人员）或填写外部责任人'); return; }
      if (!due) { alert('必须填写具体截止日期，不接受“尽快/近期”'); return; }
      try {
        await api('/api/meetings/' + meetingId + '/actions', 'POST', { action: act, owner, assignee_id: assigneeId || undefined, due_date: due, note: $('#ac-note').value.trim() });
        v5toast(assigneeId ? '已保存，决策已自动生成待办任务' : '已保存');
        closeSheet(); renderMeeting();
      } catch (e) { alert(e.message); }
    },
    actionState: async (id, action) => {
      try { await api('/api/meeting-actions/' + id, 'PUT', { action }); app.closeSheet(); renderMeeting(); } catch (e) { alert(e.message); }
    },
    delAction: async (id) => {
      if (!confirm('删除该行动项？')) return;
      try { await api('/api/meeting-actions/' + id, 'DELETE'); app.closeSheet(); renderMeeting(); } catch (e) { alert(e.message); }
    }
  });

  /* ===== 审计检查与整改 ===== */
  let auditTab = 'check';
  async function renderAudit() {
    const el = $('#page-audit');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const checks = await api('/api/audit-checks');
      const issues = await api('/api/audit-issues');
      const users = await api('/api/users');
      const isAppr = MYLV() >= 2;
      const ibadge = (st) => ({ open: '<span class="badge bad">待整改</span>', rectifying: '<span class="badge warn">整改中</span>', verified: '<span class="badge info">待复查</span>', closed: '<span class="badge ok">已闭环</span>' }[st] || st);
      el.innerHTML = `
        <div class="sub-tabs">
          <div class="sub-tab${auditTab === 'check' ? ' on' : ''}" onclick="app.auditTab('check')">检查记录</div>
          <div class="sub-tab${auditTab === 'issue' ? ' on' : ''}" onclick="app.auditTab('issue')">整改台账</div>
        </div>
        <div class="sub-panel${auditTab === 'check' ? ' show' : ''}" id="au-check">
          <div class="actions">${isAppr ? '<button class="btn sm" onclick="app.addCheck()">＋ 新增检查</button>' : ''}</div>
          <div class="card"><h3>检查记录（${checks.length}）</h3>
            ${checks.map((c) => `
              <div class="list-item" onclick="app.openCheckDetail(${c.id})">
                <div class="ic">🔍</div>
                <div class="body">
                  <div class="t">${esc(c.project)} ${c.result === 'issue' ? '<span class="badge bad">发现问题</span>' : '<span class="badge ok">正常</span>'}</div>
                  <div class="d">${c.check_date} · ${esc(c.area || '')} · 检查人 ${esc(c.checker || '—')} · 问题 ${c.open_issues}/${c.issue_count}</div>
                  ${c.summary ? '<div class="d" style="white-space:pre-wrap;">📋 ' + esc(c.summary.length > 60 ? c.summary.slice(0, 60) + '…' : c.summary) + '</div>' : ''}
                </div>
                <div class="act">${isAppr ? '<button class="btn sm ghost" onclick="event.stopPropagation();app.addIssue(' + c.id + ')">加问题</button>' : ''}<span class="ai-arrow">›</span></div>
              </div>`).join('') || '<div class="empty">暂无检查记录</div>'}
          </div>
        </div>
        <div class="sub-panel${auditTab === 'issue' ? ' show' : ''}" id="au-issue">
          <div class="actions">${isAppr ? '<button class="btn sm" onclick="app.addIssue()">＋ 登记问题</button>' : ''}</div>
          <div class="card"><h3>问题整改台账（${issues.length}）</h3>
            ${issues.map((i) => `
              <div class="list-item">
                <div class="ic">⚠️</div>
                <div class="body">
                  <div class="t">${esc(i.problem)} ${ibadge(i.status)}</div>
                  <div class="d">责任人 ${esc(i.owner_name || '未指定')} · 期限 ${i.deadline || '—'}${i.check_project ? ' · ' + esc(i.check_project) : ''}</div>
                  ${i.measure ? `<div class="d">整改措施：${esc(i.measure)}${i.rectify_at ? ' · ' + i.rectify_at : ''}</div>` : ''}
                  ${i.verify_result ? `<div class="d">复查：${esc(i.verify_result)}</div>` : ''}
                </div>
                <div class="act">
                  ${i.status === 'open' ? '<button class="btn sm warn" onclick="app.issueAction(' + i.id + ',\'rectify\')">整改</button>' : ''}
                  ${i.status === 'rectifying' ? '<button class="btn sm ok" onclick="app.issueAction(' + i.id + ',\'verify\')">复查</button>' : ''}
                  ${i.status === 'verified' ? '<button class="btn sm ok" onclick="app.issueAction(' + i.id + ',\'close\')">闭环</button>' : ''}
                </div>
              </div>`).join('') || '<div class="empty">暂无问题</div>'}
          </div>
        </div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  window.app = Object.assign(window.app || {}, {
    auditTab: (t) => { auditTab = t; renderAudit(); },
    openCheckDetail: async (id) => {
      try {
        const checks = await api('/api/audit-checks');
        const c = checks.find((x) => String(x.id) === String(id));
        if (!c) return alert('未找到该检查记录');
        openSheet(`<div style="padding:18px 0 6px;"><div class="sheet-title">🔍 检查详情 <span class="badge ${c.result === 'issue' ? 'bad' : 'ok'}">${c.result === 'issue' ? '发现问题' : '正常'}</span></div>
          ${[['检查项目', c.project], ['检查日期', c.check_date], ['检查区域', c.area], ['检查人', c.checker], ['问题数', c.open_issues + '/' + c.issue_count]].map(([k, v]) => infoRow(k, v)).join('')}
          ${c.summary ? '<div class="field"><label>检查情况</label><div style="font-size:14px;color:#333;white-space:pre-wrap;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:10px;">' + esc(c.summary) + '</div></div>' : ''}
          <button class="btn block" style="margin-top:14px;" onclick="app.closeSheet()">关闭</button></div>`);
      } catch (e) { alert(e.message); }
    },
    addCheck: () => {
      openSheet(`
        <div class="sheet-title">新增检查记录<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="row2">
          <div class="field"><label>检查日期 *</label><input id="ck-date" type="date"></div>
          <div class="field"><label>检查项目 *</label><input id="ck-project" placeholder="如：围界巡查"></div>
        </div>
        <div class="row2">
          <div class="field"><label>区域/部位</label><input id="ck-area"></div>
          <div class="field"><label>检查人</label><input id="ck-checker"></div>
        </div>
        <div class="field"><label>结论</label><select id="ck-result"><option value="normal">正常</option><option value="issue">发现问题</option></select></div>
        <div class="field"><label>情况摘要</label><textarea id="ck-summary" rows="3"></textarea></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveCheck()">保存</button></div>`);
      $('#ck-date').value = todayStr();
    },
    saveCheck: async () => {
      try {
        await api('/api/audit-checks', 'POST', {
          check_date: $('#ck-date').value, project: $('#ck-project').value.trim(), area: $('#ck-area').value.trim(),
          checker: $('#ck-checker').value.trim(), result: $('#ck-result').value, summary: $('#ck-summary').value.trim()
        });
        closeSheet(); renderAudit();
      } catch (e) { alert(e.message); }
    },
    addIssue: (checkId) => {
      api('/api/users').then((users) => {
        openSheet(`
          <div class="sheet-title">登记整改问题<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="field"><label>问题描述 *</label><textarea id="is-problem" rows="3"></textarea></div>
          <div class="row2">
            <div class="field"><label>责任人</label><select id="is-owner"><option value="">未指定</option>${users.map((x) => '<option value="' + x.id + '">' + esc(x.real_name) + '</option>').join('')}</select></div>
            <div class="field"><label>整改期限</label><input id="is-deadline" type="date"></div>
          </div>
          ${checkId ? '' : '<div class="field"><label>关联检查项目</label><input id="is-check" placeholder="检查项目名称（可选）"></div>'}
          <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveIssue(${checkId || 'null'})">保存</button></div>`);
      });
    },
    saveIssue: async (checkId) => {
      try {
        await api('/api/audit-issues', 'POST', {
          check_id: checkId, problem: $('#is-problem').value.trim(),
          owner_id: $('#is-owner').value ? Number($('#is-owner').value) : null, deadline: $('#is-deadline').value
        });
        closeSheet(); renderAudit();
      } catch (e) { alert(e.message); }
    },
    issueAction: async (id, action) => {
      let extra = {};
      if (action === 'rectify') {
        const m = prompt('填写整改措施：');
        if (m === null) return;
        extra.measure = m;
      }
      if (action === 'verify' || action === 'close') {
        const v = prompt(action === 'close' ? '填写复查结果（闭环）：' : '填写复查结果：');
        if (v === null) return;
        extra.verify_result = v;
      }
      try { await api('/api/audit-issues/' + id, 'PUT', { action, ...extra }); renderAudit(); } catch (e) { alert(e.message); }
    }
  });

  /* ===== 值班排班 ===== */
  async function renderDuty() {
    const el = $('#page-duty');
    if (el) el.innerHTML = '<div class="empty">值班排班模块已停用（按部门要求下线）。当日值班信息如需展示，请改用「数据录入」中的通知/公告。</div>';
  }
  async function renderDutyLegacy() {
    const el = $('#page-duty');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const list = await api('/api/duty');
      const isAppr = MYLV() >= 2;
      const today = todayStr();
      const cur = list.filter((x) => x.day === today);
      el.innerHTML = `
        <div class="actions">${isAppr ? '<button class="btn sm" onclick="app.addDuty()">＋ 新增排班</button>' : ''}</div>
        ${cur.length ? `<div class="card"><h3>今日值班</h3>${cur.map((d) => `<div class="list-item"><div class="ic">🕐</div><div class="body"><div class="t">${esc(d.user_name)}${d.shift ? ' · ' + esc(d.shift) : ''}</div><div class="d">${esc(d.duty || '值班')}${d.phone ? ' · ' + esc(d.phone) : ''}</div></div></div>`).join('')}</div>` : ''}
        <div class="card"><h3>值班表（${list.length}）</h3>
          ${list.map((d) => `
            <div class="list-item">
              <div class="ic">🗓️</div>
              <div class="body">
                <div class="t">${d.day}${d.day === today ? ' <span class="badge info">今天</span>' : ''}${d.shift ? ' · ' + esc(d.shift) : ''}</div>
                <div class="d">${esc(d.user_name)} · ${esc(d.duty || '值班')}${d.phone ? ' · ' + esc(d.phone) : ''}</div>
              </div>
              <div class="act">${isAppr ? '<button class="btn sm danger" onclick="app.delDuty(' + d.id + ')">删</button>' : ''}</div>
            </div>`).join('') || '<div class="empty">暂无排班</div>'}
        </div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  window.app = Object.assign(window.app || {}, {
    addDuty: () => {
      openSheet(`
        <div class="sheet-title">新增值班排班<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="row2">
          <div class="field"><label>日期 *</label><input id="dy-day" type="date"></div>
          <div class="field"><label>班次</label><input id="dy-shift" placeholder="如：白班/夜班"></div>
        </div>
        <div class="field"><label>值班人 *</label><input id="dy-user"></div>
        <div class="row2">
          <div class="field"><label>职责</label><input id="dy-duty" placeholder="如：消防值班"></div>
          <div class="field"><label>联系电话</label><input id="dy-phone"></div>
        </div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveDuty()">保存</button></div>`);
      $('#dy-day').value = todayStr();
    },
    saveDuty: async () => {
      try {
        await api('/api/duty', 'POST', {
          day: $('#dy-day').value, shift: $('#dy-shift').value.trim(), user_name: $('#dy-user').value.trim(),
          duty: $('#dy-duty').value.trim(), phone: $('#dy-phone').value.trim()
        });
        closeSheet(); renderDuty();
      } catch (e) { alert(e.message); }
    },
    delDuty: async (id) => {
      if (!confirm('删除该条排班？')) return;
      try { await api('/api/duty/' + id, 'DELETE'); renderDuty(); } catch (e) { alert(e.message); }
    }
  });

  /* ===== 数据录入（自定义表单）===== */
  async function renderForm() {
    const el = $('#page-form');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const forms = await api('/api/forms');
      const isAdm = ME.role === 'admin';
      el.innerHTML = `
        <div class="actions">${isAdm ? '<button class="btn sm" onclick="app.newForm()">＋ 新建表单</button>' : ''}</div>
        ${forms.map((f) => `
          <div class="card">
            <h3>${esc(f.name)}<span class="more"><button class="btn sm ghost" onclick="app.openForm(${f.id})">录入</button> <button class="btn sm ghost" onclick="app.viewFormRecords(${f.id})">记录</button></span></h3>
            <div class="muted">字段：${f.fields.length ? f.fields.map((x) => esc(x.label || x.name)).join('、') : '（未定义字段，录入自由文本）'}</div>
          </div>`).join('') || '<div class="empty">暂无表单（管理员可新建，如：消防器材检查、值班记录等）</div>'}
        `;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  window.app = Object.assign(window.app || {}, {
    newForm: () => {
      openSheet(`
        <div class="sheet-title">新建数据表单<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>表单名称 *</label><input id="f-name" placeholder="如：消防器材检查记录"></div>
        <div class="field"><label>字段（用逗号分隔）</label><textarea id="f-fields" rows="4" placeholder="如：检查日期,器材名称,状态,检查人"></textarea></div>
        <div class="muted">可选条件显隐规则（v7.8）：在字段名后加 [规则]，多个规则用 ; 分隔<br>
          · [userType:xinren] —— 仅指定人员类型显示<br>
          · [field:0:eq:是] —— 当第 1 个字段值为「是」时显示<br>
          · [field:0:neq:无] —— 第 1 个字段值不为「无」时显示<br>
          · [field:0:has] —— 第 1 个字段已填写时显示<br>
          例：整改措施[field:2:eq:有问题]</div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveForm()">创建</button></div>`);
    },
    parseFieldRule: (s) => {
      const m = String(s).match(/\[([^\]]+)\]/);
      if (!m) return null;
      const rule = {};
      m[1].split(';').forEach((seg) => {
        const parts = seg.split(':');
        const k = parts.shift();
        if (k === 'userType') rule.userType = parts.length ? parts.join(':').split(',') : [];
        else if (k === 'field' && parts[0] !== undefined) {
          rule.field = Number(parts[0]);
          if (parts[1] === 'eq') rule.eq = parts.slice(2).join(':');
          if (parts[1] === 'neq') rule.neq = parts.slice(2).join(':');
          if (parts[1] === 'has') rule.has = true;
        }
      });
      return Object.keys(rule).length ? rule : null;
    },
    saveForm: async () => {
      try {
        const fields = $('#f-fields').value.split(/[,，]/).map((s) => s.trim()).filter(Boolean).map((n) => {
          const rule = app.parseFieldRule(n);
          const clean = String(n).replace(/\[[^\]]+\]/, '').trim();
          return rule ? { label: clean, rule } : { label: n };
        });
        await api('/api/forms', 'POST', { name: $('#f-name').value.trim(), fields });
        closeSheet(); renderForm();
      } catch (e) { alert(e.message); }
    },
    /* v7.8 表单条件显隐（借鉴云网OA显示规则）：字段 rule 支持 userType / field+eq / field+neq / field+has */
    applyFormRules: (fields) => {
      fields.forEach((x, i) => {
        if (!x || !x.rule) return;
        const inp = $('#fr-' + i);
        if (!inp) return;
        const fieldEl = inp.closest('.field');
        const r = x.rule;
        const apply = () => {
          let show = true;
          if (r.userType) {
            const uts = Array.isArray(r.userType) ? r.userType : [r.userType];
            if (!uts.includes(ME.user_type)) show = false;
          }
          if (show && r.field !== undefined && r.field !== null) {
            const src = $('#fr-' + r.field);
            const v = src ? String(src.value || '').trim() : '';
            if (r.eq !== undefined && v !== String(r.eq)) show = false;
            if (r.neq !== undefined && v === String(r.neq)) show = false;
            if (r.has !== undefined && ((r.has && !v) || (!r.has && v))) show = false;
          }
          fieldEl.style.display = show ? '' : 'none';
          inp.disabled = !show;
        };
        apply();
        if (r.field !== undefined && r.field !== null) {
          const src = $('#fr-' + r.field);
          if (src) src.addEventListener('input', apply);
        }
      });
    },
    openForm: async (id) => {
      const forms = await api('/api/forms');
      const f = forms.find((x) => x.id === id);
      openSheet(`
        <div class="sheet-title">录入：${esc(f.name)}<span class="x" onclick="app.closeSheet()">✕</span></div>
        ${f.fields.map((x, i) => `<div class="field"><label>${esc(x.label)}</label><input id="fr-${i}" data-name="${esc(x.label)}"></div>`).join('')}
        ${!f.fields.length ? '<div class="field"><label>内容</label><textarea id="fr-0" data-name="内容" rows="3"></textarea></div>' : ''}
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveRecord(${id})">保存</button></div>`);
      if (f.fields && f.fields.length) app.applyFormRules(f.fields);
    },
    saveRecord: async (id) => {
      const data = {};
      let idx = 0;
      document.querySelectorAll('#sheet .field').forEach((fd) => {
        const inp = fd.querySelector('input, textarea, select');
        if (!inp || inp.disabled) return;
        idx++;
        data[inp.dataset.name || '字段' + idx] = inp.value.trim();
      });
      try { await api('/api/forms/' + id + '/records', 'POST', { data }); closeSheet(); renderForm(); } catch (e) { alert(e.message); }
    },
    viewFormRecords: async (id) => {
      const forms = await api('/api/forms');
      const f = forms.find((x) => x.id === id);
      const recs = await api('/api/forms/' + id + '/records');
      openSheet(`
        <div class="sheet-title">${esc(f.name)} · 记录（${recs.length}）<span class="x" onclick="app.closeSheet()">✕</span></div>
        ${recs.map((r) => `<div class="detail-row"><div class="k">${r.created_at.slice(5, 16)}</div><div class="v">${Object.entries(r.data).map(([k, v]) => esc(k) + ': ' + esc(v)).join('　') || '（空）'}</div></div>`).join('') || '<div class="empty">暂无记录</div>'}`);
    }
  });

  /* ===== v4.0 检查管理（年度计划/日检/月检/自查/专项，多级审核） ===== */
  const CHECK_TYPES = [['daily', '日检查'], ['monthly', '月检查'], ['self', '自查'], ['special', '专项检查']];
  function checkTypeName(t) { return (CHECK_TYPES.find((x) => x[0] === t) || [t, t])[1]; }
  const ST_BADGE = { pending: '<span class="badge warn">待审核</span>', completed: '<span class="badge ok">已审核</span>', rejected: '<span class="badge bad">已驳回</span>', approved: '<span class="badge ok">已审核</span>' };
  const RES_BADGE = { ok: '<span class="badge ok">合格</span>', basic: '<span class="badge warn">基本合格（需整改）</span>', bad: '<span class="badge bad">不合格</span>', issue: '<span class="badge bad">发现问题</span>' };
  const ISSUE_ST = { open: '<span class="badge warn">待整改</span>', in_progress: '<span class="badge info">整改中</span>', submitted: '<span class="badge info">已提交整改材料</span>', accepted: '<span class="badge ok">验收合格</span>', rejected: '<span class="badge bad">验收不合格</span>' };
  async function renderCheck() {
    if (MYLV() === 0) { $('#page-check').innerHTML = '<div class="empty">新人暂无检查模块权限，请先在「审批-发起申请」提交功能申请。</div>'; return; }
    const el = $('#page-check');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const plans = await api('/api/check-plans');
      const recs = await api('/api/check-records');
      const issues = await api('/api/check-issues');
      const lists = await api('/api/checklists');
      const lv = MYLV();
      const canPlan = lv >= 2;
      const pending = lv >= 2 ? recs.filter((r) => r.status === 'pending') : [];
      const badge = (st) => ST_BADGE[st] || st;
      el.innerHTML = `
        <div class="sub-tabs">
          <div class="sub-tab${checkTab === 'plan' ? ' on' : ''}" onclick="app.checkTab('plan')">年度计划</div>
          <div class="sub-tab${checkTab === 'rec' ? ' on' : ''}" onclick="app.checkTab('rec')">检查记录</div>
          <div class="sub-tab${checkTab === 'issue' ? ' on' : ''}" onclick="app.checkTab('issue')">问题闭环</div>
          <div class="sub-tab${checkTab === 'list' ? ' on' : ''}" onclick="app.checkTab('list')">检查单库</div>
          <div class="sub-tab${checkTab === 'audit' ? ' on' : ''}" onclick="app.checkTab('audit')">待我审核</div>
        </div>
        <div class="sub-panel${checkTab === 'plan' ? ' show' : ''}" id="check-plan">
          <div class="actions">${canPlan ? '<button class="btn sm" onclick="app.addCheckPlan()">＋ 制定年度计划</button>' : ''}</div>
          <div class="card"><h3>年度检查计划（${plans.length}）</h3>
            ${plans.map((p) => `<div class="list-item">
              <div class="ic">🗂️</div>
              <div class="body"><div class="t">${esc(p.name)} <span class="badge info">${checkTypeName(p.check_type)}</span></div><div class="d">${p.year}年 · ${esc(p.cycle || '—')} · 负责人 ${esc(p.owner_name || '—')} · ${(p.items || []).length} 项</div></div>
              <div class="act"><button class="btn sm ghost" onclick="app.checkPlanDetail(${p.id})">详情</button>${canPlan ? '<button class="btn sm danger" onclick="app.delCheckPlan(' + p.id + ')">删</button>' : ''}</div>
            </div>`).join('') || '<div class="empty">暂无计划</div>'}
          </div>
        </div>
        <div class="sub-panel${checkTab === 'rec' ? ' show' : ''}" id="check-rec">
          <div class="actions"><button class="btn sm" onclick="app.addCheckRecord()">＋ 上报检查记录</button></div>
          <div class="card"><h3>检查记录（${recs.length}）</h3>
            ${recs.map((r) => `<div class="list-item">
              <div class="ic">🔍</div>
              <div class="body"><div class="t">${checkTypeName(r.check_type)} · ${esc(r.area || '—')} ${badge(r.status)}</div>
              <div class="d">${esc(r.check_date)} ${r.start_time ? ' ' + esc(r.start_time) + '—' + esc(r.end_time || '') : ''} · ${esc(r.checker_name)}${r.checklist_name ? ' · 检查单：' + esc(r.checklist_name) : ''}${r.status === 'pending' && r.pending_level_name ? ' · 待「' + r.pending_level_name + '」审核' : ''} · ${RES_BADGE[r.result] || esc(r.result)}</div></div>
              <div class="act"><button class="btn sm ghost" onclick="app.checkRecDetail(${r.id})">详情</button><button class="btn sm" onclick="app.checkIssueAdd(${r.id})">登记问题</button></div>
            </div>`).join('') || '<div class="empty">暂无记录</div>'}
          </div>
        </div>
        <div class="sub-panel${checkTab === 'audit' ? ' show' : ''}" id="check-audit">
          ${pending.length ? `<div class="card"><h3>待我审核（${pending.length}）</h3>
            ${pending.map((r) => `<div class="list-item">
              <div class="ic">⏳</div>
              <div class="body"><div class="t">${checkTypeName(r.check_type)} · ${esc(r.area || '—')}（${esc(r.checker_name)}）</div><div class="d">${esc(r.check_date)} · 待「${esc(r.pending_level_name || '')}」审核${r.result === 'issue' ? ' · <span class="badge bad">发现问题</span>' : ''}</div></div>
              <div class="act"><button class="btn sm ok" onclick="app.approveCheck(${r.id},'approve')">通过</button> <button class="btn sm danger" onclick="app.approveCheck(${r.id},'reject')">驳回</button> <button class="btn sm ghost" onclick="app.checkRecDetail(${r.id})">详情</button></div>
            </div>`).join('')}</div>` : '<div class="empty">暂无待审核记录</div>'}
        </div>
        <div class="sub-panel${checkTab === 'issue' ? ' show' : ''}" id="check-issue">
          <div class="card"><h3>检查问题闭环（${issues.length}）</h3>
            ${issues.map((x) => `<div class="list-item">
              <div class="ic">${x.issue_type === 'spot' ? '⚡' : '📌'}</div>
              <div class="body">
                <div class="t">${x.issue_type === 'spot' ? '<span class="badge info">当场整改</span>' : '<span class="badge warn">限期整改</span>'} ${esc(x.content)} ${ISSUE_ST[x.status] || x.status}</div>
                <div class="d">${esc(x.check_type || '检查')} · ${esc(x.check_date || '')}${x.location ? ' · ' + esc(x.location) : ''} · 整改人 ${esc(x.assignee_name || '—')}${x.rectify_deadline ? ' · 期限 ' + x.rectify_deadline : ''}${x.notice_no ? ' · 通知号 ' + x.notice_no : ''}${x.accept_report_no ? ' · 验收报告 ' + x.accept_report_no : ''}</div>
              </div>
              <div class="act">
                ${x.issue_type === 'rectify' && !x.notice_signed_at && lv >= 2 ? '<button class="btn sm warn" onclick="app.checkIssueNotice(' + x.id + ')">下发整改通知</button>' : ''}
                ${x.status === 'open' && x.assigned_to === ME.id ? '<button class="btn sm" onclick="app.checkIssueReport(' + x.id + ')">提交整改材料</button>' : ''}
                ${x.status === 'submitted' && lv >= 2 ? '<button class="btn sm ok" onclick="app.checkIssueAccept(' + x.id + ')">验收</button>' : ''}
                ${x.status === 'rejected' && x.assigned_to === ME.id ? '<button class="btn sm" onclick="app.checkIssueReport(' + x.id + ')">重新整改提交</button>' : ''}
              </div>
            </div>`).join('') || '<div class="empty">暂无检查问题，检查中发现问题时在检查记录详情中「登记问题」</div>'}
          </div>
        </div>
        <div class="sub-panel${checkTab === 'list' ? ' show' : ''}" id="check-list">
          <div class="actions">${lv >= 2 ? '<button class="btn sm" onclick="app.addChecklist()">＋ 新增检查单</button>' : '<div class="muted" style="font-size:13px;">内置三类安保设施检查单（依据石河子花园机场安保设施定期检测计划）；班组长及以上可新增自定义检查单</div>'}</div>
          <div class="card"><h3>检查单库（${lists.length}）</h3>
            ${lists.map((c) => `<div class="list-item">
              <div class="ic">📋</div>
              <div class="body">
                <div class="t">${esc(c.name)}${c.id <= 3 ? ' <span class="badge info">内置标准</span>' : ''}</div>
                <div class="d">${c.items.length} 项检查内容${lv >= 4 ? '<button class="btn sm danger" style="margin-left:8px;" onclick="app.delChecklist(' + c.id + ')">删</button>' : ''}</div>
                <div class="chk-items" style="margin-top:6px;">${c.items.map((it) => `<div style="padding:5px 0;border-bottom:1px dashed #eee;font-size:13px;"><b>${esc(it.item || it)}</b><div style="color:#6B7280;font-size:12px;">合格标准：${esc(it.std || '—')}</div></div>`).join('')}</div>
              </div>
            </div>`).join('') || '<div class="empty">暂无检查单</div>'}
          </div>
        </div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }
  let checkTab = 'plan';

  /* ===== v4.0 巡逻上报（多级审核） ===== */
  async function renderPatrol() {
    if (MYLV() === 0) { $('#page-patrol').innerHTML = '<div class="empty">新人暂无巡逻权限，请先在「审批-发起申请」提交功能申请。</div>'; return; }
    const el = $('#page-patrol');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const list = await api('/api/patrols');
      const lv = MYLV();
      const pending = lv >= 2 ? list.filter((r) => r.status === 'pending') : [];
      el.innerHTML = `
        <div class="actions"><button class="btn sm" onclick="app.addPatrol()">＋ 巡逻上报</button></div>
        <div class="card"><h3>巡逻记录（${list.length}）</h3>
          ${list.map((r) => `<div class="list-item">
            <div class="ic">🚶</div>
            <div class="body"><div class="t">${esc(r.area)} ${ST_BADGE[r.status] || r.status}</div>
            <div class="d">${esc(r.patrol_date)}${r.start_time ? ' ' + esc(r.start_time) + (r.end_time ? '~' + esc(r.end_time) : '') : ''} · ${esc(r.patroler_name)}${r.status === 'pending' && r.pending_level_name ? ' · 待「' + r.pending_level_name + '」审核' : ''}${r.result === 'issue' ? ' · <span class="badge bad">发现问题</span>' : ''}</div></div>
            <div class="act"><button class="btn sm ghost" onclick="app.patrolDetail(${r.id})">详情</button></div>
          </div>`).join('') || '<div class="empty">暂无巡逻记录</div>'}
        </div>
        ${pending.length ? `<div class="card"><h3>待我审核（${pending.length}）</h3>
          ${pending.map((r) => `<div class="list-item">
            <div class="ic">⏳</div>
            <div class="body"><div class="t">${esc(r.area)}（${esc(r.patroler_name)}）</div><div class="d">${esc(r.patrol_date)} · 待「${esc(r.pending_level_name || '')}」审核${r.result === 'issue' ? ' · <span class="badge bad">发现问题</span>' : ''}</div></div>
            <div class="act"><button class="btn sm ok" onclick="app.approvePatrol(${r.id},'approve')">通过</button> <button class="btn sm danger" onclick="app.approvePatrol(${r.id},'reject')">驳回</button> <button class="btn sm ghost" onclick="app.patrolDetail(${r.id})">详情</button></div>
          </div>`).join('')}</div>` : ''}`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  /* ===== 管理（运维/管理员） ===== */
  const UTYPES = [['xinren', '新人'], ['zaizhi', '在职人员'], ['banzuzhang', '班组长'], ['bumenlingdao', '部门领导'], ['weihu', '运维工程师'], ['admin', '管理员']];
  function typeBadge(t) { return '<span class="badge ' + (t === 'xinren' ? 'warn' : t === 'admin' || t === 'weihu' ? 'info' : 'ok') + '">' + (UTYPES.find((x) => x[0] === t) || [t, t])[1] + '</span>'; }
  async function renderAdmin() {
    if (MYLV() < 4) { $('#page-admin').innerHTML = '<div class="empty">无权限：仅运维工程师/管理员可访问</div>'; return; }
    const el = $('#page-admin');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const users = await api('/api/users');
      const depts = await api('/api/depts');
      let toCfg = { days: 7 };
      try { const tc = await api('/api/admin/config?key=approval_timeout_days'); if (tc && tc.days) toCfg = tc; } catch (e) {}
      const gl = await api('/api/speech/glossary/all');
      let cl = null; try { cl = await api('/api/cloud/status'); } catch (e) {}
      let oit = null; try { oit = await api('/api/oit/status'); } catch (e) {}
      let sys = null; try { sys = await api('/api/system/status'); } catch (e) {}
      el.innerHTML = `
        <div class="card">
          <h3>云端备份（异步同步服务器）<span class="badge ok" style="float:right">v7.9-cloud</span></h3>
          <div class="muted" style="margin-bottom:8px;">主服务器（办公电脑，与 OIT 系统同机）定期将全库数据加密（AES-256-GCM）推送到云端异步备份服务器，云端仅保存备份（保留最近 30 份）、不参与业务，用于容灾恢复。借鉴 litestream 持续备份思路：定期快照 + 版本保留 + 异地存储。若暂无云端 / 不知道 OIT 对接方式，可用「导出本地备份包」先取资料。</div>
          ${cl ? `<div class="badge" style="margin-bottom:8px;background:${cl.state === 'ok' ? '#e7f9ef;color:#16a34a' : cl.state === 'err' ? '#fdecec;color:#dc2626' : '#f1f2f4;color:#666'}">同步状态：${cl.state === 'ok' ? '✓ 正常' : cl.state === 'err' ? '✗ 失败' : '未配置'}${cl.auto ? ' · 自动间隔 ' + cl.intervalMin + ' 分钟' : ''}${cl.last ? ' · 上次备份 ' + esc(cl.last) + ' · 第 ' + cl.seq + ' 份' : ''}</div>` : ''}
          ${cl && cl.lastError ? `<div class="muted" style="color:#dc2626;margin-bottom:8px;">上次错误：${esc(cl.lastError)}</div>` : ''}
          <div class="field"><label>云端服务器地址（http(s):// 开头，如 https://backup.example.com:8199）</label><input id="cloud-url" type="text" placeholder="https://服务器地址:8199" value="${esc((cl && cl.url) || '')}"></div>
          <div class="field"><label>同步密钥（至少 8 位，需与云端 SYNC_KEY 完全一致；已设置时留空表示不修改）</label><input id="cloud-key" type="password" placeholder="${cl && cl.keyMask ? '已设置：' + esc(cl.keyMask) : '请设置同步密钥'}"></div>
          <div class="field"><label>自动备份间隔（分钟，5~1440，默认 360 即 6 小时）</label><input id="cloud-interval" type="number" min="5" max="1440" value="${(cl && cl.intervalMin) || 360}"></div>
          <button class="btn" onclick="app.saveCloudCfg()">保存配置</button> <button class="btn" onclick="app.cloudBackupNow()">立即备份并推送</button> <button class="btn ghost" onclick="app.cloudExport()">导出本地备份包</button>
        </div>
        <div class="card">
          <h3>OIT 数据自动采集（云端/备份共用组件）<span class="badge ok" style="float:right">v7.9-cloud</span></h3>
          <div class="muted" style="margin-bottom:8px;">办公电脑按时间段自动运行采集器读取 oit_setup（演示信息.mdb）→ 同一份数据包自动提供给云端业务（本服务器）与备份服务器；主服务器在每次云备份前自动整合最新 OIT 数据后推送云端，保证备份含最新人员资料。OIT 采集为自动调度，不手动触发。</div>
          ${oit ? `<div class="badge" style="margin-bottom:8px;background:#e7f9ef;color:#16a34a">当前：员工 ${oit.employees} 人 · 部门 ${oit.depts} 个</div>` : ''}
          ${sys && sys.oit ? `<div class="badge" style="margin-bottom:8px;background:#f1f2f4;color:#555">采集计划：${esc(sys.oit.times)}${sys.oit.script ? ' · 脚本：' + esc(sys.oit.script) : ''} · 最近采集：${esc(sys.oit.last)}${sys.oit.hasData ? ' · 数据包就绪' : ''}</div>` : ''}
          <div class="field"><label>手动接收数据包（自动采集器/主服务器推送产生；本入口用于数据包到达）</label><input type="file" id="oit-file" accept=".json"></div>
          <button class="btn" onclick="app.oitImport()">接收数据包并导入</button> <button class="btn ghost" onclick="app.oitStatus()">刷新统计</button>
        </div>
        <div class="card">
          <h3>运行状态工作台<span class="badge ok" style="float:right">借鉴 cool-workflow workbench</span></h3>
          <div class="muted" style="margin-bottom:8px;">只读工作台：实时显示主服务器 / 云端业务 / 备份端 / OIT 采集的运行状态与最近运行记录（黑匣子台账），一眼分清"服务器问题还是软件问题"。</div>
          <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px;">
            <div class="badge" style="background:#e7f9ef;color:#16a34a;padding:8px 12px;">● 主服务器 运行中${sys && sys.server ? ' · 已运行 ' + Math.round((sys.server.uptimeSec || 0) / 3600) + ' 小时' : ''}</div>
            <div class="badge" id="pub-badge" style="background:#f1f2f4;color:#666;padding:8px 12px;">○ 公网地址 探测中…</div>
            <div class="badge" style="${(sys && sys.main && sys.main.state === 'ok') ? 'background:#e7f9ef;color:#16a34a' : 'background:#f1f2f4;color:#666'};padding:8px 12px;">${(sys && sys.main && sys.main.state === 'ok') ? '● 云端备份 ' + (sys.main.seq || 0) + ' 份' : '○ 云端备份 未配置（可选）'}${sys && sys.main && sys.main.last ? ' · ' + esc(sys.main.last) : ''}</div>
          </div>
          <div class="muted" style="margin-bottom:4px;">公告牌（公网地址自动更新中枢）：</div>
          <div id="pub-detail" style="font-size:13px;color:#333;margin-bottom:8px;word-break:break-all;">读取中…</div>
          ${sys && sys.main && sys.main.lastError ? `<div class="muted" style="color:#dc2626;margin-bottom:8px;">云端备份上次错误：${esc(sys.main.lastError)}（不影响主业务）</div>` : ''}
          <div class="muted" style="margin-bottom:4px;">最近运行记录（台账）：</div>
          <div style="max-height:220px;overflow:auto;border:1px solid #eef0f3;border-radius:8px;padding:6px;">
            ${(sys && sys.runs && sys.runs.length) ? sys.runs.slice(0, 12).map((r) => `<div style="padding:4px 6px;border-bottom:1px solid #f2f3f5;font-size:13px;display:flex;gap:6px;"><span style="color:#8a8f99;white-space:nowrap;">${esc(r.ts)}</span><span style="color:${r.result === 'ok' ? '#16a34a' : r.result === 'warn' ? '#d97706' : '#dc2626'};white-space:nowrap;">${r.result === 'ok' ? '✓' : r.result === 'warn' ? '△' : '✗'}</span><span style="color:#666;">${esc(r.kind)}</span><span style="color:#333;flex:1;min-width:0;word-break:break-all;">${esc(r.detail)}</span></div>`).join('') : '<div class="empty">暂无运行记录</div>'}
          </div>
          <button class="btn ghost" onclick="app.oitStatus()" style="margin-top:8px;">刷新统计</button> <button class="btn ghost" onclick="app.probePub()" style="margin-top:8px;">实测公网</button>
        </div>
        <div class="card">
          <h3>语音词库（语音转写专业术语纠错）<span class="badge ok" style="float:right">v7.9</span><span class="more"><button class="btn sm" onclick="app.addGlossary()">＋ 添加词条</button> <button class="btn sm ghost" onclick="app.refreshGlossary()">刷新</button></span></h3>
          <div class="muted" style="margin-bottom:8px;">MosMos 式专业词库：语音转写文本中的常见误识别词将自动替换为专业术语（前端本地生效，离线可用）。适合民航消防/安保专业场景。</div>
          ${gl.map((g) => `<div class="list-item"><div class="ic">${ico('mic')}</div><div class="body"><div class="t">${esc(g.term)} <span class="badge">${esc(g.kind)}</span></div><div class="d">误识别词：${esc(g.alias)}${g.note ? ' · ' + esc(g.note) : ''}</div></div><div class="actions"><button class="btn sm ghost" onclick="app.delGlossary(${g.id})">删除</button></div></div>`).join('') || '<div class="empty">暂无词条，点击「添加词条」录入专业术语</div>'}
        </div>
        <div class="card">
          <h3>流程试跑（模拟用户调试）<span class="badge ok" style="float:right">v7.8</span></h3>
          <div class="muted" style="margin-bottom:8px;">管理员可切换任意用户视角，查看其工作台 / 待办 / 权限表现，便于排查流程与权限问题；调试期间页面顶部显示「模拟模式」横幅，点击可一键退出。</div>
          <div class="field"><label>选择要模拟的用户</label><select id="imp-user"><option value="">— 选择用户 —</option>${users.map((u2) => `<option value="${u2.id}">${esc(u2.real_name)}（${esc(u2.work_no || u2.username)} · ${esc(u2.user_type_name || u2.user_type || '')}）</option>`).join('')}</select></div>
          <button class="btn" onclick="app.startImpersonate()">切换进入模拟</button>
        </div>
        <div class="card">
          <h3>审批超时自动交办<span class="badge ok" style="float:right">v7.8</span></h3>
          <div class="muted" style="margin-bottom:8px;">待审批（请假 / 检查审核 / 巡逻 / 通用审批）超过设定天数未处理时，系统自动转交给部门领导 / 管理员，避免流程长期滞留。</div>
          <div class="field"><label>超时天数（1~90，默认 7）</label><input id="cfg-timeout-days" type="number" min="1" max="90" value="${toCfg.days}"></div>
          <button class="btn" onclick="app.saveTimeoutCfg()">保存配置</button>
        </div>
        <div class="card">
          <h3>用户管理（${users.length}）<span class="more"><button class="btn sm" onclick="app.addUser()">＋ 新增用户</button> <button class="btn sm ghost" onclick="app.importUsers()">导入人员</button></span></h3>
          ${users.map((u) => `<div class="list-item">
            <div class="ic">👤</div>
            <div class="body"><div class="t">${esc(u.real_name)}（${esc(u.work_no || u.username)}）${typeBadge(u.user_type)}${u.contract_signed && u.user_type === 'xinren' ? ' <span class="badge warn">已签合同待调级</span>' : ''}</div>
            <div class="d">${esc(depts.find((d) => d.id === u.dept_id)?.name || '未分配部门')}</div></div>
            <div class="act"><button class="btn sm ghost" onclick="app.editUser(${u.id})">编辑</button></div>
          </div>`).join('')}
        </div>
        <div class="card">
          <h3>班组管理<span class="more"><button class="btn sm ghost" onclick="app.addDept()">＋ 班组</button></span></h3>
          ${depts.map((d) => {
            const used = users.filter((u2) => u2.dept_id === d.id && !u2.deleted_at).length;
            const isMgmt = /管理|运维/i.test(d.name);
            return `<div class="list-item"><div class="ic">${isMgmt ? '⚙️' : '🏢'}</div><div class="body"><div class="t">${esc(d.name)}${isMgmt ? ' <span class="badge info">管理/运维组</span>' : ''}<span class="badge gray" style="margin-left:4px;">${used} 人</span></div></div><div class="act"><button class="btn sm danger" onclick="app.delDept(${d.id})">删</button></div></div>`;
          }).join('')}
        </div>
        <div class="card"><h3>人员类型说明</h3><div class="d">新人（只读+打卡，功能需申请）→ 在职人员 → 班组长（班组级审批/检查）→ 管理岗（部门级终审/人事，限 3 人）→ 运维工程师（系统维护）。管理岗与运维工程师单独归入「管理/运维组」；新人确认签劳动合同后系统提醒调整类型，超过 15 天自动提升为在职人员。</div></div>
        <div class="card"><h3>说明</h3><div class="muted">v4.0 · 数据全部存储在本机 data/ 目录；人员信息需与 OIT 保持一致，可通过「导入人员」批量录入（CSV：姓名,工作证编号,部门,类型），未登记人员登录时会提示联系管理员。</div></div>`;
      if (window.app && app.probePub) setTimeout(() => app.probePub(), 200);
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }

  window.app = Object.assign(window.app || {}, {
    addUser: () => {
      api('/api/depts').then((d) => {
        openSheet(`
          <div class="sheet-title">新增用户（与 OIT 保持一致）<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="field"><label>姓名 *</label><input id="u-real"></div>
          <div class="field"><label>工作证编号（登录名）*</label><input id="u-username" placeholder="与 OIT 一致，初始密码同编号"></div>
          <div class="field"><label>初始密码</label><input id="u-pwd" type="text" placeholder="默认等于工作证编号"></div>
          <div class="row2">
            <div class="field"><label>部门</label><select id="u-dept"><option value="">未分配</option>${d.map((x) => '<option value="' + x.id + '">' + esc(x.name) + '</option>').join('')}</select></div>
            <div class="field"><label>人员类型</label><select id="u-type">${UTYPES.map(([v, n]) => '<option value="' + v + '">' + n + '</option>').join('')}</select></div>
          </div>
          <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveUser()">创建</button></div>`);
      });
    },
    saveUser: async () => {
      const no = $('#u-username').value.trim();
      const pwd = $('#u-pwd').value.trim() || no;
      try {
        await api('/api/users', 'POST', {
          username: no, work_no: no, password: pwd, real_name: $('#u-real').value.trim(),
          dept_id: $('#u-dept').value ? Number($('#u-dept').value) : null, user_type: $('#u-type').value
        });
        closeSheet(); renderAdmin();
      } catch (e) { alert(e.message); }
    },
    importUsers: () => {
      openSheet(`
        <div class="sheet-title">导入人员（与 OIT 对齐）<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>CSV 内容 *</label><textarea id="iu-csv" rows="6" placeholder="姓名,工作证编号,部门,类型&#10;张三,1001,消防护卫部,新人&#10;李四,1002,综合办公室,在职&#10;王五,1003,消防护卫部,班组长"></textarea></div>
        <div class="d" style="font-size:12px;color:#6B7280;">类型取值：新人 / 在职 / 班组长 / 部门领导 / 运维工程师（不填默认新人）。已存在的编号自动跳过。</div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.doImport()">导入</button></div>`);
    },
    doImport: async () => {
      const csv = $('#iu-csv').value;
      if (!csv.trim()) { alert('请粘贴 CSV 内容'); return; }
      try {
        const r = await api('/api/users/import', 'POST', { csv });
        closeSheet(); renderAdmin();
        alert('导入完成：新增 ' + r.added + ' 人，跳过 ' + r.skipped + ' 人（编号已存在）');
      } catch (e) { alert(e.message); }
    },
    setType: (id) => {
      api('/api/users').then((users) => {
        const u = users.find((x) => x.id === id);
        openSheet(`
          <div class="sheet-title">调整类型：${esc(u.real_name)}<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="field"><label>人员类型</label><select id="st-type">${UTYPES.map(([v, n]) => '<option value="' + v + '"' + (u.user_type === v ? ' selected' : '') + '>' + n + '</option>').join('')}</select></div>
          <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveType(${id})">保存</button></div>`);
      });
    },
    saveType: async (id) => {
      try { await api('/api/users/' + id + '/type', 'PUT', { user_type: $('#st-type').value }); closeSheet(); renderHR(); } catch (e) { alert(e.message); }
    },
    confirmContract: async (id) => {
      if (!confirm('确认该员工已签订劳动合同？系统将提醒管理员调整类型，超过 15 天自动提升为在职人员。')) return;
      try { await api('/api/users/' + id + '/confirm-contract', 'POST'); renderHR(); } catch (e) { alert(e.message); }
    },
    editUser: (id) => {
      api('/api/users').then((users) => {
        const u = users.find((x) => x.id === id);
        api('/api/depts').then((d) => {
          openSheet(`
            <div class="sheet-title">编辑用户：${esc(u.real_name)}<span class="x" onclick="app.closeSheet()">✕</span></div>
            <div class="field"><label>姓名</label><input id="eu-real" value="${esc(u.real_name)}"></div>
            <div class="field"><label>工作证编号</label><input id="eu-workno" value="${esc(u.work_no || '')}"></div>
            <div class="field"><label>重置密码（留空不改）</label><input id="eu-pwd" type="text"></div>
            <div class="row2">
              <div class="field"><label>部门</label><select id="eu-dept"><option value="">未分配</option>${d.map((x) => '<option value="' + x.id + '"' + (u.dept_id === x.id ? ' selected' : '') + '>' + esc(x.name) + '</option>').join('')}</select></div>
              <div class="field"><label>人员类型</label><select id="eu-type">${UTYPES.map(([v, n]) => '<option value="' + v + '"' + (u.user_type === v ? ' selected' : '') + '>' + n + '</option>').join('')}</select></div>
            </div>
            <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.updateUser(${id})">保存</button></div>`);
        });
      });
    },
    updateUser: async (id) => {
      try {
        await api('/api/users/' + id, 'PUT', {
          real_name: $('#eu-real').value.trim(), work_no: $('#eu-workno').value.trim(), password: $('#eu-pwd').value || undefined,
          dept_id: $('#eu-dept').value ? Number($('#eu-dept').value) : null, user_type: $('#eu-type').value
        });
        closeSheet(); renderAdmin();
      } catch (e) { alert(e.message); }
    },
    addDept: () => {
      const n = prompt('新班组名称：');
      if (!n) return;
      api('/api/depts', 'POST', { name: n.trim() }).then(renderAdmin).catch((e) => alert(e.message));
    },
    delDept: async (id) => {
      if (!confirm('确定删除该班组？班组内已分配人员将显示为「未分配」，请先调整人员归属。')) return;
      try { await api('/api/depts/' + id, 'DELETE'); renderAdmin(); } catch (e) { alert(e.message); }
    },
    /* ---- 检查管理 ---- */
    checkTab: (t) => { checkTab = t; renderCheck(); },
    addCheckPlan: () => {
      openSheet(`
        <div class="sheet-title">制定年度检查计划<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>年份 *</label><input id="cp-year" type="number" value="${new Date().getFullYear()}"></div>
        <div class="field"><label>计划名称 *</label><input id="cp-name" placeholder="如：2026年度围界设施日检查计划"></div>
        <div class="field"><label>检查类型 *</label><select id="cp-type">${CHECK_TYPES.map(([v, n]) => '<option value="' + v + '">' + n + '</option>').join('')}</select></div>
        <div class="field"><label>周期说明</label><input id="cp-cycle" placeholder="如：每周一至周五每日一次"></div>
        <div class="field"><label>检查项目（每行一项）</label><textarea id="cp-items" rows="4" placeholder="围界完好性&#10;监控设备运行&#10;道口管控"></textarea></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveCheckPlan()">保存</button></div>`);
    },
    saveCheckPlan: async () => {
      try {
        await api('/api/check-plans', 'POST', {
          year: Number($('#cp-year').value), name: $('#cp-name').value.trim(), check_type: $('#cp-type').value,
          cycle: $('#cp-cycle').value.trim(), items: $('#cp-items').value.split('\n').map((s) => s.trim()).filter(Boolean)
        });
        closeSheet(); renderCheck();
      } catch (e) { alert(e.message); }
    },
    delCheckPlan: async (id) => {
      if (!confirm('确认删除该计划？')) return;
      try { await api('/api/check-plans/' + id, 'DELETE'); renderCheck(); } catch (e) { alert(e.message); }
    },
    checkPlanDetail: (id) => {
      api('/api/check-plans').then((plans) => {
        const p = plans.find((x) => x.id === id);
        openSheet(`
          <div class="sheet-title">${esc(p.name)}<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="detail-row"><div class="k">年度/类型</div><div class="v">${p.year}年 · ${checkTypeName(p.check_type)}</div></div>
          <div class="detail-row"><div class="k">周期</div><div class="v">${esc(p.cycle || '—')}</div></div>
          <div class="detail-row"><div class="k">负责人</div><div class="v">${esc(p.owner_name || '—')}</div></div>
          <div class="detail-row"><div class="k">检查项目</div><div class="v">${(p.items || []).map((i) => '· ' + esc(i)).join('<br>') || '—'}</div></div>`);
      });
    },
    addCheckRecord: () => {
      checkDraft = { start: null, end: null, photos: [], items: [] };
      Promise.all([api('/api/check-plans'), api('/api/checklists')]).then(([plans, lists]) => {
        openSheet(`
          <div class="sheet-title">上报检查记录<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="field"><label>检查类型 *</label><select id="cr-type">${CHECK_TYPES.map(([v, n]) => '<option value="' + v + '">' + n + '</option>').join('')}</select></div>
          <div class="field"><label>使用检查单</label><select id="cr-list" onchange="app.pickChecklist()"><option value="">不使用检查单</option>${lists.map((c) => '<option value="' + c.id + '">' + esc(c.name) + '（' + c.items.length + '项）</option>').join('')}</select>
            <div id="cr-items-box"></div></div>
          <div class="field"><label>关联计划</label><select id="cr-plan"><option value="">无</option>${plans.map((p) => '<option value="' + p.id + '">' + esc(p.name) + '</option>').join('')}</select></div>
          <div class="row2">
            <div class="field"><label>检查日期 *</label><input id="cr-date" type="date" value="${new Date().toISOString().slice(0, 10)}"></div>
            <div class="field"><label>检查单编号（如 001—316）</label><input id="cr-no" placeholder="可选"></div>
          </div>
          <div class="row2">
            <div class="field"><label>开始时间</label><input id="cr-start" type="time"></div>
            <div class="field"><label>结束时间</label><input id="cr-end" type="time"></div>
          </div>
          <div class="field"><label>检查区域 *</label><input id="cr-area" placeholder="如：东侧围界"></div>
          <div class="card" style="background:#f6f8fc;">
            <h3 style="font-size:14px;">📍 位置定位（开始/结束检查）</h3>
            <div class="d" style="font-size:12px;color:#6B7280;margin-bottom:8px;">点击按钮向手机申请定位（GPS+网络双定位），开始与结束均记录时间与经纬度。</div>
            <div class="row2">
              <button type="button" class="btn sm" onclick="app.geoStart()">▶ 开始检查定位</button>
              <button type="button" class="btn sm ghost" onclick="app.geoEnd()">⏹ 结束检查定位</button>
            </div>
            <div id="loc-start" class="d" style="font-size:12px;color:#1d4ed8;margin-top:6px;">尚未定位</div>
            <div id="loc-end" class="d" style="font-size:12px;color:#1d4ed8;margin-top:4px;">尚未定位</div>
          </div>
          <div class="card" style="background:#f6f8fc;">
            <h3 style="font-size:14px;">📷 现场拍照（时间+经纬度水印）</h3>
            <div class="d" style="font-size:12px;color:#6B7280;margin-bottom:8px;">调用手机摄像头拍照，自动在照片上合成拍摄时间与 GPS 经纬度水印。</div>
            <button type="button" class="btn sm" onclick="app.photoShot()">拍照（带水印）</button>
            <div id="photo-list" class="d" style="margin-top:6px;"></div>
          </div>
          <div class="field"><label>检查结论 *</label><select id="cr-result"><option value="ok">合格</option><option value="basic">基本合格（需整改）</option><option value="bad">不合格</option></select></div>
          <div class="field"><label>问题/说明</label><textarea id="cr-summary" rows="3" placeholder="发现问题时填写具体描述"></textarea></div>
          <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.saveCheckRecord()">提交（上报审核）</button></div>`);
      });
    },
    geoStart: async () => {
      try { checkDraft.start = await GEO.get(); $('#loc-start').textContent = '开始检查：' + GEO.fmt(checkDraft.start); }
      catch (e) { alert(e.message); }
    },
    geoEnd: async () => {
      try { checkDraft.end = await GEO.get(); $('#loc-end').textContent = '结束检查：' + GEO.fmt(checkDraft.end); }
      catch (e) { alert(e.message); }
    },
    photoShot: () => {
      // [需求2] 双版本归档：水印版共享可见（share_flag=1），原始版仅本人可见（share_flag=0）
      snapPhoto(async (wmBlob, origBlob, pos, timeStr) => {
        const toB64 = (blob) => new Promise((rs) => { const fr = new FileReader(); fr.onload = () => rs(fr.result.split(',')[1]); fr.readAsDataURL(blob); });
        try {
          const stamp = Date.now();
          const [b64wm, b64orig] = await Promise.all([toB64(wmBlob), toB64(origBlob)]);
          const rOrig = await api('/api/files/upload', 'POST', { name: '现场照片原图_' + stamp + '.jpg', data: b64orig, share_flag: 0 });
          const rWm = await api('/api/files/upload', 'POST', { name: '现场照片_' + stamp + '.jpg', data: b64wm, share_flag: 1 });
          checkDraft.photos.push({ file_id: rWm.id, orig_file_id: rOrig.id, time: timeStr, loc: GEO.brief(pos) || '定位失败' });
          $('#photo-list').innerHTML = checkDraft.photos.map((ph, i) => `<span style="display:inline-block;margin:4px 6px 0 0;padding:4px 8px;background:#eef2ff;color:#3730a3;border-radius:8px;font-size:12px;">📷 第${i + 1}张 · ${ph.time} · ${ph.loc}</span>`).join('');
        } catch (e) { alert('照片上传失败：' + e.message); }
      });
    },
    saveCheckRecord: async () => {
      try {
        await api('/api/check-records', 'POST', {
          plan_id: $('#cr-plan').value ? Number($('#cr-plan').value) : null, check_type: $('#cr-type').value,
          check_date: $('#cr-date').value, area: $('#cr-area').value.trim(), result: $('#cr-result').value, summary: $('#cr-summary').value.trim(),
          checklist_id: $('#cr-list').value ? Number($('#cr-list').value) : null, checklist_no: ($('#cr-no').value || '').trim(),
          start_time: ($('#cr-start').value || '').trim(), end_time: ($('#cr-end').value || '').trim(),
          items_json: JSON.stringify(checkDraft.items || []),
          start_loc: GEO.brief(checkDraft.start), end_loc: GEO.brief(checkDraft.end), photos: checkDraft.photos
        });
        closeSheet(); renderCheck(); checkTab = 'rec'; renderCheck();
      } catch (e) { alert(e.message); }
    },
    pickChecklist: () => {
      const id = Number($('#cr-list').value);
      if (!id) { $('#cr-items-box').innerHTML = ''; return; }
      api('/api/checklists').then((lists) => {
        const c = lists.find((x) => x.id === id);
        if (!c) { $('#cr-items-box').innerHTML = ''; return; }
        checkDraft.items = c.items.map((it) => ({ item: it.item || it, std: it.std || '', pass: '' }));
        $('#cr-items-box').innerHTML = '<div class="chk-items">' + checkDraft.items.map((it, i) => `<div style="padding:5px 0;border-bottom:1px dashed #eee;font-size:13px;"><b>${i + 1}. ${esc(it.item)}</b><div style="color:#6B7280;font-size:12px;">合格标准：${esc(it.std || '—')}</div><select onchange="checkDraft.items[${i}].pass=this.value" style="margin-top:4px;font-size:13px;"><option value="">— 判定 —</option><option value="pass">合格</option><option value="fail">不合格</option><option value="na">不适用</option></select></div>`).join('') + '</div>';
      }).catch(() => { $('#cr-items-box').innerHTML = ''; });
    },
    approveCheck: async (id, action) => {
      const note = action === 'reject' ? (prompt('请填写驳回原因：') || '') : '';
      if (action === 'reject' && !note) { alert('驳回需填写原因'); return; }
      try { await api('/api/check-records/' + id + '/approve', 'POST', { action, note }); renderCheck(); } catch (e) { alert(e.message); }
    },
    checkIssueAdd: (recId) => {
      api('/api/check-records').then((recs) => {
        const r = recs.find((x) => x.id === recId);
        if (!r) return;
        api('/api/users').then((us) => {
          const opts = us.filter((u) => u.user_type !== 'xinren').map((u) => '<option value="' + u.id + '">' + esc(u.name) + '（' + esc(u.work_no) + '）</option>').join('');
          openSheet(`
            <div class="sheet-title">登记检查问题<span class="x" onclick="app.closeSheet()">✕</span></div>
            <div class="detail-row"><div class="k">来源检查</div><div class="v">${checkTypeName(r.check_type)} · ${esc(r.check_date)} · ${esc(r.area || '—')}</div></div>
            <div class="field"><label>问题类型 *</label><select id="ci-type"><option value="spot">当场整改（现场整改并验收）</option><option value="rectify">限期整改（下发整改通知）</option></select></div>
            <div class="field"><label>问题内容 *</label><textarea id="ci-content" rows="3" placeholder="描述问题位置、现象和程度"></textarea></div>
            <div class="field"><label>问题位置</label><input id="ci-loc" placeholder="如：东侧围界第 012 段"></div>
            <div class="field"><label>整改责任人 *</label><select id="ci-assign">${opts}</select></div>
            <div class="field" id="ci-deadline-f"><label>整改期限</label><input id="ci-deadline" type="date"></div>
            ${ME && ME.sign ? '' : '<div class="warn-box">登记问题需手写签字确认，请先在「我的 → 手写签名」中完成授权。</div>'}
            <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.checkIssueSave(${r.id})">登记并签字提交</button></div>`);
          document.getElementById('ci-type').onchange = () => { document.getElementById('ci-deadline-f').style.display = document.getElementById('ci-type').value === 'rectify' ? '' : 'none'; };
          if (document.getElementById('ci-type').value === 'spot') document.getElementById('ci-deadline-f').style.display = 'none';
        });
      });
    },
    checkIssueSave: async (recId) => {
      const type = $('#ci-type').value, content = $('#ci-content').value.trim(), loc = $('#ci-loc').value.trim(), assign = Number($('#ci-assign').value), deadline = $('#ci-deadline').value || null;
      if (!content) { alert('请填写问题内容'); return; }
      if (type === 'rectify' && !deadline) { alert('限期整改需填写整改期限'); return; }
      if (!ME.sign) { alert('请先在「我的 → 手写签名」完成手写授权后再登记问题'); return; }
      try {
        await api('/api/check-issues', 'POST', { check_record_id: recId, issue_type: type, content, location: loc, assigned_to: assign, rectify_deadline: deadline, sig: ME.sign });
        alert(type === 'spot' ? '已登记当场整改问题（现场整改后由班组长验收）' : '已登记限期整改问题，请班组长下发整改通知');
        closeSheet(); renderCheck();
      } catch (e) { alert(e.message); }
    },
    checkIssueNotice: async (id) => {
      api('/api/check-issues').then((issues) => {
        const x = issues.find((i) => i.id === id);
        if (!x) return;
        openSheet(`
          <div class="sheet-title">下发整改通知<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="card" style="background:#f6f8fc;font-size:13px;white-space:pre-wrap;">${esc(x.notice_preview || '（将按模板生成整改通知）')}</div>
          <div class="d" style="font-size:12px;color:#6B7280;margin:8px 0;">签发后将同步推送部门群通报（限时撤回机制生效），并生成通知编号留档。</div>
          ${ME && ME.sign ? '' : '<div class="warn-box">签发整改通知需班组长及以上手写签字。</div>'}
          <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn warn" onclick="app.checkIssueNoticeSave(${id})">签发（签字下发）</button></div>`);
      });
    },
    checkIssueNoticeSave: async (id) => {
      if (!ME.sign) { alert('请先完成手写签名授权'); return; }
      try {
        await api('/api/check-issues/' + id + '/notice', 'POST', { sig: ME.sign });
        alert('整改通知已签发并群内通报');
        closeSheet(); renderCheck();
      } catch (e) { alert(e.message); }
    },
    checkIssueReport: async (id) => {
      api('/api/check-issues').then((issues) => {
        const x = issues.find((i) => i.id === id);
        if (!x) return;
        openSheet(`
          <div class="sheet-title">提交整改材料<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="detail-row"><div class="k">整改问题</div><div class="v">${esc(x.content)}${x.notice_no ? '（通知 ' + x.notice_no + '）' : ''}</div></div>
          <div class="field"><label>整改措施报告 *</label><textarea id="ir-content" rows="4" placeholder="整改措施、完成情况"></textarea></div>
          <div class="field"><label>证明材料说明</label><textarea id="ir-evidence" rows="2" placeholder="如：已更换网片，附照片"></textarea></div>
          ${ME && ME.sign ? '' : '<div class="warn-box">提交整改材料需手写签字。</div>'}
          <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.checkIssueReportSave(${id})">提交（签字）</button></div>`);
      });
    },
    checkIssueReportSave: async (id) => {
      if (!ME.sign) { alert('请先完成手写签名授权'); return; }
      try {
        await api('/api/check-issues/' + id + '/report', 'POST', { report_content: $('#ir-content').value.trim(), evidence_note: $('#ir-evidence').value.trim(), sig: ME.sign });
        alert('整改材料已提交，等待班组长验收');
        closeSheet(); renderCheck();
      } catch (e) { alert(e.message); }
    },
    checkIssueAccept: async (id) => {
      api('/api/check-issues').then((issues) => {
        const x = issues.find((i) => i.id === id);
        if (!x) return;
        openSheet(`
          <div class="sheet-title">班组长验收<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="detail-row"><div class="k">整改问题</div><div class="v">${esc(x.content)}</div></div>
          <div class="detail-row"><div class="k">整改措施</div><div class="v">${esc(x.report_content || '—')}</div></div>
          <div class="detail-row"><div class="k">证明材料</div><div class="v">${esc(x.evidence_note || '—')}</div></div>
          <div class="field"><label>验收结论 *</label><select id="ac-pass"><option value="accept">验收合格（生成验收合格报告留档）</option><option value="reject">验收不合格（退回重新整改）</option></select></div>
          ${ME && ME.sign ? '' : '<div class="warn-box">验收需班组长及以上手写签字。</div>'}
          <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn ok" onclick="app.checkIssueAcceptSave(${id})">验收（签字）</button></div>`);
      });
    },
    checkIssueAcceptSave: async (id) => {
      if (!ME.sign) { alert('请先完成手写签名授权'); return; }
      try {
        await api('/api/check-issues/' + id + '/accept', 'POST', { action: $('#ac-pass').value, sig: ME.sign });
        alert($('#ac-pass').value === 'accept' ? '验收合格，验收合格报告已生成留档' : '已退回，请整改人重新提交');
        closeSheet(); renderCheck();
      } catch (e) { alert(e.message); }
    },
    addChecklist: () => {
      openSheet(`
        <div class="sheet-title">新增检查单<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>检查单名称 *</label><input id="cl-name" placeholder="如：消防器材检查单"></div>
        <div class="field"><label>检查项（每行一项，格式：检查项|合格标准）</label><textarea id="cl-items" rows="6" placeholder="灭火器压力|指针在绿区，无锈蚀&#10;消防通道|畅通无堵塞"></textarea></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.addChecklistSave()">保存</button></div>`);
    },
    addChecklistSave: async () => {
      const name = $('#cl-name').value.trim();
      const items = $('#cl-items').value.split(/\n/).map((s) => s.trim()).filter(Boolean).map((s) => { const p = s.split('|'); return { item: p[0].trim(), std: (p[1] || '').trim() }; });
      if (!name || !items.length) { alert('请填写名称和至少一个检查项'); return; }
      try { await api('/api/checklists', 'POST', { name, items }); closeSheet(); renderCheck(); } catch (e) { alert(e.message); }
    },
    delChecklist: async (id) => {
      if (!confirm('确定删除该检查单？删除后不可恢复。')) return;
      try { await api('/api/checklists/' + id, 'DELETE'); renderCheck(); } catch (e) { alert(e.message); }
    },
    checkRecDetail: (id) => {
      Promise.all([api('/api/check-records'), api('/api/check-issues')]).then(([recs, issues]) => {
        const r = recs.find((x) => x.id === id);
        const mine = issues.filter((x) => x.check_record_id === id);
        const canIssue = ME && (r.checker_id === ME.id || MYLV() >= 1);
        openSheet(`
          <div class="sheet-title">${checkTypeName(r.check_type)} · ${esc(r.area || '—')}<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="detail-row"><div class="k">日期/时间</div><div class="v">${esc(r.check_date)}${r.start_time ? ' ' + esc(r.start_time) + '—' + esc(r.end_time || '') : ''} · ${esc(r.checker_name)}</div></div>
          <div class="detail-row"><div class="k">计划/检查单</div><div class="v">${esc(r.plan_name || '—')}${r.checklist_name ? ' · 检查单：' + esc(r.checklist_name) : ''}${r.checklist_no ? '（编号 ' + esc(r.checklist_no) + '）' : ''}</div></div>
          <div class="detail-row"><div class="k">结论</div><div class="v">${RES_BADGE[r.result] || esc(r.result)}</div></div>
          <div class="detail-row"><div class="k">说明</div><div class="v">${esc(r.summary || '—')}</div></div>
          ${(r.items || []).length ? `<div class="detail-row"><div class="k">逐项检查结果</div><div class="v">${r.items.map((it) => `<div style="font-size:13px;padding:3px 0;">${esc(it.item || it)} — ${it.pass === 'pass' ? '<span class="badge ok">合格</span>' : it.pass === 'fail' ? '<span class="badge bad">不合格</span>' : it.pass === 'na' ? '<span class="badge info">不适用</span>' : '<span style="color:#6B7280;">未判定</span>'}</div>`).join('')}</div></div>` : ''}
          ${r.start_loc ? `<div class="detail-row"><div class="k">开始定位</div><div class="v">${esc(r.start_loc)}</div></div>` : ''}
          ${r.end_loc ? `<div class="detail-row"><div class="k">结束定位</div><div class="v">${esc(r.end_loc)}</div></div>` : ''}
          ${(r.photos || []).length ? `<div class="detail-row"><div class="k">现场照片</div><div class="v">${r.photos.map((ph) => '<img src="/api/files/' + ph.file_id + '/image?token=' + encodeURIComponent(TOKEN) + '" style="width:100%;max-width:260px;border-radius:8px;margin:4px 0;display:block;">' + '<div style="font-size:12px;color:#6B7280;">' + esc(ph.time || '') + ' · ' + esc(ph.loc || '') + '</div>').join('')}</div></div>` : ''}
          <div class="detail-row"><div class="k">审核链</div><div class="v">${esc((r.chain || []).join(' → ') || '—')}${r.status === 'pending' && r.pending_level_name ? '（当前待「' + esc(r.pending_level_name) + '」）' : ''}</div></div>
          <div class="detail-row"><div class="k">状态</div><div class="v">${ST_BADGE[r.status] || r.status}${r.approver_name ? ' · ' + esc(r.approver_name) + (r.approve_note ? '：' + esc(r.approve_note) : '') : ''}</div></div>
          ${mine.length ? `<div class="card" style="margin-top:8px;background:#f6f8fc;"><h3 style="font-size:14px;">本次检查问题（${mine.length}）</h3>${mine.map((x) => `<div style="font-size:13px;padding:4px 0;">${x.issue_type === 'spot' ? '<span class="badge info">当场整改</span>' : '<span class="badge warn">限期整改</span>'} ${esc(x.content)} ${ISSUE_ST[x.status] || ''}${x.notice_no ? ' · ' + x.notice_no : ''}${x.accept_report_no ? ' · ' + x.accept_report_no : ''}</div>`).join('')}</div>` : ''}
          ${canIssue ? '<div class="sheet-actions" style="margin-top:10px;"><button class="btn" onclick="app.checkIssueAdd(' + r.id + ')">＋ 登记检查问题</button></div>' : ''}`);
        lvCache = lvCache;
      });
    },
    /* ---- 巡逻 ---- */
    addPatrol: () => {
      patrolDraft = { start: null, end: null };
      openSheet(`
        <div class="sheet-title">巡逻上报<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>巡逻日期 *</label><input id="pt-date" type="date" value="${new Date().toISOString().slice(0, 10)}"></div>
        <div class="field"><label>巡逻区域 *</label><input id="pt-area" placeholder="如：飞行区东侧"></div>
        <div class="row2">
          <div class="field"><label>开始时间</label><input id="pt-start" type="time"></div>
          <div class="field"><label>结束时间</label><input id="pt-end" type="time"></div>
        </div>
        <div class="card" style="background:#f6f8fc;">
          <h3 style="font-size:14px;">📍 位置定位（开始/结束巡逻）</h3>
          <div class="d" style="font-size:12px;color:#6B7280;margin-bottom:8px;">点击按钮向手机申请定位（GPS+网络），记录经纬度。</div>
          <div class="row2">
            <button type="button" class="btn sm" onclick="app.patrolGeoStart()">▶ 开始定位</button>
            <button type="button" class="btn sm ghost" onclick="app.patrolGeoEnd()">⏹ 结束定位</button>
          </div>
          <div id="ploc-start" class="d" style="font-size:12px;color:#1d4ed8;margin-top:6px;">尚未定位</div>
          <div id="ploc-end" class="d" style="font-size:12px;color:#1d4ed8;margin-top:4px;">尚未定位</div>
        </div>
        <div class="field"><label>结果 *</label><select id="pt-result"><option value="ok">正常</option><option value="issue">发现问题</option></select></div>
        <div class="field"><label>发现问题描述</label><textarea id="pt-issues" rows="3" placeholder="发现异常时填写"></textarea></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.savePatrol()">提交（上报审核）</button></div>`);
    },
    patrolGeoStart: async () => {
      try { patrolDraft.start = await GEO.get(); $('#ploc-start').textContent = '开始巡逻：' + GEO.fmt(patrolDraft.start); }
      catch (e) { alert(e.message); }
    },
    patrolGeoEnd: async () => {
      try { patrolDraft.end = await GEO.get(); $('#ploc-end').textContent = '结束巡逻：' + GEO.fmt(patrolDraft.end); }
      catch (e) { alert(e.message); }
    },
    savePatrol: async () => {
      try {
        await api('/api/patrols', 'POST', {
          patrol_date: $('#pt-date').value, area: $('#pt-area').value.trim(), start_time: $('#pt-start').value,
          end_time: $('#pt-end').value, result: $('#pt-result').value, issues: $('#pt-issues').value.trim(),
          start_loc: GEO.brief(patrolDraft.start), end_loc: GEO.brief(patrolDraft.end)
        });
        closeSheet(); renderPatrol();
      } catch (e) { alert(e.message); }
    },
    approvePatrol: async (id, action) => {
      const note = action === 'reject' ? (prompt('请填写驳回原因：') || '') : '';
      if (action === 'reject' && !note) { alert('驳回需填写原因'); return; }
      try { await api('/api/patrols/' + id + '/approve', 'POST', { action, note }); renderPatrol(); } catch (e) { alert(e.message); }
    },
    patrolDetail: (id) => {
      api('/api/patrols').then((list) => {
        const r = list.find((x) => x.id === id);
        openSheet(`
          <div class="sheet-title">巡逻 · ${esc(r.area)}<span class="x" onclick="app.closeSheet()">✕</span></div>
          <div class="detail-row"><div class="k">日期/时间</div><div class="v">${esc(r.patrol_date)}${r.start_time ? ' ' + esc(r.start_time) + (r.end_time ? '~' + esc(r.end_time) : '') : ''}</div></div>
          <div class="detail-row"><div class="k">巡逻人</div><div class="v">${esc(r.patroler_name)}</div></div>
          ${r.start_loc ? `<div class="detail-row"><div class="k">开始定位</div><div class="v">${esc(r.start_loc)}</div></div>` : ''}
          ${r.end_loc ? `<div class="detail-row"><div class="k">结束定位</div><div class="v">${esc(r.end_loc)}</div></div>` : ''}
          <div class="detail-row"><div class="k">结果</div><div class="v">${r.result === 'issue' ? '发现问题' : '正常'}</div></div>
          <div class="detail-row"><div class="k">问题</div><div class="v">${esc(r.issues || '—')}</div></div>
          <div class="detail-row"><div class="k">审核链</div><div class="v">${esc((r.chain || []).join(' → ') || '—')}${r.status === 'pending' && r.pending_level_name ? '（当前待「' + esc(r.pending_level_name) + '」）' : ''}</div></div>
          <div class="detail-row"><div class="k">状态</div><div class="v">${ST_BADGE[r.status] || r.status}${r.approver_name ? ' · ' + esc(r.approver_name) + (r.approve_note ? '：' + esc(r.approve_note) : '') : ''}</div></div>`);
      });
    }
  });

  /* ===== 启动 ===== */
  (async function init() {
    if (TOKEN) {
      try { await enterApp(); return; } catch (e) { TOKEN = ''; localStorage.removeItem('dept_token'); }
    }
  })();


  /* ================= v5.0 新模块 ================= */
  /* ---- 启动时间校验（联网同步标准时间，误差>4秒阻止运行） ---- */
  /* [需求1] 时间校验闸门：容差由 4 秒放宽到 25 秒（手机与服务器轻微漂移属正常）；
     已登录状态下**不再整页阻断**，只给一次轻提示，避免"打开就是白屏闸门"的误伤体验。
     未登录才显示全屏闸门（含「重新检测」「重启软件」两个按钮）。 */
  async function timeGateCheck() {
    try {
      const r = await fetch((API_BASE || '') + '/api/time-sync');
      const j = await r.json();
      if (!(j.ok && j.data && j.data.server_time)) return true;
      const diff = Math.abs(Date.now() - j.data.server_time);
      if (diff <= 25000) return true;
      if (TOKEN) { v5toast('本机时间与服务器相差 ' + Math.round(diff / 1000) + ' 秒，建议校准后再提交操作'); return true; }
      const g = $('#time-gate');
      if (g) g.style.display = 'flex';
      const lv = $('#login-view');
      if (lv) lv.style.display = 'none';
      return false;
    } catch (e) { return true; }   // 时间源不可达：放行
  }
  window.timeGateCheck = timeGateCheck;
  window.timeGateRetry = async () => { const okk = await timeGateCheck(); if (okk) { const g = $('#time-gate'); if (g) g.style.display = 'none'; const lv = $('#login-view'); if (lv) lv.style.display = ''; } };
  window.timeGateReload = () => location.reload();
  timeGateCheck();

  /* ---- 手机信息上报（屏幕适配） ---- */
  function reportDevice() {
    try {
      api('/api/device', 'POST', {
        ua: String(navigator.userAgent || '').slice(0, 300),
        screen: window.screen ? screen.width + 'x' + screen.height : '',
        dpr: String(window.devicePixelRatio || 1),
        cores: String(navigator.hardwareConcurrency || ''),
        platform: String(navigator.platform || '')
      }).catch(() => {});
      // 窄屏微调
      if (window.screen && screen.width < 360) document.documentElement.style.fontSize = '13.5px';
    } catch (e) {}
  }

  /* ---- 全局轻提示（iOS 胶囊 + 退场动画） ---- */
  function v5toast(msg, ms) {
    let t = $('#v5-toast');
    if (!t) { t = document.createElement('div'); t.id = 'v5-toast'; document.body.appendChild(t); }
    t.classList.remove('closing');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._tm);
    t._tm = setTimeout(() => { t.classList.add('closing'); setTimeout(() => t.classList.remove('show', 'closing'), 180); }, ms || 3500);
  }

  /* ---- 按钮 loading 辅助（保留文字 + 内嵌 spinner + 防重复提交） ---- */
  function btnLoading(btn, on) {
    if (!btn) return;
    if (on) {
      if (!btn.querySelector('.spin')) { const s = document.createElement('span'); s.className = 'spin'; btn.insertBefore(s, btn.firstChild); }
      const sp = btn.querySelector('.spin'); if (sp) sp.classList.add('show');
      btn.classList.add('loading'); btn.dataset._d = btn.disabled; btn.disabled = true;
    } else {
      const sp = btn.querySelector('.spin'); if (sp) sp.classList.remove('show');
      btn.classList.remove('loading'); btn.disabled = btn.dataset._d === 'true' ? true : false;
    }
  }

  /* ---- 草稿箱统一层 ---- */
  function collectSheetForm() {
    const fields = {};
    $('#sheet').querySelectorAll('input, textarea, select').forEach((el) => {
      const k = el.id || el.name;
      if (!k) return;
      if (el.type === 'checkbox') fields[k] = el.checked;
      else if (el.type === 'radio') { if (el.checked) fields[k] = el.value; }
      else fields[k] = el.value;
    });
    return fields;
  }
  function fillSheetForm(payload) {
    if (!payload || !payload.fields) return;
    $('#sheet').querySelectorAll('input, textarea, select').forEach((el) => {
      const k = el.id || el.name;
      if (!k || !(k in payload.fields)) return;
      const v = payload.fields[k];
      if (el.type === 'checkbox') el.checked = !!v;
      else el.value = v;
    });
  }
  async function saveDraftNow() {
    const key = CURRENT_DRAFT_KEY;
    if (!key) { v5toast('当前无填写中的表单'); return; }
    try {
      await api('/api/drafts', 'POST', { feature: key, payload: collectSheetForm() });
      v5toast('已保存到草稿箱：' + key);
      refreshDraftBadge();
    } catch (e) { v5toast('保存失败：' + e.message); }
  }
  async function loadDraftNow() {
    const key = CURRENT_DRAFT_KEY;
    if (!key) return;
    try {
      const d = await api('/api/drafts/' + encodeURIComponent(key));
      if (!d) { v5toast('暂无草稿'); return; }
      fillSheetForm(d);
      v5toast('已恢复草稿：' + key);
    } catch (e) { v5toast('恢复失败：' + e.message); }
  }
  async function refreshDraftBadge() {
    try {
      const list = await api('/api/drafts');
      const b = $('#draft-badge');
      if (b) b.textContent = list.length ? ' · ' + list.length : '';
    } catch (e) {}
  }
  const DRAFT_FEAT2PAGE = { '发布通知': 'msg', '请假': 'approval', '检查': 'check', '巡逻': 'patrol', '培训': 'train', '会议': 'meeting', '值班': 'duty', '任务': 'task', '数据录入': 'form', '入职': 'hr', '离职': 'hr', '转正': 'hr', '调岗': 'hr', '审计': 'audit', '考勤': 'attendance', '加班': 'approval', '公出': 'approval', '物资': 'approval' };
  function draftPageOf(feature) {
    for (const k of Object.keys(DRAFT_FEAT2PAGE)) { if (String(feature).includes(k)) return DRAFT_FEAT2PAGE[k]; }
    return null;
  }
  async function renderDraft() {
    const el = $('#page-draft');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const list = await api('/api/drafts');
      el.innerHTML = `<div class="card"><h3>草稿箱（${list.length}）</h3>
        ${list.map((d) => {
          const page = draftPageOf(d.feature);
          return `<div class="list-item draft-card">
            <div class="df">📝</div>
            <div class="body">
              <div class="t">${esc(d.feature)}</div>
              <div class="d">${d.updated_at}${page ? ' · ' + esc(page) : ''}</div>
            </div>
            <div class="act">
              <button class="btn sm ghost" onclick="app.openDraft('${esc(d.feature)}')">查看</button>
              <button class="btn sm danger" onclick="app.delDraft('${esc(d.feature)}')">删</button>
            </div>
          </div>`;}).join('') || '<div class="empty">暂无草稿。填写表单时点「💾 存草稿」可随时保存；网络异常时系统会自动把填写内容存入草稿箱</div>'}</div>`;
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }
  function draftFieldsHtml(d) {
    const fields = (d && d.fields) || {};
    return Object.keys(fields).map((k) => `<div class="detail-row"><div class="k">${esc(k)}</div><div class="v">${esc(fields[k])}</div></div>`).join('') || '<div class="empty">空草稿</div>';
  }

  /* ---- 网络检测（前端隐藏，每30秒随机ping域名） ---- */
  const PING_HOSTS = ['https://www.baidu.com/favicon.ico', 'https://www.qq.com/favicon.ico', 'https://www.163.com/favicon.ico', 'https://cn.bing.com/favicon.ico'];
  let netWatchTimer = null, netOk = true, offlineCount = 0, offlineShowing = false;
  function pingOnce() {
    const host = PING_HOSTS[Math.floor(Math.random() * PING_HOSTS.length)];
    return new Promise((resolve) => {
      const ctrl = new AbortController();
      const to = setTimeout(() => ctrl.abort(), 3500);
      fetch(host, { method: 'GET', signal: ctrl.signal, mode: 'no-cors', cache: 'no-store' })
        .then(() => { clearTimeout(to); resolve(true); })
        .catch(() => { clearTimeout(to); resolve(false); });
    });
  }
  function showOfflineGate(secs) {
    let g = $('#offline-gate');
    if (!g) {
      g = document.createElement('div');
      g.id = 'offline-gate';
      g.innerHTML = '<div class="og-card"><div class="og-ico">📡</div><div class="og-title">网络异常</div><div class="og-sub" id="og-sub">网络断开或信号不良，正在把您填写的内容保存到草稿箱…</div><div class="og-count" id="og-count">' + secs + '</div><div class="og-sub">秒内未恢复将退出；10 秒内网络恢复则不退出</div></div>';
      document.body.appendChild(g);
    }
    g.classList.add('show');
  }
  function hideOfflineGate() { const g = $('#offline-gate'); if (g) g.classList.remove('show'); offlineShowing = false; }
  async function handleOffline() {
    offlineShowing = true;
    const key = CURRENT_DRAFT_KEY;
    if (key) { try { await api('/api/drafts', 'POST', { feature: key, payload: collectSheetForm() }); } catch (e) {} }
    showOfflineGate(10);
    let left = 10;
    const iv = setInterval(async () => {
      left--;
      const c = $('#og-count');
      if (c) c.textContent = String(Math.max(0, left));
      if (left <= 0 && !netOk) { clearInterval(iv); const s = $('#og-sub'); if (s) s.textContent = '网络仍未恢复，已停止当前操作。请检查网络后重新打开软件（内容已保存到草稿箱）。'; }
      if (await pingOnce()) { clearInterval(iv); if (!netOk) { netOk = true; offlineCount = 0; hideOfflineGate(); v5toast('网络已恢复，继续使用'); setTimeout(() => { v5toast('草稿箱内有自动保存的信息，请查看'); refreshDraftBadge(); }, 20000); } }
    }, 1000);
  }
  function startNetWatch() {
    if (netWatchTimer) return;
    pingOnce().then((ok) => { netOk = ok; });
    netWatchTimer = setInterval(async () => {
      const ok = await pingOnce();
      if (ok) {
        if (!netOk && offlineShowing) { hideOfflineGate(); setTimeout(() => { v5toast('网络已恢复：草稿箱内有自动保存的信息，请查看'); refreshDraftBadge(); }, 20000); }
        netOk = true; offlineCount = 0;
      } else {
        offlineCount++;
        if (offlineCount >= 2 && netOk) { netOk = false; await handleOffline(); }
      }
    }, 30000);
  }

  /* ---- 手写签名（canvas 手写 + 季度核验） ---- */
  let sigCtx = null, sigDrawing = false;
  async function refreshSetup() {
    const sp = $('#page-setup');
    if (sp && sp.classList.contains('show')) renderSetup();
  }
  function openSignPad() {
    openSheet(`
      <div class="sheet-title">手写签名授权<span class="x" onclick="app.closeSheet()">✕</span></div>
      <div class="setup-tip">请在下方白色区域手写您的签名（手指或鼠标），保存后系统内所有需要签字的位置统一使用该手写签名；每季度需核验一次。</div>
      <div class="field"><label>本人姓名（须与系统登记姓名一致，用于签名认证）</label><input id="sig-name" placeholder="请输入本人姓名"></div>
      <div class="sign-box"><canvas id="sig-canvas" width="560" height="180"></canvas></div>
      <div class="sign-actions"><button class="btn ghost" onclick="app.clearSign()">清空重写</button><button class="btn" onclick="app.saveSign()">保存签名</button></div>`, '手写签名授权');
    const cv = $('#sig-canvas');
    if (!cv) return;
    const ctx = cv.getContext('2d');
    sigCtx = ctx;
    ctx.lineWidth = 3.2; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#1c2b3a';
    const pos = (e) => { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left) * (cv.width / r.width), y: (e.clientY - r.top) * (cv.height / r.height) }; };
    cv.addEventListener('pointerdown', (e) => { e.preventDefault(); sigDrawing = true; ctx.beginPath(); const p = pos(e); ctx.moveTo(p.x, p.y); });
    cv.addEventListener('pointermove', (e) => { if (!sigDrawing) return; e.preventDefault(); const p = pos(e); ctx.lineTo(p.x, p.y); ctx.stroke(); });
    cv.addEventListener('pointerup', () => { sigDrawing = false; });
    cv.addEventListener('pointerleave', () => { sigDrawing = false; });
  }
  async function saveSign() {
    const cv = $('#sig-canvas');
    if (!cv || !sigCtx) return;
    const data = cv.toDataURL('image/png').split(',')[1];
    if (!data || data.length < 100) { v5toast('请先手写签名再保存'); return; }
    const nm = (($('#sig-name') || {}).value || '').trim();
    if (!nm) { v5toast('请填写本人姓名用于签名认证'); return; }
    try {
      await api('/api/signature', 'POST', { data, name: nm });
      closeSheet(); v5toast('签名授权成功（有效期一个季度）'); refreshSetup();
    } catch (e) { v5toast(e.message); }
  }
  async function verifySig() {
    const nm = prompt('请输入本人姓名用于签名季度核验（须与系统登记姓名一致）');
    if (!nm) return;
    try { await api('/api/signature/verify', 'POST', { name: nm.trim() }); v5toast('季度核验完成，签名继续有效'); refreshSetup(); } catch (e) { v5toast(e.message); }
  }
  async function sigRemind() {
    try {
      const sig = await api('/api/signature');
      if (!sig.valid) v5toast('手写字体授权验证：您的签名未授权或已过期，请到「我的-手写签名」完成授权（每季度核验一次）', 6500);
    } catch (e) {}
  }

  /* ---- 设置页（只读信息 + 签名管理 + 信息反馈） ---- */
  async function renderSetup() {
    const el = $('#page-setup');
    el.innerHTML = '<div class="muted">加载中…</div>';
    try {
      const me = await api('/api/me');
      const sig = await api('/api/signature');
      const isAdmin = MYLV() >= 5;
      el.innerHTML = `
        ${MYLV() >= 4 ? `<div class="card"><h3><svg class="lg-ic"><use href="#i-gear"/></svg> 配置中心<span class="badge ok" style="float:right">需求9</span></h3>
          <div class="setup-tip">字典、单号规则、数据级权限、自定义字段、提醒规则均可在线维护——改配置不必改代码、不必重新发版。</div>
          <div class="actions" style="margin-top:6px;">
            <button class="btn sm ghost" onclick="app.cfgDict()">数据字典</button>
            <button class="btn sm ghost" onclick="app.cfgSeq()">业务单号</button>
            <button class="btn sm ghost" onclick="app.cfgScope()">数据级权限</button>
            <button class="btn sm ghost" onclick="app.cfgAttr()">自定义字段</button>
            <button class="btn sm ghost" onclick="app.cfgRemind()">提醒规则</button>
            <button class="btn sm ghost" onclick="app.cfgTable()">表结构</button>
            <button class="btn sm ghost" onclick="app.cfgView()">视图格式</button>
          </div>
        </div>` : ''}
        <div class="card"><h3>拍照水印<span class="badge info" style="float:right">需求2</span></h3>
          <div class="setup-tip">现场拍照会同时归档「水印版」（共享可见）与「原始版」（仅本人可见，供事后核验原图）。水印为半透明浮层，不遮挡画面主体，位置与透明度可调。</div>
          <div class="muted" style="font-size:12px;margin-bottom:8px;">当前：${wmCfg().on ? '已开启' : '已关闭'} · ${esc(wmCfg().text)} · 位置 ${({ br: '右下', bl: '左下', tr: '右上', tl: '左上' })[wmCfg().pos] || '右下'} · 透明度 ${Math.round(wmCfg().opacity * 100)}% · 字号 ${wmCfg().size}px</div>
          <button class="btn ghost" onclick="app.wmSet()">设置水印内容与样式</button>
        </div>
        <div class="card"><h3>我的信息（只读）</h3>
          <div class="setup-info"><div class="si-k">姓名</div><div class="si-v">${esc(me.real_name || me.username)}</div></div>
          <div class="setup-info"><div class="si-k">工作证编号</div><div class="si-v">${esc(me.work_no || me.username)}</div></div>
          <div class="setup-info"><div class="si-k">部门</div><div class="si-v">${esc(me.dept_name || '未分配')}</div></div>
          <div class="setup-info"><div class="si-k">人员类型</div><div class="si-v">${esc(me.user_type_name || '')}</div></div>
          <div class="setup-tip" style="margin-top:10px;">个人信息不支持自行修改。信息如有误，请联系管理员（按 OIT 系统信息为准）修改，并可在下方反馈具体内容。</div>
        </div>
        <div class="card"><h3>手写签名 ${sig.valid ? '<span class="badge ok">有效</span>' : '<span class="badge bad">未授权/已过期</span>'}</h3>
          <div class="muted" style="margin-bottom:8px;">系统内所有需要签字的位置统一使用该手写签名；每季度核验一次，剩余 ${sig.days_left >= 0 ? sig.days_left : 0} 天。</div>
          ${sig.file_id ? '<div style="margin-bottom:8px;"><img class="sig-thumb" src="/api/files/' + sig.file_id + '/image?token=' + encodeURIComponent(TOKEN) + '"></div>' : ''}
          <div class="actions">
            <button class="btn sm" onclick="app.openSignPad()">${sig.valid ? '重新授权' : '去授权'}</button>
            <button class="btn sm ghost" onclick="app.verifySig()">立即季度核验</button>
          </div>
        </div>
        <div class="card"><h3>信息修改反馈</h3>
          <div class="field"><label>请说明需要修改的信息及修改后内容（提交后管理员处理）</label><textarea id="pf-content" rows="4" placeholder="例如：姓名由“张三”改为“张三丰”；手机号由138…改为139…"></textarea></div>
          <button class="btn block" onclick="app.submitFeedback()">提交给管理员</button>
        </div>
        ${isAdmin ? '<div class="card"><h3>用户修改反馈（管理员）</h3><div id="pf-list"></div></div>' : ''}
      `;
      if (isAdmin) {
        const list = await api('/api/profile-feedback');
        $('#pf-list').innerHTML = list.map((f) => `<div class="list-item" onclick="app.openFeedback('${f.id}', '${esc(f.user_name)}', '${esc(f.content)}', '${f.user_id !== undefined ? f.user_id : ''}')">
          <div class="body"><div class="t">${esc(f.user_name)}：${esc(f.content)}</div><div class="d">${f.created_at} · ${f.status === 'pending' ? '<span class="badge warn">待处理</span>' : '<span class="badge ok">已处理</span>'} · <span style="color:#1e88e5;">点击处理 ›</span></div></div></div>`).join('') || '<div class="empty">暂无反馈</div>';
      }
    } catch (e) { el.innerHTML = '<div class="empty">加载失败：' + esc(e.message) + '</div>'; }
  }
  /* v8.3 管理员打开反馈 → 直接定位修改 */
  async function openFeedback(id, userName, content, userId) {
    openSheet(`<div style="padding:18px 0 6px;"><div class="sheet-title">📨 用户修改反馈<span class="x" onclick="app.closeSheet()">✕</span></div>
      <div class="field"><label>用户</label><div style="font-size:14px;color:#333;">${esc(userName)}</div></div>
      <div class="field"><label>反馈内容</label><div style="font-size:14px;color:#333;white-space:pre-wrap;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:10px;">${esc(content)}</div></div>
      <div class="sheet-actions">
        ${userId ? '<button class="btn" onclick="app.closeSheet();switchPage(\'admin\');setTimeout(function(){app.editUser(' + userId + ')},300)">✏️ 去修改该用户资料</button>' : ''}
        <button class="btn ghost" onclick="app.markFeedbackDone(${id})">标记已处理</button>
        <button class="btn ghost" onclick="app.closeSheet()">关闭</button>
      </div></div>`);
  }
  async function markFeedbackDone(id) {
    try { await api('/api/profile-feedback/' + id, 'PUT', { status: 'done' }); closeSheet(); renderSetup(); v5toast('已标记处理'); } catch (e) { v5toast(e.message); }
  }
  async function submitFeedback() {
    const c = $('#pf-content');
    if (!c || !c.value.trim()) { v5toast('请填写需要修改的信息'); return; }
    try { await api('/api/profile-feedback', 'POST', { content: c.value.trim() }); c.value = ''; v5toast('已提交给管理员，请耐心等待处理'); } catch (e) { v5toast(e.message); }
  }

  /* 暴露 v5.0 全局函数 */
  window.app = Object.assign(window.app || {}, {
    saveDraftNow, loadDraftNow,
    openDraft: async (feature) => {
      try {
        const d = await api('/api/drafts/' + encodeURIComponent(feature));
        if (!d) { v5toast('草稿已不存在'); renderDraft(); return; }
        const page = draftPageOf(feature);
        openSheet(`
          <div class="sheet-title">草稿：${esc(feature)}<span class="x" onclick="app.closeSheet()">✕</span></div>
          ${draftFieldsHtml(d)}
          <div class="sheet-actions"><button class="btn ghost" onclick="app.delDraft('${esc(feature)}')">删除草稿</button><button class="btn" onclick="app.goFill('${page || 'draft'}','${esc(feature)}')">继续填写</button></div>`);
      } catch (e) { v5toast(e.message); }
    },
    goFill: (page, feature) => { closeSheet(); switchPage(page); v5toast('请在「' + feature + '」表单中点击「📥 恢复草稿」自动回填'); },
    delDraft: async (feature) => {
      if (!confirm('删除该草稿？')) return;
      try { await api('/api/drafts/' + encodeURIComponent(feature), 'DELETE'); closeSheet(); renderDraft(); refreshDraftBadge(); } catch (e) { v5toast(e.message); }
    },
    openSignPad, clearSign: () => { const cv = $('#sig-canvas'); if (cv && sigCtx) sigCtx.clearRect(0, 0, cv.width, cv.height); },
    saveSign, verifySig, submitFeedback
  });


  /* ===== v5.6 新增方法 ===== */
  window.app = Object.assign(window.app || {}, {

    doSearch: async () => {
      const el = document.getElementById('sq-result');
      const i = document.getElementById('sq');
      if (!el || !i) return;
      const q = i.value.trim();
      if (!q) return;
      el.innerHTML = '<div class="muted">检索中…</div>';
      try {
        const r = await api('/api/search?q=' + encodeURIComponent(q));
        window.__searchQ = q; window.__searchContent = (r.groups || []).map((g) => g.label + ' ' + g.items.length + ' 条').join('；') || (r.answer || r.report || '').slice(0, 200);
        let html = '';
        if (r.report) { window.__lastReport = r.report; html += `<div class="card" style="border-left:3px solid #8b5cf6;"><h3><svg class="lg-ic"><use href="#i-note"/></svg> 工作报告</h3><div class="d" style="white-space:pre-wrap;">${esc(r.report)}</div><div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;"><button class="btn" style="font-size:13px;padding:4px 12px;" onclick="app.copyReport(this)">复制报告</button><button class="btn" style="font-size:13px;padding:4px 12px;" onclick="app.actReport()">📌 加入我的待办</button></div></div>`; }
        if (r.answer) html += `<div class="card" style="border-left:3px solid #22c55e;"><h3><svg class="lg-ic"><use href="#i-ai"/></svg> 智能回答</h3><div class="d">${esc(r.answer)}</div></div>`;
        if (r.summary && r.summary !== r.answer) html += `<div class="card" style="border-left:3px solid #3b82f6;"><h3><svg class="lg-ic"><use href="#i-chart"/></svg> 统计摘要</h3><div class="d">${esc(r.summary)}</div></div>`;
        if (/建议/.test(q)) {
          try {
            const td = await api('/api/todos');
            if (td.advice && td.advice.length) html += `<div class="card" style="border-left:3px solid #f59e0b;"><h3><svg class="lg-ic"><use href="#i-dash"/></svg> 工作流建议</h3>${td.advice.map((a) => `<div class="d">${esc(a)}</div>`).join('')}</div>`;
          } catch (e2) {}
        }
        html += r.groups.map((g) => `<div class="card"><h3>${esc(g.label)}（${g.items.length}）</h3>
          ${g.items.map((it) => `<div class="list-item" style="cursor:pointer;" onclick="app.searchGo('${g.key}',${it.id})">
            <div class="body"><div class="t">${esc(it.title)}</div><div class="d">${esc(it.meta)}</div></div>
            <div class="act">${(g.key === 'issue' && it.can_notice) ? `<button class="btn sm ghost" onclick="event.stopPropagation();app.actRectify(${it.id})">📄 生成整改通知</button>` : ''}<span style="color:#9ca3af;">›</span></div></div>`).join('')}</div>`).join('');
        if (r.groups.length) html += `<div style="margin:8px 0;"><button class="btn" style="font-size:13px;padding:6px 14px;" onclick="app.actSearchTask()">📌 把本次检索结论加入我的待办</button></div>`;
        html += html ? '' : '<div class="empty">未找到相关内容，可换关键词或加时间词（如"上月""今年""近7天""6月"）重试</div>';
        if (r.time_range) html = `<div class="muted" style="font-size:12px;padding:0 6px 8px;">时间范围：${esc(r.time_range[0])} 至 ${esc(r.time_range[1])}</div>` + html;
        el.innerHTML = html;
      } catch (e) { el.innerHTML = '<div class="empty">检索失败：' + esc(e.message) + '</div>'; }
    },
    actConfirm: (title, fn) => {
      window.__actFn = fn;
      openSheet(`<div class="sheet-title">执行确认<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="d" style="margin:10px 0;">${esc(title)}</div>
        <div class="field"><label>完成期限（可选）</label><input type="date" id="act-due"></div>
        <div class="sheet-actions"><button class="btn" onclick="app.closeSheet()">取消</button><button class="btn primary" onclick="app.confirmAct()">确认执行</button></div>`);
    },
    confirmAct: () => { if (typeof window.__actFn === 'function') window.__actFn(); window.__actFn = null; },
    applyTask: async (title, content, due) => {
      try {
        const d = await api('/api/actions/apply', 'POST', { type: 'task', title, content, due_date: due || '' });
        app.closeSheet();
        alert('已加入我的待办（任务 ' + d.id + '），可在待办中心查看');
      } catch (e) { alert('执行失败：' + e.message); }
    },
    actReport: () => {
      const r = window.__lastReport || '';
      if (!r) { alert('请先生成工作报告'); return; }
      app.actConfirm('将工作报告保存为待办任务，之后可到待办中心打开查看。', () => {
        const due = (document.getElementById('act-due') || {}).value || '';
        app.applyTask('工作报告（' + new Date().toISOString().slice(0, 10) + '）', r, due);
      });
    },
    actRectify: (id) => {
      app.actConfirm('将对该问题生成整改通知（需班组长及以上签字签发，将跳转到检查模块完成签发）。', () => {
        api('/api/actions/apply', 'POST', { type: 'rectify', issue_id: id }).then((d) => {
          app.closeSheet();
          if (d.jump) { switchPage('check'); alert('已定位待整改问题，请在该问题详情中完成整改通知签发（需签字）。'); }
        }).catch((e) => { app.closeSheet(); alert('执行失败：' + e.message); });
      });
    },
    actSearchTask: () => {
      const q = window.__searchQ || '检索记录';
      app.actConfirm('把本次检索结论整理成待办任务（内容含检索结果概要）。', () => {
        const due = (document.getElementById('act-due') || {}).value || '';
        app.applyTask('检索记录：' + q.slice(0, 60), window.__searchContent || '', due);
      });
    },
    actAdvice: () => {
      app.actConfirm('把工作流建议整理为待办任务，之后可到待办中心逐条处理。', () => {
        const due = (document.getElementById('act-due') || {}).value || '';
        app.applyTask('工作流建议整理', '按建议逐项处理待办事项。', due);
      });
    },
    q: (t) => { const i = document.getElementById('sq'); if (i) i.value = t; app.doSearch(); },
    copyReport: (btn) => {
      const d = btn.parentElement.querySelector('.d');
      if (!d) return;
      const ta = document.createElement('textarea');
      ta.value = d.innerText; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch (e) {}
      document.body.removeChild(ta);
      btn.textContent = '已复制';
      setTimeout(() => { btn.textContent = '复制报告'; }, 1500);
    },
    searchGo: (kind, id) => {
      if (kind === 'person') { switchPage('contact'); return; }
      if (kind === 'file') { switchPage('file'); return; }
      if (kind === 'issue') { switchPage('check'); app.checkTab('issue'); return; }
      if (kind === 'leave') { switchPage('approval'); return; }
      const fnMap = { train: 'trainDetail', check: 'checkRecDetail', approval: 'apDetail' };
      const pageMap = { train: 'train', check: 'check', approval: 'approval', meeting: 'meeting', task: 'task', reward: 'reward', asset: 'asset', duty: 'duty' };
      switchPage(pageMap[kind] || 'more');
      if (fnMap[kind]) setTimeout(() => { try { app[fnMap[kind]](id); } catch (e) {} }, 300);
    },    todoGo: (kind, id) => {
      closeSheet();
      if (kind === 'approval') { switchPage('approval'); setTimeout(() => { try { app.apDetail(id); } catch (e) {} }, 300); }
      else if (kind === 'check') { switchPage('check'); setTimeout(() => { try { app.checkRecDetail(id); } catch (e) {} }, 300); }
      else if (kind === 'rectify') { switchPage('check'); app.checkTab('issue'); setTimeout(() => { try { app.checkIssueReport(id); } catch (e) {} }, 300); }
      else if (kind === 'accept') { switchPage('check'); app.checkTab('issue'); setTimeout(() => { try { app.checkIssueAccept(id); } catch (e) {} }, 300); }
      else if (kind === 'task') { switchPage('task'); }
    },
    fileSearch: () => renderFile(),
    fileClear: () => { const i = document.getElementById('file-q'); if (i) i.value = ''; renderFile(); },
    assetTab: (t) => { assetTab = t; renderAsset(); },
    assetAdd: () => openSheet(`<div class="sheet-title">新增台账<span class="x" onclick="app.closeSheet()">✕</span></div>
      <div class="field"><label>名称 *</label><input id="as-name"></div>
      <div class="field"><label>编号（如 XF-001）</label><input id="as-no"></div>
      <div class="field"><label>类别</label><select id="as-cat"><option>车辆</option><option>消防装备</option><option>设备</option></select></div>
      <div class="field"><label>型号/规格</label><input id="as-model"></div>
      <div class="field"><label>状态</label><select id="as-st"><option>在用</option><option>停用</option><option>维修中</option><option>报废</option></select></div>
      <div class="field"><label>责任人</label><input id="as-owner"></div>
      <div class="field"><label>购置日期</label><input id="as-pd" type="date"></div>
      <div class="field"><label>备注</label><input id="as-remark"></div>
      <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.assetAddSave()">保存</button></div>`),
    assetAddSave: async () => {
      const name = $('#as-name').value.trim();
      if (!name) return v5toast('名称必填');
      try { await api('/api/assets', 'POST', { no: $('#as-no').value.trim(), name, category: $('#as-cat').value, model: $('#as-model').value.trim(), status: $('#as-st').value, owner: $('#as-owner').value.trim(), purchase_date: $('#as-pd').value, remark: $('#as-remark').value.trim() }); closeSheet(); renderAsset(); } catch (e) { v5toast(e.message); }
    },
    assetEdit: (id) => {
      const a = window.__assets ? window.__assets.find(x => x.id === id) : null;
      const row = a || { name: '', no: '', category: '车辆', model: '', status: '在用', owner: '', purchase_date: '', remark: '' };
      openSheet(`<div class="sheet-title">编辑台账<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>名称</label><input id="as-name" value="${esc(row.name)}"></div>
        <div class="field"><label>编号</label><input id="as-no" value="${esc(row.no)}"></div>
        <div class="field"><label>类别</label><select id="as-cat"><option${row.category === '车辆' ? ' selected' : ''}>车辆</option><option${row.category === '消防装备' ? ' selected' : ''}>消防装备</option><option${row.category === '设备' ? ' selected' : ''}>设备</option></select></div>
        <div class="field"><label>型号</label><input id="as-model" value="${esc(row.model)}"></div>
        <div class="field"><label>状态</label><select id="as-st"><option${row.status === '在用' ? ' selected' : ''}>在用</option><option${row.status === '停用' ? ' selected' : ''}>停用</option><option${row.status === '维修中' ? ' selected' : ''}>维修中</option><option${row.status === '报废' ? ' selected' : ''}>报废</option></select></div>
        <div class="field"><label>责任人</label><input id="as-owner" value="${esc(row.owner)}"></div>
        <div class="field"><label>购置日期</label><input id="as-pd" type="date" value="${esc(row.purchase_date)}"></div>
        <div class="field"><label>备注</label><input id="as-remark" value="${esc(row.remark)}"></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.assetEditSave(${id})">保存</button></div>`);
    },
    assetEditSave: async (id) => {
      try { await api('/api/assets/' + id, 'PUT', { no: $('#as-no').value.trim(), name: $('#as-name').value.trim(), category: $('#as-cat').value, model: $('#as-model').value.trim(), status: $('#as-st').value, owner: $('#as-owner').value.trim(), purchase_date: $('#as-pd').value, remark: $('#as-remark').value.trim() }); closeSheet(); renderAsset(); } catch (e) { v5toast(e.message); }
    },
    assetDel: async (id) => {
      if (!confirm('确认删除该台账？此操作不可恢复')) return;
      try { await api('/api/assets/' + id, 'DELETE'); renderAsset(); } catch (e) { v5toast(e.message); }
    },
    assetCheckNew: () => {
      fetchAssetsForSheet('as2-aid');
      openSheet(`<div class="sheet-title">每日检查（早检查 10:00—10:30）<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>台账 *</label><select id="as2-aid"><option value="">加载中…</option></select></div>
        <div class="field"><label>检查日期</label><input id="as2-date" type="date" value="${todayStr()}"></div>
        <div class="field"><label>开始时间</label><input id="as2-st" type="time" value="10:00"></div>
        <div class="field"><label>结束时间</label><input id="as2-et" type="time" value="10:30"></div>
        <div class="field"><label>检查项</label><div id="as2-items">${VEHICLE_ITEMS.map((it, i) => `<div style="display:flex;align-items:center;gap:8px;padding:4px 0;font-size:13px;"><span style="flex:1;">${it}</span><select id="as2-it${i}" style="width:110px;"><option value="正常">正常</option><option value="异常">异常</option><option value="不适用">不适用</option></select></div>`).join('')}</div></div>
        <div class="field"><label>问题/说明</label><input id="as2-summary"></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.assetCheckSave()">保存</button></div>`);
    },
    assetCheckSave: async () => {
      const aid = ($('#as2-aid') || {}).value || window.__assetAid || '';
      if (!aid) return v5toast('请选择台账');
      const items = VEHICLE_ITEMS.map((it, i) => ({ item: it, pass: $('#as2-it' + i).value }));
      const hasBad = items.some(x => x.pass === '异常');
      try { await api('/api/asset-checks', 'POST', { asset_id: Number(aid), check_date: $('#as2-date').value, start_time: $('#as2-st').value, end_time: $('#as2-et').value, items, result: hasBad ? '异常' : '正常', summary: $('#as2-summary').value.trim() }); closeSheet(); renderAsset(); v5toast(hasBad ? '已保存：存在异常项，请安排维修' : '已保存：全部正常'); } catch (e) { v5toast(e.message); }
    },
    assetCheck: (id) => { const a = window.__assets ? window.__assets.find(x => x.id === id) : null; if (a) { window.__assetAid = id; openSheet(`<div class="sheet-title">对「${esc(a.name)}」每日检查<span class="x" onclick="app.closeSheet()">✕</span></div>
      <div class="field"><label>检查日期</label><input id="as2-date" type="date" value="${todayStr()}"></div>
      <div class="field"><label>开始时间</label><input id="as2-st" type="time" value="10:00"></div>
      <div class="field"><label>结束时间</label><input id="as2-et" type="time" value="10:30"></div>
      <div class="field"><label>检查项</label><div>${VEHICLE_ITEMS.map((it, i) => `<div style="display:flex;align-items:center;gap:8px;padding:4px 0;font-size:13px;"><span style="flex:1;">${it}</span><select id="as2-it${i}" style="width:110px;"><option value="正常">正常</option><option value="异常">异常</option><option value="不适用">不适用</option></select></div>`).join('')}</div></div>
      <div class="field"><label>问题/说明</label><input id="as2-summary"></div>
      <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.assetCheckSave()">保存</button></div>`); } },
    assetUse: (id) => { const a = window.__assets ? window.__assets.find(x => x.id === id) : null; if (a) openSheet(`<div class="sheet-title">对「${esc(a.name)}」登记使用<span class="x" onclick="app.closeSheet()">✕</span></div>
      <div class="field"><label>用途 *</label><input id="as3-purpose"></div>
      <div class="field"><label>开始时间</label><input id="as3-st" type="datetime-local" value="${new Date().toISOString().slice(0, 16).replace('T', ' ')}"></div>
      <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.assetUseSave(${id})">登记使用</button></div>`); },
    assetUseSave: async (id) => {
      const purpose = $('#as3-purpose').value.trim();
      if (!purpose) return v5toast('用途必填');
      try { await api('/api/asset-uses', 'POST', { asset_id: id, purpose, start_time: $('#as3-st').value }); closeSheet(); renderAsset(); v5toast('使用登记成功，用毕请及时归还'); } catch (e) { v5toast(e.message); }
    },
    assetReturn: async (id) => {
      if (!confirm('确认归还？')) return;
      try { await api('/api/asset-uses/' + id + '/return', 'POST', { end_time: new Date().toISOString().slice(0, 16).replace('T', ' ') }); renderAsset(); v5toast('已归还'); } catch (e) { v5toast(e.message); }
    },
    assetRepairNew: () => {
      fetchAssetsForSheet('as4-aid');
      openSheet(`<div class="sheet-title">报修<span class="x" onclick="app.closeSheet()">✕</span></div>
        <div class="field"><label>台账 *</label><select id="as4-aid"><option value="">加载中…</option></select></div>
        <div class="field"><label>维修内容 *</label><input id="as4-content"></div>
        <div class="field"><label>开始日期</label><input id="as4-sd" type="date" value="${todayStr()}"></div>
        <div class="sheet-actions"><button class="btn ghost" onclick="app.closeSheet()">取消</button><button class="btn" onclick="app.assetRepairSave()">报修</button></div>`);
    },
    assetRepairSave: async () => {
      const aid = $('#as4-aid').value, content = $('#as4-content').value.trim();
      if (!aid || !content) return v5toast('台账与维修内容必填');
      try { await api('/api/asset-repairs', 'POST', { asset_id: Number(aid), content, start_date: $('#as4-sd').value }); closeSheet(); renderAsset(); v5toast('已报修，台账状态更新为维修中'); } catch (e) { v5toast(e.message); }
    },
    assetRepairClose: async (id) => {
      if (!confirm('确认维修完工？完成后台账恢复为「在用」')) return;
      try { await api('/api/asset-repairs/' + id + '/close', 'POST', { end_date: todayStr() }); renderAsset(); } catch (e) { v5toast(e.message); }
    }
  });
  window.app = Object.assign(window.app || {}, {
    /* ---- v8.7 数桥管理 ---- */
    bridgeTab: (t) => { bridgeTab = t; app.bridgeLoad(); },
    bridgeLoad,
    bridgeAddField: async () => {
      try {
        const b = { biz_term: $('#sf-term').value.trim(), table_name: $('#sf-table').value.trim(), column_name: $('#sf-col').value.trim(), column_label: $('#sf-label').value.trim(), note: $('#sf-note').value.trim() };
        if (!b.biz_term || !b.table_name || !b.column_name) { v5toast('请填写业务词、表名、字段'); return; }
        await api('/api/bridge/fields', 'POST', b);
        v5toast('✅ 语义映射已添加'); app.bridgeLoad();
      } catch (e) { v5toast('添加失败：' + e.message); }
    },
    bridgeDelField: async (id) => {
      if (!confirm('确认删除该语义映射？')) return;
      try { await api('/api/bridge/fields/' + id, 'DELETE'); v5toast('已删除'); app.bridgeLoad(); } catch (e) { v5toast('删除失败：' + e.message); }
    },
    bridgeAddGrant: async () => {
      try {
        const b = { role: $('#gr-role').value, table_name: $('#gr-table').value, row_scope: $('#gr-scope').value };
        await api('/api/bridge/grants', 'POST', b);
        v5toast('✅ 授权已添加'); app.bridgeLoad();
      } catch (e) { v5toast('添加失败：' + e.message); }
    },
    bridgeDelGrant: async (id) => {
      if (!confirm('确认撤销该授权？')) return;
      try { await api('/api/bridge/grants/' + id, 'DELETE'); v5toast('已撤销'); app.bridgeLoad(); } catch (e) { v5toast('撤销失败：' + e.message); }
    },
    /* ---- v8.7 操作审计 ---- */
    oplogDays: (d) => { oplogDays = d; app.oplogSearch(); },
    oplogSearch,
    /* ---- v8.1 AI 对话助手（对标 Cordys WorkBuddy）---- */
    aiChatSend: async () => {
      const i = document.getElementById('ai-chat-q');
      if (!i) return;
      const q = i.value.trim();
      if (!q) return;
      const expert = window.aiExpert || 'general';
      aiChatLog.push({ me: true, t: q });
      i.value = '';
      app.aiChatRender();
      const box = document.getElementById('ai-chat');
      const bubble = document.createElement('div');
      bubble.style.cssText = 'margin:6px 0;text-align:left;';
      bubble.innerHTML = '<div style="display:inline-block;max-width:85%;padding:9px 12px;border-radius:12px;font-size:14px;background:#f3f4f6;color:#6b7280;">思考中…</div>';
      box.appendChild(bubble); box.scrollTop = box.scrollHeight;
      try {
        const r = await api('/api/ai/chat', 'POST', { message: q, expert });
        let extra = '';
        // v8.7 结构化增强：数据专家→数桥表格；制度专家→知识库出处卡片
        if (expert === 'data' && /数桥受控取数/.test(r.reply || '')) {
          try { const br = await api('/api/bridge/ask', 'POST', { message: q }); if (br && br.rows) extra = aiBridgeTable(br); } catch (e2) {}
        }
        if (expert === 'kb') {
          try { const kb = await api('/api/kb/ask', 'POST', { message: q }); if (kb && kb.hits) extra = aiKbHits(kb); } catch (e2) {}
        }
        aiChatLog.push({ me: false, t: r.reply || r, src: r.source, sensitive: r.sensitive, extra });
        // 若为录入意图，弹出确认表单
        if (/^录\s*(培训|检查)|录入/.test(q)) { app.aiParseBox(q); }
      } catch (e) { aiChatLog.push({ me: false, t: '连接失败：' + e.message }); }
      app.aiChatRender();
    },
    aiExpert: (k) => {
      window.aiExpert = k;
      switchPage('ai');
    },
    aiChatVoice: () => {
      const el = document.getElementById('ai-chat-q');
      if (el && window.SPEECH) window.SPEECH.start(el);
      else if (window.DeptBridge) window.DeptBridge.startSpeechInput('app._speechCb');
      else v5toast('当前浏览器不支持语音，请手动输入');
    },
    aiChatRender: () => {
      const el = document.getElementById('ai-chat');
      if (el) { el.innerHTML = aiChatLog.map((m) => aiChatBubble(m)).join(''); el.scrollTop = el.scrollHeight; }
    },
    /* ---- v8.1 智能录入：解析 + 确认 + 提交 ---- */
    aiParseBox: async (q) => {
      const box = document.getElementById('ai-parse');
      if (!box) return;
      box.innerHTML = '<div class="muted" style="font-size:13px;">🧾 正在解析录入内容…</div>';
      try {
        const r = await api('/api/ai/parse', 'POST', { text: q });
        const d = r.data || r;
        if (d.kind === 'training') {
          box.innerHTML = `<div class="card" style="border-left:3px solid #22c55e;background:#f7fdf9;"><h3 style="font-size:15px;">📝 确认培训录入</h3>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;font-size:14px;">
              <div>姓名<input id="ap-name" value="${esc(d.emp_name || '')}" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
              <div>类别<select id="ap-svc" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"><option ${d.train_service==='内培'?'selected':''}>内培</option><option ${d.train_service==='外培'?'selected':''}>外培</option></select></div>
              <div>课程<input id="ap-cls" value="${esc(d.class_info || '')}" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
              <div>日期<input id="ap-date" value="${esc(d.beg_date || '')}" type="date" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
              <div>学时<input id="ap-hours" value="${d.hours || ''}" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
              <div>成绩<input id="ap-grade" value="${esc(d.mark_grade || '')}" placeholder="可选" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
            </div>
            <div style="margin-top:10px;display:flex;gap:8px;"><button class="btn sm" onclick="app.aiApply('training')">✅ 确认保存</button><button class="btn sm ghost" onclick="document.getElementById('ai-parse').innerHTML=''">取消</button></div></div>`;
        } else if (d.kind === 'check') {
          box.innerHTML = `<div class="card" style="border-left:3px solid #f59e0b;background:#fffbef;"><h3 style="font-size:15px;">📝 确认检查录入</h3>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;font-size:14px;">
              <div>项目<input id="ac-project" value="${esc(d.project || '')}" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
              <div>区域<input id="ac-area" value="${esc(d.area || '')}" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
              <div>日期<input id="ac-date" value="${esc(d.check_date || '')}" type="date" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
              <div>结果<select id="ac-result" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"><option ${d.result==='合格'?'selected':''}>合格</option><option ${d.result==='不合格'?'selected':''}>不合格</option></select></div>
              <div style="grid-column:1/-1;">情况摘要<input id="ac-summary" value="${esc(d.summary || '')}" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
            </div>
            <div style="margin-top:10px;display:flex;gap:8px;"><button class="btn sm" onclick="app.aiApply('check')">✅ 确认保存</button><button class="btn sm ghost" onclick="document.getElementById('ai-parse').innerHTML=''">取消</button></div></div>`;
        } else {
          box.innerHTML = `<div class="card" style="border-left:3px solid #9ca3af;"><h3 style="font-size:15px;">🤔 未识别为培训/检查录入</h3><div class="d">试试：「录培训：张三 消防演练 2026-05-20 4学时」或「录检查：候机楼巡查 不合格」</div></div>`;
        }
      } catch (e) { box.innerHTML = '<div class="empty">解析失败：' + esc(e.message) + '</div>'; }
    },
    aiApply: async (kind) => {
      try {
        if (kind === 'training') {
          const data = { emp_name: $('#ap-name').value, train_service: $('#ap-svc').value, class_info: $('#ap-cls').value, beg_date: $('#ap-date').value, hours: $('#ap-hours').value, mark_grade: $('#ap-grade').value };
          const r = await api('/api/ai/apply', 'POST', { kind, data });
          v5toast('✅ 培训记录已保存');
        } else {
          const data = { project: $('#ac-project').value, area: $('#ac-area').value, check_date: $('#ac-date').value, result: $('#ac-result').value, summary: $('#ac-summary').value };
          const r = await api('/api/ai/apply', 'POST', { kind, data });
          v5toast('✅ 检查记录已保存');
        }
        document.getElementById('ai-parse').innerHTML = '';
        aiChatLog.push({ me: false, t: '已保存 ✓ 可在对应页面查看' });
        app.aiChatRender();
      } catch (e) { v5toast('保存失败：' + e.message); }
    },
    /* ---- v8.1 大模型配置（管理员）---- */
    /* [需求3] 大模型运行控制：总开关（仅管理员，需专属指令）+ 临时授权（年/月/日/小时）+ 暂停（整体/指定人）
       默认关闭；关闭后本页 AI 入口对普通用户隐藏，重登后须由管理员输指令再开。 */
    aiLoadSetup: async () => {
      const el = document.getElementById('ai-setup');
      if (!el) return;
      try {
        const [c, g] = await Promise.all([
          api('/api/ai/config').catch(() => ({})),
          api('/api/ai/grant').catch(() => ({ rows: [] }))
        ]);
        const rows = (g && g.rows) || [];
        const master = !!(g && g.master);
        el.innerHTML = `
          <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:10px;">
            <span class="badge ${master ? 'ok' : 'gray'}" style="font-size:13px;">总开关：${master ? '已开启' : '已关闭（默认）'}</span>
            <button class="btn sm ${master ? 'danger' : ''}" onclick="app.aiMasterToggle(${master ? 0 : 1})">${master ? '关闭大模型' : '开启大模型'}</button>
            <button class="btn sm ghost" onclick="app.aiPauseAll(1)">整体暂停</button>
            <button class="btn sm ghost" onclick="app.aiPauseAll(0)">恢复全部</button>
            <span class="muted" style="font-size:12px;">开启/关闭都要输入专属指令（首次开启即设置，≥6 位）</span>
          </div>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;font-size:14px;margin-bottom:8px;">
            <div>授权范围<select id="ai-g-scope" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"><option value="all">全员</option><option value="user">指定人员</option></select></div>
            <div>指定人员<input id="ai-g-user" placeholder="姓名或工号" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
            <div>时长<input id="ai-g-num" type="number" value="1" min="1" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
            <div>单位<select id="ai-g-unit" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"><option value="hour">小时</option><option value="day" selected>天</option><option value="month">月</option><option value="year">年</option></select></div>
          </div>
          <div style="margin-bottom:10px;"><button class="btn sm" onclick="app.aiGrantAdd()">＋ 发放临时授权</button>
            <span class="muted" style="font-size:12px;">到期自动失效；暂停只停服务不改到期时间。</span></div>
          <div class="muted" style="font-size:12px;margin-bottom:4px;">现有授权（${rows.length}）</div>
          ${rows.slice(0, 8).map((r) => `<div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px dashed #eee;font-size:13px;flex-wrap:wrap;">
            <span class="badge ${r.expired ? 'gray' : (r.paused ? 'warn' : 'ok')}" style="font-size:12px;">${r.expired ? '已过期' : (r.paused ? '已暂停' : '生效中')}</span>
            <span>${r.scope === 'all' ? '全员' : esc(r.user_name || ('用户' + r.user_id))} · ${r.unit === 'hour' ? '小时' : r.unit === 'day' ? '天' : r.unit === 'month' ? '月' : '年'}</span>
            <span class="muted">到期 ${r.expire_at ? new Date(Number(r.expire_at)).toLocaleString('zh-CN', { hour12: false }) : '—'}</span>
            <button class="btn sm ghost" onclick="app.aiPauseOne(${r.id}, ${r.paused ? 0 : 1})">${r.paused ? '恢复' : '暂停'}</button>
          </div>`).join('') || '<div class="muted" style="font-size:12px;">暂无授权记录</div>'}
          <hr style="border:none;border-top:1px solid #eee;margin:12px 0;">
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px;font-size:14px;">
            <div>API 地址<input id="ai-base" value="${esc((c || {}).base_url || '')}" placeholder="OpenAI 兼容地址" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
            <div>模型名<input id="ai-model" value="${esc((c || {}).model || '')}" placeholder="如 doubao-pro / gpt-4o-mini" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
            <div>API 密钥<input id="ai-key" value="" placeholder="${(c || {}).has_key ? '已配置（留空不修改）' : '填写 API Key'}" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
          </div>
          <div class="muted" style="font-size:12px;margin:12px 0 6px;">备用通道（主通道断流时自动接管，建议填商汤日日新等第二个厂商）</div>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px;font-size:14px;">
            <div>备用 API 地址<input id="ai-b-base" value="${esc((c || {}).backup_base_url || '')}" placeholder="商汤兼容端点 …/compatible-mode/v1" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
            <div>备用模型名<input id="ai-b-model" value="${esc((c || {}).backup_model || '')}" placeholder="如 sensenova-6.8-flash" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
            <div>备用 API 密钥<input id="ai-b-key" value="" placeholder="${(c || {}).has_backup_key ? '已配置（留空不修改）' : '填写备用 Key'}" style="width:100%;margin-top:3px;padding:6px;border:1px solid #d0d7de;border-radius:6px;"></div>
          </div>
          <div style="margin-top:10px;"><button class="btn sm" onclick="app.aiSaveSetup()">保存配置</button> <span class="muted" style="font-size:12px;">未配置时用内置本地引擎；主通道失败自动切备用通道。</span></div>`;
      } catch (e) { el.innerHTML = '<div class="empty">配置加载失败：' + esc(e.message) + '</div>'; }
    },
    aiMasterToggle: async (on) => {
      const pass = prompt(on ? '输入专属指令（首次开启即设置，≥6 位）' : '输入专属指令以关闭大模型');
      if (pass === null) return;
      try { const r = await api('/api/ai/master', 'POST', { on: !!on, pass }); v5toast(r.master ? '大模型已开启' : '大模型已关闭'); app.aiLoadSetup(); } catch (e) { v5toast(e.message); }
    },
    aiGrantAdd: async () => {
      const b = { scope: $('#ai-g-scope').value, unit: $('#ai-g-unit').value, note: '' };
      const n = Number($('#ai-g-num').value) || 1;
      if (b.scope === 'user') { const t = $('#ai-g-user').value.trim(); if (!t) return v5toast('请填写姓名或工号'); b.target = t; }
      // 后端按 1 个单位发放；需要多单位时把 note 写上便于追溯
      b.note = n + ' ' + b.unit;
      try { await api('/api/ai/grant', 'POST', b); v5toast('已发放授权（' + n + ' ' + b.unit + '）'); app.aiLoadSetup(); } catch (e) { v5toast(e.message); }
    },
    aiPauseAll: async (p) => { try { await api('/api/ai/grant/pause', 'POST', { paused: p }); v5toast(p ? '已整体暂停' : '已恢复全部'); app.aiLoadSetup(); } catch (e) { v5toast(e.message); } },
    aiPauseOne: async (id, p) => { try { await api('/api/ai/grant/pause', 'POST', { id, paused: p }); v5toast(p ? '已暂停该授权' : '已恢复该授权'); app.aiLoadSetup(); } catch (e) { v5toast(e.message); } },
    aiSaveSetup: async () => {
      try {
        const b = { base_url: $('#ai-base').value.trim(), model: $('#ai-model').value.trim() };
        const k = $('#ai-key').value.trim(); if (k) b.api_key = k;
        // [需求3] 备用通道一并保存（留空即不改）
        b.backup_base_url = $('#ai-b-base').value.trim();
        b.backup_model = $('#ai-b-model').value.trim();
        const bk = $('#ai-b-key').value.trim(); if (bk) b.backup_api_key = bk;
        await api('/api/ai/config', 'POST', b);
        v5toast('✅ AI 配置已保存');
      } catch (e) { v5toast('保存失败：' + e.message); }
    },
    /* ---- AI 问询 ---- */
    aiAsk: async () => {
      const i = document.getElementById('ai-q');
      const el = document.getElementById('ai-result');
      if (!i || !el) return;
      const q = i.value.trim();
      if (!q) return;
      el.innerHTML = '<div class="muted">🤖 分析中…（本地智能引擎，不依赖外部服务）</div>';
      try {
        const r = await api('/api/search?q=' + encodeURIComponent(q));
        const summary = (r.answer || r.report || (r.groups || []).map((g) => g.label + ' ' + g.items.length + ' 条').join('；')).slice(0, 200);
        try { await api('/api/ai/log', 'POST', { q: q.slice(0, 200), summary, kind: 'ask' }); } catch (e2) {}
        let html = '';
        if (r.report) { window.__lastReport = r.report; html += `<div class="card" style="border-left:3px solid #8b5cf6;"><h3><svg class="lg-ic"><use href="#i-note"/></svg> 工作报告</h3><div class="d" style="white-space:pre-wrap;">${esc(r.report)}</div><div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;"><button class="btn" style="font-size:13px;padding:4px 12px;" onclick="app.copyReport(this)">复制报告</button><button class="btn" style="font-size:13px;padding:4px 12px;" onclick="app.actReport()">📌 加入我的待办</button></div></div>`; }
        if (r.answer) html += `<div class="card" style="border-left:3px solid #22c55e;"><h3><svg class="lg-ic"><use href="#i-ai"/></svg> 智能回答</h3><div class="d">${esc(r.answer)}</div></div>`;
        if (r.summary && r.summary !== r.answer) html += `<div class="card" style="border-left:3px solid #3b82f6;"><h3><svg class="lg-ic"><use href="#i-chart"/></svg> 统计摘要</h3><div class="d">${esc(r.summary)}</div></div>`;
        html += (r.groups || []).map((g) => `<div class="card"><h3>${esc(g.label)}（${g.items.length}）<span class="more" onclick="app.aiGo('${g.key}')">去${esc(g.label)} ›</span></h3>
          ${g.items.map((it) => `<div class="list-item" style="cursor:pointer;" onclick="app.aiDetail('${g.key === 'person' ? 'user' : g.key}',${it.id})">
            <div class="body"><div class="t">${esc(it.title)}</div><div class="d">${esc(it.meta)}</div></div>
            <div class="act"><span style="color:#9ca3af;">›</span></div></div>`).join('')}</div>`).join('');
        if (r.actions && r.actions.length) html += `<div class="card" style="border-left:3px solid #f59e0b;"><h3><svg class="lg-ic"><use href="#i-gear"/></svg> 可执行动作（人确认后执行）</h3>${r.actions.map((a, idx) => `<div style="padding:4px 0;"><button class="btn sm ghost" onclick="app.aiRunAction(${idx},${JSON.stringify(a).replace(/"/g, '&quot;')})">${esc(a.label)}</button></div>`).join('')}</div>`;
        html += html ? '' : '<div class="empty">未找到相关内容，可换关键词或加时间词（如"上月""今年""近7天"）重试</div>';
        if (r.time_range) html = `<div class="muted" style="font-size:12px;padding:0 6px 8px;">时间范围：${esc(r.time_range[0])} 至 ${esc(r.time_range[1])}</div>` + html;
        el.innerHTML = html;
      } catch (e) { el.innerHTML = '<div class="empty">分析失败：' + esc(e.message) + '</div>'; }
    },
    aiQuick: (t) => { const i = document.getElementById('ai-q'); if (i) i.value = t; app.aiAsk(); },
    /* ---- 场景预警顾问 ---- */
    aiLoadAlerts: async () => {
      const el = document.getElementById('ai-alerts');
      if (!el) return;
      try {
        const { alerts } = await api('/api/ai/alerts');
        const lvColor = { high: '#e74c3c', mid: '#f59e0b', low: '#16a34a' };
        const lvTxt = { high: '高风险', mid: '关注', low: '提示' };
        el.innerHTML = alerts.length ? alerts.map((a) => `
          <div class="list-item" style="border-left:3px solid ${lvColor[a.level] || '#9ca3af'};${a.page ? 'cursor:pointer;' : ''}" ${a.page ? `onclick="app.aiAlertGo('${a.kind}',${a.id || 0},'${a.page}')"` : ''}>
            <div class="body">
              <div class="t">${esc(a.title)} <span class="badge" style="background:${lvColor[a.level] || '#9ca3af'};color:#fff;">${lvTxt[a.level] || ''}</span></div>
              <div class="d">${esc(a.detail)}</div>
              ${a.owner ? `<div class="d" style="color:#b45309;">👤 卡在：${esc(a.owner)}</div>` : ''}
            </div>
            ${a.action ? `<div class="act"><button class="btn sm ghost" onclick="event.stopPropagation();app.aiAlertAct('${a.action.type}','${a.kind}',${a.id || 0},'${esc(a.title).replace(/'/g, '')}')">${esc(a.action.label)}</button></div>` : ''}
          </div>`).join('') : '<div class="empty">暂无风险预警，各项业务均在受控状态 ✓</div>';
      } catch (e) { el.innerHTML = '<div class="empty">预警加载失败：' + esc(e.message) + '</div>'; }
    },
    aiAlertAct: async (act, kind, id, title) => {
      if (!confirm('【人审关口】确认执行：「' + title + '」\n' + (act === 'notify' ? '将生成催办通知并发送给责任人' : act === 'remind' ? '将向责任人发送催办消息' : '将生成跟进任务') + '？')) return;
      try {
        const r = await api('/api/ai/action', 'POST', { action: act, kind: kind || undefined, id: id || undefined, note: prompt('可填写备注（不超过200字）：', '') || '' });
        v5toast(r.done || '已执行');
        app.aiLoadAlerts();
        try { await api('/api/ai/log', 'POST', { q: '[动作] ' + title, summary: r.done || '', kind: 'action' }); } catch (e2) {}
      } catch (e) { v5toast(e.message); }
    },
    aiAlertGo: (kind, id, page) => { if (id && kind) app.aiDetail(kind, id); else switchPage(page); },
    aiGenTask: async (title, content) => {
      const due = prompt('任务期限（YYYY-MM-DD，留空不限）：', '');
      if (!confirm('确认生成任务「' + title + '」？')) return;
      try {
        const r = await api('/api/ai/action', 'POST', { action: 'task', title: title.slice(0, 80), note: content || '', due: due || '', assignee_id: 0 });
        v5toast(r.done || '已生成任务');
      } catch (e) { v5toast(e.message); }
    },
    aiRunAction: async (idx, aJson) => {
      let a = aJson;
      try { if (typeof a === 'string') a = JSON.parse(a); } catch (e) { return; }
      if (!a) return;
      if (a.type === 'task') { app.aiGenTask(a.title || 'AI 生成任务', a.content || ''); return; }
      if (a.type === 'rectify') {
        if (!confirm('确认生成整改通知：' + (a.label || '') + '？')) return;
        try { const r = await api('/api/ai/action', 'POST', { action: 'notify', kind: 'check_issue', id: a.issue_id, note: '' }); v5toast(r.done || '已发送整改通知'); app.aiLoadAlerts(); } catch (e) { v5toast(e.message); }
        return;
      }
      v5toast('该动作类型暂不支持，请在预警面板中操作');
    },
    /* ---- 聚合详情：点击条目查看完整情况与闭环状态 ---- */
    aiDetail: async (kind, id) => {
      try {
        const d = await api('/api/ai/detail?kind=' + encodeURIComponent(kind) + '&id=' + id);
        if (!d || !d.kind) return;
        const esc2 = (x) => esc(x || '—');
        let body = '';
        if (d.record) {
          const items = d.items || [];
          body = `<div class="field"><label>检查信息</label><div style="font-size:13px;line-height:1.8;">${esc2(d.record.check_type)} · ${esc2(d.record.check_date)} · ${esc2(d.record.area)}<br>检查人：${esc2(d.record.checker_name)} · 结果：${esc2(d.record.result)} · 状态：${esc2(d.record.status === 'approved' ? '已审核' : d.record.status)}</div></div>
            ${d.record.summary ? `<div class="field"><label>总结</label><div style="font-size:13px;">${esc2(d.record.summary)}</div></div>` : ''}
            ${items.length ? `<div class="field"><label>检查明细（${items.length}）</label><div style="font-size:13px;">${items.map((it, i) => `<div style="padding:3px 0;">${i + 1}. ${esc2(it.item || it.name)}：${esc2(it.pass || it.result)}${it.note ? '（' + esc2(it.note) + '）' : ''}</div>`).join('')}</div></div>` : ''}
            ${d.issues && d.issues.length ? `<div class="field"><label>发现问题与整改闭环（${d.issues.length}）</label>${d.issues.map((x) => `<div style="border-left:3px solid ${x.status === 'accepted' ? '#16a34a' : '#e74c3c'};padding:6px 8px;margin:4px 0;background:#f8fafc;font-size:13px;"><b>${esc2(x.content)}</b><br>位置：${esc2(x.location)} · 整改人：${esc2(x.assignee_name)} · 限期：${esc2(x.rectify_deadline)}<br>状态：${esc2(x.status)}${x.closed_at ? ' · 闭环时间：' + esc2(x.closed_at) : ''}</div>`).join('')}</div>` : ''}`;
        } else if (d.issue) {
          const x = d.issue;
          const statusTxt = { open: '待整改', submitted: '已提交整改', accepted: '已验收闭环' }[x.status] || x.status;
          body = `<div class="field"><label>整改问题</label><div style="font-size:14px;font-weight:600;">${esc2(x.content)}</div></div>
            <div class="field"><label>详情</label><div style="font-size:13px;line-height:1.8;">位置：${esc2(x.location)}<br>状态：${statusTxt}${x.notified_at ? ' · 已催办：' + esc2(x.notified_at) : ''}${x.notice_no ? ' · 通知编号：' + esc2(x.notice_no) : ''}<br>整改人：${esc2(x.assignee_name)} · 限期：${esc2(x.rectify_deadline)}${x.closed_at ? '<br>闭环时间：' + esc2(x.closed_at) : ''}</div></div>
            ${x.report_content ? `<div class="field"><label>整改报告</label><div style="font-size:13px;">${esc2(x.report_content)}</div></div>` : ''}
            ${d.record ? `<div class="field"><label>来源检查</label><div style="font-size:13px;">${esc2(d.record.check_type)} · ${esc2(d.record.check_date)} · ${esc2(d.record.area)}（检查人：${esc2(d.record.checker_name)}）</div></div>` : ''}`;
        } else if (d.task) {
          const t = d.task;
          body = `<div class="field"><label>任务</label><div style="font-size:14px;font-weight:600;">${esc2(t.title)}</div></div>
            <div class="field"><label>详情</label><div style="font-size:13px;line-height:1.8;">内容：${esc2(t.content)}<br>负责人：${esc2(t.assignee_name)} · 创建人：${esc2(t.creator_name)}<br>期限：${esc2(t.due_date)} · 优先级：${esc2(t.priority)}<br>状态：${esc2(t.status)}</div></div>`;
        } else if (d.train) {
          const t = d.train;
          body = `<div class="field"><label>培训记录</label><div style="font-size:14px;font-weight:600;">${esc2(t.title)}</div></div>
            <div class="field"><label>详情</label><div style="font-size:13px;line-height:1.8;">类别：${esc2(t.category)} · 日期：${esc2(t.train_date)} · 学时：${esc2(t.hours)}<br>教员：${esc2(t.trainer)}<br>内容：${esc2(t.content)}<br>参训：${esc2(t.participants)}</div></div>`;
        } else if (d.plan) {
          const t = d.plan;
          body = `<div class="field"><label>培训计划</label><div style="font-size:14px;font-weight:600;">${esc2(t.title)}</div></div>
            <div class="field"><label>详情</label><div style="font-size:13px;line-height:1.8;">类别：${esc2(t.category)} · 计划日期：${esc2(t.plan_date)} · 学时：${esc2(t.hours)}<br>对象：${esc2(t.target)} · 状态：${esc2(t.status)}</div></div>`;
        } else if (d.patrol) {
          const r = d.patrol;
          body = `<div class="field"><label>巡逻记录</label><div style="font-size:13px;line-height:1.8;">${esc2(r.patrol_date)} · ${esc2(r.area)} · ${esc2(r.start_time)}—${esc2(r.end_time)}<br>结果：${esc2(r.result)} · 状态：${esc2(r.status)}<br>巡逻人：${esc2(r.patroler_name)}${r.issues ? '<br>发现问题：' + esc2(r.issues) : ''}</div></div>`;
        } else if (d.repair) {
          const r = d.repair;
          body = `<div class="field"><label>维修记录</label><div style="font-size:13px;line-height:1.8;">设备：${esc2(d.asset ? d.asset.name : '')}${d.asset && d.asset.no ? '（' + esc2(d.asset.no) + '）' : ''}<br>内容：${esc2(r.content)}<br>开始：${esc2(r.start_date)} · 结束：${esc2(r.end_date)} · 状态：${esc2(r.status)}</div></div>`;
        } else if (d.approval) {
          const a = d.approval;
          body = `<div class="field"><label>审批</label><div style="font-size:14px;font-weight:600;">[${esc2(a.type)}] ${esc2(a.title)}</div></div>
            <div class="field"><label>详情</label><div style="font-size:13px;line-height:1.8;">申请人：${esc2(a.user_name)} · 状态：${esc2(a.status)} · 提交：${esc2(a.created_at)}<br>${a.approver_name ? '审批人：' + esc2(a.approver_name) + ' · 审批：' + esc2(a.approve_at) : ''}${a.approve_note ? '<br>意见：' + esc2(a.approve_note) : ''}</div></div>`;
        } else if (d.duty) {
          const r = d.duty;
          body = `<div class="field"><label>值班安排</label><div style="font-size:13px;line-height:1.8;">${esc2(r.day)} · ${esc2(r.user_name)}<br>岗位：${esc2(r.duty)}${r.shift ? ' · ' + esc2(r.shift) : ''}${r.phone ? '<br>电话：' + esc2(r.phone) : ''}</div></div>`;
        } else if (d.message) {
          const m = d.message;
          body = `<div class="field"><label>消息</label><div style="font-size:14px;font-weight:600;">${esc2(m.title)}</div></div>
            <div class="field"><label>内容</label><div style="font-size:13px;white-space:pre-wrap;">${esc2(m.content)}</div></div>
            <div class="field"><label>来源</label><div style="font-size:13px;">${esc2(m.sender_name)} · ${esc2(m.created_at)}</div></div>`;
        } else if (d.asset) {
          const a = d.asset;
          body = `<div class="field"><label>资产台账</label><div style="font-size:13px;line-height:1.8;">${esc2(a.name)}${a.no ? '（' + esc2(a.no) + '）' : ''}<br>类别：${esc2(a.category)} · 型号：${esc2(a.model)} · 状态：${esc2(a.status)}<br>负责人：${esc2(a.owner)} · 购置：${esc2(a.purchase_date)}${a.remark ? '<br>备注：' + esc2(a.remark) : ''}</div></div>
            ${d.repairs && d.repairs.length ? `<div class="field"><label>维修记录（${d.repairs.length}）</label>${d.repairs.map((r) => `<div style="font-size:13px;padding:3px 0;">${esc2(r.start_date)}：${esc2(r.content)}（${esc2(r.status)}）</div>`).join('')}</div>` : ''}`;
        }
        openSheet(`<div class="sheet-title">🔍 ${esc2(kind === 'check_issue' ? '整改详情' : kind === 'check_record' ? '检查详情' : kind === 'task' ? '任务详情' : kind === 'train' ? '培训详情' : kind === 'training_plan' ? '培训计划详情' : kind === 'patrol' ? '巡逻详情' : kind === 'asset_repair' ? '维修详情' : kind === 'approval' ? '审批详情' : kind === 'duty' ? '值班详情' : kind === 'message' ? '消息详情' : kind === 'asset' ? '资产详情' : '详情')}<span class="x" onclick="app.closeSheet()">✕</span></div>
          ${body || '<div class="empty">暂无详情</div>'}`);
      } catch (e) { v5toast('详情获取失败：' + e.message); }
    },
    aiGo: (key) => { const m = { person: 'contact', train: 'train', check: 'check', issue: 'check', approval: 'approval', meeting: 'meeting', task: 'task', reward: 'reward', file: 'file', leave: 'approval', asset: 'asset', duty: 'duty' }; if (m[key]) switchPage(m[key]); },
    /* ---- P0-3 打印模板：A4 打印当前页 + CSV 导出当前页 ---- */
    _pageName: () => {
      const names = { dash: '工作台', contact: '通讯录', approval: '审批', train: '培训', msg: '消息通知', file: '文件', more: '更多', attendance: '考勤打卡', task: '待办任务', hr: '人事管理', meeting: '会议纪要', audit: '审计整改', duty: '值班排班', form: '数据录入', admin: '系统管理', check: '检查管理', patrol: '巡逻上报', draft: '草稿箱', setup: '设置', backup: '数据备份', summary: '年度汇总', reward: '奖励处罚', import: '批量导入', archive: '我的档案', todo: '待办中心', asset: '车辆台账', search: '全局检索', ai: 'AI 工作台', recycle: '数据回收站', kb: '部门知识库', v6dash: '数据看板', autorules: '自动化规则', webhooks: 'Webhook 推送', importtpl: '通用导入' };
      return names[_curPage] || '部门综合管理系统';
    },
    printA4: (title) => {
      try {
        const cur = document.getElementById('page-' + (_curPage || 'dash'));
        if (!cur) { v5toast('未找到当前页面'); return; }
        const tbl = cur.querySelector('table');
        const bodyHtml = tbl ? tbl.outerHTML : (cur.innerHTML || '');
        if (!bodyHtml.replace(/<[^>]+>/g, '').trim()) { v5toast('当前页面暂无内容可打印'); return; }
        const today = new Date();
        const dstr = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-' + String(today.getDate()).padStart(2, '0');
        const t = title || app._pageName();
        const w = window.open('', '_blank', 'width=920,height=720');
        if (!w) { v5toast('浏览器拦截了打印窗口，请允许弹窗后重试'); return; }
        w.document.write('<!DOCTYPE html><html><head><meta charset="utf-8"><title>' + esc(t) + '</title>' +
          '<style>@page{size:A4;margin:18mm 15mm;}' +
          'body{font-family:"Microsoft YaHei",PingFang SC,sans-serif;color:#000;font-size:12px;margin:0;}' +
          'h1.title{text-align:center;font-size:20px;font-weight:700;margin:0 0 4px;}' +
          '.meta{text-align:center;font-size:12px;color:#444;margin-bottom:12px;}' +
          'table{width:100%;border-collapse:collapse;font-size:11px;word-break:break-all;}' +
          'th,td{border:1px solid #333;padding:4px 6px;text-align:left;}' +
          'th{background:#ececec;font-weight:700;}' +
          '.footer{margin-top:14px;text-align:center;font-size:11px;color:#666;}' +
          'img{max-width:100%;}</style></head><body>' +
          '<h1 class="title">' + esc(t) + '</h1>' +
          '<div class="meta">部门综合管理系统 · 打印日期：' + dstr + '</div>' +
          bodyHtml +
          '<div class="footer">— 打印自部门综合管理系统 · ' + dstr + ' —</div>' +
          '</body></html>');
        w.document.close();
        w.focus();
        setTimeout(function () { try { w.print(); } catch (e) { v5toast('打印触发失败，请在新窗口按 Ctrl+P 打印'); } }, 350);
      } catch (e) { v5toast('打印失败：' + e.message); }
    },
    exportCSV: (name) => {
      try {
        const cur = document.getElementById('page-' + (_curPage || 'dash'));
        if (!cur) { v5toast('未找到当前页面'); return; }
        const tbl = cur.querySelector('table');
        if (!tbl) { v5toast('当前页面没有可导出的表格（仅支持表格类页面）'); return; }
        const rows = Array.prototype.map.call(tbl.querySelectorAll('tr'), function (tr) {
          return Array.prototype.map.call(tr.querySelectorAll('th,td'), function (c) {
            let t = (c.innerText || '').replace(/\s+/g, ' ').trim();
            return '"' + t.replace(/"/g, '""') + '"';
          }).join(',');
        });
        if (!rows.length) { v5toast('当前表格无数据'); return; }
        const csv = '\ufeff' + rows.join('\r\n');
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
        a.download = (name || (_curPage || 'data')) + '.csv';
        document.body.appendChild(a); a.click(); a.remove();
        URL.revokeObjectURL(a.href);
        v5toast('已导出 CSV（可用 Excel 打开）');
      } catch (e) { v5toast('导出失败：' + e.message); }
    },
    /* ---- 问询留痕 ---- */
    aiLoadHistory: async () => {
      const el = document.getElementById('ai-history');
      if (!el) return;
      try {
        const rows = await api('/api/ai/logs');
        el.innerHTML = rows.length ? rows.map((r) => `<div class="list-item"><div class="body"><div class="t">${esc(r.kind === 'action' ? '⚙️ ' : '💬 ') + esc(r.q)}</div><div class="d">${esc(r.summary)}<br><span style="color:#9ca3af;font-size:11px;">${esc(r.user_name || '')} · ${esc(r.created_at)}</span></div></div></div>`).join('') : '<div class="empty">暂无问询记录，向 AI 提问后将在此留痕（谁问的、何时、问了什么、返回什么）</div>';
      } catch (e) { el.innerHTML = '<div class="empty">留痕加载失败</div>'; }
    }
  });


  async function fetchAssetsForSheet(selId) {
    try {
      const list = await api('/api/assets');
      window.__assets = list;
      const sel = document.getElementById(selId);
      if (sel) sel.innerHTML = list.map(a => '<option value="' + a.id + '">' + esc(a.name) + (a.no ? '（' + esc(a.no) + '）' : '') + '</option>').join('');
    } catch (e) {}
  }

  /* 暴露给 HTML onclick 使用的全局函数 */
  window.logout = logout;
  window.switchPage = switchPage;
})();
