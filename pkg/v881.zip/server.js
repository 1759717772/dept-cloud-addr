// 部门综合管理系统 v3.1 —— 自托管服务端
// 技术：Node.js 内置模块 + SQLite（零外部依赖）
// 数据全部存储在本机 data/ 目录（system.db + uploads/）
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');
const zlib = require('zlib');
const child_process = require('child_process');
// [需求9] 模块化拆分：通用工具（口令/模板/时间/授时/摘要/HTTP/脱敏/限流/缓存）已迁至 modules/util.js
// 纯函数、无 db 与业务闭包依赖，此处一次性解构，保持全文同名调用不变。
const UTIL = require('./modules/util');
const {
  hashPassword, fillTemplate, sha256hex, nowLocalStr,
  ntpTime, httpTime, syncServerTime, httpPostJson, dirSize,
  maskPhone2, maskIdCard2, maskField,
  rateLimit, cacheGet
} = UTIL;
const CACHE = UTIL.cacheStore; // 缓存存储对象（server.js 内个别位置需直读）
// ---- v7.9-cloud 运行台账（借鉴 cool-workflow workbench 黑匣子记录思想：每次关键动作留痕可审计）----
function addRun(kind, result, detail) {
  try { db.prepare("INSERT INTO system_runs (kind,result,detail) VALUES (?,?,?)").run(kind, result || 'ok', (detail || '').slice(0, 800)); } catch (e) {}
}

const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const AUDIO_DIR = path.join(DATA_DIR, 'audio');
const PDF_DIR = path.join(DATA_DIR, 'pdf');
const TMP_DIR = path.join(DATA_DIR, 'tmp');
const PUBLIC_DIR = path.join(ROOT, 'public');
const DB_FILE = path.join(DATA_DIR, 'system.db');
const PORT = parseInt(process.env.PORT || '8090', 10);
const MAX_UPLOAD = 20 * 1024 * 1024; // 20MB
const ASR_PY = '/home/user/.dept-asr'; // faster-whisper 本地离线转写（数据不出内网）

fs.mkdirSync(UPLOAD_DIR, { recursive: true });
fs.mkdirSync(AUDIO_DIR, { recursive: true });
fs.mkdirSync(PDF_DIR, { recursive: true });
fs.mkdirSync(TMP_DIR, { recursive: true });
fs.mkdirSync(PUBLIC_DIR, { recursive: true });

// WAL 定期 checkpoint：防止异常退出导致 WAL 帧未落盘（每 30 秒合并一次）
setInterval(() => { try { db.exec('PRAGMA wal_checkpoint(TRUNCATE)'); } catch (e) { /* 忽略瞬时锁冲突 */ } }, 30000).unref();

// ==================== 数据库初始化 ====================
let db = new DatabaseSync(DB_FILE);
// [需求9] 模块化拆分：数据库工具已迁到 core/db.js，此处仅装配
// [需求6] 表名白名单 safeT 在 core/db.js 内实现（启动时惰性读 sqlite_master）
const DBT = require('./core/db')({ getDb: () => db, DatabaseSync });
const { sqlTables, safeT, ensureColumn, refreshTables } = DBT;
db.exec("CREATE TABLE IF NOT EXISTS system_runs (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, ts TEXT DEFAULT (datetime('now','localtime')), result TEXT NOT NULL DEFAULT 'ok', detail TEXT DEFAULT '')");
// 连接健康自检：轻量探测，异常时自动重建（防止连接失效后持续报错；SQLite 单例长连接为最佳实践，无需按需开闭）
function dbHealthCheck() {
  try { db.prepare('SELECT 1').get(); return; }
  catch (e) {
    try { db.close(); } catch (e2) {}
    db = new DatabaseSync(DB_FILE);
    try { db.exec('PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 10000;'); } catch (e3) {}
    console.log('[健康检查] 数据库连接已重建');
  }
}
dbHealthCheck();
setInterval(dbHealthCheck, 300000).unref(); // 每 5 分钟探测一次
db.exec(`
PRAGMA journal_mode = WAL;
PRAGMA busy_timeout = 10000;
CREATE TABLE IF NOT EXISTS depts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  salt TEXT NOT NULL,
  real_name TEXT NOT NULL,
  dept_id INTEGER,
  role TEXT NOT NULL DEFAULT 'member',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS training_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS trainings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  trainer TEXT NOT NULL,
  train_date TEXT NOT NULL,
  hours REAL NOT NULL DEFAULT 0,
  content TEXT DEFAULT '',
  participants TEXT DEFAULT '',
  created_by INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS leave_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS leaves (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  type TEXT NOT NULL,
  start_time TEXT NOT NULL,
  end_time TEXT NOT NULL,
  reason TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending',
  approver_id INTEGER,
  approve_note TEXT DEFAULT '',
  approve_at TEXT,
  return_time TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  content TEXT DEFAULT '',
  sender_id INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS message_reads (
  message_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  read_at TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY (message_id, user_id)
);
CREATE TABLE IF NOT EXISTS signatures (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  file_id INTEGER,
  verified_at TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE(user_id)
);
CREATE TABLE IF NOT EXISTS drafts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  feature TEXT NOT NULL,
  payload_json TEXT DEFAULT '{}',
  updated_at TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE(user_id, feature)
);
CREATE TABLE IF NOT EXISTS device_info (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  ua TEXT DEFAULT '',
  screen TEXT DEFAULT '',
  dpr TEXT DEFAULT '',
  cores TEXT DEFAULT '',
  platform TEXT DEFAULT '',
  report_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS profile_feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  content TEXT NOT NULL,
  status TEXT DEFAULT 'pending',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  stored_name TEXT NOT NULL,
  size INTEGER NOT NULL DEFAULT 0,
  uploader_id INTEGER,
  share_flag INTEGER NOT NULL DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS forms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  fields_json TEXT NOT NULL DEFAULT '[]',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS form_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  form_id INTEGER NOT NULL,
  data_json TEXT NOT NULL,
  created_by INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- ===== v3.0 员工档案 =====
CREATE TABLE IF NOT EXISTS profiles (
  user_id INTEGER PRIMARY KEY,
  position TEXT DEFAULT '',
  phone TEXT DEFAULT '',
  hire_date TEXT DEFAULT '',
  id_number TEXT DEFAULT '',
  remark TEXT DEFAULT ''
);
-- ===== v3.0 通用审批流（请假/加班/公出/培训/物资/转正/调岗）=====
CREATE TABLE IF NOT EXISTS approvals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  form_json TEXT NOT NULL DEFAULT '{}',
  user_id INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  approver_id INTEGER,
  approve_note TEXT DEFAULT '',
  approve_at TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- ===== v3.0 培训计划 =====
CREATE TABLE IF NOT EXISTS training_plans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  plan_date TEXT,
  target TEXT DEFAULT '',
  hours REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'planned',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- ===== v3.0 培训签到 =====
CREATE TABLE IF NOT EXISTS training_signins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  training_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  signed_at TEXT DEFAULT (datetime('now','localtime')),
  UNIQUE(training_id, user_id)
);
-- ===== v3.0 培训考核成绩 =====
CREATE TABLE IF NOT EXISTS training_scores (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  training_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  score REAL,
  result TEXT DEFAULT '',
  note TEXT DEFAULT '',
  UNIQUE(training_id, user_id)
);
-- ===== v3.0 教员资质 =====
CREATE TABLE IF NOT EXISTS trainers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  category TEXT DEFAULT '',
  cert_no TEXT DEFAULT '',
  cert_date TEXT DEFAULT '',
  expire_date TEXT DEFAULT '',
  refresh_note TEXT DEFAULT '',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- ===== v3.0 考勤打卡 =====
CREATE TABLE IF NOT EXISTS attendance (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  day TEXT NOT NULL,
  check_in TEXT,
  check_out TEXT,
  UNIQUE(user_id, day)
);
-- ===== v3.0 待办任务 =====
CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  content TEXT DEFAULT '',
  assignee_id INTEGER,
  creator_id INTEGER,
  due_date TEXT,
  priority TEXT NOT NULL DEFAULT 'normal',
  status TEXT NOT NULL DEFAULT 'open',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- ===== v3.0 审计检查记录 =====
CREATE TABLE IF NOT EXISTS audit_checks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  check_date TEXT NOT NULL,
  project TEXT NOT NULL,
  area TEXT DEFAULT '',
  checker TEXT DEFAULT '',
  result TEXT NOT NULL DEFAULT 'normal',
  summary TEXT DEFAULT '',
  created_by INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- ===== v3.0 审计问题整改台账 =====
CREATE TABLE IF NOT EXISTS audit_issues (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  check_id INTEGER,
  problem TEXT NOT NULL,
  owner_id INTEGER,
  deadline TEXT,
  measure TEXT DEFAULT '',
  rectify_at TEXT,
  verify_result TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'open',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- ===== v3.0 值班排班 =====
CREATE TABLE IF NOT EXISTS duty_roster (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  day TEXT NOT NULL,
  shift TEXT DEFAULT '',
  user_name TEXT DEFAULT '',
  duty TEXT DEFAULT '',
  phone TEXT DEFAULT '',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- ===== v5.11 AI 智能体工作台：问询与动作留痕 =====
CREATE TABLE IF NOT EXISTS ai_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  q TEXT NOT NULL DEFAULT '',
  kind TEXT NOT NULL DEFAULT 'ask',
  summary TEXT NOT NULL DEFAULT '',
  deleted_at TEXT DEFAULT NULL,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- ===== v8.1 开放 API 网关：外部系统（OA/其他软件）直连密钥 =====
CREATE TABLE IF NOT EXISTS api_keys (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL DEFAULT '',
  key TEXT NOT NULL UNIQUE,
  scope TEXT NOT NULL DEFAULT 'read,write',
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- ===== v8.0 OIT 对标：培训记录（人×记录维度，对齐 OIT train_list：一条记录=一人一次培训）=====
CREATE TABLE IF NOT EXISTS train_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  emp_id TEXT NOT NULL DEFAULT '',
  emp_name TEXT NOT NULL DEFAULT '',
  train_service TEXT NOT NULL DEFAULT '内培',   -- 内培(内部培训)/外培(委外培训) 对齐 OIT train_service_type A/B
  train_type TEXT NOT NULL DEFAULT '',          -- 001非专业安保 002服务 004专项/季节 005岗前 006机坪安全运行
  train_method TEXT NOT NULL DEFAULT '',        -- A集中培训 B视频培训
  class_info TEXT NOT NULL DEFAULT '',          -- 课程名称
  beg_date TEXT NOT NULL DEFAULT '',
  end_date TEXT NOT NULL DEFAULT '',
  days REAL NOT NULL DEFAULT 0,
  hours REAL NOT NULL DEFAULT 0,
  fee REAL NOT NULL DEFAULT 0,
  mark_grade TEXT NOT NULL DEFAULT '',          -- 成绩/分项成绩（如 B6:88/C6.1:96）
  train_effect TEXT NOT NULL DEFAULT '',        -- 培训效果
  certificate_no TEXT NOT NULL DEFAULT '',      -- 证书编号
  lmt_service_date TEXT NOT NULL DEFAULT '',    -- 服务期至（外培常见）
  teacher_id INTEGER NOT NULL DEFAULT 0,
  teacher_name TEXT NOT NULL DEFAULT '',
  corp_organize TEXT NOT NULL DEFAULT '',       -- 组织单位
  corp_operate TEXT NOT NULL DEFAULT '',        -- 承办机构
  note_info TEXT NOT NULL DEFAULT '',
  create_date TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  create_user_id INTEGER NOT NULL DEFAULT 0,
  deleted_at TEXT
);
-- ===== v8.0 OIT 对标：教员库（对齐 OIT train_teacher）=====
CREATE TABLE IF NOT EXISTS train_teachers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  teacher_name TEXT NOT NULL,
  teacher_type TEXT NOT NULL DEFAULT '',
  is_outer TEXT NOT NULL DEFAULT 'N',   -- N内部教员 Y外聘教员
  skill_info TEXT NOT NULL DEFAULT '', -- 擅长领域
  corporate_name TEXT NOT NULL DEFAULT '',
  dept TEXT NOT NULL DEFAULT '',
  dept_post TEXT NOT NULL DEFAULT '',
  mobile_no TEXT NOT NULL DEFAULT '',
  culture_degree TEXT NOT NULL DEFAULT '',
  note_info TEXT NOT NULL DEFAULT '',
  create_date TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  deleted_at TEXT
);
-- ===== v8.0 OIT 对标：考核记录（对齐 OIT eas_add_up/eas_g_item 简化版）=====
CREATE TABLE IF NOT EXISTS assess_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  emp_id TEXT NOT NULL DEFAULT '',
  emp_name TEXT NOT NULL DEFAULT '',
  assess_name TEXT NOT NULL DEFAULT '',   -- 考核方案/批次
  item_name TEXT NOT NULL DEFAULT '',     -- 考核项目
  mark REAL NOT NULL DEFAULT 0,
  grade TEXT NOT NULL DEFAULT '',         -- 等级（OIT eas_assess_grade: 优秀/良好/合格/不合格）
  assessor_name TEXT NOT NULL DEFAULT '',
  assess_date TEXT NOT NULL DEFAULT '',
  note_info TEXT NOT NULL DEFAULT '',
  create_date TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  create_user_id INTEGER NOT NULL DEFAULT 0,
  deleted_at TEXT
);
-- ===== v8.2 OIT 员工档案子模块：卡证 / 异动 / 奖惩 =====
CREATE TABLE IF NOT EXISTS emp_cards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  emp_id TEXT NOT NULL DEFAULT '',
  card_no TEXT NOT NULL DEFAULT '',
  card_type TEXT NOT NULL DEFAULT '',
  granter TEXT NOT NULL DEFAULT '',
  grant_date TEXT NOT NULL DEFAULT '',
  invalid_date TEXT NOT NULL DEFAULT '',
  state TEXT NOT NULL DEFAULT '',
  note_info TEXT NOT NULL DEFAULT '',
  deleted_at TEXT
);
CREATE TABLE IF NOT EXISTS emp_moves (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  emp_id TEXT NOT NULL DEFAULT '',
  move_type TEXT NOT NULL DEFAULT '',
  move_date TEXT NOT NULL DEFAULT '',
  o_dept TEXT NOT NULL DEFAULT '',
  dept TEXT NOT NULL DEFAULT '',
  o_post TEXT NOT NULL DEFAULT '',
  dept_post TEXT NOT NULL DEFAULT '',
  note_info TEXT NOT NULL DEFAULT '',
  deleted_at TEXT
);
CREATE TABLE IF NOT EXISTS emp_rewards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  emp_id TEXT NOT NULL DEFAULT '',
  kind TEXT NOT NULL DEFAULT '',           -- 奖励 / 处分
  r_type TEXT NOT NULL DEFAULT '',
  r_date TEXT NOT NULL DEFAULT '',
  cause TEXT NOT NULL DEFAULT '',
  agree_emp TEXT NOT NULL DEFAULT '',
  amount REAL NOT NULL DEFAULT 0,
  note_info TEXT NOT NULL DEFAULT '',
  deleted_at TEXT
);
-- ===== v5.6 车辆/设备台账（依据运行手册第五章：每日早检查/周五车场日）=====
CREATE TABLE IF NOT EXISTS assets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  no TEXT DEFAULT '',
  name TEXT NOT NULL,
  category TEXT DEFAULT '车辆',
  model TEXT DEFAULT '',
  status TEXT DEFAULT '在用',
  owner TEXT DEFAULT '',
  purchase_date TEXT DEFAULT '',
  remark TEXT DEFAULT '',
  created_by INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS asset_checks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  asset_id INTEGER NOT NULL,
  check_date TEXT NOT NULL,
  start_time TEXT DEFAULT '',
  end_time TEXT DEFAULT '',
  items_json TEXT DEFAULT '[]',
  result TEXT DEFAULT '正常',
  summary TEXT DEFAULT '',
  checker_id INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS asset_uses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  asset_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  purpose TEXT DEFAULT '',
  start_time TEXT DEFAULT '',
  end_time TEXT DEFAULT '',
  status TEXT DEFAULT '使用中',
  approved_by INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS configs (k TEXT PRIMARY KEY, v TEXT);
-- ===== [需求9] 配置化底座：数据字典 / 自定义字段 / 业务单号 / 数据级权限 =====
-- 数据字典：把「请假类型、检查类型、资产类别」等枚举从代码里搬到库里，管理员可在线增删改
CREATE TABLE IF NOT EXISTS app_dict (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  dict_type TEXT NOT NULL, code TEXT NOT NULL, name TEXT NOT NULL,
  sort INTEGER DEFAULT 0, extra_json TEXT DEFAULT '{}', is_default INTEGER DEFAULT 0,
  deleted_at TEXT, created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- 自定义字段定义：给指定表挂扩展字段（不锁表结构，按 JSON 存值）
CREATE TABLE IF NOT EXISTS custom_attrs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  table_name TEXT NOT NULL, field_key TEXT NOT NULL, label TEXT NOT NULL,
  ftype TEXT NOT NULL DEFAULT 'text', options_json TEXT DEFAULT '[]', required INTEGER DEFAULT 0,
  sort INTEGER DEFAULT 0, deleted_at TEXT, created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS custom_values (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  table_name TEXT NOT NULL, row_id INTEGER NOT NULL, field_key TEXT NOT NULL,
  val TEXT DEFAULT '', updated_at TEXT DEFAULT (datetime('now','localtime'))
);
-- 业务单号：前缀 + 日期段 + 递增序号，按天/月/年归零
CREATE TABLE IF NOT EXISTS app_seq (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  seq_key TEXT NOT NULL UNIQUE, prefix TEXT NOT NULL, padding INTEGER DEFAULT 3,
  reset_period TEXT DEFAULT 'day', last_date TEXT DEFAULT '', next_no INTEGER DEFAULT 1
);
-- 数据级权限：某角色对某表只能看 全部/本部门/本人/不可见
CREATE TABLE IF NOT EXISTS data_scopes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  role TEXT NOT NULL, table_name TEXT NOT NULL, scope TEXT NOT NULL DEFAULT 'dept',
  note TEXT DEFAULT '', deleted_at TEXT
);
-- 提醒规则：某业务表某日期字段提前 N 天/小时提醒，走站内/钉钉/双通道
CREATE TABLE IF NOT EXISTS app_remind_def (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  rule_key TEXT NOT NULL, name TEXT NOT NULL, target_table TEXT NOT NULL, target_field TEXT NOT NULL,
  offset_value INTEGER DEFAULT 1, offset_unit TEXT DEFAULT 'day', channel TEXT DEFAULT 'both',
  enabled INTEGER DEFAULT 1, note TEXT DEFAULT '', deleted_at TEXT
);
-- 查询条件持久化：按用户+页面记住上次筛选条件
CREATE TABLE IF NOT EXISTS app_sql_cond (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL, page_key TEXT NOT NULL, cond_json TEXT DEFAULT '{}',
  updated_at TEXT DEFAULT (datetime('now','localtime'))
);
-- [需求3] 大模型临时授权：scope=all 全员 / user 指定人员；unit=hour|day|month|year，到期自动失效；paused=1 表示暂停服务（入口仍可见）
CREATE TABLE IF NOT EXISTS ai_grant (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  scope TEXT NOT NULL DEFAULT 'all',
  user_id INTEGER DEFAULT 0,
  unit TEXT DEFAULT 'day',
  expire_at INTEGER NOT NULL DEFAULT 0,
  paused INTEGER DEFAULT 0,
  note TEXT DEFAULT '',
  created_by INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  deleted_at TEXT
);
CREATE TABLE IF NOT EXISTS integrity_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, pkg TEXT, version_code INTEGER, sig_ok INTEGER DEFAULT 0, dex_hash TEXT, device_id TEXT, ip TEXT, created_at TEXT DEFAULT (datetime('now','localtime')));
CREATE TABLE IF NOT EXISTS asset_repairs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  asset_id INTEGER NOT NULL,
  content TEXT NOT NULL,
  start_date TEXT DEFAULT '',
  end_date TEXT DEFAULT '',
  status TEXT DEFAULT '维修中',
  reporter_id INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- ===== v3.1 人事管理：入职追踪 =====
CREATE TABLE IF NOT EXISTS onboardings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  work_no TEXT DEFAULT '',
  position TEXT DEFAULT '',
  dept TEXT DEFAULT '',
  entry_date TEXT,
  offer_status TEXT NOT NULL DEFAULT '待发送',
  bg_check TEXT NOT NULL DEFAULT '未开始',
  computer_ready INTEGER NOT NULL DEFAULT 0,
  account_ready INTEGER NOT NULL DEFAULT 0,
  train_ready INTEGER NOT NULL DEFAULT 0,
  note TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'onboarding',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- ===== v3.1 人事管理：离职追踪 =====
CREATE TABLE IF NOT EXISTS offboardings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  leave_date TEXT,
  handover_person TEXT DEFAULT '',
  doc_link TEXT DEFAULT '',
  project_handover INTEGER NOT NULL DEFAULT 0,
  permission_reclaim INTEGER NOT NULL DEFAULT 0,
  device_return INTEGER NOT NULL DEFAULT 0,
  social_insurance INTEGER NOT NULL DEFAULT 0,
  note TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'offboarding',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- ===== v6.1 招聘面试登记 =====
CREATE TABLE IF NOT EXISTS interviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  candidate TEXT NOT NULL,
  position TEXT DEFAULT '',
  dept TEXT DEFAULT '',
  interviewer TEXT DEFAULT '',
  interview_date TEXT,
  result TEXT NOT NULL DEFAULT '待面试',
  offer_status TEXT NOT NULL DEFAULT '未发送',
  note TEXT DEFAULT '',
  created_by INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  deleted_at TEXT
);
-- ===== v6.1 面试扫码表单默认字段（参照 OIT 人员档案字段；常量 DEFAULT_IV_FIELDS 见模块级代码） =====
-- ===== v3.1 会议纪要 =====
CREATE TABLE IF NOT EXISTS rewards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  type TEXT NOT NULL DEFAULT 'reward',
  title TEXT NOT NULL,
  reason TEXT DEFAULT '',
  rdate TEXT NOT NULL,
  created_by INTEGER,
  user_name TEXT DEFAULT '',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS meetings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  mtype TEXT NOT NULL DEFAULT '例会',
  meet_date TEXT,
  host TEXT DEFAULT '',
  attendees TEXT DEFAULT '',
  summary TEXT DEFAULT '',
  dissent TEXT DEFAULT '',
  next_time TEXT DEFAULT '',
  created_by INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- [需求10] 视频会议：参会人明细（按班组/个人/全员三种范围展开后落库）
CREATE TABLE IF NOT EXISTS meeting_attendees (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  meeting_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  dept_id INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- ===== v6.3 会议录音转文字（离线 ASR：ffmpeg + faster-whisper，数据不出内网）=====
CREATE TABLE IF NOT EXISTS audio (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT DEFAULT '',
  stored_name TEXT,
  size INTEGER DEFAULT 0,
  duration INTEGER DEFAULT 0,
  transcript TEXT DEFAULT '',
  summary TEXT DEFAULT '',
  actions TEXT DEFAULT '',
  status TEXT DEFAULT 'uploaded',
  error TEXT DEFAULT '',
  created_by INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  deleted_at TEXT
);
-- ===== v3.1 会议行动项（三要素：做什么/谁负责/截止日期）=====
CREATE TABLE IF NOT EXISTS meeting_actions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  meeting_id INTEGER NOT NULL,
  action TEXT NOT NULL,
  owner TEXT NOT NULL,
  due_date TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT '待开始',
  note TEXT DEFAULT '',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- ===== v7.9 MosMos 融合：专业术语纠错词库（语音转写本地纠错 + 管理员维护）=====
CREATE TABLE IF NOT EXISTS speech_glossary (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  term TEXT NOT NULL UNIQUE,     -- 正确专业术语
  alias TEXT NOT NULL,           -- 常见误识别/近音词（多个用 | 分隔）
  note TEXT DEFAULT '',          -- 说明
  kind TEXT DEFAULT '通用',       -- 分类：安保/消防/通用
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
INSERT OR IGNORE INTO speech_glossary (term, alias, note, kind) VALUES
 ('围界','威界|维界|为界|违规界','机场物理围界','安保'),
 ('道口','倒口','车辆人员通行道口','安保'),
 ('应急道口','应急岛口|应急倒口|应急道沟','应急疏散道口','安保'),
 ('FOD','佛得|福德|夫的|福的','外来物（Foreign Object Debris）','安保'),
 ('航空安保审计','航空安爆审计|航空安保申计|航空安保算计','航空安保审计','安保'),
 ('安保方案','安报方案|安保犯案|安保防范','航空安保方案','安保'),
 ('视频监看','视频监砍|视频间看|视频监坎','视频监控监看','安保'),
 ('隐蔽报警','隐必报警|引必报警|隐蔽暴警','隐蔽式报警装置','安保'),
 ('门禁','门进|闷禁','门禁系统','安保'),
 ('通行证','同行证|通形证','控制区通行证','安保'),
 ('控制区','控住区','机场控制区','安保'),
 ('隔离区','隔离机区|各离区|候机隔离区','候机隔离区','安保'),
 ('机坪','机平','机坪区域','安保'),
 ('停机坪','停机平|停机场','停机坪','安保'),
 ('远机位','远机尾|缘机位','远机位','安保'),
 ('廊桥','狼桥|郎桥','登机廊桥','安保'),
 ('消火栓','消防栓|小火栓|消火拴','消防给水设施','消防'),
 ('灭火器','灭火旗|面火器|灭活器','灭火器材','消防'),
 ('消防控制室','消防控制事|消防控制使|消控室','消防控制中心','消防'),
 ('空气呼吸器','空气呼吸机|空呼|呼吸机','正压式空气呼吸器','消防'),
 ('破拆','破柴|破彩','破拆救援','消防'),
 ('防火巡查','防滑巡查|防化巡查','防火巡查','消防'),
 ('疏散通道','书散通道|输散通道|疏散同道','疏散通道','消防'),
 ('应急演练','应及演练|应急言练|应急眼练','应急演练','消防'),
 ('值班','值办|职班','值班值守','通用'),
 ('台账','抬账|太账|台张','工作台账','通用'),
 ('检查单','检查蛋|检查担|检查弹','检查单','通用'),
 ('巡逻','寻逻|循逻','巡逻检查','安保'),
 ('监控室','监空室|监控事','视频监控室','安保'),
 ('报警','暴警','报警装置','安保'),
 ('外来物','外地物|外来务','FOD 外来物','安保'),
 ('巡检','寻检|巡捡','巡检','通用'),
 ('整改','整该|政改|整盖','整改落实','通用'),
 ('培训','陪训|培新','培训','通用'),
 ('复训','负训|复迅','复训','通用'),
 ('教员','教元|教援','教员资质','通用'),
 ('档案','当案','档案管理','通用'),
 ('审批','申批','审批流程','通用'),
 ('考勤','考琴|靠勤','考勤打卡','通用'),
 ('巡检记录','寻检记录|巡捡记录','巡检记录','安保'),
 ('应急设备','应及设备|应急社备','应急设备','消防'),
 ('消防通道','消防同道|防滑通道','消防通道','消防'),
 ('救援','就援|救源','应急救援','消防');
-- ===== v4.0 分级权限/多级审批/检查/巡逻 =====
CREATE TABLE IF NOT EXISTS user_grants (
  user_id INTEGER NOT NULL,
  feature TEXT NOT NULL,
  granted_at TEXT DEFAULT (datetime('now','localtime')),
  PRIMARY KEY (user_id, feature)
);
CREATE TABLE IF NOT EXISTS check_plans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  year INTEGER NOT NULL,
  name TEXT NOT NULL,
  check_type TEXT NOT NULL,
  cycle TEXT DEFAULT '',
  items_json TEXT NOT NULL DEFAULT '[]',
  owner_id INTEGER,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS checklists (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  items_json TEXT NOT NULL DEFAULT '[]',
  created_by INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS check_issues (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  check_record_id INTEGER NOT NULL,
  issue_type TEXT NOT NULL DEFAULT 'rectify',
  content TEXT NOT NULL,
  location TEXT DEFAULT '',
  assigned_to INTEGER,
  rectify_deadline TEXT,
  notice_no TEXT DEFAULT '',
  notice_signed_at TEXT,
  notified_at TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'open',
  report_content TEXT DEFAULT '',
  evidence_note TEXT DEFAULT '',
  accept_result TEXT DEFAULT '',
  accept_report_no TEXT DEFAULT '',
  accept_signed_at TEXT,
  closed_at TEXT,
  created_by INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS doc_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ttype TEXT NOT NULL UNIQUE,
  name TEXT DEFAULT '',
  content TEXT NOT NULL DEFAULT '',
  updated_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS check_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  plan_id INTEGER,
  check_type TEXT NOT NULL,
  check_date TEXT NOT NULL,
  area TEXT DEFAULT '',
  items_json TEXT NOT NULL DEFAULT '[]',
  result TEXT NOT NULL DEFAULT 'ok',
  summary TEXT DEFAULT '',
  checker_id INTEGER,
  status TEXT NOT NULL DEFAULT 'pending',
  chain_json TEXT NOT NULL DEFAULT '[]',
  level INTEGER NOT NULL DEFAULT 0,
  approver_id INTEGER,
  approve_note TEXT DEFAULT '',
  approve_at TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS patrols (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patrol_date TEXT NOT NULL,
  area TEXT NOT NULL,
  start_time TEXT,
  end_time TEXT,
  result TEXT NOT NULL DEFAULT 'ok',
  issues TEXT DEFAULT '',
  patroler_id INTEGER,
  status TEXT NOT NULL DEFAULT 'pending',
  chain_json TEXT NOT NULL DEFAULT '[]',
  level INTEGER NOT NULL DEFAULT 0,
  approver_id INTEGER,
  approve_note TEXT DEFAULT '',
  approve_at TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS kb_docs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  category TEXT DEFAULT '其他',
  file_path TEXT DEFAULT '',
  file_name TEXT DEFAULT '',
  file_size INTEGER DEFAULT 0,
  uploader_id INTEGER,
  ver INTEGER DEFAULT 1,
  scope TEXT DEFAULT 'dept',
  deleted_at TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS kb_versions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  doc_id INTEGER,
  file_path TEXT DEFAULT '',
  file_size INTEGER DEFAULT 0,
  ver INTEGER DEFAULT 1,
  uploader_id INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS auto_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  trigger_type TEXT NOT NULL,
  cond_json TEXT DEFAULT '{}',
  enabled INTEGER DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS webhooks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  url TEXT NOT NULL,
  events_json TEXT DEFAULT '[]',
  enabled INTEGER DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
-- ===== v8.7 OneBox 融合：数桥（受控取数）/ 知识库出处 / 操作审计 =====
CREATE TABLE IF NOT EXISTS kb_chunks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  doc_id INTEGER DEFAULT 0,
  title TEXT DEFAULT '',
  category TEXT DEFAULT '其他',
  chunk_text TEXT DEFAULT '',
  file_path TEXT DEFAULT '',
  file_name TEXT DEFAULT '',
  deleted_at TEXT,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS semantic_fields (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  biz_term TEXT NOT NULL,
  table_name TEXT NOT NULL,
  column_name TEXT DEFAULT '',
  column_label TEXT DEFAULT '',
  mask INTEGER DEFAULT 0,
  note TEXT DEFAULT '',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS data_grants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  role TEXT DEFAULT '',
  table_name TEXT NOT NULL,
  column_name TEXT DEFAULT '*',
  row_scope TEXT DEFAULT 'all',
  enabled INTEGER DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER DEFAULT 0,
  user_name TEXT DEFAULT '',
  action TEXT NOT NULL,
  target TEXT DEFAULT '',
  detail TEXT DEFAULT '',
  result TEXT DEFAULT 'ok',
  ip TEXT DEFAULT '',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);
`);

// v8.5.2 会话加固：sessions 表追加 device_id（设备绑定）+ expires_at（会话过期）——ALTER 幂等，兼容旧库
(function () {
  try {
    const _cols = db.prepare("SELECT * FROM sessions LIMIT 0").columns().map(function (c) { return c.name; });
    if (_cols.indexOf('device_id') < 0) { try { db.prepare("ALTER TABLE sessions ADD COLUMN device_id TEXT").run(); } catch (e) {} }
    if (_cols.indexOf('expires_at') < 0) { try { db.prepare("ALTER TABLE sessions ADD COLUMN expires_at INTEGER").run(); } catch (e) {} }
  } catch (e) {}
})();
// v8.7 兼容旧库：ai_logs 补充 deleted_at（用量统计过滤用）——ALTER 幂等
(function () {
  try {
    const _cols = db.prepare("SELECT * FROM ai_logs LIMIT 0").columns().map(function (c) { return c.name; });
    if (_cols.indexOf('deleted_at') < 0) { try { db.prepare("ALTER TABLE ai_logs ADD COLUMN deleted_at TEXT").run(); } catch (e) {} }
  } catch (e) {}
})();

// ===== v6.1 面试扫码表单默认字段（参照 OIT 人员档案字段，可经「招聘面试-表单设置」调整） =====
const DEFAULT_IV_FIELDS = [
  { key: 'candidate', label: '姓名', type: 'text', required: true },
  { key: 'position', label: '应聘岗位', type: 'text', required: true },
  { key: 'phone', label: '联系电话', type: 'text', required: true },
  { key: 'gender', label: '性别', type: 'select', options: ['男', '女'], required: false },
  { key: 'nation', label: '民族', type: 'text', required: false },
  { key: 'birth_date', label: '出生日期', type: 'date', required: false },
  { key: 'id_number', label: '身份证号', type: 'text', required: false },
  { key: 'political', label: '政治面貌', type: 'select', options: ['群众', '共青团员', '中共党员', '其他'], required: false },
  { key: 'education', label: '学历', type: 'select', options: ['高中及以下', '大专', '本科', '硕士及以上'], required: false },
  { key: 'school', label: '毕业院校/专业', type: 'text', required: false },
  { key: 'experience', label: '工作经历', type: 'textarea', required: false },
  { key: 'interview_date', label: '面试日期', type: 'date', required: false },
  { key: 'result', label: '面试结果', type: 'select', options: ['待面试', '通过', '淘汰', '待定'], required: false },
  { key: 'note', label: '备注', type: 'textarea', required: false }
];

// ---- 回收站（软删除）迁移：主要业务表增加 deleted_at ----
{
  const recycleTables = ['users','trainings','training_plans','trainers','check_records','check_issues','check_plans','checklists','assets','asset_repairs','approvals','leaves','patrols','tasks','meetings','meeting_actions','messages','rewards','duty_roster','onboardings','offboardings','interviews','audit_checks','audit_issues','asset_checks','asset_uses'];
  for (const t of recycleTables) ensureColumn(t, 'deleted_at', "TEXT");
  for (const t of recycleTables) db.exec(`UPDATE ${t} SET deleted_at=NULL WHERE deleted_at=''`);
}
// 回收站元数据：表名 → { 标题字段, 归属字段（用于过滤本人删除） }
const RECYCLE_META = {
  users: { label: '人员档案', title: 'real_name', who: 'id' },
  trainings: { label: '培训记录', title: 'title', who: 'id' },
  training_plans: { label: '培训计划', title: 'title', who: 'id' },
  trainers: { label: '教员档案', title: 'name', who: 'id' },
  check_records: { label: '检查记录', title: 'check_type', who: 'id' },
  check_issues: { label: '检查问题', title: 'content', who: 'id' },
  check_plans: { label: '检查计划', title: 'name', who: 'id' },
  checklists: { label: '检查单', title: 'name', who: 'id' },
  assets: { label: '资产台账', title: 'name', who: 'id' },
  approvals: { label: '审批单', title: 'title', who: 'user_id' },
  leaves: { label: '请假单', title: 'leave_type', who: 'user_id' },
  patrols: { label: '巡逻记录', title: 'result', who: 'patroler_id' },
  tasks: { label: '任务', title: 'title', who: 'id' },
  meetings: { label: '会议', title: 'title', who: 'id' },
  meeting_actions: { label: '会议事项', title: 'content', who: 'id' },
  messages: { label: '消息', title: 'title', who: 'id' },
  rewards: { label: '奖励记录', title: 'reason', who: 'id' },
  duty_roster: { label: '值班排班', title: 'day', who: 'id' },
  onboardings: { label: '入职登记', title: 'real_name', who: 'id' },
  offboardings: { label: '离职登记', title: 'real_name', who: 'id' },
  interviews: { label: '招聘面试', title: 'candidate', who: 'id' }
};
function softDel(table, id) {
  const t = safeT(table);   // [需求6] 表名白名单
  db.prepare(`UPDATE ${t} SET deleted_at=? WHERE id=?`).run(nowLocalStr(), Number(id));
}
function recycleCounts() {
  const out = [];
  for (const t of Object.keys(RECYCLE_META)) {
    const n = db.prepare(`SELECT COUNT(*) c FROM ${safeT(t)} WHERE deleted_at IS NOT NULL`).get().c;
    if (n > 0) out.push({ table: t, label: RECYCLE_META[t].label, count: n });
  }
  return out;
}

// ---- 人员档案字段迁移（幂等；与 OIT 系统人员档案对齐） ----
{
  const userCols2 = db.prepare('PRAGMA table_info(users)').all().map((c) => c.name);
  const addUC = (col, decl) => { if (!userCols2.includes(col)) db.exec('ALTER TABLE users ADD COLUMN ' + col + ' ' + decl); };
  addUC('gender', "TEXT DEFAULT ''");
  addUC('nation', "TEXT DEFAULT ''");
  addUC('birth_date', "TEXT DEFAULT ''");
  addUC('mobile', "TEXT DEFAULT ''");
  addUC('id_card', "TEXT DEFAULT ''");
  addUC('political_status', "TEXT DEFAULT ''");
  addUC('education', "TEXT DEFAULT ''");
  addUC('hire_date', "TEXT DEFAULT ''");
  addUC('job_title', "TEXT DEFAULT ''");
  addUC('photo', "TEXT DEFAULT ''");
}
const PORTRAIT_DIR = path.join(DATA_DIR, 'portraits');
fs.mkdirSync(PORTRAIT_DIR, { recursive: true });

// ---- v4.0 列迁移 ----
// ==================== [需求6] SQL 表名白名单（2026-11-10） ====================
// 现状复核：值全部走参数绑定、IN 子句用占位符，风险只剩"表名/列名拼接"。
// 这里在启动时从 sqlite_master 读真实表名作为白名单，任何拼进 FROM/UPDATE/DELETE 的表名都必须先过 safeT()，
// 未来若有人把外部入参接到表名，会在这里直接抛错而不是拼进 SQL。
// [需求10] 视频会议：预约时间、时长（0=不限）、参会范围（all/team/users）、指定人员、纪要开关（默认开）、录制文件
ensureColumn('meetings', 'meet_start', "TEXT DEFAULT ''");
ensureColumn('meetings', 'duration_min', 'INTEGER DEFAULT 0');
ensureColumn('meetings', 'scope', "TEXT DEFAULT 'all'");
ensureColumn('meetings', 'panel_json', "TEXT DEFAULT '[]'");
ensureColumn('meetings', 'recorder_on', 'INTEGER DEFAULT 1');
ensureColumn('meetings', 'video_url', "TEXT DEFAULT ''");
ensureColumn('meetings', 'status', "TEXT DEFAULT '待召开'");
ensureColumn('users', 'user_type', "TEXT NOT NULL DEFAULT 'zaizhi'");
ensureColumn('users', 'work_no', "TEXT DEFAULT ''");
ensureColumn('users', 'updated_at', "TEXT DEFAULT ''");
ensureColumn('users', 'deleted_at', "TEXT");
ensureColumn('users', 'contract_signed', 'INTEGER NOT NULL DEFAULT 0');
ensureColumn('users', 'contract_signed_at', 'TEXT');
ensureColumn('users', 'type_updated_at', 'TEXT');
ensureColumn('approvals', 'chain_json', "TEXT NOT NULL DEFAULT '[]'");
ensureColumn('approvals', 'level', 'INTEGER NOT NULL DEFAULT 0');
ensureColumn('leaves', 'chain_json', "TEXT NOT NULL DEFAULT '[]'");
ensureColumn('leaves', 'level', 'INTEGER NOT NULL DEFAULT 0');
ensureColumn('trainings', 'start_time', "TEXT DEFAULT ''");
ensureColumn('trainings', 'end_time', "TEXT DEFAULT ''");
ensureColumn('check_records', 'start_time', "TEXT DEFAULT ''");
ensureColumn('check_records', 'end_time', "TEXT DEFAULT ''");
ensureColumn('check_records', 'checklist_id', "INTEGER");
ensureColumn('check_records', 'checklist_name', "TEXT DEFAULT ''");
ensureColumn('check_records', 'start_loc', "TEXT DEFAULT ''");
ensureColumn('check_records', 'end_loc', "TEXT DEFAULT ''");
ensureColumn('check_records', 'photos_json', "TEXT DEFAULT '[]'");
ensureColumn('patrols', 'start_loc', "TEXT DEFAULT ''");
db.prepare("INSERT OR IGNORE INTO doc_templates (ttype,name,content) VALUES (?,?,?)").run('rectify_notice', '整改通知（默认模板，正式模板待提供）',
  '整改通知\n编号：{notice_no}\n\n{name}（{work_no}）：\n在{check_date}进行的{check_type}检查中，发现以下问题需限期整改：\n问题：{content}（位置：{location}）\n\n整改要求：请于 {deadline} 前完成整改，并提交整改措施报告及证明材料，由班组长验收合格后归档。\n\n签发：{signer}\n{sign_date}');
  // 内置三类安保设施检查单（依据云盘《石河子花园机场2026年度民用运输机场安保设施定期检测工作计划》）
  const defaultChecklists = [
    ['机场围界检查单', [['围界完整性', '围界连续无缺口、无破损；钢板网网片无变形、无锈蚀穿透、无脱落；砖围界无裂缝、无坍塌、无明显倾斜。'], ['围界高度', '围界高度符合设计要求（不低于2.5米）；顶部防攀爬设施完好有效。'], ['基础与稳定性', '围界基础无沉降、无松动；立柱垂直稳固；支撑构件无锈蚀、无断裂。'], ['围界出入口', '应急通道门、工作通道门锁具完好、关闭严密；门体无变形；标识标牌清晰完整。'], ['警示标识', '围界外侧警示标识齐全、清晰、无破损；"禁止攀爬""控制区"等标识设置规范。'], ['围界内侧净空', '围界内侧无堆积物、无辅助攀爬物；排水沟通畅，无淤堵导致基础浸泡。'], ['视频监控联动', '围界重点部位监控覆盖无盲区；摄像头与围界段对应关系准确。']]],
    ['视频监控系统检查单', [['设备在线状态', '全部监控设备在线运行；无离线、无死机、无频繁重启现象。'], ['图像质量', '视频图像清晰、无雪花、无模糊、无偏色、无严重抖动；分辨率和帧率符合设计要求；夜间红外或低照度成像有效。'], ['云台与镜头控制', '球机云台转动灵活、定位准确；变焦、聚焦功能正常；预置位调用准确。'], ['存储与回放', '录像存储时间满足规定要求（不少于90天）；回放流畅、无丢帧、无时间跳变；检索功能正常。'], ['覆盖范围', '围界、道口、候机隔离区、行李分拣区、停机坪、停车场等重点部位监控覆盖无盲区。'], ['系统平台', '监控管理平台运行稳定；用户权限管理规范；电子地图与实际点位一致；告警联动正常。'], ['网络与供电', '监控网络传输稳定；设备供电可靠；UPS后备电源功能正常。'], ['防雷与接地', '室外摄像头防雷器完好；接地电阻符合规范；设备箱体防水防尘。']]],
    ['门禁系统检查单', [['设备运行状态', '全部门禁控制器、读卡器、电锁、出门按钮在线运行；无故障报警、无离线。'], ['刷卡通行', '有效证件刷卡后门体正常开启；无效证件刷卡被拒绝并有提示；响应时间正常。'], ['权限管理', '门禁权限与持证人岗位、通行证权限一致；权限变更记录完整；离职调岗人员权限及时注销。'], ['防尾随功能', '防尾随措施有效；双人通行规则执行到位；异常通行有报警记录。'], ['异常报警', '门未关、强行闯入、胁迫报警功能正常；报警信息实时上传控制中心；记录可查询。'], ['应急开启', '火灾等紧急情况下门禁联动释放正常；手动应急开启按钮有效；应急开启有记录。'], ['记录与审计', '门禁通行记录完整保存（不少于90天）；记录含时间、地点、人员、事件类型；不可篡改。'], ['供电与网络', '门禁系统供电可靠；UPS后备电源正常；网络通信稳定；控制器脱机时可正常记录。']]]
  ];
  for (const [clName, items] of defaultChecklists) {
    if (!db.prepare('SELECT id FROM checklists WHERE name=?').get(clName)) {
      db.prepare('INSERT INTO checklists (name,items_json,created_by) VALUES (?,?,?)').run(clName, JSON.stringify(items.map(([item, std]) => ({ item, std }))), 1);
    }
  }
  // 默认培训分类（依据《消防护卫部运行手册》第九章：岗前/日常/复训/真火实训/消防宣教/外部培训）
  for (const tcat of ['岗前培训', '日常培训', '复训培训', '真火实训', '消防安全教育', '外部培训']) {
    if (!db.prepare('SELECT id FROM training_categories WHERE name=?').get(tcat)) {
      db.prepare('INSERT INTO training_categories (name) VALUES (?)').run(tcat);
    }
  }
db.prepare("INSERT OR IGNORE INTO doc_templates (ttype,name,content) VALUES (?,?,?)").run('accept_report', '验收合格报告（默认模板，正式模板待提供）',
  '验收合格报告\n编号：{report_no}\n\n整改问题：{content}（整改通知：{notice_no}）\n整改人：{name}（{work_no}）\n整改措施：{report_content}\n证明材料：{evidence_note}\n\n验收结论：经班组长现场验收，整改符合要求，验收合格。\n\n验收人：{acceptor}\n{accept_date}');
ensureColumn('patrols', 'end_loc', "TEXT DEFAULT ''");
db.exec("UPDATE users SET user_type='admin' WHERE role='admin' AND user_type='zaizhi'");

// 默认数据
function ensureDefaults() {
  // 迁移：messages 增加发送范围（群发/单发）
  const msgCols = db.prepare('PRAGMA table_info(messages)').all().map((c) => c.name);
  if (!msgCols.includes('send_type')) db.exec("ALTER TABLE messages ADD COLUMN send_type TEXT DEFAULT 'all'");
  if (!msgCols.includes('target_user_id')) db.exec('ALTER TABLE messages ADD COLUMN target_user_id INTEGER');
  if (!msgCols.includes('recalled')) db.exec("ALTER TABLE messages ADD COLUMN recalled INTEGER DEFAULT 0");
  const fCols = db.prepare('PRAGMA table_info(files)').all().map((c) => c.name);
  if (!fCols.includes('min_level')) db.exec('ALTER TABLE files ADD COLUMN min_level INTEGER DEFAULT 0');
  if (!fCols.includes('sign_file_id')) db.exec('ALTER TABLE files ADD COLUMN sign_file_id INTEGER');
  // v8.6.0 文件安全：仅在线阅读/禁止下载/水印防截/阅读需申请/下载需双班组长审批/指定可见名单
  if (!fCols.includes('no_download')) db.exec('ALTER TABLE files ADD COLUMN no_download INTEGER DEFAULT 0');
  if (!fCols.includes('readonly')) db.exec('ALTER TABLE files ADD COLUMN readonly INTEGER DEFAULT 0');
  if (!fCols.includes('watermark')) db.exec('ALTER TABLE files ADD COLUMN watermark INTEGER DEFAULT 0');
  if (!fCols.includes('read_apply')) db.exec('ALTER TABLE files ADD COLUMN read_apply INTEGER DEFAULT 0');
  if (!fCols.includes('download_apply')) db.exec('ALTER TABLE files ADD COLUMN download_apply INTEGER DEFAULT 0');
  if (!fCols.includes('visible_json')) db.exec("ALTER TABLE files ADD COLUMN visible_json TEXT DEFAULT ''");
  db.exec(`CREATE TABLE IF NOT EXISTS file_perm_reqs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    reason TEXT DEFAULT '',
    created_at TEXT DEFAULT (datetime('now','localtime')),
    updated_at TEXT DEFAULT (datetime('now','localtime')),
    UNIQUE(file_id, user_id, action)
  )`);
  db.exec(`CREATE TABLE IF NOT EXISTS file_perm_approvals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    req_id INTEGER NOT NULL,
    approver_id INTEGER NOT NULL,
    approve INTEGER NOT NULL DEFAULT 1,
    comment TEXT DEFAULT '',
    created_at TEXT DEFAULT (datetime('now','localtime')),
    UNIQUE(req_id, approver_id)
  )`);
  db.exec(`CREATE TABLE IF NOT EXISTS file_readmarks (
    user_id INTEGER NOT NULL,
    file_id INTEGER NOT NULL,
    page INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT DEFAULT (datetime('now','localtime')),
    PRIMARY KEY (user_id, file_id)
  )`);
  const acCols = db.prepare('PRAGMA table_info(meeting_actions)').all().map((c) => c.name);
  if (!acCols.includes('assignee_id')) db.exec('ALTER TABLE meeting_actions ADD COLUMN assignee_id INTEGER');
  const tkCols = db.prepare('PRAGMA table_info(tasks)').all().map((c) => c.name);
  if (!tkCols.includes('meeting_action_id')) db.exec('ALTER TABLE tasks ADD COLUMN meeting_action_id INTEGER');
  if (!tkCols.includes('source')) db.exec("ALTER TABLE tasks ADD COLUMN source TEXT DEFAULT 'manual'");
  const d = db.prepare('SELECT COUNT(*) AS c FROM users').get();
  if (d.c === 0) {
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.scryptSync('admin123', salt, 32).toString('hex');
    db.prepare('INSERT INTO users (username,password_hash,salt,real_name,role) VALUES (?,?,?,?,?)')
      .run('admin', hash, salt, '系统管理员', 'admin');
    db.prepare('INSERT INTO depts (name) VALUES (?)').run('综合办公室');
    db.prepare('INSERT INTO depts (name) VALUES (?)').run('消防护卫部');
  }
  const tc = db.prepare('SELECT COUNT(*) AS c FROM training_categories').get();
  if (tc.c === 0) {
    for (const n of ['安全教育', '服务培训', '非专业安保', '消防业务', '应急救援']) {
      db.prepare('INSERT INTO training_categories (name) VALUES (?)').run(n);
    }
  }
  const lt = db.prepare('SELECT COUNT(*) AS c FROM leave_types').get();
  if (lt.c === 0) {
    for (const n of ['事假', '病假', '年休假', '婚假', '产假', '丧假', '公出']) {
      db.prepare('INSERT INTO leave_types (name) VALUES (?)').run(n);
    }
  }
}
ensureDefaults();

db.exec(`
CREATE INDEX IF NOT EXISTS idx_users_name ON users(real_name);
CREATE INDEX IF NOT EXISTS idx_train_date ON trainings(train_date);
CREATE INDEX IF NOT EXISTS idx_train_title ON trainings(title);
CREATE INDEX IF NOT EXISTS idx_chk_date ON check_records(check_date);
CREATE INDEX IF NOT EXISTS idx_chk_type ON check_records(check_type);
CREATE INDEX IF NOT EXISTS idx_chk_status ON check_records(status);
CREATE INDEX IF NOT EXISTS idx_iss_status ON check_issues(status);
CREATE INDEX IF NOT EXISTS idx_iss_assign ON check_issues(assigned_to);
CREATE INDEX IF NOT EXISTS idx_iss_created ON check_issues(created_at);
CREATE INDEX IF NOT EXISTS idx_ap_user ON approvals(user_id);
CREATE INDEX IF NOT EXISTS idx_ap_status ON approvals(status);
CREATE INDEX IF NOT EXISTS idx_ap_created ON approvals(created_at);
CREATE INDEX IF NOT EXISTS idx_ap_title ON approvals(title);
CREATE INDEX IF NOT EXISTS idx_meet_date ON meetings(meet_date);
CREATE INDEX IF NOT EXISTS idx_meet_title ON meetings(title);
CREATE INDEX IF NOT EXISTS idx_task_assign ON tasks(assignee_id);
CREATE INDEX IF NOT EXISTS idx_files_name ON files(name);
CREATE INDEX IF NOT EXISTS idx_msg_title ON messages(title);
CREATE INDEX IF NOT EXISTS idx_duty_day ON duty_roster(day);
CREATE INDEX IF NOT EXISTS idx_leave_user ON leaves(user_id);
CREATE INDEX IF NOT EXISTS idx_leave_start ON leaves(start_time);
CREATE INDEX IF NOT EXISTS idx_asset_no ON assets(no);
CREATE INDEX IF NOT EXISTS idx_asset_name ON assets(name);
CREATE INDEX IF NOT EXISTS idx_iss_st_assign ON check_issues(status, assigned_to);
CREATE INDEX IF NOT EXISTS idx_ap_st_level ON approvals(status, level);
CREATE INDEX IF NOT EXISTS idx_chk_st_checker ON check_records(status, checker_id);
CREATE INDEX IF NOT EXISTS idx_plans_date ON training_plans(plan_date);
CREATE INDEX IF NOT EXISTS idx_att_date ON attendance(day);
CREATE INDEX IF NOT EXISTS idx_tr_emp ON train_records(emp_id);
CREATE INDEX IF NOT EXISTS idx_tr_service ON train_records(train_service);
CREATE INDEX IF NOT EXISTS idx_ar_emp ON assess_records(emp_id);
CREATE INDEX IF NOT EXISTS idx_empc_emp ON emp_cards(emp_id);
CREATE INDEX IF NOT EXISTS idx_empm_emp ON emp_moves(emp_id);
CREATE INDEX IF NOT EXISTS idx_empr_emp ON emp_rewards(emp_id);
`);

// ==================== 工具函数 ====================
// 上述 hashPassword/fillTemplate/nowLocalStr/ntpTime/httpTime/syncServerTime 已迁至 modules/util.js（[需求9]）
// 手写签名有效性：季度（90天）内有效
const SIGNATURE_QUARTER_DAYS = 90;
function getSignature(u) {
  return db.prepare('SELECT * FROM signatures WHERE user_id=?').get(u.id);
}
function signatureValid(u) {
  const s = getSignature(u);
  if (!s || !s.file_id || !s.verified_at) return false;
  const v = new Date(s.verified_at.replace(' ', 'T'));
  return (Date.now() - v.getTime()) / 86400000 < SIGNATURE_QUARTER_DAYS;
}
function requireSig(u, res, scene) {
  if (!signatureValid(u)) { fail(res, 403, '该操作需要手写签名：请先在「设置-手写签名」完成签名授权（每季度核验一次）' + (scene ? '（' + scene + '）' : '')); return false; }
  return true;
}
// 保存签名图（base64→文件→files 表），返回 file_id
function saveSignFile(u, b, label) {
  const buf = Buffer.from(b.data, 'base64');
  if (buf.length > 2 * 1024 * 1024) return { err: '签名图片过大（限2MB）' };
  const stored = 'sig_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex') + '.png';
  fs.writeFileSync(path.join(UPLOAD_DIR, stored), buf);
  // [需求3] 签名图单独存放：归入「签名档案」分类(folder_id='_sig')，与普通共享文件隔离，
  // 避免签名被当成普通资料被检索/批量移动/误删
  const ins = db.prepare('INSERT INTO files (name,stored_name,size,uploader_id,share_flag,folder_id) VALUES (?,?,?,?,?,?)')
    .run(label, stored, buf.length, u.id, 0, '_sig');
  return { file_id: Number(ins.lastInsertRowid) };
}

// [需求9] 模块化拆分：响应与请求体工具已迁到 core/responder.js，此处仅装配
const { json, ok, fail, readBody } = require('./core/responder')({
  getIdemMap: () => idemMap,
  maxUpload: MAX_UPLOAD
});

// ==================== v6.3 离线语音转写（ffmpeg + faster-whisper，数据不出内网）====================
const OFFICE_EXT = ['.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.txt', '.md', '.csv'];
const IMG_EXT = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'];
const AUDIO_EXT = ['.wav', '.mp3', '.m4a', '.aac', '.ogg', '.webm', '.amr'];
function runCmd(cmd, args, opts) {
  return new Promise((resolve, reject) => {
    const { execFile } = require('child_process');
    const p = execFile(cmd, args, { timeout: 15 * 60 * 1000, maxBuffer: 64 * 1024 * 1024, ...(opts || {}) }, (e, so, se) => e ? reject(e) : resolve(so));
  });
}
// 转写执行：stored 音频 → 16k wav → whisper → {text, duration}
async function transcribeFile(stored, srcPath) {
  const wav = path.join(TMP_DIR, stored.replace(/\.[^.]+$/, '') + '.wav');
  await runCmd('ffmpeg', ['-y', '-i', srcPath, '-ar', '16000', '-ac', '1', '-f', 'wav', wav]);
  const py = `
import sys, json
sys.path.insert(0, '/home/user/.dept-asr')
try:
    from faster_whisper import WhisperModel
    m = WhisperModel('small', device='cpu', compute_type='int8')
    segs, info = m.transcribe(r"""${wav}""", language='zh', beam_size=5)
    text = ''.join(s.text for s in segs).strip()
    print(json.dumps({'ok': True, 'text': text, 'duration': round(info.duration, 1)}))
except Exception as e:
    print(json.dumps({'ok': False, 'error': str(e)}))
`;
  const out = await runCmd('python3', ['-c', py]);
  const last = out.trim().split('\n').pop();
  try { return JSON.parse(last); } catch (e) { return { ok: false, error: '转写结果解析失败: ' + String(out).slice(0, 200) }; }
}
// 本地纪要生成（关键词规则，不依赖外部大模型）：分句 → 议题/要点/待办
function genMinutes(text) {
  const sents = String(text || '').split(/[。！？!?\n]+/).map((s) => s.trim()).filter((s) => s.length > 1);
  const KEY = /(议题|会议主题|本次会议|会议内容|首先|接着|然后|部署|安排|要求|强调|决定|明确|讨论|汇报)/;
  const TODO = /(要|需|请|务必|尽快|负责|牵头|完成|落实|于.*前|月底前|下周|三天内|一周内)/;
  const summary = [];
  const actions = [];
  let cur = '';
  for (const s of sents) {
    if (s.length > 24 || KEY.test(s)) {
      if (cur) { if (TODO.test(cur)) actions.push(cur); else if (cur.length > 8) summary.push(cur); }
      cur = s;
    } else {
      cur = cur ? cur + '；' + s : s;
    }
  }
  if (cur) { if (TODO.test(cur)) actions.push(cur); else if (cur.length > 8) summary.push(cur); }
  return { summary: summary.slice(0, 12).join('\n'), actions: actions.slice(0, 12).join('\n') };
}
// 后台转写队列：上传后异步转写，不阻塞主进程
const audioQueue = [];
let audioBusy = false;
async function pumpAudioQueue() {
  if (audioBusy || !audioQueue.length) return;
  audioBusy = true;
  const job = audioQueue.shift();
  try {
    db.prepare("UPDATE audio SET status='transcribing' WHERE id=?").run(job.id);
    const src = path.join(AUDIO_DIR, job.stored);
    if (!fs.existsSync(src)) throw new Error('音频文件缺失');
    const r = await transcribeFile(job.stored, src);
    if (r.ok) {
      const min = genMinutes(r.text);
      db.prepare('UPDATE audio SET transcript=?, summary=?, actions=?, duration=?, status=?, error=? WHERE id=?')
        .run(r.text || '', min.summary, min.actions, Math.round(r.duration || 0), 'done', '', job.id);
    } else {
      db.prepare("UPDATE audio SET status='failed', error=? WHERE id=?").run(String(r.error || '转写失败'), job.id);
    }
  } catch (e) {
    db.prepare("UPDATE audio SET status='failed', error=? WHERE id=?").run(String(e.message || '转写失败'), job.id);
  } finally { audioBusy = false; pumpAudioQueue(); }
}
// ==================== v6.3 文件转 PDF（soffice 矢量转换 + tesseract OCR 双层扫描件）====================
async function convertToPdf(name, srcPath) {
  const ext = path.extname(name).toLowerCase();
  const outBase = path.join(PDF_DIR, Date.now() + '_' + crypto.randomBytes(4).toString('hex'));
  const hasBin = (b) => { try { return require('child_process').spawnSync(process.platform === 'win32' ? 'where' : 'which', [b]).status === 0; } catch { return false; } };
  if (OFFICE_EXT.includes(ext)) {
    if (!hasBin('soffice')) throw new Error('办公电脑服务器未安装 LibreOffice 转换组件，Office 转 PDF 不可用；可连接云端服务器转换（云端已内置），或在本机安装 LibreOffice 后重试');
    // Office/文本 → LibreOffice 矢量 PDF（文字可选中编辑、高保真）
    const r = await runCmd('soffice', ['--headless', '--convert-to', 'pdf', '--outdir', outBase + '_o', srcPath]);
    const pdfs = fs.readdirSync(outBase + '_o').filter((f) => f.toLowerCase().endsWith('.pdf'));
    if (!pdfs.length) throw new Error('文档转换失败');
    const dst = outBase + '.pdf';
    fs.renameSync(path.join(outBase + '_o', pdfs[0]), dst);
    return { dst, mode: '矢量可编辑（LibreOffice 转换）' };
  }
  if (IMG_EXT.includes(ext)) {
    // 图片 → 高精度双层扫描件：tesseract 生成"图像+隐藏文字层"可搜索 PDF
    if (!hasBin('tesseract')) throw new Error('办公电脑服务器未安装 OCR 组件（tesseract），图片转 PDF 不可用；可连接云端服务器转换');
    let png = srcPath;
    if (!ext.endsWith('.png')) {
      png = outBase + '.png';
      await runCmd('ffmpeg', ['-y', '-i', srcPath, '-f', 'png', png]);
    }
    const dst = outBase + '.pdf';
    const r = await runCmd('tesseract', [png, dst.replace(/\.pdf$/, ''), '-l', 'chi_sim+eng', 'pdf']);
    if (!fs.existsSync(dst)) throw new Error('OCR 转换失败');
    return { dst, mode: '高精度扫描件 + OCR 文字层（可搜索/可编辑）' };
  }
  throw new Error('该类型暂不支持转 PDF');
}
// 转换进度占位（同步执行，前端 loading 处理）

// v8.5.2 会话加固：鉴权失败原因（expired 默认 / device 设备不匹配），供 401 响应头区分提示
// [需求9] 模块化拆分：会话鉴权已迁到 core/authz.js，此处仅装配
const AZ = require('./core/authz')({ getDb: () => db, fail: (res, code, msg) => fail(res, code, msg) });
const { authUser, requireAuth } = AZ;
function isAdmin(u) { return typeLevel(u) >= 4; } // 运维工程师/管理员均视为系统管理权限（与前端「系统管理」页门槛一致）
function isApprover(u) { return u.role === 'admin' || u.role === 'leader'; }

// ==================== v4.0 人员类型与分级权限 ====================
const TYPE_LEVEL = { xinren: 0, zaizhi: 1, banzuzhang: 2, bumenlingdao: 3, weihu: 4, admin: 5 };
const TYPE_NAMES = { xinren: '新人', zaizhi: '在职人员', banzuzhang: '班组长', bumenlingdao: '部门领导', weihu: '运维工程师', admin: '管理员' };
const LEVEL_NAMES = { 0: '新人', 1: '在职人员', 2: '班组长', 3: '部门领导', 4: '运维工程师', 5: '管理员' };
function utype(u) { return u.user_type || (u.role === 'admin' ? 'admin' : 'zaizhi'); }
function typeLevel(u) { return TYPE_LEVEL[utype(u)] !== undefined ? TYPE_LEVEL[utype(u)] : 1; }
function requireLevel(u, min, res) {
  if (typeLevel(u) < min) { fail(res, 403, '权限不足：当前身份（' + TYPE_NAMES[utype(u)] + '）无权执行该操作'); return false; }
  return true;
}
// v8.5.1 AI 助手权限隔离：仅管理员/运维工程师（typeLevel>=4）可见可用，其他任何人员不可见也无法调用
function isAIUser(u) { return !!u && typeLevel(u) >= 4; }
// 新人的可读白名单操作：仅查看类接口放行，写操作按功能申请（grants）控制
function checkWritePerm(u, method, path, feature) {
  if (typeLevel(u) >= 1) return true;                     // 在职及以上放行
  // 新人：GET 查看放行；写操作必须有对应功能授权
  if (method === 'GET') return true;
  if (feature === 'attendance' && path.startsWith('/api/attendance')) return true; // 打卡为工作必需默认开通
  if (feature) {
    const g = db.prepare('SELECT 1 FROM user_grants WHERE user_id=? AND feature=?').get(u.id, feature);
    if (g) return true;
    return false; // 调用方输出 403 提示
  }
  return false;
}
function defaultChain(type) {
  const t = String(type || '');
  if (/请假|休假|年休|病假|事假|产假/.test(t)) return [2, 3];
  if (/培训|学习/.test(t)) return [2, 3];
  if (/加班|公出|出差/.test(t)) return [2, 3];
  if (/巡逻/.test(t)) return [2, 3];
  if (/检查/.test(t)) return [2, 3];
  if (/调岗|调动/.test(t)) return [2, 3];
  if (/物资|采购|领用/.test(t)) return [2, 3];
  if (/功能申请|权限申请/.test(t)) return [3];
  return [3]; // 转正等其他申请默认部门领导终审
}
function chainLabels(chainJson) {
  try { return (JSON.parse(chainJson || '[]')).map((l) => LEVEL_NAMES[l] || ('级别' + l)); } catch (e) { return []; }
}
// 通用多级审批流转：approve 通过后 level+1，到达链尾则完成
function approveFlow(db, table, id, rec, b, u, res) {
  const chain = (() => { try { return JSON.parse(rec.chain_json || '[]'); } catch (e) { return []; } })();
  const need = chain[rec.level];
  if (need === undefined) { fail(res, 400, '审批链配置异常'); return false; }
  if (typeLevel(u) < need) { fail(res, 403, '当前环节需「' + LEVEL_NAMES[need] + '」审批，您无权限'); return false; }
  const finished = rec.level + 1 >= chain.length;
  const status = finished ? 'completed' : 'pending';
  const nLevel = finished ? rec.level : rec.level + 1;
  db.prepare('UPDATE ' + table + ' SET status=?, level=?, approver_id=?, approve_note=?, approve_at=? WHERE id=?')
    .run(status, nLevel, u.id, b.note || '', nowLocalStr(), id);
  return true;
}
function rejectFlow(db, table, id, u, b) {
  db.prepare('UPDATE ' + table + " SET status='rejected', approver_id=?, approve_note=?, approve_at=? WHERE id=?")
    .run(u.id, b.note || '', nowLocalStr(), id);
}
// 新人 15 天自动升级：签合同后 15 天未人工调整，自动提升为在职人员
function autoUpgradeNewbies() {
  const rows = db.prepare("SELECT id, contract_signed, contract_signed_at FROM users WHERE user_type='xinren' AND contract_signed=1 AND contract_signed_at IS NOT NULL").all();
  const now = new Date();
  for (const r of rows) {
    const signed = new Date(r.contract_signed_at);
    const days = (now - signed) / 86400000;
    if (days >= 15) {
      db.prepare("UPDATE users SET user_type='zaizhi', type_updated_at=? WHERE id=?").run(nowLocalStr(), r.id);
    }
  }
}

// ==================== 静态文件 ====================
function serveStatic(req, res, urlPath) {
  let p = path.normalize(path.join(PUBLIC_DIR, decodeURIComponent(urlPath)));
  if (!p.startsWith(PUBLIC_DIR)) { fail(res, 403, '禁止访问'); return; }
  if (p === PUBLIC_DIR || fs.existsSync(p) && fs.statSync(p).isDirectory()) p = path.join(p, 'index.html');
  if (!fs.existsSync(p)) { fail(res, 404, '页面不存在'); return; }
  const ext = path.extname(p).toLowerCase();
  const mime = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'text/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon'
  };
  const body = fs.readFileSync(p);
  // 前端静态资源每次重新验证（升级后即时生效，避免旧版缓存）
  res.writeHead(200, { 'Content-Type': mime[ext] || 'application/octet-stream', 'Content-Length': body.length, 'Cache-Control': 'no-cache' });
  res.end(body);
}

// ==================== v6.1 增强：错误告警 / 限流 / 幂等 ====================
// 说明：员工编号以 OIT 系统工作证编号为准（登录名=工作证编号），不做自动编号生成
// 结构化错误告警：写入 console.error（可观测性，供日志采集/告警接入）
function errorLog(ctx, err) {
  try {
    console.error('[ERR ' + nowLocalStr() + '] ' + (ctx || 'route') + ' :: ' + (err && err.message ? err.message : String(err)));
  } catch (e2) { /* 告警通道本身异常不扩散 */ }
}
// 限流 rateLimit 已迁至 modules/util.js（[需求9]，模块内持有滑动窗口状态）
// 写接口幂等：X-Idempotency-Key 去重（60 秒内相同键的重复请求直接返回首次结果，不重复执行）
const idemMap = new Map(); // key -> { body, exp }
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of idemMap) if (v.exp < now) idemMap.delete(k);
}, 60000).unref();

// ==================== 路由 ====================
// 轻量缓存 cacheGet 已迁至 modules/util.js；此处 CACHE 为 UTIL.cacheStore 引用（[需求9]）

// 备份管理已整体迁至 modules/backup.js（含 3 槽轮转、定时器与 /api/backup/* 路由，[需求9]）
// ==================== 模块级：事件推送 / 自动化规则引擎 / 后台扫描（v6.1 从请求回调内移出，确保定时器稳定运行） ====================
// 事件推送：fireWebhooks(event, payload) —— 异步调用配置的 URL（不回阻塞业务）
function fireWebhooks(event, payload) {
  try {
    const list = db.prepare('SELECT * FROM webhooks WHERE enabled=1').all();
    for (const w of list) {
      const evs = JSON.parse(w.events_json || '[]');
      if (evs.length && !evs.includes(event)) continue;
      fetch(w.url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ event, ts: nowLocalStr(), payload }), timeout: 5000 }).catch(() => {});
    }
  } catch (e) { /* 推送失败不影响业务 */ }
}
// 自动化规则执行引擎
function runAutoRules(trigger, ctx) {
  let fired = 0;
  try {
    const rules = db.prepare('SELECT * FROM auto_rules WHERE enabled=1 AND trigger_type=?').all(trigger);
    for (const r of rules) {
      if (trigger === 'issue_created') {
        // 检查隐患自动生成整改通知 + 通知责任人（班组长）
        const issue = ctx.issue;
        if (issue && issue.id) {
          const assignee = db.prepare('SELECT * FROM users WHERE id=?').get(issue.assigned_to || 0);
          if (assignee) {
            db.prepare("INSERT INTO messages (title, content, sender_id, send_type, target_user_id) VALUES (?,?,?,?,?)").run('自动整改任务：' + (issue.content || '').slice(0, 30), '系统已按规则将检查问题「' + (issue.content || '') + '」自动生成整改任务，请按期整改并在检查-问题中提交整改情况。', null, 'single', assignee.id);
          }
          fireWebhooks('issue_created', { id: issue.id, content: issue.content });
          fired++;
        }
      } else if (trigger === 'issue_overdue') {
        const issue = ctx.issue;
        const assignee = db.prepare('SELECT * FROM users WHERE id=?').get(issue.assigned_to || 0);
        if (assignee) {
          db.prepare("INSERT INTO messages (title, content, sender_id, send_type, target_user_id) VALUES (?,?,?,?,?)").run('整改超期升级：' + (issue.content || '').slice(0, 30), '整改任务已超期，请立即处理，超期将影响班组考核。', null, 'single', assignee.id);
          db.prepare("INSERT INTO messages (title, content, sender_id, send_type) VALUES (?,?,?,?)").run('整改超期告警：' + (issue.content || '').slice(0, 30), '存在超期未闭环整改任务，请管理员关注。', null, 'all');
        }
        fireWebhooks('issue_overdue', { id: issue.id, content: issue.content });
        fired++;
      } else if (trigger === 'training_soon') {
        const t = ctx.plan;
        db.prepare("INSERT INTO messages (title, content, sender_id, send_type) VALUES (?,?,?,?)").run('培训临期提醒：' + (t.name || t.title || ''), '培训计划将于 ' + t.plan_date + ' 开展，请提前组织准备。', null, 'all');
        fired++;
      } else if (trigger === 'contract_overdue') {
        const nu = ctx.user || {};
        if (nu.id) {
          db.prepare("INSERT INTO messages (title, content, sender_id, send_type) VALUES (?,?,?,?)").run('劳动合同签约超期升级：' + (nu.real_name || nu.work_no || nu.id), '该新人劳动合同签约超期仍未处理，请管理员跟进。', null, 'all');
          fired++;
        }
      }
    }
  } catch (e) { /* 规则执行异常不阻断 */ }
  return fired;
}
// 后台扫描（每分钟）：整改超期升级 + 新人 30 天签约预警 + 回收站 30 天自动清理
setInterval(() => {
  try {
    const today = new Date().toISOString().slice(0, 10);
    const overdue = db.prepare("SELECT * FROM check_issues WHERE deleted_at IS NULL AND status NOT IN ('closed','accepted') AND rectify_deadline IS NOT NULL AND rectify_deadline != '' AND rectify_deadline < ?").all(today);
    for (const iss of overdue) {
      const key = 'overdue_' + iss.id;
      const cfg = db.prepare('SELECT v FROM configs WHERE k=?').get(key);
      if (cfg) continue; // 已提醒过
      db.prepare('INSERT INTO configs (k,v) VALUES (?,?)').run(key, nowLocalStr());
      runAutoRules('issue_overdue', { issue: iss });
    }
    // v6.1 新人 30 天未签劳动合同 → 预警（每人一次，通知管理员 + 自动化规则）
    const cut30 = new Date(Date.now() - 30 * 86400000);
    const cut30Str = String(cut30.getFullYear()) + '-' + String(cut30.getMonth() + 1).padStart(2, '0') + '-' + String(cut30.getDate()).padStart(2, '0');
    const c30rows = db.prepare("SELECT id, real_name, work_no, created_at FROM users WHERE user_type='xinren' AND contract_signed=0 AND deleted_at IS NULL AND created_at != '' AND created_at < ?").all(cut30Str + ' 23:59:59');
    for (const nu of c30rows) {
      const ck = 'contract30_' + nu.id;
      if (db.prepare('SELECT v FROM configs WHERE k=?').get(ck)) continue; // 已提醒
      db.prepare('INSERT INTO configs (k,v) VALUES (?,?)').run(ck, nowLocalStr());
      db.prepare("INSERT INTO messages (title, content, sender_id, send_type) VALUES (?,?,?,?)")
        .run('劳动合同签约超期提醒', '新人 ' + (nu.real_name || nu.work_no || nu.id) + ' 入职已满 30 天仍未签订劳动合同（《劳动合同法》规定自用工之日起超过一个月不满一年未订立书面合同的，应向劳动者每月支付二倍工资）。请尽快完成签约确认。', null, 'all');
      runAutoRules('contract_overdue', { user: nu });
    }
    // 回收站 30 天自动彻底清理（每天零点后首个周期执行一次，通过 configs 记账）
    const dayKey = 'recycle_purge_' + today;
    if (!db.prepare('SELECT v FROM configs WHERE k=?').get(dayKey)) {
      db.prepare('INSERT INTO configs (k,v) VALUES (?,?)').run(dayKey, nowLocalStr());
      const cutoff = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 19).replace('T', ' ');
      for (const t of Object.keys(RECYCLE_META)) {
        db.prepare(`DELETE FROM ${t} WHERE deleted_at IS NOT NULL AND deleted_at < ?`).run(cutoff);
      }
    }
    // v7.8 审批超时自动交办（云网OA"超时策略-自动交办"）：超过配置天数未处理 → 自动转交部门领导/管理员
    let toDays = 7;
    try {
      const tc = db.prepare("SELECT v FROM configs WHERE k='approval_timeout_days'").get();
      if (tc) { const t = JSON.parse(tc.v || '{}'); if (Number(t.days) > 0) toDays = Number(t.days); }
    } catch (e) { /* 默认 7 天 */ }
    const toCut = new Date(Date.now() - toDays * 86400000).toISOString().slice(0, 19).replace('T', ' ');
    const admEsc = db.prepare("SELECT * FROM users WHERE role='admin' OR user_type='bumenlingdao' ORDER BY id LIMIT 1").get();
    for (const tbl of ['approvals', 'leaves', 'check_records', 'patrols']) {
      let pendList = [];
      try { pendList = db.prepare(`SELECT * FROM ${tbl} WHERE deleted_at IS NULL AND status='pending' AND created_at IS NOT NULL AND created_at != '' AND created_at < ?`).all(toCut); } catch (e) { continue; }
      for (const rec of pendList) {
        const ck = 'appr_to_' + tbl + '_' + rec.id;
        if (db.prepare('SELECT v FROM configs WHERE k=?').get(ck)) continue;
        const chain = (() => { try { return JSON.parse(rec.chain_json || '[]'); } catch (e) { return []; } })();
        if (!chain.length) continue;
        if ((rec.level || 0) >= chain.length - 1) continue; // 已是最后环节，不重复交办
        db.prepare('INSERT INTO configs (k,v) VALUES (?,?)').run(ck, nowLocalStr());
        if (!admEsc) continue;
        db.prepare(`UPDATE ${tbl} SET approver_id=?, level=? WHERE id=?`).run(admEsc.id, chain.length - 1, rec.id);
        const ttl = String(rec.title || (tbl === 'check_records' ? rec.check_type : tbl === 'patrols' ? (rec.area || '巡逻') : rec.reason || '流程') || '流程');
        db.prepare("INSERT INTO messages (title, content, sender_id, send_type, target_user_id) VALUES (?,?,?,?,?)").run(
          '审批超时自动交办', '「' + ttl.slice(0, 40) + '」超过 ' + toDays + ' 天未处理，已自动转交至部门领导/管理员，请及时处理。', null, 'single', admEsc.id);
        fireWebhooks('approval_timeout', { table: tbl, id: rec.id, title: ttl });
      }
    }
  } catch (e) { /* 忽略瞬时错误 */ }
}, 60000).unref();

// [需求9] 模块化拆分：路由表 + 新模块注册（未注册的路径继续落到下方原有分支，平滑迁移）
const ROUTER = require('./core/router')();
const { VERSION: APP_VERSION } = require('./modules/system')(ROUTER, { ok, fail, db: () => db });
require('./modules/recycle')(ROUTER, { ok, fail, authUser, requireLevel, recycleCounts });
require('./modules/ai')(ROUTER, { ok, fail, authUser, isAIUser, db: () => db });
require('./modules/config')(ROUTER, { ok, fail, authUser, typeLevel, isAdmin, db: () => db, readBody });
require('./modules/deploy')(ROUTER, { ok, fail, authUser, typeLevel, isAdmin });
// [需求9] 备份管理模块：3 槽轮转 + 自动备份定时器 + /api/backup/* 路由
// doRestore 会重建数据库连接，因此通过 getDb/setDb 与主进程共享同一连接变量。
// [需求9] 表结构 JSON 化 + 列表/表单格式分级配置
require('./modules/schema')(ROUTER, {
  ok, fail, authUser, typeLevel, isAdmin, db: () => db, readBody,
  safeT, ensureColumn, refreshTables
});
require('./modules/backup')(ROUTER, {
  ok, fail, authUser, requireLevel, readBody,
  getDb: () => db,
  setDb: (nd) => { db = nd; },
  DatabaseSync,
  nowLocalStr, dirSize,
  dirs: {
    BACKUP_DIR: path.join(DATA_DIR, 'backups'),
    DB_FILE, UPLOAD_DIR, PUBLIC_DIR, ROOT, SLOTS: 3
  }
});

const server = http.createServer(async (req, res) => {
  let m2; // v8.7 数桥管理路由局部匹配变量（在 let m 声明之前使用）
  // v8.6.1 安全响应头：全站统一（不覆盖各分支已有头，setHeader 幂等合并）
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self' https: wss: http:; frame-ancestors 'self'; object-src 'none'; base-uri 'self'");
  // v8.5 跨隧道 CORS：任一云端隧道均可直连（毫秒级切换基础）；OPTIONS 预检直接放行
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type,Authorization',
      'Access-Control-Max-Age': '600'
    });
    return res.end();
  }
  const url = new URL(req.url, 'http://localhost');
  const p = url.pathname;
  // [需求9] 先走模块化路由表；未命中返回 false 后继续走原有分支
  if (await ROUTER.dispatch(req, res, p, { db, ok, fail, url, req: req })) return;
  const clientIp = req.socket.remoteAddress || '127.0.0.1';
  try {
    // ---- v8.5.1 AI 助手权限隔离（统一拦截）----
    // [需求3] 2026-11-10 改为「总开关 + 临时授权」双层控制：
    //   1) ai_master 默认关，仅管理员在设置里输入专属指令可开启，关闭后所有调用一律 403；
    //   2) 开启后管理员/运维始终可用；其他人员须持未过期的临时授权，且授权未被暂停。
    //   3) 暂停只停服务，前端入口仍可见并提示「已暂停」。
    if (p.indexOf('/api/ai/') === 0) {
      const uAI = authUser(req);
      if (!uAI) return fail(res, 401, '请先登录');
      const isCtl = /^\/api\/ai\/(access|master|grant|grant\/pause)$/.test(p);   // 开关与授权管理接口不走业务门禁
      if (!isCtl) {
        const masterOn = ((db.prepare("SELECT v FROM configs WHERE k='ai_master'").get() || {}).v === '1');
        if (!masterOn) return fail(res, 403, '大模型服务已关闭（管理员可在设置中用专属指令开启）');
        if (!isAIUser(uAI)) {
          const g = db.prepare("SELECT * FROM ai_grant WHERE deleted_at IS NULL AND (scope='all' OR (scope='user' AND user_id=?)) AND expire_at>? ORDER BY id DESC LIMIT 1").get(uAI.id, Date.now());
          if (!g) return fail(res, 403, '大模型未授权或授权已过期，请联系管理员开通临时授权');
          if (Number(g.paused) === 1) return fail(res, 403, '大模型已暂停服务（入口可见，暂不可用）');
        }
      }
    }
    // ---- v6.1 写接口幂等（X-Idempotency-Key，60 秒内同键只执行一次）----
    const idemKey = req.headers['x-idempotency-key'] || '';
    if (idemKey && /^(POST|PUT|DELETE|PATCH)$/.test(req.method)) {
      const hit = idemMap.get(idemKey);
      if (hit && hit.exp > Date.now()) {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'X-Idempotent-Replay': '1', 'Content-Length': Buffer.byteLength(hit.body) });
        res.end(hit.body);
        return;
      }
      res.__idemKey = idemKey;
    }
    // ---- v6.1 登录限流：同 IP 每分钟最多 10 次（防暴力破解/刷接口）----
    if (p === '/api/login') {
      if (!rateLimit('login_' + clientIp, 10, 60000)) return fail(res, 429, '尝试过于频繁，请 1 分钟后再试');
    }
    // ---- API 登录（无需认证）----
    // ---- v7.9.15 云端地址健康状态（公开接口）：供 APP 心跳/人工排查查询当前隧道地址池 ----
    if (p === '/api/addr/status' && req.method === 'GET') {
      let tunnels = [];
      try {
        const st = fs.readFileSync('/home/user/Doubao/chats/38447831097341698/run/tunnel-guard.state', 'utf8').split('\n').filter(Boolean);
        for (const line of st) {
          const parts = line.split('|');
          if (parts.length >= 2 && parts[1].startsWith('http')) tunnels.push({ role: parts[0], url: parts[1] });
        }
      } catch (e) { /* 守护未运行时为空 */ }
      return ok(res, {
        service: 'dept-system-cloud',
        port: PORT,
        local_ok: true,
        time: Date.now(),
        tunnels: tunnels,
        board: 'https://raw.githubusercontent.com/1759717772/dept-cloud-addr/main/addr.txt'
      });
    }
    // [需求9] /api/version 已迁到 modules/system.js（路由表统一分发）
    // v8.6.1 客户端完整性二次校验（壳启动后上报：签名哈希+dex哈希+版本+设备，服务端审计留档）
    // v8.6.3 扩展：pin 校验失败上报（failDomain/spki，TrustKit 报告机制）→ 写入 data/pin_fail.log 审计
    if (p === '/api/check' && req.method === 'POST') {
      if (!rateLimit('check_' + clientIp, 30, 60000)) return fail(res, 429, '尝试过于频繁，请稍后再试');
      let b = {}; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '参数格式错误'); }
      const pkg = String(b.package || '').slice(0, 64);
      const vc = Number(b.versionCode) || 0;
      const sig = String(b.sigHash || '').toLowerCase().slice(0, 128);
      const dex = String(b.dexHash || '').toLowerCase().slice(0, 128);
      const dev = String(b.deviceId || '').slice(0, 64);
      const OFFICIAL_SIG = '5af03160992a706d23884b1ce2ba07bc3d787fc9a771fd9f9f3fdcd8d0abfb86';
      const valid = pkg === 'com.dept.mgmt' && sig === OFFICIAL_SIG;
      try {
        db.prepare("INSERT INTO integrity_logs (pkg, version_code, sig_ok, dex_hash, device_id, ip, created_at) VALUES (?,?,?,?,?,?,datetime('now','localtime'))")
          .run(pkg, vc, valid ? 1 : 0, dex, dev, clientIp);
      } catch (e2) { /* 表异常不阻塞响应 */ }
      const failDomain = String(b.failDomain || '').slice(0, 128);
      const spki = String(b.spki || '').slice(0, 128);
      if (failDomain) {
        try {
          fs.appendFileSync(path.join(DATA_DIR, 'pin_fail.log'),
            `${new Date().toISOString()} ip=${clientIp} pkg=${pkg} vc=${vc} failDomain=${failDomain} spki=${spki}\n`);
        } catch (e3) { /* 审计文件写入失败不影响响应 */ }
      }
      return ok(res, { ok: true, valid, pkg, versionCode: vc });
    }
    if (p === '/api/time-sync' && req.method === 'GET') {
      // 启动时间校验（公开接口）：百度/谷歌/国家授时中心 多源同步
      const r = await syncServerTime();
      return ok(res, r);
    }
    // ==================== v6.9 免登录转写（APP 录音页用：数据不出内网、转写后不留档）====================
    if (p === '/api/audio/transcribe-open' && req.method === 'POST') {
      // 仅供部门综合管理系统 APP 录音页免登录调用；音频 30 分钟内（20MB 内），转写完成即删除，不入库
      let b; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '请求数据格式错误'); }
      if (!b.name || !b.data) return fail(res, 400, '文件名和音频内容必填');
      const safeName = path.basename(String(b.name).replace(/[\\\/:*?"<>|]/g, '_'));
      const ext = path.extname(safeName).toLowerCase();
      if (!AUDIO_EXT.includes(ext)) return fail(res, 400, '不支持的音频格式（' + (ext || '无扩展名') + '）。支持 wav/mp3/m4a/aac/ogg/webm/amr');
      const buf = Buffer.from(b.data, 'base64');
      if (!buf.length || buf.length > MAX_UPLOAD) return fail(res, 400, '音频超过 20MB 限制');
      const stored = Date.now() + '_' + crypto.randomBytes(4).toString('hex') + ext;
      const src = path.join(AUDIO_DIR, stored);
      fs.writeFileSync(src, buf);
      let r;
      try { r = await transcribeFile(stored, src); } catch (e) { r = { ok: false, error: String((e && e.message) || e) }; }
      try { fs.unlinkSync(src); } catch (e) {}
      try { fs.unlinkSync(path.join(TMP_DIR, stored.replace(/\.[^.]+$/, '') + '.wav')); } catch (e) {}
      if (!r || !r.ok) return fail(res, 500, (r && r.error) || '转写失败');
      return ok(res, { text: r.text || '', duration: r.duration || 0 });
    }
    if (p === '/api/login' && req.method === 'POST') {
      const b = JSON.parse(await readBody(req));
      autoUpgradeNewbies();
      const name = String(b.username || '').trim();
      // 登录名 = 工作证编号 或 系统账号
      const u = db.prepare('SELECT * FROM users WHERE username = ? OR work_no = ?').get(name, name);
      if (!u) {
        return fail(res, 401, '未授权人员：您的信息未在系统中登记，请联系管理员录入（工作证编号与部门信息需与 OIT 一致）');
      }
      const pass = String(b.password || '');
      if (hashPassword(pass, u.salt) !== u.password_hash) {
        return fail(res, 401, '密码错误（初始密码为工作证编号）。忘记密码请联系管理员重置');
      }
      const token = crypto.randomBytes(32).toString('hex');
      // v8.5.2 会话加固：登录即绑定设备 ID（前端传入 deviceId）+ 30 天有效期
      const devId = String((b && b.deviceId) || '').trim();
      const expAt = Date.now() + 30 * 24 * 3600 * 1000;
      db.prepare('INSERT INTO sessions (token, user_id, device_id, expires_at) VALUES (?,?,?,?)').run(token, u.id, devId || null, expAt);
      return ok(res, { token, user: publicUser(u) });
    }
    if (p === '/api/logout' && req.method === 'POST') {
      const h = req.headers['authorization'] || '';
      const token = h.startsWith('Bearer ') ? h.slice(7) : '';
      if (token) db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
      return ok(res, {});
    }

    // ---- v6.1 面试扫码填写公开接口（仅需有效二维码令牌；表单字段与提交）----
    if (p === '/api/iv/form' && req.method === 'GET') {
      const t = String(url.searchParams.get('t') || '');
      const rec = db.prepare('SELECT v FROM configs WHERE k=?').get('iv_qr_' + t);
      if (!rec) return fail(res, 403, '二维码已失效，请联系管理员重新生成');
      let cfg;
      try { cfg = JSON.parse(db.prepare('SELECT v FROM configs WHERE k=?').get('iv_form_cfg').v || '{}'); } catch (e2) { cfg = {}; }
      const fields = Array.isArray(cfg.fields) && cfg.fields.length ? cfg.fields : DEFAULT_IV_FIELDS;
      return ok(res, { title: cfg.title || '招聘面试登记', fields, note: cfg.note || '' });
    }
    if (p === '/api/iv/submit' && req.method === 'POST') {
      if (!rateLimit('iv_sub_' + clientIp, 20, 60000)) return fail(res, 429, '提交过于频繁，请稍后再试');
      const t = String(url.searchParams.get('t') || '');
      const rec = db.prepare('SELECT v FROM configs WHERE k=?').get('iv_qr_' + t);
      if (!rec) return fail(res, 403, '二维码已失效，请联系管理员重新生成');
      const b = JSON.parse(await readBody(req));
      const data = b.fields || {};
      const name = String(data.candidate || data.name || '').trim();
      const pos = String(data.position || data.岗位 || data.应聘岗位 || '').trim();
      if (!name || !pos) return fail(res, 400, '请填写姓名与应聘岗位（必填项）');
      const noteParts = [];
      for (const k of Object.keys(data)) {
        if (['candidate', 'name', 'position', '岗位', '应聘岗位', 'phone', 'mobile', '联系电话', 'note', '备注'].includes(k)) continue;
        const v = String(data[k]);
        if (v) noteParts.push(k + '：' + v);
      }
      const baseNote = String(data.note || data.备注 || '').trim();
      const note = baseNote + (noteParts.length ? (baseNote ? '；' : '') + noteParts.join('；') : '');
      db.prepare("INSERT INTO interviews (candidate,position,dept,interviewer,interview_date,result,offer_status,note,created_by) VALUES (?,?,?,?,?,?,?,?,?)")
        .run(name, pos, String(data.dept || '扫码填写').slice(0, 50), String(data.interviewer || '扫码填写').slice(0, 50), String(data.interview_date || '').slice(0, 10), String(data.result || '待面试').slice(0, 10), String(data.offer_status || '未发送').slice(0, 10), String(note).slice(0, 500), null);
      return ok(res, { ok: true, msg: '提交成功，信息已进入系统招聘面试列表' });
    }

    // ---- v7.9.2-cloud 网络提示（免登录）：APP 自动同步云端备用地址（仅公网地址，不含密钥/敏感信息） ----
    if (p === '/api/network/hint' && req.method === 'GET') {
      const cc = clCfg();
      return ok(res, { bizUrl: cc.bizUrl || '', bizUrl2: cc.bizUrl2 || '' });
    }

    // ================= v8.1-cloud 开放 API 网关（对标 Cordys CRM 开放 API / MCP Server）=================
    // 外部系统（OA、其他软件）通过 API 密钥直连获取/写入业务数据，无需转换或重新录入。
    // 密钥由管理员在系统内生成；请求头携带 X-API-Key。
    if (p === '/api/open/config' && req.method === 'GET') {   // 管理员：查看已生成密钥
      const u = authUser(req); if (!u || u.role !== 'admin') return fail(res, 403, '仅管理员可操作');
      return ok(res, db.prepare('SELECT id,name,key,scope,created_at,enabled FROM api_keys ORDER BY id').all());
    }
    if (p === '/api/open/config' && req.method === 'POST') {  // 管理员：生成/停用密钥
      const u = authUser(req); if (!u || u.role !== 'admin') return fail(res, 403, '仅管理员可操作');
      let body = {}; try { body = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '参数格式错误'); }
      if (body.action === 'create') {
        const name = String(body.name || '外部系统').slice(0, 50);
        const key = 'dpt_' + crypto.randomBytes(18).toString('hex');
        db.prepare('INSERT INTO api_keys (name,key,scope,created_at,enabled) VALUES (?,?,?,datetime(\'now\',\'localtime\'),1)').run(name, key, body.scope || 'read,write');
        return ok(res, { key, name, scope: body.scope || 'read,write' });
      }
      if (body.action === 'disable' && body.id) {
        db.prepare('UPDATE api_keys SET enabled=0 WHERE id=?').run(Number(body.id));
        return ok(res, { ok: true });
      }
      if (body.action === 'enable' && body.id) {
        db.prepare('UPDATE api_keys SET enabled=1 WHERE id=?').run(Number(body.id));
        return ok(res, { ok: true });
      }
      return fail(res, 400, 'action 需为 create/disable/enable');
    }
    if (p.startsWith('/api/open/')) {
      const ak = req.headers['x-api-key'] || '';
      const akey = db.prepare('SELECT * FROM api_keys WHERE key=? AND enabled=1').get(ak);
      if (!akey) return fail(res, 401, '无效或已停用的 API 密钥');
      // 人员档案（含个人培训聚合，对标 Cordys 联系人详情）
      if (p === '/api/open/persons' && req.method === 'GET') {
        const rows = db.prepare("SELECT u.id,u.work_no,u.real_name,u.dept_id,d.name AS dept_name,u.role,u.user_type,u.job_title,u.hire_date,u.mobile,u.gender,u.education,u.nation,u.political_status FROM users u LEFT JOIN depts d ON d.id=u.dept_id WHERE u.deleted_at IS NULL ORDER BY d.name,u.real_name").all();
        return ok(res, rows.map(u => {
          const trains = db.prepare("SELECT train_service,train_type,class_info,beg_date,end_date,hours,mark_grade,teacher_name,corp_organize FROM train_records WHERE emp_id=? AND deleted_at IS NULL ORDER BY beg_date DESC").all(u.id);
          return { ...u, train_count: trains.length, trainings: trains.slice(0, 20) };
        }));
      }
      // 培训记录（按人/类型/时间过滤）
      if (p === '/api/open/trainings' && req.method === 'GET') {
        const q = new URL(req.url, 'http://x').searchParams;
        const emp = q.get('emp_id'), svc = q.get('train_service'), from = q.get('from'), to = q.get('to');
        let sql = "SELECT t.*,u.real_name AS emp_name FROM train_records t LEFT JOIN users u ON u.id=t.emp_id WHERE t.deleted_at IS NULL";
        const prm = [];
        if (emp) { sql += ' AND t.emp_id=?'; prm.push(Number(emp)); }
        if (svc) { sql += ' AND t.train_service=?'; prm.push(String(svc)); }
        if (from) { sql += ' AND t.beg_date>=?'; prm.push(String(from)); }
        if (to) { sql += ' AND t.beg_date<=?'; prm.push(String(to)); }
        sql += ' ORDER BY t.beg_date DESC LIMIT 500';
        return ok(res, db.prepare(sql).all(...prm));
      }
      // 检查整改记录（按检查项目维度）
      if (p === '/api/open/checks' && req.method === 'GET') {
        const q = new URL(req.url, 'http://x').searchParams;
        const res2 = q.get('result'), area = q.get('area');
        let sql = "SELECT c.* FROM audit_checks c WHERE c.deleted_at IS NULL";
        const prm = [];
        if (res2) { sql += ' AND c.result=?'; prm.push(String(res2)); }
        if (area) { sql += ' AND c.area=?'; prm.push(String(area)); }
        sql += ' ORDER BY c.check_date DESC LIMIT 500';
        return ok(res, db.prepare(sql).all(...prm));
      }
      // 文件清单
      if (p === '/api/open/files' && req.method === 'GET') {
        return ok(res, db.prepare("SELECT id,name,size,uploader_id,created_at FROM files ORDER BY created_at DESC LIMIT 500").all());
      }
      // 外部系统写入（对标 Cordys 开放录入：线索/跟进/记录统一入口）
      if (p === '/api/open/records' && req.method === 'POST') {
        if (!String(akey.scope || '').includes('write')) return fail(res, 403, '该密钥无写入权限');
        let body = {}; try { body = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '数据包格式错误'); }
        const kind = String(body.kind || ''); let n = 0;
        if (kind === 'training' && Array.isArray(body.records)) {
          const ins = db.prepare(`INSERT INTO train_records (emp_id,emp_name,train_service,train_type,train_method,class_info,beg_date,end_date,days,hours,fee,mark_grade,train_effect,certificate_no,lmt_service_date,teacher_id,teacher_name,corp_organize,corp_operate,note_info,create_user_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
          for (const r of body.records) {
            let eid = null, ename = '';
            if (r.emp_id) { const w = db.prepare('SELECT id,real_name FROM users WHERE work_no=? OR id=?').get(String(r.emp_id), Number(r.emp_id) || 0); if (w) { eid = w.id; ename = w.real_name; } }
            if (!eid && r.emp_name) { const w2 = db.prepare('SELECT id FROM users WHERE real_name=? LIMIT 1').get(String(r.emp_name)); if (w2) eid = w2.id; }
            const svc = r.train_service === '外培' || r.train_service === 'B' ? '外培' : '内培';
            ins.run(eid, ename || String(r.emp_name || '').slice(0,50), svc, String(r.train_type || '').slice(0,50), String(r.train_method || '').slice(0,50), String(r.class_info || '').slice(0,200), String(r.beg_date || '').slice(0,10), String(r.end_date || r.beg_date || '').slice(0,10), Number(r.days) || 0, Number(r.hours) || 0, Number(r.fee) || 0, String(r.mark_grade || '').slice(0,200), String(r.train_effect || '').slice(0,50), String(r.certificate_no || '').slice(0,50), String(r.lmt_service_date || '').slice(0,10), 0, String(r.teacher_name || '').slice(0,50), String(r.corp_organize || '').slice(0,100), String(r.corp_operate || '').slice(0,100), String(r.note_info || '').slice(0,200), 0);
            n++;
          }
        } else if (kind === 'check' && Array.isArray(body.records)) {
          const ins = db.prepare("INSERT INTO audit_checks (check_date,project,area,checker,result,summary,created_by) VALUES (?,?,?,?,?,?,?)");
          for (const r of body.records) {
            ins.run(String(r.check_date || new Date().toISOString().slice(0, 10)).slice(0, 10), String(r.project || '安全检查').slice(0, 100), String(r.area || '').slice(0, 100), String(r.checker || '').slice(0, 50), String(r.result || '合格').slice(0, 20), String(r.summary || r.note || '').slice(0, 500), 0);
            n++;
          }
        } else return fail(res, 400, 'kind 需为 training/check，且 records 为数组');
        return ok(res, { imported: n });
      }
      return fail(res, 404, '开放接口不存在');
    }

    if (p === '/api/ai/apply' && req.method === 'POST') {   // 智能录入确认提交（登录用户）
      const u = authUser(req); if (!u) return fail(res, 401, '请先登录');
      let body = {}; try { body = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '参数格式错误'); }
      const kind = String(body.kind || '');
      const d = body.data || {};
      if (kind === 'training') {
        let eid = null, ename = d.emp_name || '';
        if (d.emp_id) { const w = db.prepare('SELECT id,real_name FROM users WHERE work_no=? OR id=?').get(String(d.emp_id), Number(d.emp_id) || 0); if (w) { eid = w.id; ename = w.real_name; } }
        if (!eid && ename) { const w2 = db.prepare('SELECT id FROM users WHERE real_name=? LIMIT 1').get(String(ename)); if (w2) eid = w2.id; }
        const svc = d.train_service === '外培' || d.train_service === 'B' ? '外培' : '内培';
        db.prepare("INSERT INTO train_records (emp_id,emp_name,train_service,train_type,train_method,class_info,beg_date,end_date,days,hours,fee,mark_grade,train_effect,certificate_no,lmt_service_date,teacher_id,teacher_name,corp_organize,corp_operate,note_info,create_user_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)").run(
          eid, ename || '', svc, String(d.train_type || '').slice(0,50), String(d.train_method || '').slice(0,50), String(d.class_info || '').slice(0,200), String(d.beg_date || '').slice(0,10), String(d.end_date || d.beg_date || '').slice(0,10), Number(d.days)||0, Number(d.hours)||0, Number(d.fee)||0, String(d.mark_grade || '').slice(0,200), String(d.train_effect || '').slice(0,50), String(d.certificate_no || '').slice(0,50), String(d.lmt_service_date || '').slice(0,10), 0, String(d.teacher_name || '').slice(0,50), String(d.corp_organize || '').slice(0,100), String(d.corp_operate || '').slice(0,100), String(d.note_info || '').slice(0,200), u.id);
        return ok(res, { saved: true, kind: 'training' });
      }
      if (kind === 'check') {
        db.prepare("INSERT INTO audit_checks (check_date,project,area,checker,result,summary,created_by) VALUES (?,?,?,?,?,?,?)").run(String(d.check_date || new Date().toISOString().slice(0,10)).slice(0,10), String(d.project || '安全检查').slice(0,100), String(d.area || '').slice(0,100), String(d.checker || u.real_name || '').slice(0,50), String(d.result || '合格').slice(0,20), String(d.summary || '').slice(0,500), u.id);
        return ok(res, { saved: true, kind: 'check' });
      }
      return fail(res, 400, 'kind 需为 training/check');
    }

    // ==================== [需求3] 大模型开关 / 临时授权 / 暂停 ====================
    const aiCfgGet = (k) => { const r = db.prepare('SELECT v FROM configs WHERE k=?').get(k); return r ? r.v : ''; };
    const aiCfgSet = (k, v) => { const ex = db.prepare('SELECT 1 FROM configs WHERE k=?').get(k); if (ex) db.prepare('UPDATE configs SET v=? WHERE k=?').run(String(v || ''), k); else db.prepare('INSERT INTO configs (k,v) VALUES (?,?)').run(k, String(v || '')); };
    // [需求9] /api/ai/access 已迁到 modules/ai.js
    if (p === '/api/ai/master' && req.method === 'POST') {    // 管理员：开关总开关（需专属指令）
      const u = authUser(req); if (!u || u.role !== 'admin') return fail(res, 403, '仅管理员可操作');
      let b = {}; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '参数格式错误'); }
      const pass = String(b.pass || '').trim();
      const saved = aiCfgGet('ai_pass');
      if (b.on) {
        if (!saved) { if (pass.length < 6) return fail(res, 400, '首次开启需设置不少于 6 位的专属指令'); aiCfgSet('ai_pass', pass); }
        else if (pass !== saved) return fail(res, 403, '专属指令不正确，无法开启');
        aiCfgSet('ai_master', '1');
      } else {
        if (saved && pass !== saved) return fail(res, 403, '关闭大模型同样需要专属指令');
        aiCfgSet('ai_master', '0');
      }
      auditLog(u, '大模型开关', b.on ? '开启' : '关闭', '管理员用专属指令切换大模型总开关', 'ok');
      return ok(res, { master: b.on ? true : false });
    }
    if (p === '/api/ai/grant' && req.method === 'GET') {       // 管理员：授权列表
      const u = authUser(req); if (!u || !isAIUser(u)) return fail(res, 403, '仅管理员/运维可查看');
      const rows = db.prepare("SELECT g.*, us.real_name AS user_name FROM ai_grant g LEFT JOIN users us ON g.user_id=us.id WHERE g.deleted_at IS NULL ORDER BY g.id DESC LIMIT 100").all();
      // 过期记录不删，标状态便于核查
      return ok(res, { master: aiCfgGet('ai_master') === '1', has_pass: !!aiCfgGet('ai_pass'), rows: rows.map((x) => Object.assign({}, x, { expired: Number(x.expire_at) <= Date.now() })) });
    }
    if (p === '/api/ai/grant' && req.method === 'POST') {      // 管理员：新增临时授权（年/月/日/小时）
      const u = authUser(req); if (!u || !isAIUser(u)) return fail(res, 403, '仅管理员/运维可操作');
      let b = {}; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '参数格式错误'); }
      const MS = { hour: 3600e3, day: 86400e3, month: 30 * 86400e3, year: 365 * 86400e3 };
      const unit = ['hour', 'day', 'month', 'year'].indexOf(String(b.unit)) >= 0 ? String(b.unit) : 'day';
      const scope = String(b.scope) === 'user' ? 'user' : 'all';
      let uid = 0;
      if (scope === 'user') {
        uid = Number(b.user_id) || 0;
        if (!uid) { const w = db.prepare('SELECT id FROM users WHERE work_no=? OR real_name=?').get(String(b.target || ''), String(b.target || '')); uid = w ? w.id : 0; }
        if (!uid) return fail(res, 400, '未找到被授权人员');
      }
      const expire = Date.now() + (MS[unit] || MS.day);
      db.prepare('INSERT INTO ai_grant (scope,user_id,unit,expire_at,note,created_by) VALUES (?,?,?,?,?,?)').run(scope, uid, unit, expire, String(b.note || '').slice(0, 100), u.id);
      auditLog(u, '大模型授权', scope === 'all' ? '全员' : ('用户' + uid), '临时授权 ' + unit + '，到期 ' + new Date(expire).toLocaleString('zh-CN'), 'ok');
      return ok(res, { expire_at: expire });
    }
    if (p === '/api/ai/grant/pause' && req.method === 'POST') {  // 管理员：暂停/恢复（整体或指定授权）
      const u = authUser(req); if (!u || !isAIUser(u)) return fail(res, 403, '仅管理员/运维可操作');
      let b = {}; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '参数格式错误'); }
      const paused = b.paused ? 1 : 0;
      const id = Number(b.id) || 0;
      if (id) db.prepare('UPDATE ai_grant SET paused=? WHERE id=?').run(paused, id);
      else db.prepare('UPDATE ai_grant SET paused=? WHERE deleted_at IS NULL').run(paused);   // 不传 id = 整体暂停
      auditLog(u, '大模型暂停', id ? ('授权#' + id) : '全部', paused ? '暂停服务' : '恢复服务', 'ok');
      return ok(res, { paused: !!paused });
    }
    // 管理员配置大模型（OpenAI 兼容协议）；未配置时本地意图引擎兜底，保证 AI 工作台开箱可用。
    if (p === '/api/ai/config' && req.method === 'GET') {    // 管理员：查看 AI 配置（不返回密钥原文）
      const u = authUser(req); if (!u || u.role !== 'admin') return fail(res, 403, '仅管理员可操作');
      const g = (k) => { const r = db.prepare('SELECT v FROM configs WHERE k=?').get(k); return r ? r.v : ''; };
      return ok(res, { base_url: g('aiBaseUrl'), model: g('aiModel'), has_key: !!g('aiKey'),
        backup_base_url: g('aiBackupBase'), backup_model: g('aiBackupModel'), has_backup_key: !!g('aiBackupKey') });
    }
    if (p === '/api/ai/config' && req.method === 'POST') {   // 管理员：保存 AI 配置
      const u = authUser(req); if (!u || u.role !== 'admin') return fail(res, 403, '仅管理员可操作');
      let body = {}; try { body = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '参数格式错误'); }
      const set = (k, v) => { const ex = db.prepare('SELECT 1 FROM configs WHERE k=?').get(k); if (ex) db.prepare('UPDATE configs SET v=? WHERE k=?').run(String(v || ''), k); else db.prepare('INSERT INTO configs (k,v) VALUES (?,?)').run(k, String(v || '')); };
      if (body.base_url) set('aiBaseUrl', body.base_url);
      if (body.model) set('aiModel', body.model);
      if (body.api_key) set('aiKey', body.api_key);
      // [需求3] 备用通道（如商汤日日新）：主通道断流时自动接管，避免 AI 整体不可用
      if (body.backup_base_url !== undefined) set('aiBackupBase', body.backup_base_url);
      if (body.backup_model !== undefined) set('aiBackupModel', body.backup_model);
      if (body.backup_api_key) set('aiBackupKey', body.backup_api_key);
      auditLog(u, 'AI配置变更', 'base_url/model/api_key', '管理员修改大模型接入配置', 'ok');
      return ok(res, { saved: true });
    }
    if (p === '/api/ai/chat' && req.method === 'POST') {     // 个人 AI 对话（按用户隔离）v8.7：专家团路由 + 安全会话
      const u = authUser(req); if (!u) return fail(res, 401, '请先登录');
      let body = {}; try { body = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '参数格式错误'); }
      const ask = String(body.message || '').slice(0, 500);
      if (!ask) return fail(res, 400, '请输入内容');
      // [需求8] 输入侧注入拦截：命中即不进入模型，返回固定话术并留审计（不透露任何系统设定）
      if (aiInjectCheck(ask)) {
        auditLog(u, 'AI提示词注入拦截', ask, '拒绝处理并记录', 'blocked');
        return ok(res, { reply: '这个问题涉及系统内部设定，我不能提供。可以问我业务数据、制度条款或写作建议。', source: 'guard', expert: 'guard', sensitive: true });
      }
      const expert = String(body.expert || 'general');
      const cfg = db.prepare('SELECT v FROM configs WHERE k=?').get('aiKey');
      const g = (k) => { const r = db.prepare('SELECT v FROM configs WHERE k=?').get(k); return r ? r.v : ''; };
      // 安全会话：命中敏感词（身份证/手机号/工资/密钥等）强制本地处理，不调用外部大模型
      const sens = isSensitiveAsk(ask);
      let reply = aiLocalReply(u, ask);
      let src = 'local'; let expertUsed = expert;
      // 专家团路由：数据专家走数桥、制度专家走知识库、写作/人事走本地+LLM
      if (expert === 'data') {
        const plan = bridgePlan(ask, u);
        if (plan) {
          const ex = bridgeExec(plan, u);
          reply = ex.error ? '数据专家：' + ex.error : '（数桥受控取数 ' + ex.count + ' 行）\n' + ex.rows.slice(0, 8).map(function (r) { return Object.keys(r).map(function (k) { return k + '=' + r[k]; }).join(' | '); }).join('\n');
          src = 'bridge';
        } else { reply = '数据专家：未能识别到可查询的业务数据表，可试试「今年培训统计」「最近检查记录」「本月待办任务」。'; }
      } else if (expert === 'kb') {
        const hits = kbSearch(ask);
        reply = hits.length ? '制度专家（知识库命中 ' + hits.length + ' 条，出处见下方引用）：' + hits[0].snippet : '制度专家：知识库暂无相关条目（可先上传资料到知识库并点击「抽取入库」）。';
        src = 'kb';
      } else if (expert === 'write') {
        reply = aiWriteReply(u, ask);
        src = 'write';
      } else if (expert === 'hr') {
        reply = aiLocalReply(u, ask);
        src = 'local';
      }
      // 非敏感任务且配置了大模型：LLM 增强（数桥/知识库结果保持本地，不额外调外部模型）
      if (cfg && cfg.v && !sens && expert !== 'data' && expert !== 'kb') {
        try { const r2 = await aiLLMCallAny((expert === 'write' ? AI_SYS_WRITE : AI_SYS_GENERAL) + ask); if (r2) { reply = r2; src = 'llm'; } } catch (e) { /* 大模型失败用本地兜底 */ }
      }
      // [需求8] 输出侧指纹擦除：模型若复述系统提示词，落库与回显前统一脱敏
      reply = aiScrubOut(reply);
      db.prepare("INSERT INTO ai_logs (user_id, q, kind, summary, created_at) VALUES (?,?,?,?,datetime('now','localtime'))").run(u.id, ask, 'chat:' + expertUsed, reply.slice(0, 500));
      if (sens) auditLog(u, 'AI敏感问答', ask, '强制本地处理（安全会话）', 'ok');
      return ok(res, { reply, source: src, expert: expertUsed, sensitive: sens });
    }
    if (p === '/api/ai/parse' && req.method === 'POST') {    // 智能录入解析：自然语言 → 结构化业务数据
      const u = authUser(req); if (!u) return fail(res, 401, '请先登录');
      let body = {}; try { body = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '参数格式错误'); }
      const text = String(body.text || '').slice(0, 500);
      if (!text) return fail(res, 400, '请输入内容');
      const cfg = db.prepare('SELECT v FROM configs WHERE k=?').get('aiKey');
      let out = aiParseLocal(text);
      if (cfg && cfg.v) {
        const g = (k) => { const r = db.prepare('SELECT v FROM configs WHERE k=?').get(k); return r ? r.v : ''; };
        try { const r = await aiLLMCallAny('把下面这段话解析为培训记录或检查记录的结构化 JSON（只输出 JSON，不要多余文字）：' + text); if (r) { const j = r.replace(/```json|```/g, '').trim(); const o = JSON.parse(j); if (o) out = o; } } catch (e) { /* 解析失败用本地兜底 */ }
      }
      return ok(res, out);
    }

    // ===== v8.7 OneBox 融合：数桥·受控取数（语义层 + 数据授权 + NL→受控SQL→脱敏→留痕）=====
    if (p === '/api/bridge/tables' && req.method === 'GET') {   // 数据资产总览（领导及以上）
      const u = authUser(req); if (!u) return fail(res, 401, '请先登录');
      if (typeLevel(u) < 3) return fail(res, 403, '仅领导及以上可查看数据资产');
      const grants = db.prepare('SELECT * FROM data_grants').all();
      const sfs = db.prepare('SELECT * FROM semantic_fields').all();
      return ok(res, Object.keys(BRIDGE_TABLES).map(function (t) { return { table: t, label: BRIDGE_TABLES[t].label, fields: Object.keys(BRIDGE_TABLES[t].fields), grants: grants.filter(function (g) { return g.table_name === t; }), semantics: sfs.filter(function (f) { return f.table_name === t; }) }; }));
    }
    if (p === '/api/bridge/fields' && req.method === 'GET') {   // 语义层词典
      const u = authUser(req); if (!u) return fail(res, 401, '请先登录');
      return ok(res, db.prepare('SELECT * FROM semantic_fields ORDER BY id DESC LIMIT 500').all());
    }
    if (p === '/api/bridge/fields' && req.method === 'POST') {  // 新增语义（管理员）
      const u = authUser(req); if (!u || !isAdmin(u)) return fail(res, 403, '仅管理员可维护语义层');
      let b = {}; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '参数格式错误'); }
      const term = String(b.biz_term || '').trim(); const tbl = String(b.table_name || '').trim();
      if (!term || !tbl || !BRIDGE_TABLES[tbl]) return fail(res, 400, '业务词与白名单表必填');
      if (b.column_name && !BRIDGE_TABLES[tbl].fields[b.column_name]) return fail(res, 400, '该表无此可查字段');
      const r = db.prepare('INSERT INTO semantic_fields (biz_term,table_name,column_name,column_label,mask,note) VALUES (?,?,?,?,?,?)')
        .run(term, tbl, String(b.column_name || ''), String(b.column_label || ''), b.mask ? 1 : 0, String(b.note || '').slice(0, 200));
      auditLog(u, '语义层配置', term + '→' + tbl, '新增业务词映射', 'ok');
      return ok(res, { id: Number(r.lastInsertRowid) });
    }
    if ((m2 = p.match(/^\/api\/bridge\/fields\/(\d+)$/)) && req.method === 'DELETE') {  // 删除语义（管理员）
      const u = authUser(req); if (!u || !isAdmin(u)) return fail(res, 403, '仅管理员可维护语义层');
      const f = db.prepare('SELECT * FROM semantic_fields WHERE id=?').get(Number(m2[1]));
      if (f) auditLog(u, '语义层配置', f.biz_term + '→' + f.table_name, '删除业务词映射', 'ok');
      db.prepare('DELETE FROM semantic_fields WHERE id=?').run(Number(m2[1]));
      return ok(res, {});
    }
    if (p === '/api/bridge/grants' && req.method === 'POST') {  // 数据授权（管理员）
      const u = authUser(req); if (!u || !isAdmin(u)) return fail(res, 403, '仅管理员可配置数据授权');
      let b = {}; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '参数格式错误'); }
      const tbl = String(b.table_name || '').trim();
      if (!tbl || !BRIDGE_TABLES[tbl]) return fail(res, 400, '白名单表必填');
      if (b.column_name && b.column_name !== '*' && !BRIDGE_TABLES[tbl].fields[b.column_name]) return fail(res, 400, '该表无此字段');
      const r = db.prepare('INSERT INTO data_grants (role,table_name,column_name,row_scope,enabled) VALUES (?,?,?,?,?)')
        .run(String(b.role || ''), tbl, String(b.column_name || '*'), ['all', 'dept', 'mine'].indexOf(b.row_scope) >= 0 ? b.row_scope : 'all', b.enabled === 0 ? 0 : 1);
      auditLog(u, '数据授权', tbl + (b.column_name && b.column_name !== '*' ? '.' + b.column_name : ''), 'row_scope=' + b.row_scope + ' enabled=' + (b.enabled === 0 ? 0 : 1), 'ok');
      return ok(res, { id: Number(r.lastInsertRowid) });
    }
    if ((m2 = p.match(/^\/api\/bridge\/grants\/(\d+)$/)) && req.method === 'DELETE') {  // 撤销授权（管理员）
      const u = authUser(req); if (!u || !isAdmin(u)) return fail(res, 403, '仅管理员可配置数据授权');
      const g = db.prepare('SELECT * FROM data_grants WHERE id=?').get(Number(m2[1]));
      if (g) auditLog(u, '数据授权', g.table_name + (g.column_name && g.column_name !== '*' ? '.' + g.column_name : ''), '撤销授权', 'ok');
      db.prepare('DELETE FROM data_grants WHERE id=?').run(Number(m2[1]));
      return ok(res, {});
    }
    if (p === '/api/bridge/ask' && req.method === 'POST') {    // 数桥取数：NL→受控SQL→脱敏→审计
      const u = authUser(req); if (!u) return fail(res, 401, '请先登录');
      let b = {}; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '参数格式错误'); }
      const ask = String(b.message || '').slice(0, 300);
      if (!ask) return fail(res, 400, '请输入问题');
      const plan = bridgePlan(ask, u);
      if (!plan) { auditLog(u, '数桥取数', ask, '未识别到受控数据表', 'skip'); return fail(res, 400, '暂未识别到可查询的业务数据，可试试：今年培训统计 / 最近检查记录 / 本月待办任务'); }
      const exec = bridgeExec(plan, u);
      if (exec.error) { auditLog(u, '数桥取数', ask, exec.error, 'fail'); return fail(res, 500, exec.error); }
      auditLog(u, '数桥取数', ask, plan.sql + ' → ' + exec.count + ' 行', 'ok');
      return ok(res, { plan: { table: plan.table, cols: plan.cols, sql: plan.sql, time_range: plan.timeRange }, count: exec.count, rows: exec.rows });
    }
    // 操作审计日志（领导及以上，可检索）
    if (p === '/api/audit/logs' && req.method === 'GET') {
      const u = authUser(req); if (!u || typeLevel(u) < 3) return fail(res, 403, '仅领导及以上可查看审计日志');
      const q = String(url.searchParams.get('q') || '').trim();
      const days = Math.min(90, Math.max(1, Number(url.searchParams.get('days')) || 7));
      let sql = "SELECT * FROM audit_logs WHERE created_at >= datetime('now','localtime','-" + days + " days')";
      const args = [];
      if (q) { sql += ' AND (user_name LIKE ? OR action LIKE ? OR target LIKE ? OR detail LIKE ?)'; args.push('%' + q + '%', '%' + q + '%', '%' + q + '%', '%' + q + '%'); }
      sql += ' ORDER BY created_at DESC LIMIT 500';
      return ok(res, db.prepare(sql).all(...args));
    }
    // AI 用量统计（领导及以上）
    if (p === '/api/ai/stats' && req.method === 'GET') {
      const u = authUser(req); if (!u || typeLevel(u) < 3) return fail(res, 403, '仅领导及以上可查看用量统计');
      const days = Math.min(90, Math.max(1, Number(url.searchParams.get('days')) || 30));
      const byUser = db.prepare("SELECT COALESCE(us.real_name,'?') un, COUNT(*) c FROM ai_logs l LEFT JOIN users us ON us.id=l.user_id WHERE l.created_at >= datetime('now','localtime','-" + days + " days') AND l.deleted_at IS NULL GROUP BY l.user_id ORDER BY c DESC LIMIT 20").all();
      const byKind = db.prepare("SELECT kind, COUNT(*) c FROM ai_logs WHERE created_at >= datetime('now','localtime','-" + days + " days') AND deleted_at IS NULL GROUP BY kind ORDER BY c DESC").all();
      const audits = db.prepare("SELECT action, COUNT(*) c FROM audit_logs WHERE created_at >= datetime('now','localtime','-" + days + " days') GROUP BY action ORDER BY c DESC").all();
      const total = db.prepare("SELECT COUNT(*) c FROM ai_logs WHERE created_at >= datetime('now','localtime','-" + days + " days') AND deleted_at IS NULL").get().c;
      return ok(res, { days: days, total: total, by_user: byUser, by_kind: byKind, audit_actions: audits });
    }
    // 知识库出处问答：自动抽取入库 / 粘贴文本入库 / 问答出处
    if (p === '/api/kb/extract' && req.method === 'POST') {    // 从已存文件自动抽取文本分块入库
      const u = authUser(req); if (!u || typeLevel(u) < 2) return fail(res, 403, '班组长及以上可维护知识库');
      let b = {}; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '参数格式错误'); }
      const doc = db.prepare('SELECT * FROM kb_docs WHERE id=? AND deleted_at IS NULL').get(Number(b.doc_id || 0));
      if (!doc) return fail(res, 404, '文档不存在');
      const fp = path.join(UPLOAD_DIR, doc.file_path);
      if (!fs.existsSync(fp)) return fail(res, 404, '文件已丢失');
      const text = kbExtractText(fp);
      if (!text) return fail(res, 400, '未能从该文件抽取文本（支持 pdf/docx/xlsx/pptx/txt/md/csv）');
      const n = kbChunkize(text, doc.title, doc.id, doc.file_path, doc.file_name || doc.title, doc.category);
      auditLog(u, '知识库入库', doc.title, '自动抽取分块 ' + n + ' 条', 'ok');
      return ok(res, { chunks: n, preview: text.slice(0, 200) });
    }
    if (p === '/api/kb/ingest' && req.method === 'POST') {    // 粘贴文本入库
      const u = authUser(req); if (!u || typeLevel(u) < 2) return fail(res, 403, '班组长及以上可维护知识库');
      let b = {}; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '参数格式错误'); }
      const doc = db.prepare('SELECT * FROM kb_docs WHERE id=? AND deleted_at IS NULL').get(Number(b.doc_id || 0));
      if (!doc) return fail(res, 404, '文档不存在');
      const text = String(b.text || '');
      if (!text) return fail(res, 400, '请输入文本内容');
      const n = kbChunkize(text, doc.title, doc.id, doc.file_path, doc.file_name || doc.title, doc.category);
      auditLog(u, '知识库入库', doc.title, '粘贴文本分块 ' + n + ' 条', 'ok');
      return ok(res, { chunks: n });
    }
    if (p === '/api/kb/ask' && req.method === 'POST') {    // 制度专家：知识库出处问答
      const u = authUser(req); if (!u) return fail(res, 401, '请先登录');
      let b = {}; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '参数格式错误'); }
      const q = String(b.message || '').slice(0, 300);
      if (!q) return fail(res, 400, '请输入问题');
      const hits = kbSearch(q);
      const cfg = db.prepare('SELECT v FROM configs WHERE k=?').get('aiKey');
      let summary = '';
      if (cfg && cfg.v && hits.length) {
        const g = (k) => { const r = db.prepare('SELECT v FROM configs WHERE k=?').get(k); return r ? r.v : ''; };
        try { const src = hits.map(function (h) { return h.snippet; }).join('\n---\n'); summary = await aiLLMCallAny('以下是知识库检索到的原文片段，请结合问题「' + q + '」给出简洁回答（不要编造片段外的事实）：\n' + src) || ''; } catch (e) {}
      }
      db.prepare("INSERT INTO ai_logs (user_id,q,kind,summary,created_at) VALUES (?,?,?,?,datetime('now','localtime'))").run(u.id, q, 'kb', hits.length ? (summary || '命中 ' + hits.length + ' 条') : '未命中');
      auditLog(u, '知识库问答', q, hits.length ? '命中 ' + hits.length + ' 条' : '未命中', 'ok');
      return ok(res, { summary: summary, hits: hits });
    }

    // ---- 需要认证的 API ----
    if (!p.startsWith('/api/')) return serveStatic(req, res, p);
    // v7.9-cloud：/api/oit/import 支持同步密钥 Bearer 鉴权（办公电脑采集器/主服务器自动分发用），绕过登录
    if (p === '/api/oit/import' && req.method === 'POST') {
      const btok = req.headers['authorization'] || '';
      if (btok.startsWith('Bearer ')) {
        const ck = clCfg().key;
        if (ck && btok === 'Bearer ' + sha256hex(ck)) {
          // 密钥鉴权通过：直接走 oit 导入处理
          let body = {}; try { body = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '数据包格式错误（应为 OIT 采集器导出的 JSON）'); }
          if (!Array.isArray(body.depts) && !Array.isArray(body.users)) return fail(res, 400, '数据包缺少 depts/users 数组');
          const r = oitImportData(body);
          try { fs.writeFileSync(path.join(__dirname, 'data', 'oit-latest.json'), JSON.stringify(body)); } catch (e) {}
          addRun('oit', 'ok', '采集器/主服务器推送导入（部门+' + r.depts_added + ' 新增+' + r.users_added + ' 更新+' + r.users_updated + '）');
          return ok(res, r);
        }
      }
    }
    // v8.0-cloud：/api/train/import 同步密钥 Bearer 鉴权（采集器 v1.3 培训/教员/考核导入），绕过登录
    if (p === '/api/train/import' && req.method === 'POST') {
      const btok = req.headers['authorization'] || '';
      let bauthed = false;
      if (btok.startsWith('Bearer ')) {
        const ck = clCfg().key;
        if (ck && btok === 'Bearer ' + sha256hex(ck)) bauthed = true;
      }
      if (bauthed) {
        let bbody = {}; try { bbody = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '数据包格式错误'); }
        const sysU = db.prepare("SELECT * FROM users WHERE role='admin' ORDER BY id LIMIT 1").get() || { id: 0 };
        const insT = db.prepare(`INSERT INTO train_records (emp_id,emp_name,train_service,train_type,train_method,class_info,beg_date,end_date,days,hours,fee,mark_grade,train_effect,certificate_no,lmt_service_date,teacher_id,teacher_name,corp_organize,corp_operate,note_info,create_user_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
        const chkT = db.prepare("SELECT id FROM train_records WHERE emp_id=? AND class_info=? AND beg_date=? AND train_service=? AND deleted_at IS NULL");
        const updT = db.prepare("UPDATE train_records SET mark_grade=?,hours=?,fee=?,train_effect=?,certificate_no=?,teacher_name=?,end_date=?,note_info=? WHERE id=?");
        let n = 0, nt = 0, na = 0;
        if (Array.isArray(bbody.trains)) for (const t of bbody.trains) {
          const service = t.train_service === '外培' || t.train_service === 'B' ? '外培' : '内培';
          const cls = String(t.class_info || '').slice(0, 200);
          const beg = String(t.beg_date || '').slice(0, 10);
          const ename = (() => { if (!t.emp_id) return ''; const w = db.prepare('SELECT real_name FROM users WHERE work_no=? OR id=?').get(String(t.emp_id), Number(t.emp_id) || 0); return w ? w.real_name : ''; })();
          if (!t.emp_id || !cls || !ename) continue;
          const exist = chkT.get(String(t.emp_id), cls, beg, service);
          if (exist) { updT.run(String(t.mark_grade || ''), Number(t.hours) || 0, Number(t.fee) || 0, String(t.train_effect || ''), String(t.certificate_no || ''), String(t.teacher_name || ''), String(t.end_date || '').slice(0, 10), String(t.note_info || ''), exist.id); }
          else { insT.run(String(t.emp_id), ename, service, String(t.train_type || '').slice(0, 30), String(t.train_method || '').slice(0, 20), cls, beg, String(t.end_date || '').slice(0, 10), Number(t.days) || 0, Number(t.hours) || 0, Number(t.fee) || 0, String(t.mark_grade || ''), String(t.train_effect || ''), String(t.certificate_no || ''), String(t.lmt_service_date || '').slice(0, 10), Number(t.teacher_id) || 0, String(t.teacher_name || '').slice(0, 50), String(t.corp_organize || '').slice(0, 100), String(t.corp_operate || '').slice(0, 100), String(t.note_info || '').slice(0, 500), sysU.id); }
          n++;
        }
        if (Array.isArray(bbody.teachers)) for (const t of bbody.teachers) {
          if (!String(t.teacher_name || '').trim()) continue;
          const ex = db.prepare('SELECT id FROM train_teachers WHERE teacher_name=? AND deleted_at IS NULL').get(String(t.teacher_name));
          if (ex) { db.prepare("UPDATE train_teachers SET teacher_type=?,is_outer=?,skill_info=?,corporate_name=?,dept=?,dept_post=?,mobile_no=?,culture_degree=?,note_info=? WHERE id=?").run(String(t.teacher_type || ''), String(t.is_outer || 'N').slice(0, 2), String(t.skill_info || ''), String(t.corporate_name || ''), String(t.dept || ''), String(t.dept_post || ''), String(t.mobile_no || ''), String(t.culture_degree || ''), String(t.note_info || ''), ex.id); }
          else { db.prepare(`INSERT INTO train_teachers (teacher_name,teacher_type,is_outer,skill_info,corporate_name,dept,dept_post,mobile_no,culture_degree,note_info) VALUES (?,?,?,?,?,?,?,?,?,?)`).run(String(t.teacher_name).slice(0, 50), String(t.teacher_type || ''), String(t.is_outer || 'N').slice(0, 2), String(t.skill_info || ''), String(t.corporate_name || ''), String(t.dept || ''), String(t.dept_post || ''), String(t.mobile_no || ''), String(t.culture_degree || ''), String(t.note_info || '')); }
          nt++;
        }
        if (Array.isArray(bbody.assess)) for (const t of bbody.assess) {
          const ename = (() => { if (!t.emp_id) return ''; const w = db.prepare('SELECT real_name FROM users WHERE work_no=? OR id=?').get(String(t.emp_id), Number(t.emp_id) || 0); return w ? w.real_name : ''; })();
          if (!t.emp_id || !ename) continue;
          db.prepare(`INSERT INTO assess_records (emp_id,emp_name,assess_name,item_name,mark,grade,assessor_name,assess_date,note_info,create_user_id) VALUES (?,?,?,?,?,?,?,?,?,?)`).run(String(t.emp_id), ename, String(t.assess_name || '').slice(0, 100), String(t.item_name || '').slice(0, 100), Number(t.mark) || 0, String(t.grade || '').slice(0, 20), String(t.assessor_name || '').slice(0, 50), String(t.assess_date || '').slice(0, 10), String(t.note_info || '').slice(0, 500), sysU.id);
          na++;
        }
        // v8.2：员工档案子模块导入（卡证 emp_card / 异动 emp_post_move / 奖惩 emp_punishment+emp_prize）
        let nc = 0, nm = 0, nr = 0;
        const clearC = () => { try { db.prepare('DELETE FROM emp_cards').run(); } catch (e) {} };
        const clearM = () => { try { db.prepare('DELETE FROM emp_moves').run(); } catch (e) {} };
        const clearR = () => { try { db.prepare('DELETE FROM emp_rewards').run(); } catch (e) {} };
        if (Array.isArray(bbody.cards)) {
          clearC();
          for (const c of bbody.cards) {
            if (!String(c.emp_id || '').trim() || !String(c.card_no || '').trim()) continue;
            db.prepare(`INSERT INTO emp_cards (emp_id,card_no,card_type,granter,grant_date,invalid_date,state,note_info) VALUES (?,?,?,?,?,?,?,?)`).run(String(c.emp_id), String(c.card_no), String(c.card_type || ''), String(c.granter || ''), String(c.grant_date || '').slice(0, 10), String(c.invalid_date || '').slice(0, 10), String(c.state || ''), String(c.note_info || '').slice(0, 300));
            nc++;
          }
        }
        if (Array.isArray(bbody.moves)) {
          clearM();
          for (const m of bbody.moves) {
            if (!String(m.emp_id || '').trim()) continue;
            db.prepare(`INSERT INTO emp_moves (emp_id,move_type,move_date,o_dept,dept,o_post,dept_post,note_info) VALUES (?,?,?,?,?,?,?,?)`).run(String(m.emp_id), String(m.move_type || '').slice(0, 30), String(m.move_date || '').slice(0, 10), String(m.o_dept || '').slice(0, 100), String(m.dept || '').slice(0, 100), String(m.o_post || '').slice(0, 50), String(m.dept_post || '').slice(0, 50), String(m.note_info || '').slice(0, 300));
            nm++;
          }
        }
        if (Array.isArray(bbody.rewards)) {
          clearR();
          for (const r of bbody.rewards) {
            if (!String(r.emp_id || '').trim()) continue;
            db.prepare(`INSERT INTO emp_rewards (emp_id,kind,r_type,r_date,cause,agree_emp,amount,note_info) VALUES (?,?,?,?,?,?,?,?)`).run(String(r.emp_id), String(r.kind === '奖励' ? '奖励' : '处分'), String(r.r_type || '').slice(0, 50), String(r.r_date || '').slice(0, 10), String(r.cause || '').slice(0, 300), String(r.agree_emp || '').slice(0, 50), Number(r.amount) || 0, String(r.note_info || '').slice(0, 300));
            nr++;
          }
        }
        if (n + nt + na + nc + nm + nr > 0) addRun('oit', 'ok', 'OIT培训对标导入（培训' + n + ' 教员' + nt + ' 考核' + na + ' 卡证' + nc + ' 异动' + nm + ' 奖惩' + nr + '）');
        return ok(res, { trains: n, teachers: nt, assess: na, cards: nc, moves: nm, rewards: nr });
      }
    }
    // v7.9.10 文件内联预览/下载：<img>/<iframe>/<a> 标签无法携带 Authorization 头，
    // 允许这类 GET 通过 ?token= 查询参数鉴权（仅限文件查看/下载类，其余接口不受影响）
    if (req.method === 'GET' && /^\/api\/(files|kb\/files)\/\d+\/(image|raw|download|zip-read)$/.test(p) && !(req.headers['authorization'] || '').startsWith('Bearer ')) {
      try { const qt = new URL(req.url, 'http://localhost').searchParams.get('token'); if (qt) req.headers['authorization'] = 'Bearer ' + qt; } catch (e) {}
    }
    const u = requireAuth(req, res);
    if (!u) return;

    // ---- v6.1 通用限流：每用户 300 次/分钟、每 IP 600 次/分钟（防异常刷接口）----
    if (!rateLimit('api_u' + u.id, 300, 60000) || !rateLimit('api_ip' + clientIp, 600, 60000)) {
      return fail(res, 429, '请求过于频繁，请稍后再试');
    }

    // ---- v4.0 新人写权限全局拦截 ----
    if (typeLevel(u) === 0 && req.method !== 'GET' && !/^\/(api\/logout$|api\/attendance$|api\/approvals$|api\/approvals\/\d+\/cancel$|api\/users\/\d+\/confirm-contract$|api\/me$|api\/messages\/\d+\/read$|api\/profile|api\/leaves$|api\/check-records$|api\/patrols$|api\/signature|api\/drafts|api\/device$|api\/profile-feedback$|api\/tasks|api\/tasks\/\d+$)/.test(p)) {
      return fail(res, 403, '新人仅可查看，操作类功能需先在「审批-发起申请」中提交功能申请，审批通过后即可使用');
    }

    if (p === '/api/me') return ok(res, publicUser(u));

    // ---- v7.9-cloud 云端异步备份同步（仅管理员）----
    if (p === '/api/cloud/config' && req.method === 'GET') {
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      const c = clCfg();
      const okCfg = { url: c.url, keyMask: c.key ? c.key.slice(0, 3) + '****' + c.key.slice(-2) : '', intervalMin: c.intervalMin, last: c.last, seq: c.seq, state: c.state, lastError: c.lastError };
      // 自动备份下次触发时间（每分钟 tick 对 interval 取整）
      return ok(res, okCfg);
    }
    if (p === '/api/cloud/config' && req.method === 'POST') {
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      let body = {}; try { body = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '请求数据格式错误'); }
      const c = clCfg();
      if (body.url !== undefined) { if (typeof body.url !== 'string' || !/^https?:\/\/\S+$/.test(body.url)) return fail(res, 400, '云端地址需以 http(s):// 开头'); c.setVal('cloud_url', body.url); }
      if (body.key !== undefined) { if (typeof body.key !== 'string' || body.key.length < 8) return fail(res, 400, '同步密钥至少 8 位'); c.setVal('cloud_key', body.key); }
      if (body.interval !== undefined) { const n = parseInt(body.interval, 10); if (!n || n < 5 || n > 1440) return fail(res, 400, '间隔需在 5~1440 分钟之间'); c.setVal('cloud_interval', String(n)); }
      if (body.bizUrl !== undefined) { if (typeof body.bizUrl !== 'string' || (body.bizUrl !== '' && !/^https?:\/\/\S+$/.test(body.bizUrl))) return fail(res, 400, '云端业务地址需以 http(s):// 开头'); c.setVal('cloud_biz_url', body.bizUrl.trim()); }
      if (body.bizUrl2 !== undefined) { if (typeof body.bizUrl2 !== 'string' || (body.bizUrl2 !== '' && !/^https?:\/\/\S+$/.test(body.bizUrl2))) return fail(res, 400, '云端业务备用地址需以 http(s):// 开头'); c.setVal('cloud_biz_url2', body.bizUrl2.trim()); }
      if (body.oitTimes !== undefined) { if (typeof body.oitTimes !== 'string' || !/^\d{2}:\d{2}(,\d{2}:\d{2})*$/.test(body.oitTimes.trim())) return fail(res, 400, 'OIT 采集时间段格式：HH:MM,HH:MM（如 08:00,20:00）'); c.setVal('oit_times', body.oitTimes.trim()); }
      if (body.oitScript !== undefined) { if (typeof body.oitScript !== 'string') return fail(res, 400, '采集脚本路径无效'); c.setVal('oit_script', body.oitScript.trim()); }
      const cc = clCfg();
      return ok(res, { saved: true, url: cc.url, intervalMin: cc.intervalMin, bizUrl: cc.bizUrl, oitTimes: cc.oitTimes, keyMask: cc.key ? cc.key.slice(0, 3) + '****' + cc.key.slice(-2) : '' });
    }
    if (p === '/api/cloud/backup' && req.method === 'POST') {
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      const r = await cloudBackup();
      return r.ok ? ok(res, r.data) : fail(res, 500, r.error);
    }
    if (p === '/api/cloud/status' && req.method === 'GET') {
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      const c = clCfg();
      return ok(res, { auto: !!(c.url && c.key), intervalMin: c.intervalMin, last: c.last, seq: c.seq, state: c.state, lastError: c.lastError });
    }
    if (p === '/api/cloud/export' && req.method === 'GET') {
      // 配套小部件：OIT 地址未知/无云端时，导出加密本地备份包（加密密钥=同步密钥，解包需用同一密钥）
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      const c = clCfg();
      if (!c.key) return fail(res, 400, '请先在云端备份配置中设置同步密钥，再导出加密包');
      const pkg = clPack(c);
      const fname = 'dept-backup-' + new Date().toISOString().replace(/[:.]/g, '').slice(0, 15) + '.bin';
      res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Disposition': 'attachment; filename="' + fname + '"', 'Content-Length': pkg.buf.length });
      res.end(pkg.buf);
      return;
    }

    // ---- v7.9-cloud OIT 数据采集（云端业务与备份服务器共用组件；仅管理员/运维可见）----
    if (p === '/api/oit/status' && req.method === 'GET') {
      if (!isAdmin(u)) return fail(res, 403, '仅管理员与运维账号可操作');
      const emp = db.prepare("SELECT COUNT(*) c FROM users WHERE role!='admin' AND deleted_at IS NULL").get();
      const dep = db.prepare('SELECT COUNT(*) c FROM depts').get();
      return ok(res, { employees: emp.c, depts: dep.c, source: 'oit_setup' });
    }
    if (p === '/api/oit/import' && req.method === 'POST') {
      // 双鉴权：管理员/运维 或 同步密钥 Bearer（主服务器自动分发 OIT 包用）
      const bearer = req.headers['authorization'] || '';
      if (!isAdmin(u)) {
        const cfgK = clCfg();
        if (!cfgK.key || bearer !== 'Bearer ' + sha256hex(cfgK.key)) return fail(res, 403, '仅管理员与运维账号可操作（或需同步密钥）');
      }
      let body = {}; try { body = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '数据包格式错误（应为 OIT 采集器导出的 JSON）'); }
      if (!Array.isArray(body.depts) && !Array.isArray(body.users)) return fail(res, 400, '数据包缺少 depts/users 数组');
      const OIT_TYPE_MAP = { '新人': 'xinren', '在职': 'zaizhi', '在职人员': 'zaizhi', '班组长': 'banzuzhang', '部门领导': 'bumenlingdao', '运维': 'weihu', '运维工程师': 'weihu', '管理员': 'admin' };
      let addedD = 0, addedU = 0, updU = 0, skipAdmin = 0;
      const deptIds = {};
      if (Array.isArray(body.depts)) {
        for (const d of body.depts) {
          const name = String(d.name || '').trim();
          if (!name) continue;
          let row = db.prepare('SELECT id FROM depts WHERE name=?').get(name);
          if (!row) { const r = db.prepare('INSERT INTO depts (name) VALUES (?)').run(name); row = { id: r.lastInsertRowid }; addedD++; }
          deptIds[name] = row.id;
        }
      }
      if (Array.isArray(body.users)) {
        for (const u2 of body.users) {
          const code = String(u2.code || '').trim();
          const name = String(u2.name || '').trim();
          if (!code || !name) continue;
          if (code === 'admin' || code === 'admin1' || code === 'admin2') { skipAdmin++; continue; }
          const did = deptIds[String(u2.dept || '').trim()] || null;
          const ut = OIT_TYPE_MAP[String(u2.type || '').trim()] || 'zaizhi';
          const ex = db.prepare('SELECT id, user_type FROM users WHERE username=? OR work_no=?').get(code, code);
          if (ex) {
            db.prepare('UPDATE users SET real_name=?, dept_id=?, user_type=?, work_no=? WHERE id=?').run(name, did, ut, code, ex.id);
            updU++;
          } else {
            const salt = crypto.randomBytes(16).toString('hex');
            const hash = hashPassword(code, salt);
            db.prepare('INSERT INTO users (username,password_hash,salt,real_name,dept_id,role,user_type,work_no,created_at) VALUES (?,?,?,?,?,?,?,?,datetime(\'now\',\'localtime\'))')
              .run(code, hash, salt, name, did, 'member', ut, code);
            addedU++;
          }
        }
      }
      return ok(res, { source: body.source || 'oit_setup', depts_added: addedD, users_added: addedU, users_updated: updU, admin_skipped: skipAdmin, imported_at: new Date().toLocaleString('zh-CN') });
    }

    // ---- v7.9-cloud 运行状态工作台（借鉴 cool-workflow workbench：渲染运行状态与台账，只读）----
    if (p === '/api/system/status' && req.method === 'GET') {
      if (!isAdmin(u)) return fail(res, 403, '仅管理员与运维账号可查看');
      const c = clCfg();
      // 云端业务探活（GET 探活，4 秒超时）
      let biz = { url: c.bizUrl, online: false };
      if (c.bizUrl) {
        try {
          biz.online = await new Promise((resolve) => {
            const bu = new URL(c.bizUrl.replace(/\/$/, '') + '/api/time-sync');
            const mod = bu.protocol === 'https:' ? https : http;
            const rq = mod.get(bu, { timeout: 4000 }, (res) => { try { res.resume(); } catch (e) {} resolve(res.statusCode >= 200 && res.statusCode < 500); });
            rq.on('error', () => resolve(false)); rq.on('timeout', () => { try { rq.destroy(); } catch (e) {} resolve(false); });
          });
        } catch (e) { biz.online = false; }
      }
      const runs = db.prepare('SELECT * FROM system_runs ORDER BY id DESC LIMIT 30').all();
      const uptimeSec = Math.round(process.uptime());
      const emp = db.prepare("SELECT COUNT(*) c FROM users WHERE role!='admin' AND deleted_at IS NULL").get().c;
      const oitData = fs.existsSync(path.join(__dirname, 'data', 'oit-latest.json'));
      return ok(res, {
        server: { port: PORT, version: '7.9-cloud', uptimeSec, state: 'running' },
        main: { url: c.url || '', last: c.last, seq: c.seq, state: c.state, lastError: c.lastError, lastTs: c.lastTs },
        biz: biz,
        oit: { times: c.oitTimes, script: c.oitScript || '', last: c.oitLast || '未采集', hasData: oitData },
        stats: { employees: emp, depts: db.prepare('SELECT COUNT(*) c FROM depts').get().c },
        runs
      });
    }

    // 部门
    if (p === '/api/depts' && req.method === 'GET') return ok(res, db.prepare('SELECT * FROM depts ORDER BY id').all());
    if (p === '/api/depts' && req.method === 'POST') {
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      const b = JSON.parse(await readBody(req));
      if (!b.name) return fail(res, 400, '部门名称不能为空');
      db.prepare('INSERT INTO depts (name) VALUES (?)').run(b.name);
      return ok(res, {});
    }
    if ((dm = p.match(/^\/api\/depts\/(\d+)$/)) && req.method === 'DELETE') {
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      const did = Number(dm[1]);
      const used = db.prepare('SELECT COUNT(*) n FROM users WHERE dept_id=? AND deleted_at IS NULL').get(did).n;
      if (used > 0) return fail(res, 400, '该班组下还有 ' + used + ' 名成员，请先调整人员归属');
      db.prepare('DELETE FROM depts WHERE id=?').run(did);
      return ok(res, {});
    }

    // 用户
    if (p === '/api/users' && req.method === 'GET') {
      const rows = db.prepare(`SELECT u.*, d.name AS dept_name FROM users u LEFT JOIN depts d ON u.dept_id=d.id WHERE u.deleted_at IS NULL ORDER BY u.id`).all();
      return ok(res, rows.map(publicUser));
    }
    if (p === '/api/users' && req.method === 'POST') {
      if (typeLevel(u) < 4) return fail(res, 403, '权限不足：仅运维工程师/管理员可新增用户');
      const b = JSON.parse(await readBody(req));
      const username = b.username || b.work_no || '';
      if (!username || !b.password || !b.real_name) return fail(res, 400, '登录名（工作证编号）/初始密码/姓名必填');
      if (db.prepare('SELECT id FROM users WHERE username=? OR work_no=?').get(username, username)) return fail(res, 400, '登录名或工作证编号已存在');
      const salt = crypto.randomBytes(16).toString('hex');
      const ut = TYPE_LEVEL[b.user_type] !== undefined ? b.user_type : 'xinren';
      db.prepare('INSERT INTO users (username,work_no,password_hash,salt,real_name,dept_id,role,user_type) VALUES (?,?,?,?,?,?,?,?)')
        .run(username, b.work_no || username, hashPassword(b.password, salt), salt, b.real_name, b.dept_id || null, b.role || 'member', ut);
      return ok(res, {});
    }
    let m;
    if ((m = p.match(/^\/api\/users\/(\d+)$/)) && req.method === 'PUT') {
      if (typeLevel(u) < 4) return fail(res, 403, '权限不足：仅运维工程师/管理员可编辑用户');
      const b = JSON.parse(await readBody(req));
      const id = Number(m[1]);
      if (b.password) {
        const salt = crypto.randomBytes(16).toString('hex');
        db.prepare('UPDATE users SET password_hash=?, salt=?, real_name=?, dept_id=?, role=?, work_no=?, user_type=? WHERE id=?')
          .run(hashPassword(b.password, salt), salt, b.real_name, b.dept_id || null, b.role || 'member', b.work_no || '', b.user_type || utype(db.prepare('SELECT * FROM users WHERE id=?').get(id)), id);
      } else {
        db.prepare('UPDATE users SET real_name=?, dept_id=?, role=?, work_no=?, user_type=? WHERE id=?')
          .run(b.real_name, b.dept_id || null, b.role || 'member', b.work_no || '', b.user_type || utype(db.prepare('SELECT * FROM users WHERE id=?').get(id)), id);
      }
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/users\/(\d+)$/)) && req.method === 'DELETE') {
      if (typeLevel(u) < 4) return fail(res, 403, '权限不足：仅运维工程师/管理员可删除用户');
      softDel('users', m[1]); // 软删除进回收站
      db.prepare('DELETE FROM sessions WHERE user_id=?').run(Number(m[1]));
      return ok(res, {});
    }
    // ---- v4.0 人员类型管理 ----
    // 确认签劳动合同（新人本人或管理员/运维）
    if ((m = p.match(/^\/api\/users\/(\d+)\/confirm-contract$/)) && req.method === 'POST') {
      const id = Number(m[1]);
      if (id !== u.id && typeLevel(u) < 3) return fail(res, 403, '仅本人或部门领导及以上可确认劳动合同');
      const tgt = db.prepare('SELECT * FROM users WHERE id=?').get(id);
      if (!tgt) return fail(res, 404, '用户不存在');
      db.prepare("UPDATE users SET contract_signed=1, contract_signed_at=? WHERE id=?")
        .run(nowLocalStr(), id);
      return ok(res, {});
    }
    // 调整人员类型（管理员/运维）
    if ((m = p.match(/^\/api\/users\/(\d+)\/type$/)) && req.method === 'PUT') {
      if (typeLevel(u) < 4) return fail(res, 403, '权限不足：仅运维工程师/管理员可调整人员类型');
      const id = Number(m[1]);
      const b = JSON.parse(await readBody(req));
      if (TYPE_LEVEL[b.user_type] === undefined) return fail(res, 400, '人员类型不合法');
      db.prepare("UPDATE users SET user_type=?, type_updated_at=? WHERE id=?")
        .run(b.user_type, nowLocalStr(), id);
      return ok(res, {});
    }
    // 批量导入人员（与 OIT 保持一致；CSV：姓名,工作证编号,部门,类型(新人/在职/班组长/部门领导/运维工程师)）
    if (p === '/api/users/import' && req.method === 'POST') {
      if (typeLevel(u) < 4) return fail(res, 403, '权限不足：仅运维工程师/管理员可导入人员');
      const b = JSON.parse(await readBody(req));
      const lines = String(b.csv || '').split('\n').map((s) => s.trim()).filter(Boolean);
      let added = 0, skipped = 0;
      const typeMap = { '新人': 'xinren', '在职': 'zaizhi', '在职人员': 'zaizhi', '班组长': 'banzuzhang', '部门领导': 'bumenlingdao', '运维': 'weihu', '运维工程师': 'weihu' };
      for (const line of lines) {
        const parts = line.split(/[,，]/).map((s) => s.trim());
        if (parts.length < 2 || parts[0] === '姓名') continue;
        const [name, workNo, deptName, typeName] = parts;
        if (!name || !workNo) continue;
        if (db.prepare('SELECT id FROM users WHERE work_no=? OR username=?').get(workNo, workNo)) { skipped++; continue; }
        let deptId = null;
        if (deptName) {
          let d = db.prepare('SELECT id FROM depts WHERE name=?').get(deptName);
          if (!d) { db.prepare('INSERT INTO depts (name) VALUES (?)').run(deptName); d = db.prepare('SELECT id FROM depts WHERE name=?').get(deptName); }
          deptId = d.id;
        }
        const salt = crypto.randomBytes(16).toString('hex');
        const ut = typeMap[typeName] || 'xinren';
        db.prepare('INSERT INTO users (username,work_no,password_hash,salt,real_name,dept_id,role,user_type) VALUES (?,?,?,?,?,?,?,?)')
          .run(workNo, workNo, hashPassword(workNo, salt), salt, name, deptId, 'member', ut);
        added++;
      }
      return ok(res, { added, skipped });
    }

    // 培训分类
    if (p === '/api/training-categories' && req.method === 'GET') return ok(res, db.prepare('SELECT * FROM training_categories ORDER BY id').all());
    if (p === '/api/training-categories' && req.method === 'POST') {
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      const b = JSON.parse(await readBody(req));
      if (!b.name) return fail(res, 400, '分类名称不能为空');
      db.prepare('INSERT INTO training_categories (name) VALUES (?)').run(b.name);
      return ok(res, {});
    }

    // 培训记录
    if (p === '/api/trainings' && req.method === 'GET') {
      const rows = db.prepare(`SELECT t.*, us.real_name AS creator_name FROM trainings t LEFT JOIN users us ON t.created_by=us.id WHERE t.deleted_at IS NULL ORDER BY t.train_date DESC, t.id DESC`).all();
      return ok(res, rows);
    }
    if (p === '/api/trainings' && req.method === 'POST') {
      const b = JSON.parse(await readBody(req));
      if (!b.title || !b.category || !b.train_date) return fail(res, 400, '标题/分类/日期必填');
      db.prepare('INSERT INTO trainings (title,category,trainer,train_date,hours,content,participants,created_by) VALUES (?,?,?,?,?,?,?,?)')
        .run(b.title, b.category, b.trainer || '', b.train_date, Number(b.hours) || 0, b.content || '', b.participants || '', u.id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/trainings\/(\d+)$/)) && req.method === 'PUT') {
      const b = JSON.parse(await readBody(req));
      db.prepare('UPDATE trainings SET title=?,category=?,trainer=?,train_date=?,hours=?,content=?,participants=? WHERE id=?')
        .run(b.title, b.category, b.trainer || '', b.train_date, Number(b.hours) || 0, b.content || '', b.participants || '', Number(m[1]));
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/trainings\/(\d+)$/)) && req.method === 'DELETE') {
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      softDel('trainings', m[1]);
      return ok(res, {});
    }

    // 请假类型 + 请假
    if (p === '/api/leave-types' && req.method === 'GET') return ok(res, db.prepare('SELECT * FROM leave_types ORDER BY id').all());
    if (p === '/api/leaves' && req.method === 'GET') {
      const isAdm = isAdmin(u);
      const rows = db.prepare(`SELECT l.*, us.real_name AS user_name, us.dept_id, ap.real_name AS approver_name
        FROM leaves l LEFT JOIN users us ON l.user_id=us.id LEFT JOIN users ap ON l.approver_id=ap.id
        WHERE l.deleted_at IS NULL ORDER BY l.created_at DESC`).all();
      return ok(res, (isAdm ? rows : rows.filter(r => r.user_id === u.id)).map((r) => ({ ...r, chain: chainLabels(r.chain_json), pending_level_name: r.level < (JSON.parse(r.chain_json || '[]')).length ? LEVEL_NAMES[(JSON.parse(r.chain_json || '[]'))[r.level]] : '' })));
    }
    if (p === '/api/leaves' && req.method === 'POST') {
      if (!checkWritePerm(u, 'POST', p, 'leave')) return fail(res, 403, '新人暂未开通请假功能，请在「审批-发起申请」提交功能申请');
      if (!requireSig(u, res, '请假申请')) return;
      const b = JSON.parse(await readBody(req));
      if (!b.type || !b.start_time || !b.end_time) return fail(res, 400, '类型/起止时间必填');
      db.prepare('INSERT INTO leaves (user_id,type,start_time,end_time,reason,chain_json) VALUES (?,?,?,?,?,?)')
        .run(u.id, b.type, b.start_time, b.end_time, b.reason || '', JSON.stringify([2, 3]));
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/leaves\/(\d+)\/approve$/)) && req.method === 'POST') {
      if (!requireSig(u, res, '请假审批')) return;
      const b = JSON.parse(await readBody(req));
      const id = Number(m[1]);
      const lv = db.prepare('SELECT * FROM leaves WHERE id=?').get(id);
      if (!lv) return fail(res, 404, '请假记录不存在');
      if (b.action === 'reject') {
        if (typeLevel(u) < 2) return fail(res, 403, '无权审批');
        rejectFlow(db, 'leaves', id, u, b);
        return ok(res, {});
      }
      if (!approveFlow(db, 'leaves', id, lv, b, u, res)) return;
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/leaves\/(\d+)\/return$/)) && req.method === 'POST') {
      const id = Number(m[1]);
      const lv = db.prepare('SELECT * FROM leaves WHERE id=?').get(id);
      if (!lv || (lv.user_id !== u.id && !isAdmin(u))) return fail(res, 403, '无权操作');
      db.prepare("UPDATE leaves SET status='returned', return_time=datetime('now','localtime') WHERE id=?").run(id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/leaves\/(\d+)$/)) && req.method === 'DELETE') {
      const id = Number(m[1]);
      const lv = db.prepare('SELECT * FROM leaves WHERE id=?').get(id);
      if (!lv || (lv.user_id !== u.id && !isAdmin(u))) return fail(res, 403, '无权删除');
      softDel('leaves', m[1]);
      return ok(res, {});
    }

    // 消息（阅后识别）
    if (p === '/api/messages' && req.method === 'GET') {
      const isAdmin = typeLevel(u) >= 5;
      const rows = db.prepare(`SELECT m.*, us.real_name AS sender_name,
        (SELECT COUNT(*) FROM message_reads mr WHERE mr.message_id=m.id) AS read_count,
        EXISTS(SELECT 1 FROM message_reads mr2 WHERE mr2.message_id=m.id AND mr2.user_id=?) AS my_read
        FROM messages m LEFT JOIN users us ON m.sender_id=us.id WHERE m.deleted_at IS NULL ORDER BY m.id DESC`).all(u.id);
      // 非管理员：消息内容不可见，仅显示提示字符（含运维在内）
      return ok(res, rows.map((r) => {
        if (!isAdmin) {
          const targetOnly = r.send_type === 'single' && r.target_user_id && r.target_user_id !== u.id;
          if (targetOnly) return null;
          return { ...r, content: '🔒 消息内容仅管理员可见', title: r.recalled ? '（已撤回）' + r.title : '新消息·' + r.title, recalled: r.recalled };
        }
        return r;
      }).filter(Boolean));
    }
    if (p === '/api/messages' && req.method === 'POST') {
      if (typeLevel(u) < 2) return fail(res, 403, '无权发送消息');
      const b = JSON.parse(await readBody(req));
      if (!b.title) return fail(res, 400, '标题必填');
      const sendType = b.send_type === 'single' ? 'single' : 'all';
      const targetId = sendType === 'single' ? (Number(b.target_user_id) || null) : null;
      db.prepare('INSERT INTO messages (title,content,sender_id,send_type,target_user_id) VALUES (?,?,?,?,?)')
        .run(b.title, b.content || '', u.id, sendType, targetId);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/messages\/(\d+)\/recall$/)) && req.method === 'POST') {
      // 20 秒内撤回：仅发送者本人或管理员；撤回后内容清空、标题加已撤回标记
      const id = Number(m[1]);
      const msg = db.prepare('SELECT * FROM messages WHERE id=?').get(id);
      if (!msg) return fail(res, 404, '消息不存在');
      if (msg.sender_id !== u.id && typeLevel(u) < 5) return fail(res, 403, '仅发送者或管理员可撤回');
      const created = Date.parse(msg.created_at.replace(' ', 'T'));
      if (Date.now() - created > 20000) return fail(res, 400, '发送已超过 20 秒，无法撤回');
      db.prepare('UPDATE messages SET recalled=1 WHERE id=?').run(id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/messages\/(\d+)\/read$/)) && req.method === 'POST') {
      db.prepare('INSERT OR IGNORE INTO message_reads (message_id,user_id) VALUES (?,?)').run(Number(m[1]), u.id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/messages\/(\d+)$/)) && req.method === 'DELETE') {
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      softDel('messages', m[1]);
      return ok(res, {});
    }
    // 手写签名：查询/保存/季度核验
    if (p === '/api/signature' && req.method === 'GET') {
      const s = getSignature(u);
      return ok(res, { ...(s || {}), valid: signatureValid(u), days_left: s && s.verified_at ? Math.floor(SIGNATURE_QUARTER_DAYS - (Date.now() - new Date(s.verified_at.replace(' ', 'T')).getTime()) / 86400000) : 0 });
    }
    if (p === '/api/signature' && req.method === 'POST') {
      const b = JSON.parse(await readBody(req));
      // v8.3 签名认证：姓名必须与系统登记姓名一致，否则拒绝授权
      const nm = (b.name || '').trim();
      if (!nm) return fail(res, 400, '请填写本人姓名用于签名认证');
      if (nm !== (u.real_name || '').trim()) return fail(res, 403, '姓名与系统登记不一致，签名授权被拒绝');
      let fileId = Number(b.file_id) || null;
      if (!fileId && b.data) {
        const r = saveSignFile(u, b, '签名-' + (u.real_name || u.username) + '.png');
        if (r.err) return fail(res, 400, r.err);
        fileId = r.file_id;
      }
      if (!fileId) return fail(res, 400, '签名图片不能为空');
      db.prepare('INSERT INTO signatures (user_id,file_id,verified_at) VALUES (?,?,?) ON CONFLICT(user_id) DO UPDATE SET file_id=excluded.file_id, verified_at=excluded.verified_at')
        .run(u.id, fileId, nowLocalStr());
      return ok(res, { file_id: fileId });
    }
    if (p === '/api/signature/verify' && req.method === 'POST') {
      // 季度核验：重新确认手写字体（复用现有签名或重新上传）
      const b = JSON.parse(await readBody(req));
      const nm = (b.name || '').trim();
      if (!nm) return fail(res, 400, '请填写本人姓名用于签名核验');
      if (nm !== (u.real_name || '').trim()) return fail(res, 403, '姓名与系统登记不一致，签名核验被拒绝');
      let fileId = Number(b.file_id) || (getSignature(u) || {}).file_id || null;
      if (!fileId && b.data) {
        const r = saveSignFile(u, b, '签名-' + (u.real_name || u.username) + '.png');
        if (r.err) return fail(res, 400, r.err);
        fileId = r.file_id;
      }
      if (!fileId) return fail(res, 400, '尚无签名，请先在手写签名页面完成授权');
      db.prepare('INSERT INTO signatures (user_id,file_id,verified_at) VALUES (?,?,?) ON CONFLICT(user_id) DO UPDATE SET file_id=excluded.file_id, verified_at=excluded.verified_at')
        .run(u.id, fileId, nowLocalStr());
      return ok(res, { file_id: fileId });
    }
    // 草稿箱
    if (p === '/api/drafts' && req.method === 'GET') {
      const rows = db.prepare('SELECT id,feature,updated_at FROM drafts WHERE user_id=? ORDER BY updated_at DESC').all(u.id);
      return ok(res, rows);
    }
    if (p === '/api/drafts' && req.method === 'POST') {
      const b = JSON.parse(await readBody(req));
      if (!b.feature) return fail(res, 400, '功能标识必填');
      db.prepare('INSERT INTO drafts (user_id,feature,payload_json) VALUES (?,?,?) ON CONFLICT(user_id,feature) DO UPDATE SET payload_json=excluded.payload_json, updated_at=datetime(\'now\',\'localtime\')')
        .run(u.id, b.feature, JSON.stringify(b.payload || {}));
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/drafts\/([^/]+)$/)) && req.method === 'GET') {
      const s = db.prepare('SELECT payload_json FROM drafts WHERE user_id=? AND feature=?').get(u.id, m[1]);
      return ok(res, s ? JSON.parse(s.payload_json) : null);
    }
    if ((m = p.match(/^\/api\/drafts\/([^/]+)$/)) && req.method === 'DELETE') {
      db.prepare('DELETE FROM drafts WHERE user_id=? AND feature=?').run(u.id, m[1]);
      return ok(res, {});
    }
    // 手机信息上报
    if (p === '/api/device' && req.method === 'POST') {
      const b = JSON.parse(await readBody(req));
      db.prepare('INSERT INTO device_info (user_id,ua,screen,dpr,cores,platform) VALUES (?,?,?,?,?,?)')
        .run(u.id, String(b.ua || '').slice(0, 300), String(b.screen || ''), String(b.dpr || ''), String(b.cores || ''), String(b.platform || ''));
      return ok(res, {});
    }
    // 个人信息修改反馈（本人提交，管理员查看）
    if (p === '/api/profile-feedback' && req.method === 'POST') {
      const b = JSON.parse(await readBody(req));
      if (!b.content || !String(b.content).trim()) return fail(res, 400, '请填写需要修改的信息及修改后内容');
      db.prepare('INSERT INTO profile_feedback (user_id,content) VALUES (?,?)').run(u.id, String(b.content).trim());
      return ok(res, {});
    }
    if (p === '/api/profile-feedback' && req.method === 'GET') {
      if (typeLevel(u) < 5) return fail(res, 403, '仅管理员可查看反馈');
      return ok(res, db.prepare('SELECT pf.*, us.real_name AS user_name FROM profile_feedback pf LEFT JOIN users us ON pf.user_id=us.id ORDER BY pf.id DESC').all());
    }
    if ((m = p.match(/^\/api\/profile-feedback\/(\d+)$/)) && req.method === 'PUT') {
      if (typeLevel(u) < 5) return fail(res, 403, '仅管理员可处理反馈');
      const b = JSON.parse(await readBody(req));
      db.prepare('UPDATE profile_feedback SET status=? WHERE id=?').run(b.status === 'done' ? 'done' : 'pending', Number(m[1]));
      return ok(res, {});
    }

    // 文件上传/下载


    // ---- v5.7 自然语言检索 / 业务问答（数据不出内网，本地关键词+时间+类型解析） ----
    if (p === '/api/search' && req.method === 'GET') {
      const q = String(url.searchParams.get('q') || '').trim();
      if (!q) return fail(res, 400, '请输入检索内容');
      const ck = 's:' + u.id + ':' + q;
      const C = CACHE[ck];
      if (C && C.exp > Date.now()) return ok(res, C.val);
      const lv = typeLevel(u);
      const now = new Date();
      const Y = now.getFullYear(), M = now.getMonth() + 1, D = now.getDate();
      const iso = (yy, mm, dd) => yy + '-' + String(mm).padStart(2, '0') + '-' + String(dd).padStart(2, '0');
      const today = iso(Y, M, D);
      // ---- 时间范围解析 ----
      let tr = null;
      const parseTR = (s) => {
        if (/今天|今日/.test(s)) return [today, today];
        if (/昨天/.test(s)) { const d = new Date(Y, M - 1, D - 1); return [iso(d.getFullYear(), d.getMonth() + 1, d.getDate()), iso(d.getFullYear(), d.getMonth() + 1, d.getDate())]; }
        if (/本月|这个月/.test(s)) return [iso(Y, M, 1), iso(Y, M, 31)];
        if (/上月|上个月/.test(s)) { const d0 = new Date(Y, M - 2, 1); const d1 = new Date(Y, M - 1, 0); return [iso(d0.getFullYear(), d0.getMonth() + 1, 1), iso(d1.getFullYear(), d1.getMonth() + 1, d1.getDate())]; }
        if (/今年|今年以|本年度|年度/.test(s)) return [iso(Y, 1, 1), iso(Y, 12, 31)];
        if (/去年/.test(s)) return [iso(Y - 1, 1, 1), iso(Y - 1, 12, 31)];
        const mm = s.match(/(\d{1,2})月/);
        if (mm) { const mn = Math.min(12, Math.max(1, parseInt(mm[1], 10))); return [iso(Y, mn, 1), iso(Y, mn, 31)]; }
        const dt = s.match(/(\d{4})-(\d{1,2})-(\d{1,2})/);
        if (dt) { const d2 = iso(+dt[1], +dt[2], +dt[3]); return [d2, d2]; }
        const dn = s.match(/近(\d+)天/);
        if (dn) { const n = parseInt(dn[1], 10); const d0 = new Date(Y, M - 1, D - n + 1); return [iso(d0.getFullYear(), d0.getMonth() + 1, d0.getDate()), today]; }
        const dm = s.match(/近(\d+)个月/);
        if (dm) { const n = parseInt(dm[1], 10); const d0 = new Date(Y, M - 1 - n, 1); return [iso(d0.getFullYear(), d0.getMonth() + 1, 1), today]; }
        return null;
      };
      tr = parseTR(q);
      // ---- 分词：去时间词/类型词/虚词，剩余为检索关键词 ----
      const typeWords = ['培训', '检查', '整改', '问题', '审批', '申请', '会议', '任务', '文件', '资料', '人员', '员工', '奖励', '处罚', '奖惩', '值班', '请假', '休假', '巡逻', '档案', '汇总', '统计', '用车', '台账', '设备', '车辆'];
      const stopWords = ['的', '了', '有', '多少', '几次', '多少人', '什么', '哪些', '帮我', '查', '找', '一下', '统计', '看看', '情况', '记录', '信息', '内容', '怎么', '样', '啊', '呢', '请', '想', '要', '本月', '上月', '今年', '去年', '今天', '昨天', '本月', '年度', '近'];
      let rest = q;
      for (const w of typeWords) rest = rest.split(w).join(' ');
      for (const w of stopWords) rest = rest.split(w).join(' ');
      const tokens = rest.split(/[\s,，。、;；:：\/]+/).map((x) => x.trim()).filter((x) => x.length >= 1);
      // 类型意图
      const wantType = typeWords.filter((w) => q.includes(w));
      const hit = (row, fields) => {
        if (!tokens.length) return true;
        const hay = fields.map((f) => String(row[f] || '')).join(' ');
        return tokens.some((t) => hay.includes(t));
      };
      const inTR = (d) => { if (!tr) return true; const dd = String(d || '').slice(0, 10); return dd >= tr[0] && dd <= tr[1]; };
      const groups = [];
      const typeOfGroup = { person: ['人员', '员工'], train: ['培训'], check: ['检查'], issue: ['整改', '问题'], approval: ['审批', '申请'], meeting: ['会议'], task: ['任务'], file: ['文件', '资料'], reward: ['奖惩', '奖励', '处罚'], duty: ['值班'], leave: ['请假', '休假'], asset: ['台账', '设备', '车辆'] };
      const push = (key, label, items, page) => {
        if (!items.length) return;
        if (!tokens.length && wantType.length && !wantType.some((w) => (typeOfGroup[key] || []).includes(w))) return;
        groups.push({ key, label, items: items.slice(0, 20), page });
      };

      // 人员（本人或管理员/运维全可见；按权限：全员可查基础信息）
      {
        const rows = db.prepare(`SELECT id, real_name, work_no, user_type, username FROM users WHERE real_name != '' AND username NOT LIKE 'T%' ORDER BY id`).all();
        const list = rows.filter((r) => hit(r, ['real_name', 'work_no', 'username']));
        push('person', '人员', list.map((r) => ({ id: r.id, title: r.real_name, meta: (r.work_no || r.username) + ' · ' + (LEVEL_NAMES[typeLevel(r)] || r.user_type) })), 'contact');
      }
      // 培训
      if (lv >= 1) {
        const w1 = tr ? 'WHERE train_date >= ? AND train_date <= ?' : '';
        const p1 = tr ? [tr[0], tr[1]] : [];
        let rows = db.prepare(`SELECT * FROM trainings ${w1} ORDER BY train_date DESC, id DESC LIMIT 300`).all(...p1);
        let list = rows.filter((r) => hit(r, ['title', 'category', 'trainer', 'content']));
        if (!list.length && !tr && tokens.length) {
          rows = db.prepare(`SELECT * FROM trainings WHERE title >= ? AND title < ? LIMIT 300`).all(tokens[0], tokens[0] + '\u{10FFFF}');
          list = rows.filter((r) => hit(r, ['title', 'category', 'trainer', 'content']));
        }
        push('train', '培训', list.map((r) => ({ id: r.id, title: r.title, meta: (r.category || '') + ' · ' + r.train_date + ' · ' + r.hours + '学时 · 教员 ' + r.trainer })), 'train');
      }
      // 检查记录
      if (lv >= 1) {
        const w1 = tr ? 'WHERE cr.check_date >= ? AND cr.check_date <= ?' : '';
        const p1 = tr ? [tr[0], tr[1]] : [];
        const rows = db.prepare(`SELECT cr.*, us.real_name AS checker_name FROM check_records cr LEFT JOIN users us ON cr.checker_id=us.id ${w1} ORDER BY cr.id DESC LIMIT 300`).all(...p1);
        const list = rows.filter((r) => hit(r, ['check_type', 'area', 'summary', 'checklist_name', 'checker_name']));
        push('check', '检查记录', list.map((r) => ({ id: r.id, title: (r.check_type || '检查') + '·' + (r.area || ''), meta: r.check_date + ' · ' + (r.checker_name || '') + ' · ' + (r.result || '') })), 'check');
      }
      // 整改问题
      if (lv >= 1) {
        const w1 = tr ? 'WHERE ci.created_at >= ? AND ci.created_at <= ?' : '';
        const p1 = tr ? [tr[0], tr[1]] : [];
        const rows = db.prepare(`SELECT ci.*, us.real_name AS assignee_name FROM check_issues ci LEFT JOIN users us ON ci.assigned_to=us.id ${w1} ORDER BY ci.id DESC LIMIT 300`).all(...p1);
        const list = rows.filter((r) => hit(r, ['content', 'location', 'status', 'assignee_name']));
        push('issue', '整改问题', list.map((r) => ({ id: r.id, title: r.content, meta: (r.status || '') + ' · 整改人 ' + (r.assignee_name || '') + ' · ' + (r.rectify_deadline || ''), can_notice: lv >= 2 && r.issue_type === 'rectify' && r.status === 'open' && !r.notified_at })), 'check');
      }
      // 审批
      {
        const w1 = tr ? 'WHERE a.created_at >= ? AND a.created_at <= ?' : '';
        const p1 = tr ? [tr[0], tr[1]] : [];
        const rows = db.prepare(`SELECT a.*, us.real_name AS user_name FROM approvals a LEFT JOIN users us ON a.user_id=us.id ${w1} ORDER BY a.id DESC LIMIT 300`).all(...p1);
        let list = rows;
        if (lv < 2) list = rows.filter((r) => r.user_id === u.id);
        list = list.filter((r) => hit(r, ['title', 'type', 'user_name', 'approve_note']));
        push('approval', '审批', list.map((r) => ({ id: r.id, title: '[' + (r.type || '') + '] ' + r.title, meta: (r.status || '') + ' · ' + (r.user_name || '') + ' · ' + r.created_at })), 'approval');
      }
      // 会议纪要
      if (lv >= 2) {
        const w1 = tr ? 'WHERE meet_date >= ? AND meet_date <= ?' : '';
        const p1 = tr ? [tr[0], tr[1]] : [];
        const rows = db.prepare(`SELECT * FROM meetings ${w1} ORDER BY meet_date DESC, id DESC LIMIT 300`).all(...p1);
        const list = rows.filter((r) => hit(r, ['title', 'mtype', 'host', 'summary', 'dissent']));
        push('meeting', '会议纪要', list.map((r) => ({ id: r.id, title: r.title, meta: (r.mtype || '例会') + ' · ' + (r.meet_date || '') + ' · 主持人 ' + (r.host || '') })), 'meeting');
      }
      // 会议任务
      if (lv >= 2) {
        const w1 = tr ? 'WHERE t.due_date >= ? AND t.due_date <= ?' : '';
        const p1 = tr ? [tr[0], tr[1]] : [];
        const rows = db.prepare(`SELECT t.*, us.real_name AS assignee_name FROM tasks t LEFT JOIN users us ON t.assignee_id=us.id ${w1} ORDER BY t.id DESC LIMIT 300`).all(...p1);
        const list = rows.filter((r) => hit(r, ['title', 'content', 'assignee_name', 'priority', 'source']));
        push('task', '会议任务', list.map((r) => ({ id: r.id, title: r.title, meta: (r.status || '') + ' · 负责人 ' + (r.assignee_name || '') + ' · 期限 ' + (r.due_date || '') })), 'task');
      }
      // 奖惩
      if (lv >= 2) {
        const w1 = tr ? 'WHERE r.rdate >= ? AND r.rdate <= ?' : '';
        const p1 = tr ? [tr[0], tr[1]] : [];
        const rows = db.prepare(`SELECT r.*, us.real_name AS user_name FROM rewards r LEFT JOIN users us ON r.user_id=us.id ${w1} ORDER BY r.id DESC LIMIT 300`).all(...p1);
        const list = rows.filter((r) => hit(r, ['title', 'reason', 'user_name', 'category']));
        push('reward', '奖惩', list.map((r) => ({ id: r.id, title: (r.type === 'reward' ? '🏅 ' : '⚠️ ') + r.title, meta: (r.user_name || '') + ' · ' + r.rdate + ' · ' + (r.category || '') })), 'reward');
      }
      // 文件
      {
        const w1 = tr ? 'WHERE f.created_at >= ? AND f.created_at <= ?' : '';
        const p1 = tr ? [tr[0], tr[1]] : [];
        const rows = db.prepare(`SELECT f.*, us.real_name AS uploader_name FROM files f LEFT JOIN users us ON f.uploader_id=us.id ${w1} ORDER BY f.id DESC LIMIT 300`).all(...p1);
        let list = rows.filter((r) => lv >= 5 || r.uploader_id === u.id || (r.min_level || 0) <= lv);
        list = list.filter((r) => hit(r, ['name', 'uploader_name']));
        push('file', '文件', list.map((r) => ({ id: r.id, title: r.name, meta: (r.uploader_name || '') + ' · ' + r.created_at })), 'file');
      }
      // 请假
      {
        const w1 = tr ? 'WHERE l.start_time >= ? AND l.start_time <= ?' : '';
        const p1 = tr ? [tr[0], tr[1]] : [];
        const rows = db.prepare(`SELECT l.*, us.real_name AS user_name FROM leaves l LEFT JOIN users us ON l.user_id=us.id ${w1} ORDER BY l.id DESC LIMIT 300`).all(...p1);
        let list = lv >= 2 ? rows : rows.filter((r) => r.user_id === u.id);
        list = list.filter((r) => hit(r, ['type', 'reason', 'user_name']));
        push('leave', '请销假', list.map((r) => ({ id: r.id, title: '[' + (r.type || '') + '] ' + (r.user_name || ''), meta: (r.status || '') + ' · ' + r.start_time + ' — ' + r.end_time })), 'approval');
      }
      // 车辆台账
      if (lv >= 1) {
        const rows = db.prepare(`SELECT a.* FROM assets a WHERE a.deleted_at IS NULL ORDER BY a.id DESC LIMIT 300`).all();
        const list = rows.filter((r) => hit(r, ['name', 'no', 'category', 'model', 'owner', 'status']));
        push('asset', '车辆/设备', list.map((r) => ({ id: r.id, title: r.name, meta: (r.no || '') + ' · ' + (r.category || '') + ' · ' + (r.status || '') + ' · ' + (r.owner || '') })), 'asset');
      }
      // 值班
      if (lv >= 2) {
        const w1 = tr ? 'WHERE day >= ? AND day <= ?' : '';
        const p1 = tr ? [tr[0], tr[1]] : [];
        const rows = db.prepare(`SELECT * FROM duty_roster ${w1} ORDER BY day DESC, id DESC LIMIT 300`).all(...p1);
        const list = rows.filter((r) => hit(r, ['user_name', 'duty', 'shift', 'phone']));
        push('duty', '值班', list.map((r) => ({ id: r.id, title: r.day + ' ' + (r.shift || ''), meta: (r.user_name || '') + ' · ' + (r.duty || '') + (r.phone ? ' · ' + r.phone : '') })), 'duty');
      }
      // 统计摘要（问句含统计意图）
      let summary = null;
      if (/多少|几次|多少人|统计|完成|汇总/.test(q)) {
        const lines = [];
        if (groups.length) for (const g of groups) lines.push(g.label + ' ' + g.items.length + ' 条');
        else if (wantType.length) for (const w of wantType) { const k = Object.keys(typeOfGroup).find((x) => typeOfGroup[x].includes(w)); if (k) lines.push(w + ' 0 条'); }
        if (lines.length) summary = lines.join('；');
      }
      // ---- 对话式直接回答（智能助手，本地规则引擎） ----
      let answer = null;
      try {
        const T = (r) => db.prepare(r);
        const iso0 = (x) => String(x || '').slice(0, 10);
        if (/待办|待我|超期|我的任务/.test(q)) {
          const pend = db.prepare('SELECT chain_json, level, created_at FROM approvals WHERE status=?').all('pending');
          const isMine = (x) => { try { const c = JSON.parse(x.chain_json || '[]'); return lv >= 2 || c[x.level] === u.id; } catch (e) { return false; } };
          const mine = pend.filter(isMine);
          const nowS = nowLocalStr();
          const aproC = mine.length;
          const ovC = mine.filter((x) => x.created_at < nowS).length;
          const rect = lv >= 1 ? db.prepare('SELECT COUNT(*) c FROM check_issues WHERE status IN (?,?)').get('open', 'submitted') : { c: 0 };
          const due = lv >= 2 ? db.prepare('SELECT COUNT(*) c FROM tasks WHERE status=? AND due_date < ?').get('pending', today) : { c: 0 };
          answer = '待办概览：待审批 ' + aproC + ' 条（其中超期 ' + ovC + '），待整改问题 ' + rect.c + ' 条，超期任务 ' + due.c + ' 项';
        } else if (/培训/.test(q) && /多少|几次|多少人|学时|统计|汇总/.test(q)) {
          const [f0, f1] = tr || ['1900-01-01', '2999-12-31'];
          const rows = db.prepare('SELECT * FROM trainings WHERE train_date >= ? AND train_date <= ?').all(f0, f1);
          const persons = rows.reduce((s, t) => s + (t.participants ? String(t.participants).split(/[,，、\s]+/).filter(Boolean).length : 0), 0);
          const hours = rows.reduce((s, t) => s + (t.hours || 0), 0);
          answer = '共开展培训 ' + rows.length + ' 次，参训 ' + persons + ' 人次，累计 ' + hours + ' 学时';
        } else if (/检查|排查/.test(q) && /多少|几次|统计|汇总/.test(q)) {
          const [f0, f1] = tr || ['1900-01-01', '2999-12-31'];
          const chk = db.prepare('SELECT COUNT(*) c FROM check_records WHERE check_date >= ? AND check_date <= ?').get(f0, f1);
          const iss = db.prepare('SELECT COUNT(*) c FROM check_issues WHERE created_at >= ? AND created_at <= ?').get(f0, f1);
          const done = db.prepare('SELECT COUNT(*) c FROM check_issues WHERE status=? AND created_at >= ? AND created_at <= ?').get('accepted', f0, f1);
          answer = '共检查 ' + chk.c + ' 次，发现问题 ' + iss.c + ' 个，已整改验收 ' + done.c + ' 个';
        } else if (/会议/.test(q) && /多少|几次|统计|汇总/.test(q)) {
          const [f0, f1] = tr || ['1900-01-01', '2999-12-31'];
          const mt = db.prepare('SELECT COUNT(*) c FROM meetings WHERE meet_date >= ? AND meet_date <= ?').get(f0, f1);
          const act = db.prepare('SELECT COUNT(*) c FROM meeting_actions WHERE due_date >= ? AND due_date <= ?').get(f0, f1);
          answer = '共开会 ' + mt.c + ' 次，形成会议任务 ' + act.c + ' 项';
        } else if (/多少人|人员|员工|人数|各部门/.test(q)) {
          const tot = db.prepare('SELECT COUNT(*) c FROM users').get().c;
          const byType = db.prepare('SELECT user_type, COUNT(*) c FROM users GROUP BY user_type').all();
          answer = '在册人员 ' + tot + ' 人（' + byType.map((x) => (LEVEL_NAMES[typeLevel(x)] || x.user_type) + ' ' + x.c + ' 人').join('，') + '）';
        } else if (/请假|休假|销假/.test(q)) {
          const [f0, f1] = tr || ['1900-01-01', '2999-12-31'];
          const rows = lv >= 2
            ? db.prepare('SELECT * FROM leaves WHERE start_time >= ? AND start_time <= ?').all(f0, f1)
            : db.prepare('SELECT * FROM leaves WHERE user_id=? AND start_time >= ? AND start_time <= ?').all(u.id, f0, f1);
          answer = '共 ' + rows.length + ' 条请假记录' + (rows.length ? '（' + rows.map((x) => (x.type || '') + '·' + (x.status || '')).join('，') + '）' : '');
        } else if (/奖惩|奖励|处罚/.test(q) && lv >= 2) {
          const [f0, f1] = tr || ['1900-01-01', '2999-12-31'];
          const rw = db.prepare('SELECT COUNT(*) c FROM rewards WHERE rdate >= ? AND rdate <= ?').get(f0, f1);
          answer = '共 ' + rw.c + ' 条奖惩记录';
        } else if (/值班/.test(q) && lv >= 2) {
          const [f0, f1] = tr || ['1900-01-01', '2999-12-31'];
          const dt = db.prepare('SELECT COUNT(*) c FROM duty_roster WHERE day >= ? AND day <= ?').get(f0, f1);
          answer = '共 ' + dt.c + ' 条值班安排';
        }
      } catch (e) { answer = null; }
      // ---- 工作报告生成（吸收开源ERP"AI生成报告"能力，本地规则引擎） ----
      let report = null;
      try {
        if (/报告|总结/.test(q) && tr) {
          const [f0, f1] = tr;
          const seg = [];
          const label = (f0 === f1 ? f0 : f0 + ' 至 ' + f1);
          if (lv >= 1) {
            const rows = db.prepare('SELECT * FROM trainings WHERE train_date >= ? AND train_date <= ?').all(f0, f1);
            const persons = rows.reduce((s, t) => s + (t.participants ? String(t.participants).split(/[,，、\s]+/).filter(Boolean).length : 0), 0);
            const hours = rows.reduce((s, t) => s + (t.hours || 0), 0);
            seg.push('一、培训：共开展培训 ' + rows.length + ' 次，参训 ' + persons + ' 人次，累计 ' + hours + ' 学时。');
            const chk = db.prepare('SELECT COUNT(*) c FROM check_records WHERE check_date >= ? AND check_date <= ?').get(f0, f1);
            const iss = db.prepare('SELECT COUNT(*) c FROM check_issues WHERE created_at >= ? AND created_at <= ?').get(f0, f1);
            const done = db.prepare('SELECT COUNT(*) c FROM check_issues WHERE status=? AND created_at >= ? AND created_at <= ?').get('accepted', f0, f1);
            const pend = db.prepare('SELECT COUNT(*) c FROM check_issues WHERE status IN (?,?) AND created_at >= ? AND created_at <= ?').get('open', 'submitted', f0, f1);
            seg.push('二、检查：共检查 ' + chk.c + ' 次，发现问题 ' + iss.c + ' 个，已整改验收 ' + done.c + ' 个，待整改 ' + pend.c + ' 个。');
          }
          if (lv >= 2) {
            const mt = db.prepare('SELECT COUNT(*) c FROM meetings WHERE meet_date >= ? AND meet_date <= ?').get(f0, f1);
            const act = db.prepare('SELECT COUNT(*) c FROM meeting_actions WHERE due_date >= ? AND due_date <= ?').get(f0, f1);
            seg.push('三、会议：召开会议 ' + mt.c + ' 次，形成会议任务 ' + act.c + ' 项。');
          }
          const apAll = lv >= 2
            ? db.prepare('SELECT status FROM approvals WHERE created_at >= ? AND created_at <= ?').all(f0, f1)
            : db.prepare('SELECT status FROM approvals WHERE user_id=? AND created_at >= ? AND created_at <= ?').all(u.id, f0, f1);
          const passN = apAll.filter((x) => x.status === 'approved').length;
          const rejN = apAll.filter((x) => x.status === 'rejected').length;
          seg.push('四、审批：共 ' + apAll.length + ' 条（通过 ' + passN + '，驳回 ' + rejN + '）。');
          if (lv >= 2) {
            const rw = db.prepare('SELECT COUNT(*) c FROM rewards WHERE rdate >= ? AND rdate <= ?').get(f0, f1);
            seg.push('五、奖惩：共 ' + rw.c + ' 条。');
            const dt = db.prepare('SELECT COUNT(*) c FROM duty_roster WHERE day >= ? AND day <= ?').get(f0, f1);
            seg.push('六、值班：共 ' + dt.c + ' 条值班安排。');
          }
          const tot = db.prepare('SELECT COUNT(*) c FROM users').get().c;
          seg.push('七、人员：在册 ' + tot + ' 人。');
          report = '【工作报告（' + label + '）】\n' + seg.join('\n');
        }
      } catch (e) { report = null; }
      // ---- 可执行动作（建议→确认→执行闭环；人审查后采纳） ----
      const actions = [];
      if (report) {
        const lbl = tr ? (tr[0] === tr[1] ? tr[0] : tr[0] + ' 至 ' + tr[1]) : '';
        actions.push({ type: 'task', label: '把工作报告加入我的待办', title: '工作报告（' + lbl + '）', content: report });
      }
      if (lv >= 2) for (const g of groups) if (g.key === 'issue') for (const it of g.items) if (it.can_notice) actions.push({ type: 'rectify', issue_id: it.id, label: '生成整改通知：' + String(it.title).slice(0, 22) });
      if (groups.length) actions.push({ type: 'task', label: '把本次检索结论加入我的待办', title: '检索记录：' + q.slice(0, 60), content: groups.map((g) => g.label + ' ' + g.items.length + ' 条').join('；') });
      const out = { q, time_range: tr, groups, summary, answer, report, actions, tokens };
      // 防重复全表扫描：按 用户+关键词 缓存有结果响应（10 秒；空结果不缓存，避免穿透）
      if (groups.length || answer || report) cacheGet('s:' + u.id + ':' + q, 10000, () => out);
      return ok(res, out);
    }

    // ---- v5.6 统一待办中心：聚合审批/检查审核/整改/会议任务，超期标红 ----
    if (p === '/api/todos' && req.method === 'GET') {
      const lv = typeLevel(u);
      const now = Date.now();
      const pT = (s) => { if (!s) return now; const t = s.length === 10 ? s + 'T23:59:59' : s.replace(' ', 'T'); const d = new Date(t); return isNaN(d) ? now : d.getTime(); };
      const todos = [];
      const pushT = (t) => { const sec = now - pT(t.at); todos.push({ ...t, overdue: sec > 0, overdue_days: sec > 0 ? Math.ceil(sec / 86400000) : 0, soon: sec <= 0 && sec > -172800000 }); };
      const chOf = (j) => { try { return JSON.parse(j || '[]'); } catch (e) { return []; } };
      for (const r of db.prepare(`SELECT a.*, us.real_name AS user_name FROM approvals a LEFT JOIN users us ON a.user_id=us.id WHERE a.status='pending' AND a.deleted_at IS NULL ORDER BY a.id DESC`).all()) {
        const ch = chOf(r.chain_json); const need = ch[r.level];
        if (need === undefined || need !== lv || r.user_id === u.id) continue;
        pushT({ kind: 'approval', id: r.id, type: r.type, title: r.title, who: r.user_name, at: r.created_at, level_name: LEVEL_NAMES[need], page: 'approval', act: '去审批', icon: '✅' });
      }
      for (const r of db.prepare(`SELECT cr.*, us.real_name AS user_name FROM check_records cr LEFT JOIN users us ON cr.checker_id=us.id WHERE cr.status='pending' ORDER BY cr.id DESC`).all()) {
        const ch = chOf(r.chain_json); const need = ch[r.level];
        if (need === undefined || need !== lv || r.checker_id === u.id) continue;
        pushT({ kind: 'check', id: r.id, type: r.check_type, title: (r.check_type || '检查') + '·' + (r.area || ''), who: r.user_name, at: r.created_at, level_name: LEVEL_NAMES[need], page: 'check', act: '去审核', icon: '📋' });
      }
      for (const r of db.prepare(`SELECT ci.*, cr.check_type, cr.area AS check_area, us.real_name AS assignee_name FROM check_issues ci LEFT JOIN check_records cr ON ci.check_record_id=cr.id LEFT JOIN users us ON ci.assigned_to=us.id WHERE ci.status IN ('open','submitted') AND ci.deleted_at IS NULL ORDER BY ci.id DESC`).all()) {
        const brief = (r.content || '').slice(0, 24);
        if (r.assigned_to === u.id && r.status === 'open') {
          pushT({ kind: 'rectify', id: r.id, type: '限期整改', title: '整改：' + brief, who: '', at: r.rectify_deadline, level_name: '', page: 'check', act: '提交整改材料', icon: '🔧' });
        } else if (r.status === 'submitted' && lv >= 2 && r.assigned_to !== u.id) {
          pushT({ kind: 'accept', id: r.id, type: '整改验收', title: '验收：' + brief, who: r.assignee_name, at: r.rectify_deadline, level_name: '班组长及以上', page: 'check', act: '验收', icon: '✔️' });
        }
      }
      for (const r of db.prepare(`SELECT * FROM tasks WHERE assignee_id=? AND status='pending' ORDER BY id DESC`).all(u.id)) {
        pushT({ kind: 'task', id: r.id, type: '会议任务', title: r.title, who: '', at: r.due_date || r.created_at, level_name: '', page: 'task', act: '处理', icon: '📌' });
      }
      todos.sort((a, b) => (b.overdue - a.overdue) || (b.sec - a.sec));
      // ---- 工作流建议（吸收开源ERP"工作流建议"能力，本地规则引擎） ----
      const advice = [];
      const ovA = todos.filter((t) => t.kind === 'approval' && t.overdue).length;
      const ap = todos.filter((t) => t.kind === 'approval').length;
      const rect = todos.filter((t) => t.kind === 'rectify').length;
      const acc = todos.filter((t) => t.kind === 'accept').length;
      const tasks = todos.filter((t) => t.kind === 'task').length;
      if (ovA) advice.push('有 ' + ovA + ' 条审批已超期，建议优先处理');
      else if (ap) advice.push('有 ' + ap + ' 条审批待处理');
      if (rect) { const rectOv = todos.filter((t) => t.kind === 'rectify' && t.overdue).length; advice.push('有 ' + rect + ' 项问题待整改' + (rectOv ? '，其中 ' + rectOv + ' 项已超期限' : '')); }
      if (acc) advice.push('有 ' + acc + ' 项整改待验收');
      if (tasks) { const taskOv = todos.filter((t) => t.kind === 'task' && t.overdue).length; advice.push('有 ' + tasks + ' 项会议任务待处理' + (taskOv ? '，其中 ' + taskOv + ' 项已超期' : '')); }
      if (!todos.length) advice.push('当前无待办事项，状态良好');
      const actions = [];
      if (rect) { const first = db.prepare("SELECT id, content FROM check_issues WHERE status IN ('open','submitted') AND issue_type='rectify' AND notified_at='' ORDER BY id DESC LIMIT 1").get(); if (first) actions.push({ type: 'rectify', issue_id: first.id, label: '生成整改通知：' + String(first.content).slice(0, 22) }); }
      if (todos.length) actions.push({ type: 'task', label: '把以上待办整理成我的任务清单', title: '待办提醒：' + todos.length + ' 项待处理', content: advice.join('\n') });
      return ok(res, { todos, count: { total: todos.length, overdue: todos.filter(t => t.overdue).length, soon: todos.filter(t => t.soon).length }, advice, actions });
    }

    // ---- v5.6 车辆/设备台账：台账 / 每日检查 / 使用登记归还 / 维护 ----
    if (p === '/api/assets' && req.method === 'GET') {
      const lv = typeLevel(u);
      if (lv < 1) return fail(res, 403, '新人暂未开通台账模块');
      const rows = db.prepare(`SELECT a.*, u.real_name AS creator_name,
        (SELECT COUNT(*) FROM asset_checks ac WHERE ac.asset_id=a.id) AS check_count,
        (SELECT COUNT(*) FROM asset_uses au2 WHERE au2.asset_id=a.id AND au2.status='使用中') AS in_use
        FROM assets a LEFT JOIN users u ON a.created_by=u.id ORDER BY a.id DESC`).all();
      return ok(res, rows);
    }
    if (p === '/api/assets' && req.method === 'POST') {
      if (typeLevel(u) < 2) return fail(res, 403, '台账新增需班组长及以上权限');
      const b = JSON.parse(await readBody(req));
      if (!b.name) return fail(res, 400, '名称必填');
      db.prepare('INSERT INTO assets (no,name,category,model,status,owner,purchase_date,remark,created_by) VALUES (?,?,?,?,?,?,?,?,?)')
        .run(String(b.no || ''), b.name, String(b.category || '车辆'), String(b.model || ''), String(b.status || '在用'), String(b.owner || ''), String(b.purchase_date || ''), String(b.remark || ''), u.id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/assets\/(\d+)$/)) && req.method === 'PUT') {
      if (typeLevel(u) < 2) return fail(res, 403, '编辑需班组长及以上权限');
      const id = Number(m[1]); const old = db.prepare('SELECT * FROM assets WHERE id=?').get(id);
      if (!old) return fail(res, 404, '台账不存在');
      const b = JSON.parse(await readBody(req));
      db.prepare('UPDATE assets SET no=?, name=?, category=?, model=?, status=?, owner=?, purchase_date=?, remark=? WHERE id=?')
        .run(String(b.no ?? old.no), String(b.name ?? old.name), String(b.category ?? old.category), String(b.model ?? old.model), String(b.status ?? old.status), String(b.owner ?? old.owner), String(b.purchase_date ?? old.purchase_date), String(b.remark ?? old.remark), id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/assets\/(\d+)$/)) && req.method === 'DELETE') {
      if (typeLevel(u) < 4) return fail(res, 403, '删除台账需运维工程师/管理员权限');
      softDel('assets', m[1]);
      return ok(res, {});
    }
    if (p === '/api/asset-checks' && req.method === 'GET') {
      if (typeLevel(u) < 1) return fail(res, 403, '新人暂未开通台账模块');
      const aid = Number(url.searchParams.get('asset_id') || 0);
      const rows = aid ? db.prepare(`SELECT ac.*, a.name AS asset_name, us.real_name AS checker_name FROM asset_checks ac LEFT JOIN assets a ON ac.asset_id=a.id LEFT JOIN users us ON ac.checker_id=us.id WHERE ac.asset_id=? AND ac.deleted_at IS NULL ORDER BY ac.id DESC`).all(aid)
        : db.prepare(`SELECT ac.*, a.name AS asset_name, us.real_name AS checker_name FROM asset_checks ac LEFT JOIN assets a ON ac.asset_id=a.id LEFT JOIN users us ON ac.checker_id=us.id WHERE ac.deleted_at IS NULL ORDER BY ac.id DESC LIMIT 200`).all();
      return ok(res, rows);
    }
    if (p === '/api/asset-checks' && req.method === 'POST') {
      if (typeLevel(u) < 1) return fail(res, 403, '新人暂未开通台账模块');
      const b = JSON.parse(await readBody(req));
      if (!b.asset_id || !b.check_date) return fail(res, 400, '台账与检查日期必填');
      db.prepare('INSERT INTO asset_checks (asset_id,check_date,start_time,end_time,items_json,result,summary,checker_id) VALUES (?,?,?,?,?,?,?,?)')
        .run(Number(b.asset_id), b.check_date, String(b.start_time || ''), String(b.end_time || ''), JSON.stringify(b.items || []), String(b.result || '正常'), String(b.summary || ''), u.id);
      return ok(res, {});
    }
    if (p === '/api/asset-uses' && req.method === 'GET') {
      if (typeLevel(u) < 1) return fail(res, 403, '新人暂未开通台账模块');
      const rows = db.prepare(`SELECT au.*, a.name AS asset_name, us.real_name AS user_name, ap.real_name AS approver_name FROM asset_uses au LEFT JOIN assets a ON au.asset_id=a.id LEFT JOIN users us ON au.user_id=us.id LEFT JOIN users ap ON au.approved_by=ap.id WHERE au.deleted_at IS NULL ORDER BY au.id DESC LIMIT 200`).all();
      return ok(res, rows);
    }
    if (p === '/api/asset-uses' && req.method === 'POST') {
      if (typeLevel(u) < 1) return fail(res, 403, '新人暂未开通台账模块');
      const b = JSON.parse(await readBody(req));
      if (!b.asset_id) return fail(res, 400, '台账必填');
      const a = db.prepare('SELECT * FROM assets WHERE id=?').get(Number(b.asset_id));
      if (!a) return fail(res, 404, '台账不存在');
      if (a.status === '维修中') return fail(res, 400, '该设备维修中，不可使用');
      db.prepare('INSERT INTO asset_uses (asset_id,user_id,purpose,start_time,status,approved_by) VALUES (?,?,?,?,?,?)')
        .run(Number(b.asset_id), u.id, String(b.purpose || ''), String(b.start_time || ''), '使用中', u.id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/asset-uses\/(\d+)\/return$/)) && req.method === 'POST') {
      const id = Number(m[1]); const use = db.prepare('SELECT * FROM asset_uses WHERE id=?').get(id);
      if (!use) return fail(res, 404, '使用记录不存在');
      if (use.user_id !== u.id && typeLevel(u) < 2) return fail(res, 403, '仅使用人本人或班组长及以上可归还');
      if (use.status === '已归还') return fail(res, 400, '已归还');
      const b = JSON.parse(await readBody(req));
      db.prepare('UPDATE asset_uses SET status=?, end_time=? WHERE id=?').run('已归还', String(b.end_time || ''), id);
      return ok(res, {});
    }
    if (p === '/api/asset-repairs' && req.method === 'GET') {
      if (typeLevel(u) < 1) return fail(res, 403, '新人暂未开通台账模块');
      const rows = db.prepare(`SELECT ar.*, a.name AS asset_name, us.real_name AS reporter_name FROM asset_repairs ar LEFT JOIN assets a ON ar.asset_id=a.id LEFT JOIN users us ON ar.reporter_id=us.id WHERE ar.deleted_at IS NULL ORDER BY ar.id DESC LIMIT 100`).all();
      return ok(res, rows);
    }
    if (p === '/api/asset-repairs' && req.method === 'POST') {
      if (typeLevel(u) < 1) return fail(res, 403, '新人暂未开通台账模块');
      const b = JSON.parse(await readBody(req));
      if (!b.asset_id || !b.content) return fail(res, 400, '台账与维修内容必填');
      db.prepare('INSERT INTO asset_repairs (asset_id,content,start_date,status,reporter_id) VALUES (?,?,?,?,?)')
        .run(Number(b.asset_id), b.content, String(b.start_date || ''), '维修中', u.id);
      db.prepare("UPDATE assets SET status='维修中' WHERE id=?").run(Number(b.asset_id));
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/asset-repairs\/(\d+)\/close$/)) && req.method === 'POST') {
      if (typeLevel(u) < 2) return fail(res, 403, '完工确认需班组长及以上权限');
      const id = Number(m[1]); const rep = db.prepare('SELECT * FROM asset_repairs WHERE id=?').get(id);
      if (!rep) return fail(res, 404, '维修记录不存在');
      const b = JSON.parse(await readBody(req));
      db.prepare("UPDATE asset_repairs SET status='已完成', end_date=? WHERE id=?").run(String(b.end_date || ''), id);
      db.prepare("UPDATE assets SET status='在用' WHERE id=?").run(rep.asset_id);
      return ok(res, {});
    }

    if (p === '/api/files' && req.method === 'GET') {
      // v8.3 分类/回收站：按文件夹过滤、回收站与签名档案默认隐藏
      const lv = typeLevel(u);
      const q = String(url.searchParams.get('q') || '').trim();
      const fid = url.searchParams.get('folder');
      const rows = db.prepare(`SELECT f.*, us.real_name AS uploader_name FROM files f LEFT JOIN users us ON f.uploader_id=us.id WHERE f.deleted_at IS NULL ORDER BY f.id DESC`).all();
      let list = rows.filter((r) => lv >= 5 || r.uploader_id === u.id || (r.min_level || 0) <= lv);
      // v8.6.0 指定可见名单：visible_json 非空时仅名单内用户/上传者/管理员可见（优先于 min_level）
      list = list.filter((r) => {
        if (typeLevel(u) >= 5 || r.uploader_id === u.id) return true;
        let vids = [];
        try { vids = JSON.parse(r.visible_json || '[]'); } catch (e) { vids = []; }
        if (Array.isArray(vids) && vids.length) return vids.includes(u.id);
        return (r.min_level || 0) <= lv;
      });
      // 签名档案目录默认不混入共享文件列表（仅管理/运维可通过「签名档案」查看）
      list = list.filter((r) => String(r.folder_id || '') !== '_sig');
      // 修复：folder_id 因 SQLite 数值存储（1.0）与字符串比较不匹配，统一转 Number 比较
      if (fid) list = list.filter((r) => Number(r.folder_id || 0) === Number(fid));
      if (q) {
        const ql = q.toLowerCase();
        list = list.filter((r) => {
          if ((r.name || '').toLowerCase().includes(ql)) return true;
          if ((r.uploader_name || '').toLowerCase().includes(ql)) return true;
          if ((r.created_at || '').includes(q)) return true;
          if (q.startsWith('.') && (r.name || '').toLowerCase().endsWith(q.toLowerCase())) return true;
          return false;
        });
      }
      return ok(res, list.map(r => ({ ...r, stored_name: undefined, signed: !!r.sign_file_id })));
    }
    if (p === '/api/files/folders' && req.method === 'GET') {
      // 文件夹列表（含各文件夹文件计数）
      const folders = db.prepare('SELECT f.*, (SELECT COUNT(*) FROM files x WHERE x.folder_id=f.id AND x.deleted_at IS NULL) AS cnt FROM file_folders f WHERE f.deleted_at IS NULL ORDER BY f.id').all();
      return ok(res, folders);
    }
    if (p === '/api/files/folders' && req.method === 'POST') {
      if (!isAdmin(u)) return fail(res, 403, '仅管理员可新建文件夹');
      const b = JSON.parse(await readBody(req));
      if (!b.name || !String(b.name).trim()) return fail(res, 400, '文件夹名称不能为空');
      db.prepare('INSERT INTO file_folders (name, created_by) VALUES (?,?)').run(String(b.name).trim().slice(0, 30), u.id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/files\/folders\/(\d+)$/)) && req.method === 'DELETE') {
      if (!isAdmin(u)) return fail(res, 403, '仅管理员可删除文件夹');
      db.prepare('UPDATE file_folders SET deleted_at=datetime(\'now\',\'localtime\') WHERE id=?').run(Number(m[1]));
      db.prepare("UPDATE files SET folder_id=NULL WHERE folder_id=? AND deleted_at IS NULL").run(Number(m[1]));
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/files\/(\d+)$/)) && req.method === 'DELETE') {
      const lv = typeLevel(u);
      // 移入回收站（软删）
      const row = db.prepare('SELECT * FROM files WHERE id=? AND deleted_at IS NULL').get(Number(m[1]));
      if (!row) return fail(res, 404, '文件不存在');
      if (lv < 5 && row.uploader_id !== u.id) return fail(res, 403, '仅可删除本人上传的文件');
      db.prepare("UPDATE files SET deleted_at=datetime('now','localtime') WHERE id=?").run(row.id);
      return ok(res, {});
    }
    if (p === '/api/files/trash' && req.method === 'GET') {
      const lv = typeLevel(u);
      if (lv < 5) return fail(res, 403, '仅管理员可查看回收站');
      // 回收站自动清理：删除超过 180 天的文件彻底删除（含磁盘文件）
      const cutS = new Date(Date.now() - 180 * 24 * 3600 * 1000).toISOString().slice(0, 19).replace('T', ' ');
      const olds = db.prepare('SELECT * FROM files WHERE deleted_at IS NOT NULL AND deleted_at < ?').all(cutS);
      for (const o of olds) { try { if (o.stored_name) fs.unlinkSync(path.join(UPLOAD_DIR, o.stored_name)); } catch (e) {} db.prepare('DELETE FROM files WHERE id=?').run(o.id); }
      if (olds.length) console.log('[files] 回收站自动清理超180天文件', olds.length, '个');
      const rows = db.prepare('SELECT f.*, us.real_name AS uploader_name FROM files f LEFT JOIN users us ON f.uploader_id=us.id WHERE f.deleted_at IS NOT NULL ORDER BY f.deleted_at DESC').all();
      return ok(res, rows.map(r => ({ ...r, stored_name: undefined })));
    }
    if ((m = p.match(/^\/api\/files\/(\d+)\/restore$/)) && req.method === 'POST') {
      const lv = typeLevel(u);
      if (lv < 5) return fail(res, 403, '仅管理员可恢复文件');
      db.prepare('UPDATE files SET deleted_at=NULL WHERE id=?').run(Number(m[1]));
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/files\/(\d+)\/purge$/)) && req.method === 'DELETE') {
      const lv = typeLevel(u);
      if (lv < 5) return fail(res, 403, '仅管理员可彻底删除');
      const row = db.prepare('SELECT * FROM files WHERE id=?').get(Number(m[1]));
      if (!row) return fail(res, 404, '文件不存在');
      try { if (row.stored_name) fs.unlinkSync(path.join(UPLOAD_DIR, row.stored_name)); } catch (e) {}
      db.prepare('DELETE FROM files WHERE id=?').run(row.id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/files\/(\d+)\/folder$/)) && req.method === 'PUT') {
      const lv = typeLevel(u);
      const b = JSON.parse(await readBody(req));
      const fid2 = b.folder_id ? Number(b.folder_id) : null;
      const row = db.prepare('SELECT * FROM files WHERE id=? AND deleted_at IS NULL').get(Number(m[1]));
      if (!row) return fail(res, 404, '文件不存在');
      if (lv < 5 && row.uploader_id !== u.id) return fail(res, 403, '仅可移动本人上传的文件');
      db.prepare('UPDATE files SET folder_id=? WHERE id=?').run(fid2, row.id);
      return ok(res, {});
    }
    if (p === '/api/files/batch' && req.method === 'POST') {
      const lv = typeLevel(u);
      // 批量操作：{ids:[], action:'delete'|'restore'|'purge'|'move', folder_id?}
      const b = JSON.parse(await readBody(req));
      const ids = (b.ids || []).map(Number).filter(Boolean);
      if (!ids.length) return fail(res, 400, '请先选择文件');
      if (lv < 5 && !['delete', 'move'].includes(b.action)) return fail(res, 403, '无权限');
      const qs = ids.map(() => '?').join(',');
      if (b.action === 'delete') {
        const own = db.prepare(`SELECT id, uploader_id FROM files WHERE id IN (${qs}) AND deleted_at IS NULL`).all(...ids);
        for (const r0 of own) { if (lv >= 5 || r0.uploader_id === u.id) db.prepare("UPDATE files SET deleted_at=datetime('now','localtime') WHERE id=?").run(r0.id); }
      } else if (b.action === 'restore') {
        db.prepare(`UPDATE files SET deleted_at=NULL WHERE id IN (${qs})`).run(...ids);
      } else if (b.action === 'purge') {
        const rows0 = db.prepare(`SELECT * FROM files WHERE id IN (${qs})`).all(...ids);
        for (const r0 of rows0) { try { if (r0.stored_name) fs.unlinkSync(path.join(UPLOAD_DIR, r0.stored_name)); } catch (e) {} db.prepare('DELETE FROM files WHERE id=?').run(r0.id); }
      } else if (b.action === 'move') {
        const fid2 = b.folder_id ? Number(b.folder_id) : null;
        db.prepare(`UPDATE files SET folder_id=? WHERE id IN (${qs}) AND deleted_at IS NULL`).run(fid2, ...ids);
      }
      return ok(res, { done: ids.length });
    }
    if (p === '/api/files/upload' && req.method === 'POST') {
      if (!checkWritePerm(u, 'POST', p, 'file_upload')) return fail(res, 403, '暂无文件上传权限，请在「审批-发起申请」提交功能申请（功能：文件上传）');
      // 防呆：资料上传需签字认可（附带上传人签名）
      if (!requireSig(u, res, '资料上传签字认可')) return;
      let b;
      try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, e.code === 'BODY_TOO_LARGE' ? '请求体过大（文件超限）' : '请求数据格式错误'); }
      if (!b.name || !b.data) return fail(res, 400, '文件名和内容必填');
      const buf = Buffer.from(b.data, 'base64');
      if (buf.length > MAX_UPLOAD) return fail(res, 400, '文件超过 20MB 限制');
      const safeName = path.basename(String(b.name).replace(/[\\\/:*?"<>|]/g, '_'));
      // v6.2 提示注入/恶意文件防护：扩展名白名单，拒绝可执行与脚本类文件
      const ALLOW_EXT = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.pdf', '.txt', '.md', '.csv', '.zip', '.rar', '.7z', '.tar', '.gz'];
      const ext = path.extname(safeName).toLowerCase();
      if (!ALLOW_EXT.includes(ext)) return fail(res, 400, '不支持的文件类型（' + (ext || '无扩展名') + '）。仅允许办公文档/图片/压缩包；可执行、脚本、网页类文件禁止上传');
      const stored = Date.now() + '_' + crypto.randomBytes(4).toString('hex') + ext;
      fs.writeFileSync(path.join(UPLOAD_DIR, stored), buf);
      const minLevel = [0, 1, 2, 3, 5].includes(Number(b.min_level)) ? Number(b.min_level) : 0;
      const sig = getSignature(u);
      // v8.3 上传分类：folder_id 支持数字ID或新建文件夹名；签名文件归入 _sig 目录
      // v8.5.1 修复：folder_new 必须在 b.folder_id 之外独立判定（前端"＋新建分类"只传 folder_new，原逻辑嵌套导致新分类不生效、文件误入 _sig）
      let folderId = null;
      const fv = String(b.folder_id || '');
      if (fv && /^\d+$/.test(fv) && db.prepare('SELECT id FROM file_folders WHERE id=? AND deleted_at IS NULL').get(Number(fv))) {
        folderId = Number(fv);
      } else if (b.folder_new) {
        const fn = String(b.folder_new).trim().slice(0, 30);
        if (fn) {
          const ex = db.prepare('SELECT id FROM file_folders WHERE name=? AND deleted_at IS NULL').get(fn);
          folderId = ex ? ex.id : Number(db.prepare('INSERT INTO file_folders (name, created_by) VALUES (?,?)').run(fn, u.id).lastInsertRowid);
        }
      }
      const sigFolder = sig ? '_sig' : null;
      const r = db.prepare('INSERT INTO files (name,stored_name,size,uploader_id,share_flag,min_level,sign_file_id,folder_id) VALUES (?,?,?,?,?,?,?,?)')
        .run(safeName, stored, buf.length, u.id, b.share_flag === undefined ? 1 : (b.share_flag ? 1 : 0), minLevel, sig ? sig.file_id : null, folderId || sigFolder);
      return ok(res, { id: Number(r.lastInsertRowid), stored_name: stored });
    }
    // ==================== v6.3 会议录音（上传 → 离线转写 → 自动纪要）====================
    if (p === '/api/audio/upload' && req.method === 'POST') {
      if (!checkWritePerm(u, 'POST', p, 'audio_upload')) return fail(res, 403, '暂无录音上传权限，请在「审批-发起申请」提交功能申请（功能：录音转文字）');
      let b; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, e.code === 'BODY_TOO_LARGE' ? '请求体过大（音频超限）' : '请求数据格式错误'); }
      if (!b.name || !b.data) return fail(res, 400, '文件名和音频内容必填');
      const safeName = path.basename(String(b.name).replace(/[\\\/:*?"<>|]/g, '_'));
      const ext = path.extname(safeName).toLowerCase();
      if (!AUDIO_EXT.includes(ext)) return fail(res, 400, '不支持的音频格式（' + (ext || '无扩展名') + '）。支持 wav/mp3/m4a/aac/ogg/webm/amr');
      const buf = Buffer.from(b.data, 'base64');
      if (!buf.length || buf.length > MAX_UPLOAD) return fail(res, 400, '音频超过 20MB 限制');
      const stored = Date.now() + '_' + crypto.randomBytes(4).toString('hex') + ext;
      fs.writeFileSync(path.join(AUDIO_DIR, stored), buf);
      const r = db.prepare('INSERT INTO audio (title,stored_name,size,created_by) VALUES (?,?,?,?)')
        .run(String(b.title || safeName).slice(0, 120), stored, buf.length, u.id);
      const id = Number(r.lastInsertRowid);
      audioQueue.push({ id, stored }); pumpAudioQueue(); // 异步转写
      return ok(res, { id, status: 'transcribing' });
    }
    if (p === '/api/audio/list' && req.method === 'GET') {
      const rows = db.prepare("SELECT id,title,size,duration,status,error,created_at FROM audio WHERE deleted_at IS NULL AND (created_by=? OR ?>=2) ORDER BY id DESC LIMIT 200").all(u.id, typeLevel(u));
      return ok(res, rows);
    }
    // ---- v7.9 MosMos 融合：专业术语词库（语音转写纠错 + 管理员维护）----
    if (p === '/api/speech/glossary/all' && req.method === 'GET') {
      return ok(res, db.prepare('SELECT * FROM speech_glossary ORDER BY id').all());
    }
    if (p === '/api/speech/glossary' && req.method === 'POST') {
      if (!isAdmin(u)) return fail(res, 403, '仅系统管理员可维护语音词库');
      const b = JSON.parse(await readBody(req));
      if (!b.term || !b.alias) return fail(res, 400, '专业术语与误识别词必填');
      try {
        db.prepare('INSERT INTO speech_glossary (term,alias,note,kind) VALUES (?,?,?,?)')
          .run(String(b.term).trim(), String(b.alias).trim(), b.note || '', b.kind || '通用');
      } catch (e) { return fail(res, 400, '该术语已存在：' + e.message); }
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/speech\/glossary\/(\d+)$/)) && req.method === 'PUT') {
      if (!isAdmin(u)) return fail(res, 403, '仅系统管理员可维护语音词库');
      const id = Number(m[1]);
      const ex = db.prepare('SELECT * FROM speech_glossary WHERE id=?').get(id);
      if (!ex) return fail(res, 404, '词条不存在');
      const b = JSON.parse(await readBody(req));
      db.prepare('UPDATE speech_glossary SET term=?,alias=?,note=?,kind=? WHERE id=?')
        .run(b.term !== undefined ? String(b.term).trim() : ex.term, b.alias !== undefined ? String(b.alias).trim() : ex.alias, b.note !== undefined ? b.note : ex.note, b.kind !== undefined ? b.kind : ex.kind, id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/speech\/glossary\/(\d+)$/)) && req.method === 'DELETE') {
      if (!isAdmin(u)) return fail(res, 403, '仅系统管理员可维护语音词库');
      const id = Number(m[1]);
      if (!db.prepare('SELECT id FROM speech_glossary WHERE id=?').get(id)) return fail(res, 404, '词条不存在');
      db.prepare('DELETE FROM speech_glossary WHERE id=?').run(id);
      return ok(res, {});
    }
    // v7.9：转写文本术语纠错（规则替换，词库由 speech_glossary 维护；前后端本地逻辑一致）
    if (p === '/api/speech/correct' && req.method === 'POST') {
      const b = JSON.parse(await readBody(req));
      const txt = String(b.text || '');
      if (!txt.trim()) return ok(res, { text: txt, hits: [] });
      const rows = db.prepare('SELECT * FROM speech_glossary').all();
      let out = txt; const hits = [];
      for (const r of rows) {
        const aliases = String(r.alias || '').split('|').map((a) => a.trim()).filter(Boolean);
        for (const a of aliases) {
          if (!a) continue;
          const re = new RegExp(a.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
          let cnt = 0; out = out.replace(re, () => { cnt++; return r.term; });
          if (cnt) hits.push({ alias: a, term: r.term, count: cnt });
        }
      }
      return ok(res, { text: out, hits });
    }
    if ((m = p.match(/^\/api\/audio\/(\d+)$/)) && req.method === 'GET') {
      const a = db.prepare('SELECT * FROM audio WHERE id=? AND deleted_at IS NULL').get(Number(m[1]));
      if (!a) return fail(res, 404, '录音不存在');
      if (a.created_by !== u.id && typeLevel(u) < 2) return fail(res, 403, '无权限查看');
      return ok(res, { id: a.id, title: a.title, status: a.status, transcript: a.transcript, summary: a.summary, actions: a.actions, duration: a.duration, size: a.size, error: a.error, created_at: a.created_at });
    }
    if ((m = p.match(/^\/api\/audio\/(\d+)$/)) && req.method === 'DELETE') {
      const a = db.prepare('SELECT * FROM audio WHERE id=? AND deleted_at IS NULL').get(Number(m[1]));
      if (!a) return fail(res, 404, '录音不存在');
      if (a.created_by !== u.id && typeLevel(u) < 2) return fail(res, 403, '无权限删除');
      db.prepare('UPDATE audio SET deleted_at=? WHERE id=?').run(nowLocalStr(), a.id);
      return ok(res, {});
    }
    // 一键生成会议纪要（转写文本 → meetings 表）
    if ((m = p.match(/^\/api\/audio\/(\d+)\/meeting$/)) && req.method === 'POST') {
      const a = db.prepare('SELECT * FROM audio WHERE id=? AND deleted_at IS NULL').get(Number(m[1]));
      if (!a) return fail(res, 404, '录音不存在');
      if (a.created_by !== u.id && typeLevel(u) < 2) return fail(res, 403, '无权限生成纪要');
      if (a.status !== 'done') return fail(res, 400, '录音尚未转写完成，请稍后重试');
      const b = JSON.parse(await readBody(req)) || {};
      const r = db.prepare('INSERT INTO meetings (title,mtype,meet_date,host,attendees,summary,dissent,next_time,created_by) VALUES (?,?,?,?,?,?,?,?,?)')
        .run(String(b.title || a.title || '会议录音').slice(0, 100), String(b.mtype || '例会').slice(0, 20), b.meet_date || new Date().toISOString().slice(0, 10), String(b.host || u.real_name || '').slice(0, 50), String(b.attendees || '').slice(0, 200), String(a.summary || a.transcript || '').slice(0, 4000), String(b.dissent || '').slice(0, 500), String(b.next_time || '').slice(0, 30), u.id);
      if (a.actions) { // 转写中的待办写入会议行动项
        a.actions.split('\n').filter(Boolean).slice(0, 10).forEach((act, i) => {
          db.prepare('INSERT INTO meeting_actions (meeting_id, content, owner, due_date, status) VALUES (?,?,?,?,?)').run(Number(r.lastInsertRowid), String(act).slice(0, 300), '', '', '待办');
        });
      }
      return ok(res, { id: Number(r.lastInsertRowid) });
    }
    // ==================== v6.3 文件转 PDF（可编辑高精度）====================
    if (p === '/api/files/convert2pdf' && req.method === 'POST') {
      if (typeLevel(u) < 2) return fail(res, 403, '暂无文件转换权限');
      let b; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, e.code === 'BODY_TOO_LARGE' ? '请求体过大（文件超限）' : '请求数据格式错误'); }
      if (!b.name || !b.data) return fail(res, 400, '文件名和内容必填');
      const safeName = path.basename(String(b.name).replace(/[\\\/:*?"<>|]/g, '_'));
      const ext = path.extname(safeName).toLowerCase();
      const ALLOW_ALL = OFFICE_EXT.concat(IMG_EXT);
      if (!ALLOW_ALL.includes(ext)) return fail(res, 400, '不支持转 PDF 的类型（' + (ext || '无扩展名') + '）。支持 Office 文档/文本/图片');
      const buf = Buffer.from(b.data, 'base64');
      if (!buf.length || buf.length > MAX_UPLOAD) return fail(res, 400, '文件超过 20MB 限制');
      const tmpSrc = path.join(TMP_DIR, Date.now() + '_' + crypto.randomBytes(4).toString('hex') + ext);
      fs.writeFileSync(tmpSrc, buf);
      try {
        const { dst, mode } = await convertToPdf(safeName, tmpSrc);
        const pdfName = safeName.replace(/\.[^.]+$/, '') + '.pdf';
        const r = db.prepare('INSERT INTO files (name,stored_name,size,uploader_id,share_flag,min_level,sign_file_id) VALUES (?,?,?,?,?,?,?)')
          .run(pdfName, path.basename(dst), fs.statSync(dst).size, u.id, 1, 0, null);
        fs.copyFileSync(dst, path.join(UPLOAD_DIR, path.basename(dst))); // 归入文件存储，走既有下载
        fs.unlinkSync(tmpSrc);
        return ok(res, { id: Number(r.lastInsertRowid), name: pdfName, mode });
      } catch (e) { fs.unlinkSync(tmpSrc); return fail(res, 400, '转换失败：' + e.message); }
    }
    // 照片内联预览（img 标签使用，登录认证即可；下载权限另由 /download 控制）
    if ((m = p.match(/^\/api\/files\/(\d+)\/image$/)) && req.method === 'GET') {
      const f = db.prepare('SELECT * FROM files WHERE id=?').get(Number(m[1]));
      if (!f) return fail(res, 404, '文件不存在');
      if (!canSeeFile(u, f)) return fail(res, 403, '该文件不可见或可见级别高于您的权限');
      // v8.6.0 阅读需申请
      if (f.read_apply && typeLevel(u) < 5 && f.uploader_id !== u.id) {
        const st = db.prepare("SELECT status FROM file_perm_reqs WHERE file_id=? AND user_id=? AND action='read'").get(f.id, u.id);
        if (!st || st.status !== 'approved') return fail(res, 403, '该文件阅读需审批（班组长及以上批准），请先申请权限');
      }
      const fp = path.join(UPLOAD_DIR, f.stored_name);
      if (!fs.existsSync(fp)) return fail(res, 404, '文件已丢失');
      const body = fs.readFileSync(fp);
      const ext = path.extname(f.stored_name).toLowerCase();
      const ct = { '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.gif': 'image/gif', '.webp': 'image/webp' }[ext] || 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': ct, 'Content-Length': body.length, 'Cache-Control': 'private, max-age=60' });
      res.end(body);
      return;
    }
    if ((m = p.match(/^\/api\/files\/(\d+)\/download$/)) && req.method === 'GET') {
      // v4.0：新人无下载权限（除非已申请开通 file_download）
      if (typeLevel(u) === 0 && !db.prepare('SELECT 1 FROM user_grants WHERE user_id=? AND feature=?').get(u.id, 'file_download')) {
        return fail(res, 403, '新人暂无下载权限，请在「审批-发起申请」提交功能申请（功能：文件下载）');
      }
      const f = db.prepare('SELECT * FROM files WHERE id=?').get(Number(m[1]));
      if (!f) return fail(res, 404, '文件不存在');
      // v8.6.0 文件安全：仅在线阅读/禁止下载 → 一律禁止下载
      if (f.readonly || f.no_download) return fail(res, 403, '该文件已设置「仅限在线阅读」，禁止下载（如有需要请联系管理员）');
      // v8.6.0 指定可见名单校验
      if (!canSeeFile(u, f)) return fail(res, 403, '该文件不可见或可见级别高于您的权限');
      // v8.6.0 下载需审批：至少 2 名班组长批准
      if (f.download_apply && typeLevel(u) < 5 && f.uploader_id !== u.id) {
        const st = db.prepare("SELECT status FROM file_perm_reqs WHERE file_id=? AND user_id=? AND action='download'").get(f.id, u.id);
        if (!st || st.status !== 'approved') return fail(res, 403, '该文件下载需审批（至少2名班组长批准），请先申请下载权限');
      }
      // v5.1 下载权限：可见级别不足（非本人上传）禁止下载
      if (typeLevel(u) < 5 && f.uploader_id !== u.id && (f.min_level || 0) > typeLevel(u)) {
        return fail(res, 403, '该文件可见级别高于您的权限，无法下载');
      }
      const fp = path.join(UPLOAD_DIR, f.stored_name);
      if (!fs.existsSync(fp)) return fail(res, 404, '文件已丢失');
      const body = fs.readFileSync(fp);
      const ascii = f.name.replace(/[^\x20-\x7e]/g, '_');
      res.writeHead(200, {
        'Content-Type': 'application/octet-stream',
        'Content-Length': body.length,
        'Content-Disposition': `attachment; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(f.name)}`
      });
      res.end(body);
      return;
    }
    // v8.6.0 文件元数据 + 我的权限状态（前端 openFile 依赖；修复早期缺失该路由导致阅读打不开的隐患）
    if ((m = p.match(/^\/api\/files\/(\d+)$/)) && req.method === 'GET') {
      const f = db.prepare('SELECT * FROM files WHERE id=?').get(Number(m[1]));
      if (!f) return fail(res, 404, '文件不存在');
      if (!canSeeFile(u, f)) return fail(res, 403, '该文件不可见或可见级别高于您的权限');
      return ok(res, { ...f, stored_name: undefined, signed: !!f.sign_file_id, perm: permStatus(u, f) });
    }
    // v8.6.0 管理员：文件安全设置（仅管理员）
    if ((m = p.match(/^\/api\/files\/(\d+)\/secure$/)) && req.method === 'PUT') {
      if (typeLevel(u) < 5) return fail(res, 403, '仅管理员可设置文件安全属性');
      const f = db.prepare('SELECT * FROM files WHERE id=?').get(Number(m[1]));
      if (!f) return fail(res, 404, '文件不存在');
      let b; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '请求数据格式错误'); }
      const bool = (v) => (v ? 1 : 0);
      let vids = [];
      if (b.visible_users !== undefined) {
        try { const arr = Array.isArray(b.visible_users) ? b.visible_users.map(Number) : []; vids = [...new Set(arr.filter((x) => Number.isInteger(x) && x > 0))]; } catch (e) { vids = []; }
      }
      db.prepare('UPDATE files SET no_download=?, readonly=?, watermark=?, read_apply=?, download_apply=?, visible_json=? WHERE id=?')
        .run(bool(b.no_download), bool(b.readonly), bool(b.watermark), bool(b.read_apply), bool(b.download_apply), JSON.stringify(vids), f.id);
      const nf = db.prepare('SELECT * FROM files WHERE id=?').get(f.id);
      return ok(res, { ...nf, stored_name: undefined, perm: permStatus(u, nf) });
    }
    // v8.6.0 阅读/下载权限申请（本人）
    if (p === '/api/files/perm-req' && req.method === 'POST') {
      let b; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '请求数据格式错误'); }
      const fid = Number(b.file_id); const action = String(b.action || '');
      if (!['read', 'download'].includes(action)) return fail(res, 400, 'action 仅支持 read/download');
      const f = db.prepare('SELECT * FROM files WHERE id=?').get(fid);
      if (!f) return fail(res, 404, '文件不存在');
      if (typeLevel(u) >= 5 || f.uploader_id === u.id) return fail(res, 403, '您已具备该权限，无需申请');
      if (action === 'read' && !f.read_apply) return fail(res, 400, '该文件阅读无需申请（可见即可读）');
      if (action === 'download' && !f.download_apply) return fail(res, 400, '该文件下载无需审批申请');
      if (action === 'download' && (f.readonly || f.no_download)) return fail(res, 400, '该文件为「仅限在线阅读」，不开放下载申请');
      const reason = String(b.reason || '').slice(0, 200);
      db.prepare(`INSERT INTO file_perm_reqs (file_id,user_id,action,status,reason) VALUES (?,?,?,'pending',?)
        ON CONFLICT(file_id,user_id,action) DO UPDATE SET status='pending', reason=excluded.reason, updated_at=datetime('now','localtime')`)
        .run(fid, u.id, action, reason);
      return ok(res, { ok: true, message: '已提交申请，等待审批（阅读：1名班组长及以上批准；下载：至少2名班组长批准）' });
    }
    // v8.6.0 审批（班组长及以上）：阅读需 ≥1 名班组长批准；下载需 ≥2 名不同班组长批准
    if ((m = p.match(/^\/api\/files\/perm-req\/(\d+)\/approve$/)) && req.method === 'POST') {
      if (typeLevel(u) < 2) return fail(res, 403, '仅班组长及以上可审批');
      let b; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '请求数据格式错误'); }
      const reqRow = db.prepare('SELECT * FROM file_perm_reqs WHERE id=?').get(Number(m[1]));
      if (!reqRow) return fail(res, 404, '申请不存在');
      if (reqRow.status !== 'pending') return fail(res, 400, '该申请已处理（当前状态：' + reqRow.status + '）');
      const approve = b.approve ? 1 : 0;
      db.prepare('INSERT INTO file_perm_approvals (req_id,approver_id,approve,comment) VALUES (?,?,?,?) ON CONFLICT(req_id,approver_id) DO UPDATE SET approve=excluded.approve, comment=excluded.comment, created_at=datetime(\'now\',\'localtime\')')
        .run(reqRow.id, u.id, approve, String(b.comment || '').slice(0, 200));
      if (approve === 0) {
        db.prepare("UPDATE file_perm_reqs SET status='rejected', updated_at=datetime('now','localtime') WHERE id=?").run(reqRow.id);
      } else {
        const yesCount = db.prepare('SELECT COUNT(*) AS c FROM file_perm_approvals WHERE req_id=? AND approve=1').get(reqRow.id).c;
        const need = reqRow.action === 'read' ? 1 : 2;
        if (yesCount >= need) {
          db.prepare("UPDATE file_perm_reqs SET status='approved', updated_at=datetime('now','localtime') WHERE id=?").run(reqRow.id);
        }
      }
      const now = db.prepare('SELECT status FROM file_perm_reqs WHERE id=?').get(reqRow.id);
      return ok(res, { status: now.status, message: now.status === 'approved' ? '已批准（达到人数要求，权限已开通）' : (approve ? '已同意，还需 ' + (reqRow.action === 'read' ? 1 : 2) + ' 名班组长批准' : '已驳回') });
    }
    // v8.6.0 申请列表：scope=all（班组长+查看全部待批）/ mine（我的申请）
    if (p === '/api/files/perm-reqs' && req.method === 'GET') {
      const scope = url.searchParams.get('scope') || 'all';
      let rows;
      if (scope === 'mine') {
        rows = db.prepare(`SELECT r.*, f.name AS file_name FROM file_perm_reqs r LEFT JOIN files f ON r.file_id=f.id WHERE r.user_id=? ORDER BY r.id DESC`).all(u.id);
      } else {
        if (typeLevel(u) < 2) return fail(res, 403, '仅班组长及以上可查看审批列表');
        rows = db.prepare(`SELECT r.*, f.name AS file_name, us.real_name AS user_name FROM file_perm_reqs r LEFT JOIN files f ON r.file_id=f.id LEFT JOIN users us ON r.user_id=us.id WHERE r.status='pending' ORDER BY r.id DESC`).all();
        rows = rows.map((r) => {
          const yes = db.prepare('SELECT COUNT(*) AS c FROM file_perm_approvals WHERE req_id=? AND approve=1').get(r.id).c;
          const need = r.action === 'read' ? 1 : 2;
          return { ...r, need, approved_count: yes };
        });
      }
      return ok(res, rows);
    }
    // v8.6.0 断点续读：保存/读取当前阅读页码（用户退出后下次打开回到该页）
    if ((m = p.match(/^\/api\/files\/(\d+)\/readmark$/)) && req.method === 'GET') {
      const f = db.prepare('SELECT * FROM files WHERE id=?').get(Number(m[1]));
      if (!f) return fail(res, 404, '文件不存在');
      const r = db.prepare('SELECT page FROM file_readmarks WHERE user_id=? AND file_id=?').get(u.id, f.id);
      return ok(res, { page: r ? r.page : 1 });
    }
    if ((m = p.match(/^\/api\/files\/(\d+)\/readmark$/)) && req.method === 'POST') {
      let b; try { b = JSON.parse(await readBody(req)); } catch (e) { return fail(res, 400, '请求数据格式错误'); }
      const page = Math.max(1, Number(b.page) || 1);
      db.prepare('INSERT INTO file_readmarks (user_id,file_id,page,updated_at) VALUES (?,?,?,datetime(\'now\',\'localtime\')) ON CONFLICT(user_id,file_id) DO UPDATE SET page=excluded.page, updated_at=excluded.updated_at')
        .run(u.id, Number(m[1]), page);
      return ok(res, { ok: true, page });
    }
    // v5.1 在线阅读：raw（PDF/图片/文本内联预览，新人可看不可下）
    // v8.6.0 升级：指定可见名单（visible_json）优先于 min_level；可见性不自动等于可阅读（read_apply 需审批）
    function canSeeFile(u, f) {
      if (typeLevel(u) >= 5 || f.uploader_id === u.id) return true;
      let vids = [];
      try { vids = JSON.parse(f.visible_json || '[]'); } catch (e) { vids = []; }
      if (Array.isArray(vids) && vids.length) return vids.includes(u.id);
      return (f.min_level || 0) <= typeLevel(u);
    }
    // v8.6.0 权限状态：返回当前用户对该文件的阅读/下载权限与申请状态（供前端渲染）
    function permStatus(u, f) {
      const lv = typeLevel(u);
      const mine = lv >= 5 || f.uploader_id === u.id;
      const readReq = db.prepare("SELECT status FROM file_perm_reqs WHERE file_id=? AND user_id=? AND action='read'").get(f.id, u.id);
      const dlReq = db.prepare("SELECT status FROM file_perm_reqs WHERE file_id=? AND user_id=? AND action='download'").get(f.id, u.id);
      const readOK = mine || (!f.read_apply && canSeeFile(u, f)) || (f.read_apply && readReq && readReq.status === 'approved');
      let downloadOK = false;
      if (mine) downloadOK = !(f.readonly || f.no_download);
      else if (readOK && !(f.readonly || f.no_download)) {
        if (lv === 0 && !db.prepare('SELECT 1 FROM user_grants WHERE user_id=? AND feature=?').get(u.id, 'file_download')) { downloadOK = false; }
        else if (!f.download_apply) downloadOK = true;
        else downloadOK = !!(dlReq && dlReq.status === 'approved');
      }
      return {
        can_read: !!readOK,
        can_download: !!downloadOK,
        read_status: readReq ? readReq.status : '',
        download_status: dlReq ? dlReq.status : '',
        read_apply_open: !!f.read_apply,
        download_apply_open: !!f.download_apply,
        no_download: !!(f.readonly || f.no_download),
        readonly: !!f.readonly,
        watermark: !!f.watermark,
        visible_only: (() => { try { return JSON.parse(f.visible_json || '[]').length > 0; } catch (e) { return false; } })()
      };
    }
    const MIME = { '.pdf': 'application/pdf', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.txt': 'text/plain; charset=utf-8', '.md': 'text/plain; charset=utf-8', '.csv': 'text/plain; charset=utf-8', '.json': 'application/json; charset=utf-8', '.html': 'text/html; charset=utf-8', '.htm': 'text/html; charset=utf-8', '.xml': 'text/xml; charset=utf-8' };
    if ((m = p.match(/^\/api\/files\/(\d+)\/raw$/)) && req.method === 'GET') {
      const f = db.prepare('SELECT * FROM files WHERE id=?').get(Number(m[1]));
      if (!f) return fail(res, 404, '文件不存在');
      if (!canSeeFile(u, f)) return fail(res, 403, '该文件不可见或可见级别高于您的权限');
      // v8.6.0 阅读需申请：read_apply=1 且未获班组长批准 → 不可在线阅读
      if (f.read_apply && typeLevel(u) < 5 && f.uploader_id !== u.id) {
        const st = db.prepare("SELECT status FROM file_perm_reqs WHERE file_id=? AND user_id=? AND action='read'").get(f.id, u.id);
        if (!st || st.status !== 'approved') return fail(res, 403, '该文件阅读需审批（班组长及以上批准），请先申请权限');
      }
      const fp = path.join(UPLOAD_DIR, f.stored_name);
      if (!fs.existsSync(fp)) return fail(res, 404, '文件已丢失');
      const body = fs.readFileSync(fp);
      const ext = path.extname(f.name).toLowerCase();
      res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': body.length, 'Cache-Control': 'private, max-age=60' });
      res.end(body);
      return;
    }
    // v5.1 ZIP 在线解压（零依赖 zip 解析）
    function zipEntries(fp) {
      const buf = fs.readFileSync(fp);
      let eocd = -1;
      for (let i = buf.length - 22; i >= Math.max(0, buf.length - 22 - 65536); i--) {
        if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
      }
      if (eocd < 0) throw new Error('不是有效的 ZIP 压缩包');
      const cdCount = buf.readUInt16LE(eocd + 10);
      const cdOffset = buf.readUInt32LE(eocd + 16);
      const entries = [];
      let off = cdOffset;
      for (let n = 0; n < cdCount; n++) {
        if (buf.readUInt32LE(off) !== 0x02014b50) break;
        const method = buf.readUInt16LE(off + 10);
        const compSize = buf.readUInt32LE(off + 20);
        const unSize = buf.readUInt32LE(off + 24);
        const nameLen = buf.readUInt16LE(off + 28);
        const extraLen = buf.readUInt16LE(off + 30);
        const commentLen = buf.readUInt16LE(off + 32);
        const localOff = buf.readUInt32LE(off + 42);
        let name = buf.slice(off + 46, off + 46 + nameLen).toString('utf8');
        if (name.includes('\ufffd')) name = buf.slice(off + 46, off + 46 + nameLen).toString('latin1');
        entries.push({ name, method, compSize, unSize, localOff, dir: name.endsWith('/') });
        off += 46 + nameLen + extraLen + commentLen;
      }
      return entries;
    }
    function zipReadEntry(fp, entry) {
      const buf = fs.readFileSync(fp);
      const lo = entry.localOff;
      if (buf.readUInt32LE(lo) !== 0x04034b50) throw new Error('压缩条目损坏');
      const nameLen = buf.readUInt16LE(lo + 26);
      const extraLen = buf.readUInt16LE(lo + 28);
      const dataStart = lo + 30 + nameLen + extraLen;
      const data = buf.slice(dataStart, dataStart + entry.compSize);
      if (entry.method === 0) return data;
      if (entry.method === 8) return zlib.inflateRawSync(data);
      throw new Error('不支持的压缩方式（' + entry.method + '），请下载后解压');
    }
    if ((m = p.match(/^\/api\/files\/(\d+)\/zip-list$/)) && req.method === 'GET') {
      const f = db.prepare('SELECT * FROM files WHERE id=?').get(Number(m[1]));
      if (!f) return fail(res, 404, '文件不存在');
      if (!canSeeFile(u, f)) return fail(res, 403, '该文件可见级别高于您的权限');
      try {
        const es = zipEntries(path.join(UPLOAD_DIR, f.stored_name));
        return ok(res, es.filter((e) => !e.dir).map((e) => ({ name: e.name, size: e.unSize, comp: e.compSize })));
      } catch (e) { return fail(res, 400, '解压失败：' + e.message); }
    }
    if ((m = p.match(/^\/api\/files\/(\d+)\/zip-read$/)) && req.method === 'GET') {
      const f = db.prepare('SELECT * FROM files WHERE id=?').get(Number(m[1]));
      if (!f) return fail(res, 404, '文件不存在');
      if (!canSeeFile(u, f)) return fail(res, 403, '该文件可见级别高于您的权限');
      const q = new URL(req.url, 'http://localhost').searchParams;
      const item = q.get('path') || '';
      if (!item) return fail(res, 400, '缺少内部路径参数');
      try {
        const es = zipEntries(path.join(UPLOAD_DIR, f.stored_name));
        const e = es.find((x) => x.name === item && !x.dir);
        if (!e) return fail(res, 404, '压缩包内未找到该文件');
        const data = zipReadEntry(path.join(UPLOAD_DIR, f.stored_name), e);
        if (data.length > 10 * 1024 * 1024) return fail(res, 400, '内部文件超过 10MB，请下载后查看');
        const ext = path.extname(e.name).toLowerCase();
        res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': data.length, 'Cache-Control': 'private, max-age=60' });
        res.end(data);
        return;
      } catch (err) { return fail(res, 400, '读取失败：' + err.message); }
    }

    // 数据录入（自定义表单）
    if (p === '/api/forms' && req.method === 'GET') {
      const rows = db.prepare('SELECT * FROM forms ORDER BY id').all();
      return ok(res, rows.map(r => ({ id: r.id, name: r.name, fields: JSON.parse(r.fields_json), created_at: r.created_at })));
    }
    if (p === '/api/forms' && req.method === 'POST') {
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      const b = JSON.parse(await readBody(req));
      if (!b.name) return fail(res, 400, '表单名称必填');
      const fields = Array.isArray(b.fields) ? b.fields : [];
      db.prepare('INSERT INTO forms (name,fields_json) VALUES (?,?)').run(b.name, JSON.stringify(fields));
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/forms\/(\d+)\/records$/)) && req.method === 'GET') {
      const rows = db.prepare('SELECT * FROM form_records WHERE form_id=? ORDER BY id DESC').all(Number(m[1]));
      return ok(res, rows.map(r => ({ id: r.id, form_id: r.form_id, data: JSON.parse(r.data_json), created_at: r.created_at })));
    }
    if ((m = p.match(/^\/api\/forms\/(\d+)\/records$/)) && req.method === 'POST') {
      const b = JSON.parse(await readBody(req));
      db.prepare('INSERT INTO form_records (form_id,data_json,created_by) VALUES (?,?,?)')
        .run(Number(m[1]), JSON.stringify(b.data || {}), u.id);
      return ok(res, {});
    }

    // ==================== v3.0 员工档案 ====================
    if (p === '/api/profiles' && req.method === 'GET') {
      const rows = db.prepare(`SELECT u.id, u.username, u.real_name, u.dept_id, u.role, d.name AS dept_name,
        u.gender, u.nation, u.birth_date, u.mobile, u.education, u.hire_date AS u_hire_date, u.job_title, u.photo,
        pf.position, pf.phone, pf.hire_date, pf.id_number, pf.remark
        FROM users u LEFT JOIN depts d ON u.dept_id=d.id LEFT JOIN profiles pf ON pf.user_id=u.id
        ORDER BY u.id`).all();
      // v6.0 字段脱敏：身份证与手机号仅本人/管理员可见完整号码，其余掩码显示
      const maskPhone = (v) => (v ? String(v).replace(/(\d{3})\d{4}(\d{4})/, '$1****$2') : '');
      return ok(res, rows.map(r => ({
        ...r,
        id_number: (u.id === r.id || isAdmin(u)) ? (r.id_number || '') : (r.id_number ? String(r.id_number).replace(/(?<=\w{4})\w(?=\w{4})/g, '*') : ''),
        mobile: (u.id === r.id || isAdmin(u)) ? (r.mobile || '') : maskPhone(r.mobile),
        phone: (u.id === r.id || isAdmin(u)) ? (r.phone || '') : maskPhone(r.phone)
      })));
    }
    if (p === '/api/profiles/me' && req.method === 'GET') {
      return ok(res, db.prepare('SELECT * FROM profiles WHERE user_id=?').get(u.id) || {});
    }
    if ((m = p.match(/^\/api\/profiles\/(\d+)$/)) && req.method === 'PUT') {
      const b = JSON.parse(await readBody(req));
      const id = Number(m[1]);
      if (id !== u.id && !isAdmin(u)) return fail(res, 403, '无权修改他人档案');
      const ex = db.prepare('SELECT user_id FROM profiles WHERE user_id=?').get(id);
      const vals = [b.position || '', b.phone || '', b.hire_date || '', b.id_number || '', b.remark || ''];
      if (ex) {
        db.prepare('UPDATE profiles SET position=?,phone=?,hire_date=?,id_number=?,remark=? WHERE user_id=?').run(...vals, id);
      } else {
        db.prepare('INSERT INTO profiles (user_id,position,phone,hire_date,id_number,remark) VALUES (?,?,?,?,?,?)').run(id, ...vals);
      }
      return ok(res, {});
    }

    // ==================== v3.0/v4.0 通用审批流（多级） ====================
    if (p === '/api/approvals' && req.method === 'GET') {
      const rows = db.prepare(`SELECT a.*, us.real_name AS user_name, ap.real_name AS approver_name
        FROM approvals a LEFT JOIN users us ON a.user_id=us.id LEFT JOIN users ap ON a.approver_id=ap.id
        WHERE a.deleted_at IS NULL ORDER BY a.id DESC`).all();
      // 普通成员只看自己的申请；班组长及以上可看待本级审批的申请
      let list = rows;
      if (typeLevel(u) < 2) list = rows.filter((r) => r.user_id === u.id);
      return ok(res, list.map((r) => {
        const ch = (() => { try { return JSON.parse(r.chain_json || '[]'); } catch (e) { return []; } })();
        return { ...r, chain: chainLabels(r.chain_json), pending_level_name: r.status === 'pending' && r.level < ch.length ? LEVEL_NAMES[ch[r.level]] : '' };
      }));
    }
    if (p === '/api/approvals' && req.method === 'POST') {
      const b = JSON.parse(await readBody(req));
      if (!b.type || !b.title) return fail(res, 400, '审批类型和标题必填');
      if (typeLevel(u) === 0 && !/功能申请|权限申请/.test(b.type)) return fail(res, 403, '新人仅可发起功能申请，其他申请需先开通对应功能');
      if (!/功能申请|权限申请/.test(b.type) && !requireSig(u, res, b.type + '申请')) return;
      const chain = defaultChain(b.type);
      db.prepare('INSERT INTO approvals (type,title,form_json,user_id,chain_json) VALUES (?,?,?,?,?)')
        .run(b.type, b.title, JSON.stringify(b.form || {}), u.id, JSON.stringify(chain));
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/approvals\/(\d+)\/approve$/)) && req.method === 'POST') {
      if (!requireSig(u, res, '审批签字')) return;
      const b = JSON.parse(await readBody(req));
      const id = Number(m[1]);
      const ap = db.prepare('SELECT * FROM approvals WHERE id=?').get(id);
      if (!ap) return fail(res, 404, '申请不存在');
      if (b.action === 'reject') {
        if (typeLevel(u) < 2) return fail(res, 403, '无权审批');
        rejectFlow(db, 'approvals', id, u, b);
        return ok(res, {});
      }
      if (!approveFlow(db, 'approvals', id, ap, b, u, res)) return;
      // 功能申请通过后自动开通对应功能权限（新人）
      if (/功能申请|权限申请/.test(ap.type)) {
        const f = (() => { try { return JSON.parse(ap.form_json || '{}'); } catch (e) { return {}; } })();
        const feature = f.feature || f['功能代码'] || '';
        if (feature) db.prepare('INSERT OR IGNORE INTO user_grants (user_id, feature) VALUES (?,?)').run(ap.user_id, feature);
      }
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/approvals\/(\d+)\/cancel$/)) && req.method === 'POST') {
      const id = Number(m[1]);
      const ap = db.prepare('SELECT * FROM approvals WHERE id=?').get(id);
      if (!ap || ap.user_id !== u.id) return fail(res, 403, '只能撤销自己的申请');
      db.prepare("UPDATE approvals SET status='cancelled' WHERE id=?").run(id);
      return ok(res, {});
    }

    // ==================== v3.0 培训计划 ====================
    if (p === '/api/training-plans' && req.method === 'GET') return ok(res, db.prepare('SELECT * FROM training_plans WHERE deleted_at IS NULL ORDER BY plan_date DESC, id DESC').all());
    if (p === '/api/training-plans' && req.method === 'POST') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      const b = JSON.parse(await readBody(req));
      if (!b.title || !b.category) return fail(res, 400, '标题/分类必填');
      db.prepare('INSERT INTO training_plans (title,category,plan_date,target,hours,status) VALUES (?,?,?,?,?,?)')
        .run(b.title, b.category, b.plan_date || '', b.target || '', Number(b.hours) || 0, b.status || 'planned');
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/training-plans\/(\d+)$/)) && req.method === 'PUT') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      const b = JSON.parse(await readBody(req));
      db.prepare('UPDATE training_plans SET title=?,category=?,plan_date=?,target=?,hours=?,status=? WHERE id=?')
        .run(b.title, b.category, b.plan_date || '', b.target || '', Number(b.hours) || 0, b.status || 'planned', Number(m[1]));
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/training-plans\/(\d+)$/)) && req.method === 'DELETE') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      softDel('training_plans', m[1]);
      return ok(res, {});
    }

    // ==================== v3.0 培训签到/考核/我的档案 ====================
    if ((m = p.match(/^\/api\/trainings\/(\d+)\/signin$/)) && req.method === 'POST') {
      db.prepare('INSERT OR IGNORE INTO training_signins (training_id,user_id) VALUES (?,?)').run(Number(m[1]), u.id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/trainings\/(\d+)\/signins$/)) && req.method === 'GET') {
      const rows = db.prepare(`SELECT s.*, us.real_name AS user_name FROM training_signins s
        LEFT JOIN users us ON s.user_id=us.id WHERE s.training_id=? ORDER BY s.id`).all(Number(m[1]));
      return ok(res, rows);
    }
    if ((m = p.match(/^\/api\/trainings\/(\d+)\/scores$/)) && req.method === 'GET') {
      const rows = db.prepare(`SELECT s.*, us.real_name AS user_name FROM training_scores s
        LEFT JOIN users us ON s.user_id=us.id WHERE s.training_id=? ORDER BY s.id`).all(Number(m[1]));
      return ok(res, rows);
    }
    if ((m = p.match(/^\/api\/trainings\/(\d+)\/scores$/)) && req.method === 'POST') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      const b = JSON.parse(await readBody(req));
      if (!b.user_id) return fail(res, 400, '参训人员必填');
      db.prepare('INSERT OR REPLACE INTO training_scores (training_id,user_id,score,result,note) VALUES (?,?,?,?,?)')
        .run(Number(m[1]), b.user_id, b.score != null ? Number(b.score) : null, b.result || '', b.note || '');
      return ok(res, {});
    }
    if (p === '/api/my-training' && req.method === 'GET') {
      const signed = db.prepare(`SELECT t.* FROM training_signins s JOIN trainings t ON s.training_id=t.id WHERE s.user_id=? ORDER BY t.train_date DESC`).all(u.id);
      const hours = signed.reduce((a, t) => a + Number(t.hours || 0), 0);
      const scores = db.prepare(`SELECT s.*, t.title AS training_title FROM training_scores s JOIN trainings t ON s.training_id=t.id WHERE s.user_id=? ORDER BY t.train_date DESC`).all(u.id);
      return ok(res, { count: signed.length, hours, list: signed, scores });
    }

    // ==================== v3.0 教员资质 ====================
    if (p === '/api/trainers' && req.method === 'GET') {
      // v8.2：合并 OIT 教员库（train_teachers）与旧 trainers 表，返回统一字段
      const old = db.prepare('SELECT * FROM trainers WHERE deleted_at IS NULL ORDER BY id DESC').all();
      const oit = db.prepare('SELECT * FROM train_teachers WHERE deleted_at IS NULL ORDER BY id DESC').all();
      const merged = old.map((t) => ({ id: t.id, _src: 'old', name: t.name, category: t.category || '', cert_no: t.cert_no || '', cert_date: t.cert_date || '', expire_date: t.expire_date || '', refresh_note: t.refresh_note || '' }));
      for (const t of oit) {
        merged.push({ id: 't' + t.id, _src: 'oit', name: t.teacher_name, category: t.teacher_type || '', cert_no: '', cert_date: '', expire_date: '', refresh_note: '', is_outer: t.is_outer, skill_info: t.skill_info, corporate_name: t.corporate_name, dept: t.dept, dept_post: t.dept_post, mobile_no: t.mobile_no, culture_degree: t.culture_degree, note_info: t.note_info });
      }
      return ok(res, merged);
    }
    if (p === '/api/trainers' && req.method === 'POST') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      const b = JSON.parse(await readBody(req));
      if (!b.name) return fail(res, 400, '姓名必填');
      db.prepare('INSERT INTO trainers (name,category,cert_no,cert_date,expire_date,refresh_note) VALUES (?,?,?,?,?,?)')
        .run(b.name, b.category || '', b.cert_no || '', b.cert_date || '', b.expire_date || '', b.refresh_note || '');
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/trainers\/(\d+)$/)) && req.method === 'PUT') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      const b = JSON.parse(await readBody(req));
      db.prepare('UPDATE trainers SET name=?,category=?,cert_no=?,cert_date=?,expire_date=?,refresh_note=? WHERE id=?')
        .run(b.name, b.category || '', b.cert_no || '', b.cert_date || '', b.expire_date || '', b.refresh_note || '', Number(m[1]));
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/trainers\/(\d+)$/)) && req.method === 'DELETE') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      softDel('trainers', m[1]);
      return ok(res, {});
    }

    // ==================== v3.0 考勤打卡（[需求1] 整块下线）====================
    // [需求1] 2026-11-10 按需求删除考勤打卡功能：所有接口返回 410，前端入口已移除；
    // attendance 表结构与历史数据保留不删，便于日后追溯/导出（不做破坏性删表）。
    if (p === '/api/attendance' || p === '/api/attendance/all') return fail(res, 410, '考勤打卡功能已按需求下线');
// ==================== v3.0 待办任务 ====================
    if (p === '/api/tasks' && req.method === 'GET') {
      const q = url.searchParams.get('scope') || 'mine';
      const rows = db.prepare(`SELECT t.*, cr.real_name AS creator_name, asg.real_name AS assignee_name,
        (SELECT mt.title FROM meeting_actions ma LEFT JOIN meetings mt ON ma.meeting_id=mt.id WHERE ma.id=t.meeting_action_id) AS meeting_title
        FROM tasks t LEFT JOIN users cr ON t.creator_id=cr.id LEFT JOIN users asg ON t.assignee_id=asg.id
        WHERE t.deleted_at IS NULL
        ORDER BY t.status='open' DESC, t.due_date ASC, t.id DESC`).all();
      if (q === 'all' && isApprover(u)) return ok(res, rows);
      return ok(res, rows.filter(r => r.assignee_id === u.id || r.creator_id === u.id));
    }
    if (p === '/api/tasks' && req.method === 'POST') {
      const b = JSON.parse(await readBody(req));
      if (!b.title) return fail(res, 400, '任务标题必填');
      // 防越权：非审批层只能把任务派给自己
      const aid = b.assignee_id ? Number(b.assignee_id) : null;
      if (aid && aid !== u.id && !isApprover(u)) return fail(res, 403, '无权指派任务给他人（仅可给自己建任务）');
      db.prepare('INSERT INTO tasks (title,content,assignee_id,creator_id,due_date,priority) VALUES (?,?,?,?,?,?)')
        .run(b.title, b.content || '', aid, u.id, b.due_date || '', b.priority || 'normal');
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/tasks\/(\d+)$/)) && req.method === 'PUT') {
      const b = JSON.parse(await readBody(req));
      const id = Number(m[1]);
      const t = db.prepare('SELECT * FROM tasks WHERE id=?').get(id);
      if (!t) return fail(res, 404, '任务不存在');
      if (!(t.assignee_id === u.id || t.creator_id === u.id || isAdmin(u))) return fail(res, 403, '无权操作该任务');
      if (b.action === 'done') {
        db.prepare("UPDATE tasks SET status='done' WHERE id=?").run(id);
        if (t.meeting_action_id) db.prepare("UPDATE meeting_actions SET status='已完成' WHERE id=?").run(t.meeting_action_id);
      }
      else if (b.action === 'reopen') {
        db.prepare("UPDATE tasks SET status='open' WHERE id=?").run(id);
        if (t.meeting_action_id) db.prepare("UPDATE meeting_actions SET status='待开始' WHERE id=?").run(t.meeting_action_id);
      }
      else db.prepare('UPDATE tasks SET title=?,content=?,assignee_id=?,due_date=?,priority=? WHERE id=?')
        .run(b.title || t.title, b.content !== undefined ? b.content : t.content, b.assignee_id !== undefined ? b.assignee_id : t.assignee_id, b.due_date !== undefined ? b.due_date : t.due_date, b.priority || t.priority, id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/tasks\/(\d+)$/)) && req.method === 'DELETE') {
      const id = Number(m[1]);
      const t = db.prepare('SELECT * FROM tasks WHERE id=?').get(id);
      if (!t) return fail(res, 404, '任务不存在');
      if (!(t.creator_id === u.id || isAdmin(u))) return fail(res, 403, '只有创建者或管理员可删除');
      softDel('tasks', id);
      return ok(res, {});
    }

    // ==================== v3.0 审计检查与整改台账 ====================
    if (p === '/api/audit-checks' && req.method === 'GET') {
      const rows = db.prepare(`SELECT c.*, us.real_name AS creator_name,
        (SELECT COUNT(*) FROM audit_issues i WHERE i.check_id=c.id AND i.status!='closed') AS open_issues,
        (SELECT COUNT(*) FROM audit_issues i WHERE i.check_id=c.id) AS issue_count
        FROM audit_checks c LEFT JOIN users us ON c.created_by=us.id WHERE c.deleted_at IS NULL ORDER BY c.check_date DESC, c.id DESC`).all();
      return ok(res, rows);
    }
    if (p === '/api/audit-checks' && req.method === 'POST') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      const b = JSON.parse(await readBody(req));
      if (!b.check_date || !b.project) return fail(res, 400, '检查日期/项目必填');
      db.prepare('INSERT INTO audit_checks (check_date,project,area,checker,result,summary,created_by) VALUES (?,?,?,?,?,?,?)')
        .run(b.check_date, b.project, b.area || '', b.checker || '', b.result || 'normal', b.summary || '', u.id);
      return ok(res, {});
    }
    if (p === '/api/audit-issues' && req.method === 'GET') {
      const rows = db.prepare(`SELECT i.*, us.real_name AS owner_name, c.project AS check_project, c.check_date
        FROM audit_issues i LEFT JOIN users us ON i.owner_id=us.id LEFT JOIN audit_checks c ON i.check_id=c.id
        ORDER BY i.status='open' DESC, i.id DESC`).all();
      return ok(res, rows);
    }
    if (p === '/api/audit-issues' && req.method === 'POST') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      const b = JSON.parse(await readBody(req));
      if (!b.problem) return fail(res, 400, '问题描述必填');
      db.prepare('INSERT INTO audit_issues (check_id,problem,owner_id,deadline) VALUES (?,?,?,?)')
        .run(b.check_id || null, b.problem, b.owner_id || null, b.deadline || '');
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/audit-issues\/(\d+)$/)) && req.method === 'PUT') {
      const b = JSON.parse(await readBody(req));
      const id = Number(m[1]);
      const it = db.prepare('SELECT * FROM audit_issues WHERE id=?').get(id);
      if (!it) return fail(res, 404, '问题不存在');
      const act = b.action;
      if (act === 'rectify') {
        if (!(isApprover(u) || it.owner_id === u.id)) return fail(res, 403, '无权操作');
        db.prepare("UPDATE audit_issues SET status='rectifying', measure=?, rectify_at=datetime('now','localtime') WHERE id=?").run(b.measure || '', id);
      } else if (act === 'verify') {
        if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
        db.prepare("UPDATE audit_issues SET status='verified', verify_result=? WHERE id=?").run(b.verify_result || '', id);
      } else if (act === 'close') {
        if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
        db.prepare("UPDATE audit_issues SET status='closed', verify_result=? WHERE id=?").run(b.verify_result || '', id);
      } else if (act === 'edit') {
        if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
        db.prepare('UPDATE audit_issues SET problem=?,owner_id=?,deadline=? WHERE id=?').run(b.problem || it.problem, b.owner_id !== undefined ? b.owner_id : it.owner_id, b.deadline !== undefined ? b.deadline : it.deadline, id);
      } else {
        return fail(res, 400, '未知操作');
      }
      return ok(res, {});
    }

    // ==================== v3.0 值班排班（[需求1] 整块下线）====================
    // [需求1] 2026-11-10 按需求删除值班排班功能：接口返回 410，前端入口已移除；
    // duty_roster 表结构与历史数据保留不删，便于日后追溯。
    if (p === '/api/duty' || /^\/api\/duty\/\d+$/.test(p)) return fail(res, 410, '值班排班功能已按需求下线');
// ==================== v3.1 人事管理：入职追踪 ====================
    if (p === '/api/onboardings' && req.method === 'GET') {
      const rows = db.prepare('SELECT * FROM onboardings WHERE deleted_at IS NULL ORDER BY entry_date IS NULL, entry_date ASC, id DESC').all();
      // 计算准备完成度
      return ok(res, rows.map(r => ({
        ...r,
        ready: r.computer_ready + r.account_ready + r.train_ready,
        days_left: r.entry_date ? Math.ceil((new Date(r.entry_date) - new Date()) / 86400000) : null
      })));
    }
    if (p === '/api/onboardings' && req.method === 'POST') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      const b = JSON.parse(await readBody(req));
      if (!b.name || !b.entry_date) return fail(res, 400, '姓名/入职日期必填');
      db.prepare('INSERT INTO onboardings (name,work_no,position,dept,entry_date,offer_status,bg_check,note) VALUES (?,?,?,?,?,?,?,?)')
        .run(b.name, b.work_no || '', b.position || '', b.dept || '', b.entry_date, b.offer_status || '待发送', b.bg_check || '未开始', b.note || '');
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/onboardings\/(\d+)$/)) && req.method === 'PUT') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      const b = JSON.parse(await readBody(req));
      const id = Number(m[1]);
      const ex = db.prepare('SELECT * FROM onboardings WHERE id=?').get(id);
      if (!ex) return fail(res, 404, '记录不存在');
      const t = b.action;
      if (t === 'mark-ready') {
        db.prepare('UPDATE onboardings SET computer_ready=?,account_ready=?,train_ready=? WHERE id=?')
          .run(b.computer_ready !== undefined ? (b.computer_ready ? 1 : 0) : ex.computer_ready, b.account_ready !== undefined ? (b.account_ready ? 1 : 0) : ex.account_ready, b.train_ready !== undefined ? (b.train_ready ? 1 : 0) : ex.train_ready, id);
      } else if (t === 'onboard') {
        db.prepare("UPDATE onboardings SET status='onboarded' WHERE id=?").run(id);
        // v7.9.12 入职完成 → 自动建档（员工列表可见可登录；初始密码=工号）
        const ob = db.prepare('SELECT * FROM onboardings WHERE id=?').get(id);
        if (ob && ob.name) {
          const workNo = String(ob.work_no || ('RY' + ob.id));
          const did = ob.dept ? ((db.prepare('SELECT id FROM depts WHERE name=?').get(ob.dept) || {}).id || null) : null;
          const exU = db.prepare('SELECT id FROM users WHERE work_no=?').get(workNo);
          if (exU) {
            db.prepare("UPDATE users SET real_name=?,dept_id=?,job_title=?,hire_date=?,deleted_at=NULL,updated_at=datetime('now','localtime') WHERE id=?")
              .run(ob.name, did, ob.position || '', ob.entry_date || null, exU.id);
          } else {
            const salt = crypto.randomBytes(16).toString('hex');
            const hash = hashPassword(workNo, salt);
            db.prepare("INSERT INTO users (username,password_hash,salt,real_name,dept_id,role,user_type,work_no,job_title,hire_date,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,datetime('now','localtime'))")
              .run(workNo, hash, salt, ob.name, did, 'member', 'xinren', workNo, ob.position || '', ob.entry_date || null);
          }
        }
      } else if (t === 'cancel') {
        db.prepare("UPDATE onboardings SET status='cancelled' WHERE id=?").run(id);
      } else {
        db.prepare('UPDATE onboardings SET name=?,position=?,dept=?,entry_date=?,offer_status=?,bg_check=?,note=? WHERE id=?')
          .run(b.name || ex.name, b.position !== undefined ? b.position : ex.position, b.dept !== undefined ? b.dept : ex.dept, b.entry_date || ex.entry_date, b.offer_status || ex.offer_status, b.bg_check || ex.bg_check, b.note !== undefined ? b.note : ex.note, id);
      }
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/onboardings\/(\d+)$/)) && req.method === 'DELETE') {
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      softDel('onboardings', m[1]);
      return ok(res, {});
    }

    // ==================== v3.1 人事管理：离职追踪 ====================
    if (p === '/api/offboardings' && req.method === 'GET') {
      const rows = db.prepare('SELECT * FROM offboardings WHERE deleted_at IS NULL ORDER BY leave_date IS NULL, leave_date DESC, id DESC').all();
      return ok(res, rows.map(r => ({ ...r, ready: r.project_handover + r.permission_reclaim + r.device_return + r.social_insurance })));
    }
    if (p === '/api/offboardings' && req.method === 'POST') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      const b = JSON.parse(await readBody(req));
      if (!b.name || !b.leave_date) return fail(res, 400, '姓名/离职日期必填');
      db.prepare('INSERT INTO offboardings (name,leave_date,handover_person,doc_link,note) VALUES (?,?,?,?,?)')
        .run(b.name, b.leave_date, b.handover_person || '', b.doc_link || '', b.note || '');
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/offboardings\/(\d+)$/)) && req.method === 'PUT') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      const b = JSON.parse(await readBody(req));
      const id = Number(m[1]);
      const ex = db.prepare('SELECT * FROM offboardings WHERE id=?').get(id);
      if (!ex) return fail(res, 404, '记录不存在');
      const t = b.action;
      if (t === 'mark-ready') {
        db.prepare('UPDATE offboardings SET project_handover=?,permission_reclaim=?,device_return=?,social_insurance=?,doc_link=? WHERE id=?')
          .run(b.project_handover !== undefined ? (b.project_handover ? 1 : 0) : ex.project_handover, b.permission_reclaim !== undefined ? (b.permission_reclaim ? 1 : 0) : ex.permission_reclaim, b.device_return !== undefined ? (b.device_return ? 1 : 0) : ex.device_return, b.social_insurance !== undefined ? (b.social_insurance ? 1 : 0) : ex.social_insurance, b.doc_link !== undefined ? b.doc_link : ex.doc_link, id);
      } else if (t === 'done') {
        db.prepare("UPDATE offboardings SET status='done' WHERE id=?").run(id);
        // v7.9.12 离职完成 → 停用账号（通讯录/列表不再显示，保留档案）
        const ob2 = db.prepare('SELECT * FROM offboardings WHERE id=?').get(id);
        if (ob2 && ob2.name) {
          const ux = db.prepare('SELECT id FROM users WHERE real_name=? AND deleted_at IS NULL').get(ob2.name);
          if (ux) db.prepare("UPDATE users SET deleted_at=datetime('now','localtime'), updated_at=datetime('now','localtime') WHERE id=?").run(ux.id);
        }
      } else if (t === 'cancel') {
        db.prepare("UPDATE offboardings SET status='cancelled' WHERE id=?").run(id);
      } else {
        db.prepare('UPDATE offboardings SET name=?,leave_date=?,handover_person=?,doc_link=?,note=? WHERE id=?')
          .run(b.name || ex.name, b.leave_date || ex.leave_date, b.handover_person !== undefined ? b.handover_person : ex.handover_person, b.doc_link !== undefined ? b.doc_link : ex.doc_link, b.note !== undefined ? b.note : ex.note, id);
      }
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/offboardings\/(\d+)$/)) && req.method === 'DELETE') {
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      softDel('offboardings', m[1]);
      return ok(res, {});
    }

    // ==================== v6.1 招聘面试登记 ====================
    if (p === '/api/interviews' && req.method === 'GET') {
      const rows = db.prepare('SELECT * FROM interviews WHERE deleted_at IS NULL ORDER BY interview_date IS NULL, interview_date DESC, id DESC').all();
      return ok(res, rows);
    }
    if (p === '/api/interviews' && req.method === 'POST') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      const b = JSON.parse(await readBody(req));
      if (!b.candidate) return fail(res, 400, '候选人姓名必填');
      const r = db.prepare('INSERT INTO interviews (candidate,position,dept,interviewer,interview_date,result,offer_status,note,created_by) VALUES (?,?,?,?,?,?,?,?,?)')
        .run(b.candidate, b.position || '', b.dept || '', b.interviewer || '', b.interview_date || '', b.result || '待面试', b.offer_status || '未发送', b.note || '', u.id);
      return ok(res, { id: r.lastInsertRowid });
    }
    if ((m = p.match(/^\/api\/interviews\/(\d+)$/)) && req.method === 'PUT') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      const b = JSON.parse(await readBody(req));
      const id = Number(m[1]);
      const ex = db.prepare('SELECT * FROM interviews WHERE id=?').get(id);
      if (!ex) return fail(res, 404, '记录不存在');
      const t = b.action;
      if (t === 'to-onboarding') {
        // 面试通过并接受 offer → 一键转入职登记（与入职模块打通）
        if (ex.candidate) {
          db.prepare('INSERT INTO onboardings (name,position,dept,entry_date,offer_status,note) VALUES (?,?,?,?,?,?)')
            .run(ex.candidate, ex.position || '', ex.dept || '', b.entry_date || '', ex.offer_status && ex.offer_status !== '未发送' ? ex.offer_status : '待发送', '来源：招聘面试（' + ex.interviewer + '，' + (ex.interview_date || '') + '）' + (ex.note ? '；' + ex.note : ''));
          db.prepare("UPDATE interviews SET result='已入职', offer_status=? WHERE id=?").run(b.offer_status || ex.offer_status, id);
        }
      } else {
        db.prepare('UPDATE interviews SET candidate=?,position=?,dept=?,interviewer=?,interview_date=?,result=?,offer_status=?,note=? WHERE id=?')
          .run(b.candidate || ex.candidate, b.position !== undefined ? b.position : ex.position, b.dept !== undefined ? b.dept : ex.dept, b.interviewer !== undefined ? b.interviewer : ex.interviewer, b.interview_date !== undefined ? b.interview_date : ex.interview_date, b.result || ex.result, b.offer_status || ex.offer_status, b.note !== undefined ? b.note : ex.note, id);
      }
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/interviews\/(\d+)$/)) && req.method === 'DELETE') {
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      softDel('interviews', m[1]);
      return ok(res, {});
    }
    // ---- v6.1 面试扫码填写：生成二维码令牌（负责人以上），表单字段可配置（参考 OIT 人员档案）----
    if (p === '/api/interviews/qr' && req.method === 'POST') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      const token = crypto.randomBytes(12).toString('hex');
      const exp = new Date(Date.now() + 30 * 60000).toISOString().slice(0, 19).replace('T', ' ');
      db.prepare('INSERT INTO configs (k,v) VALUES (?,?)').run('iv_qr_' + token, JSON.stringify({ exp, by: u.id, at: nowLocalStr() }));
      const host = req.headers['host'] || (localIP() + ':8090');
      const proto = 'http';
      const url = proto + '://' + host + '/iv-form.html?t=' + token;
      return ok(res, { token, url, expire: exp, host });
    }
    // 表单字段配置（负责人以上可调整）
    if (p === '/api/iv/cfg' && req.method === 'GET') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      try { return ok(res, JSON.parse(db.prepare('SELECT v FROM configs WHERE k=?').get('iv_form_cfg').v || '{}')); } catch (e2) { return ok(res, { fields: DEFAULT_IV_FIELDS }); }
    }
    if (p === '/api/iv/cfg' && req.method === 'PUT') {
      if (!isApprover(u)) return fail(res, 403, '需要负责人权限');
      const b = JSON.parse(await readBody(req));
      if (!Array.isArray(b.fields) || !b.fields.length) return fail(res, 400, '字段列表不能为空');
      for (const f of b.fields) {
        if (!f.key || !f.label) return fail(res, 400, '每个字段需包含 key 与 label');
        f.required = !!f.required;
      }
      const existing = db.prepare('SELECT id FROM configs WHERE k=?').get('iv_form_cfg');
      if (existing) db.prepare('UPDATE configs SET v=? WHERE k=?').run(JSON.stringify({ title: b.title || '招聘面试登记', fields: b.fields, note: b.note || '' }), 'iv_form_cfg');
      else db.prepare('INSERT INTO configs (k,v) VALUES (?,?)').run('iv_form_cfg', JSON.stringify({ title: b.title || '招聘面试登记', fields: b.fields, note: b.note || '' }));
      return ok(res, {});
    }

    // ==================== v3.1 会议纪要 ====================
    if (p === '/api/meetings' && req.method === 'GET') {
      // 会议决策分权：审批层/admin 看全部；其他人员只看自己创建或负责行动项的会议
      const rows = db.prepare(`SELECT mt.*, us.real_name AS creator_name,
        (SELECT COUNT(*) FROM meeting_actions ma WHERE ma.meeting_id=mt.id) AS action_count,
        (SELECT COUNT(*) FROM meeting_actions ma WHERE ma.meeting_id=mt.id AND ma.status!='已完成') AS open_action_count
        FROM meetings mt LEFT JOIN users us ON mt.created_by=us.id WHERE mt.deleted_at IS NULL ORDER BY mt.meet_date DESC, mt.id DESC`).all();
      // [需求10] 可见范围：审批层看全部；其他人看自己发起、被指派行动项、以及被指定参会（meeting_attendees）的会议
      const visible = isApprover(u) ? rows : rows.filter((m) => m.created_by === u.id ||
        db.prepare('SELECT 1 FROM meeting_actions WHERE meeting_id=? AND assignee_id=?').get(m.id, u.id) ||
        db.prepare('SELECT 1 FROM meeting_attendees WHERE meeting_id=? AND user_id=?').get(m.id, u.id));
      return ok(res, visible);
    }
    if (p === '/api/meetings' && req.method === 'POST') {
      // [需求10] 视频会议：按「全员 / 班组 / 个人」三种范围发起，支持预约开会时间与时长（0=不限）
      //   全员会：部门领导及以上（typeLevel>=3）；班组会：班组长及以上（默认本班组，可另行指定其他班组人员）；个人会：任意登录用户
      const b = JSON.parse(await readBody(req));
      if (!b.title) return fail(res, 400, '会议标题必填');
      const scope = ['all', 'team', 'users'].includes(b.scope) ? b.scope : 'users';
      if (scope === 'all' && typeLevel(u) < 3 && !isAdmin(u)) return fail(res, 403, '全员会需部门领导及以上发起');
      if (scope === 'team' && typeLevel(u) < 2 && !isAdmin(u)) return fail(res, 403, '班组会需班组长及以上发起');
      const panel = Array.isArray(b.panel) ? b.panel.map(Number).filter(Boolean) : [];
      // 参会人展开
      let targets = [];
      if (scope === 'all') {
        targets = db.prepare('SELECT id, dept_id, real_name FROM users WHERE deleted_at IS NULL').all();
      } else if (scope === 'team') {
        targets = db.prepare('SELECT id, dept_id, real_name FROM users WHERE deleted_at IS NULL AND dept_id=?').all(u.dept_id);
        if (panel.length) {
          const extra = db.prepare('SELECT id, dept_id, real_name FROM users WHERE deleted_at IS NULL AND id IN (' + panel.map(() => '?').join(',') + ')').all(...panel);
          const seen = new Set(targets.map((x) => x.id));
          extra.forEach((x) => { if (!seen.has(x.id)) { targets.push(x); seen.add(x.id); } });
        }
      } else {
        if (panel.length) targets = db.prepare('SELECT id, dept_id, real_name FROM users WHERE deleted_at IS NULL AND id IN (' + panel.map(() => '?').join(',') + ')').all(...panel);
        if (!targets.some((x) => x.id === u.id)) targets.push({ id: u.id, dept_id: u.dept_id, real_name: u.real_name });
      }
      const dur = Number(b.duration_min) > 0 ? Number(b.duration_min) : 0; // 0 表示不限时长
      const names = targets.map((x) => x.real_name).filter(Boolean).join('、');
      const info = db.prepare('INSERT INTO meetings (title,mtype,meet_date,host,attendees,summary,dissent,next_time,created_by,meet_start,duration_min,scope,panel_json,recorder_on,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        .run(b.title, b.mtype || '例会', b.meet_start || b.meet_date || '', b.host || u.real_name || '', b.attendees || names, b.summary || '', b.dissent || '', b.next_time || '', u.id,
          b.meet_start || '', dur, scope, JSON.stringify(panel), b.recorder_on === 0 || b.recorder_on === false ? 0 : 1, '待召开'); // [需求10] 纪要开关默认开启
      const mid = Number(info.lastInsertRowid);
      try {
        const ins = db.prepare('INSERT INTO meeting_attendees (meeting_id,user_id,dept_id) VALUES (?,?,?)');
        targets.forEach((x) => ins.run(mid, x.id, x.dept_id));
      } catch (e) { console.error('[会议] 参会人落库失败', e.message); }
      return ok(res, { id: mid, attendees: targets.length, scope, recorder_on: 1 });
    }
    if ((m = p.match(/^\/api\/meetings\/(\d+)\/recall$/)) && req.method === 'POST') {
      // [需求10] 纪要按钮开关：会中可随时关闭/开启（默认开启）；仅发起人或管理员可改
      const id = Number(m[1]);
      const ex = db.prepare('SELECT * FROM meetings WHERE id=?').get(id);
      if (!ex) return fail(res, 404, '会议不存在');
      if (!(ex.created_by === u.id || isAdmin(u))) return fail(res, 403, '仅发起人或管理员可切换纪要开关');
      const b = JSON.parse(await readBody(req));
      const on = b.on === 0 || b.on === false ? 0 : 1;
      db.prepare('UPDATE meetings SET recorder_on=? WHERE id=?').run(on, id);
      return ok(res, { id, recorder_on: on });
    }
    if ((m = p.match(/^\/api\/meetings\/(\d+)\/export$/)) && req.method === 'GET') {
      // [需求10] 会后纪要导出（纯文本，可直接存手机/发钉钉；行动项一并带出）
      const id = Number(m[1]);
      const ex = db.prepare('SELECT * FROM meetings WHERE id=? AND deleted_at IS NULL').get(id);
      if (!ex) return fail(res, 404, '会议不存在');
      const canSee = ex.created_by === u.id || isApprover(u) || db.prepare('SELECT 1 FROM meeting_attendees WHERE meeting_id=? AND user_id=?').get(id, u.id);
      if (!canSee) return fail(res, 403, '仅发起人、参会人或管理员可导出纪要');
      const acts = db.prepare('SELECT * FROM meeting_actions WHERE meeting_id=? AND deleted_at IS NULL').all(id);
      const lines = [];
      lines.push('会议纪要：' + ex.title);
      lines.push('会议类型：' + (ex.mtype || ''));
      lines.push('开会时间：' + (ex.meet_start || ex.meet_date || '') + (Number(ex.duration_min) > 0 ? '（预计 ' + ex.duration_min + ' 分钟）' : '（时长不限）'));
      lines.push('主持人：' + (ex.host || ''));
      lines.push('参会范围：' + ({ all: '全员', team: '本班组', users: '指定人员' }[ex.scope] || '') + '（' + (ex.attendees || '') + '）');
      lines.push('纪要录制：' + (Number(ex.recorder_on) ? '开启' : '关闭'));
      lines.push('');
      lines.push('【会议纪要】');
      lines.push(ex.summary || '（未填写）');
      lines.push('');
      lines.push('【不同意见】');
      lines.push(ex.dissent || '（无）');
      lines.push('');
      lines.push('【行动项】');
      if (!acts.length) lines.push('（无）');
      acts.forEach((a, i) => lines.push((i + 1) + '. ' + a.action + ' —— 负责人：' + a.owner + '，截止 ' + a.due_date + '，状态：' + a.status));
      lines.push('');
      lines.push('【下次会议】' + (ex.next_time || '未安排'));
      lines.push('导出时间：' + nowLocalStr() + ' · 部门综合管理系统');
      const txt = lines.join('\n');
      res.writeHead(200, {
        'Content-Type': 'text/plain; charset=utf-8',
        'Content-Disposition': 'attachment; filename="meeting-' + id + '.txt"',
        'Cache-Control': 'no-store'
      });
      return res.end(txt);
    }
    if ((m = p.match(/^\/api\/meetings\/(\d+)\/video$/)) && req.method === 'POST') {
      // [需求10] 录制视频登记/取用：会后由发起人（或指定人员）回填视频地址，参会人可查看
      const id = Number(m[1]);
      const ex = db.prepare('SELECT * FROM meetings WHERE id=?').get(id);
      if (!ex) return fail(res, 404, '会议不存在');
      const b = JSON.parse(await readBody(req));
      if (b.url) {
        if (!(ex.created_by === u.id || isAdmin(u))) return fail(res, 403, '仅发起人或管理员可上传会议视频');
        const url = String(b.url).slice(0, 500);
        if (!/^https?:\/\//i.test(url)) return fail(res, 400, '视频地址需为 http(s) 链接');
        db.prepare('UPDATE meetings SET video_url=?, status=? WHERE id=?').run(url, '已结束', id);
        return ok(res, { id, video_url: url });
      }
      const canSee = ex.created_by === u.id || isApprover(u) || db.prepare('SELECT 1 FROM meeting_attendees WHERE meeting_id=? AND user_id=?').get(id, u.id);
      if (!canSee) return fail(res, 403, '仅参会人或发起人可查看会议视频');
      return ok(res, { id, video_url: ex.video_url || '' });
    }
    if ((m = p.match(/^\/api\/meetings\/(\d+)$/)) && req.method === 'PUT') {
      const b = JSON.parse(await readBody(req));
      const id = Number(m[1]);
      const ex = db.prepare('SELECT * FROM meetings WHERE id=?').get(id);
      if (!ex) return fail(res, 404, '会议不存在');
      if (!(ex.created_by === u.id || isApprover(u))) return fail(res, 403, '无权编辑');
      db.prepare('UPDATE meetings SET title=?,mtype=?,meet_date=?,host=?,attendees=?,summary=?,dissent=?,next_time=? WHERE id=?')
        .run(b.title || ex.title, b.mtype || ex.mtype, b.meet_date !== undefined ? b.meet_date : ex.meet_date, b.host !== undefined ? b.host : ex.host, b.attendees !== undefined ? b.attendees : ex.attendees, b.summary !== undefined ? b.summary : ex.summary, b.dissent !== undefined ? b.dissent : ex.dissent, b.next_time !== undefined ? b.next_time : ex.next_time, id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/meetings\/(\d+)$/)) && req.method === 'DELETE') {
      const id = Number(m[1]);
      const ex = db.prepare('SELECT * FROM meetings WHERE id=?').get(id);
      if (!ex) return fail(res, 404, '会议不存在');
      if (!(ex.created_by === u.id || isAdmin(u))) return fail(res, 403, '无权删除');
      softDel('meetings', id);
      return ok(res, {});
    }
    // 会议行动项（三要素：做什么/谁负责/截止日期）
    if ((m = p.match(/^\/api\/meetings\/(\d+)\/actions$/)) && req.method === 'GET') {
      const mtId = Number(m[1]);
      const mt = db.prepare('SELECT * FROM meetings WHERE id=?').get(mtId);
      if (!mt) return fail(res, 404, '会议不存在');
      if (!(isApprover(u) || mt.created_by === u.id)) {
        const mine = db.prepare('SELECT 1 FROM meeting_actions WHERE meeting_id=? AND assignee_id=?').get(mtId, u.id);
        if (!mine) return fail(res, 403, '您无权查看该会议行动项');
      }
      const today = new Date().toISOString().slice(0, 10);
      const rows = db.prepare(`SELECT ma.*, us.real_name AS assignee_name FROM meeting_actions ma LEFT JOIN users us ON ma.assignee_id=us.id WHERE ma.meeting_id=? ORDER BY ma.id`).all(mtId);
      return ok(res, rows.map(r => ({ ...r, overdue: r.status !== '已完成' && r.due_date && r.due_date < today ? 1 : 0 })));
    }
    if ((m = p.match(/^\/api\/meetings\/(\d+)\/actions$/)) && req.method === 'POST') {
      const mtId = Number(m[1]);
      const mt = db.prepare('SELECT * FROM meetings WHERE id=?').get(mtId);
      if (!mt) return fail(res, 404, '会议不存在');
      if (!(mt.created_by === u.id || isApprover(u) || typeLevel(u) >= 2)) return fail(res, 403, '无权添加行动项');
      const b = JSON.parse(await readBody(req));
      if (!b.action) return fail(res, 400, '行动项内容必填');
      if (!b.owner && !b.assignee_id) return fail(res, 400, '请指定负责人（系统人员或外部责任人）');
      if (!b.due_date) return fail(res, 400, '必须填写具体截止日期（不使用“尽快/近期”等模糊词）');
      const assigneeId = b.assignee_id ? Number(b.assignee_id) : null;
      if (assigneeId && !db.prepare('SELECT id FROM users WHERE id=?').get(assigneeId)) return fail(res, 400, '所选负责人不存在');
      // 决策自动转任务：负责人（系统人员）自动生成一条待办任务，有人负责、有截止、可追踪
      const ins = db.prepare('INSERT INTO meeting_actions (meeting_id,action,owner,due_date,note,assignee_id) VALUES (?,?,?,?,?,?)')
        .run(mtId, b.action, b.owner, b.due_date, b.note || '', assigneeId);
      const actId = Number(ins.lastInsertRowid);
      if (assigneeId) {
        db.prepare("INSERT INTO tasks (title,content,assignee_id,creator_id,due_date,priority,status,meeting_action_id,source) VALUES (?,?,?,?,?,'high','open',?,'meeting')")
          .run('【会议决策】' + b.action, '会议《' + (mt.title || '') + '》行动项：' + b.action + (b.note ? '（' + b.note + '）' : ''), assigneeId, u.id, b.due_date, actId);
      }
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/meeting-actions\/(\d+)$/)) && req.method === 'PUT') {
      const b = JSON.parse(await readBody(req));
      const id = Number(m[1]);
      const ex = db.prepare('SELECT * FROM meeting_actions WHERE id=?').get(id);
      if (!ex) return fail(res, 404, '行动项不存在');
      const mt = db.prepare('SELECT * FROM meetings WHERE id=?').get(ex.meeting_id);
      if (!(isApprover(u) || (mt && mt.created_by === u.id) || ex.assignee_id === u.id)) return fail(res, 403, '仅会议创建者、审批人或负责人本人可操作');
      if (b.action === 'done') {
        db.prepare("UPDATE meeting_actions SET status='已完成' WHERE id=?").run(id);
        if (ex.assignee_id) db.prepare("UPDATE tasks SET status='done' WHERE meeting_action_id=? AND source='meeting'").run(id);
      }
      else if (b.action === 'start') db.prepare("UPDATE meeting_actions SET status='进行中' WHERE id=?").run(id);
      else if (b.action === 'reopen') {
        db.prepare("UPDATE meeting_actions SET status='待开始' WHERE id=?").run(id);
        if (ex.assignee_id) db.prepare("UPDATE tasks SET status='open' WHERE meeting_action_id=? AND source='meeting'").run(id);
      }
      else db.prepare('UPDATE meeting_actions SET action=?,owner=?,due_date=?,note=?,assignee_id=? WHERE id=?')
        .run(b.action || ex.action, b.owner || ex.owner, b.due_date || ex.due_date, b.note !== undefined ? b.note : ex.note, b.assignee_id !== undefined ? (Number(b.assignee_id) || null) : ex.assignee_id, id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/meeting-actions\/(\d+)$/)) && req.method === 'DELETE') {
      const id = Number(m[1]);
      const ex = db.prepare('SELECT * FROM meeting_actions WHERE id=?').get(id);
      if (!ex) return fail(res, 404, '行动项不存在');
      const mt = db.prepare('SELECT * FROM meetings WHERE id=?').get(ex.meeting_id);
      if (!(isApprover(u) || (mt && mt.created_by === u.id))) return fail(res, 403, '仅会议创建者或审批人可删除行动项');
      db.prepare("UPDATE tasks SET deleted_at=? WHERE meeting_action_id=? AND source='meeting'").run(nowLocalStr(), id);
      softDel('meeting_actions', id);
      return ok(res, {});
    }

    // ==================== v5.4 奖励处罚 ====================
    if (p === '/api/rewards' && req.method === 'GET') {
      if (!requireLevel(u, 2, res)) return;   // 奖惩为部门级信息，LV>=2 可见（v5.7 安全加固）
      ensureColumn('rewards', 'category', "TEXT DEFAULT ''");
      const rows = db.prepare(`SELECT r.id, r.user_id, r.type, r.title, r.reason, r.category, r.rdate, r.created_by, r.created_at,
        COALESCE(us.real_name, r.user_name) AS user_name, cr.real_name AS creator_name
        FROM rewards r LEFT JOIN users us ON r.user_id=us.id LEFT JOIN users cr ON r.created_by=cr.id
        WHERE r.deleted_at IS NULL ORDER BY r.rdate DESC, r.id DESC`).all();
      return ok(res, rows);
    }
    if (p === '/api/rewards' && req.method === 'POST') {
      if (typeLevel(u) < 2) return fail(res, 403, '仅班组长及以上可录入奖励/处罚');
      const b = JSON.parse(await readBody(req));
      if (!b.title || !b.rdate) return fail(res, 400, '标题与日期必填');
      const type = b.type === 'punish' ? 'punish' : 'reward';
      const uid = b.user_id ? Number(b.user_id) : null;
      if (uid && !db.prepare('SELECT id FROM users WHERE id=?').get(uid)) return fail(res, 400, '所选人员不存在');
      if (!uid && !b.user_name) return fail(res, 400, '请选择人员或填写姓名');
      const r = db.prepare('INSERT INTO rewards (user_id,type,title,category,reason,rdate,created_by,user_name) VALUES (?,?,?,?,?,?,?,?)')
        .run(uid, type, b.title, b.category || '', b.reason || '', b.rdate, u.id, uid ? null : (b.user_name || ''));
      return ok(res, { id: Number(r.lastInsertRowid) });
    }
    if ((m = p.match(/^\/api\/rewards\/(\d+)$/)) && req.method === 'DELETE') {
      if (!isAdmin(u)) return fail(res, 403, '仅管理员可删除奖惩记录');
      softDel('rewards', m[1]);
      return ok(res, {});
    }

    // ==================== v5.4 年度汇总（年初至今） ====================
    if (p === '/api/summary/annual' && req.method === 'GET') {
      const year = new Date().getFullYear();
      const from = year + '-01-01';
      const today = new Date().toISOString().slice(0, 10);
      const q1 = db.prepare('SELECT COUNT(*) c FROM trainings WHERE train_date >= ? AND train_date <= ?').get(from, today);
      const trainings = db.prepare('SELECT title, category, train_date, participants FROM trainings WHERE train_date >= ? AND train_date <= ? ORDER BY train_date').all(from, today);
      const trainPersons = trainings.reduce((s, t) => s + (t.participants ? String(t.participants).split(/[,，、\s]+/).filter(Boolean).length : 0), 0);
      const trainPlans = db.prepare('SELECT * FROM training_plans ORDER BY plan_date').all();
      const tPlanDone = trainPlans.filter((x) => x.status === 'done').length;
      const meetings = db.prepare('SELECT COUNT(*) c FROM meetings WHERE meet_date >= ? AND meet_date <= ?').get(from, today);
      const actions = db.prepare('SELECT COUNT(*) c FROM meeting_actions').get().c;
      const actionsDone = db.prepare("SELECT COUNT(*) c FROM meeting_actions WHERE status='已完成'").get().c;
      const actionsOverdue = db.prepare("SELECT COUNT(*) c FROM meeting_actions WHERE status!='已完成' AND due_date IS NOT NULL AND due_date < ?").get(today);
      const checkPlans = db.prepare('SELECT * FROM check_plans ORDER BY year DESC').all();
      const planSummary = checkPlans.map((p2) => {
        const items = JSON.parse(p2.items_json || '[]');
        const doneRecs = db.prepare('SELECT COUNT(*) c FROM check_records WHERE plan_id=? AND status=?').get(p2.id, 'approved').c;
        const doneItems = Math.min(doneRecs, items.length);
        return { id: p2.id, year: p2.year, name: p2.name, check_type: p2.check_type, items: items.length, done: doneItems, remaining: Math.max(0, items.length - doneItems), status: doneItems >= items.length && items.length > 0 ? '已完成' : '未完成' };
      });
      const checks = db.prepare('SELECT check_type, COUNT(*) c FROM check_records WHERE check_date >= ? AND check_date <= ? GROUP BY check_type').all(from, today);
      const checkTotal = checks.reduce((s, x) => s + x.c, 0);
      const patrols = db.prepare('SELECT COUNT(*) c FROM patrols WHERE created_at >= ?').get(from + ' 00:00:00').c;
      const tasks = db.prepare('SELECT COUNT(*) c FROM tasks').get().c;
      const tasksDone = db.prepare("SELECT COUNT(*) c FROM tasks WHERE status='done'").get().c;
      const leaves = db.prepare('SELECT COUNT(*) c FROM leaves WHERE created_at >= ?').get(from + ' 00:00:00').c;
      const rewards = { reward: db.prepare("SELECT COUNT(*) c FROM rewards WHERE type='reward'").get().c, punish: db.prepare("SELECT COUNT(*) c FROM rewards WHERE type='punish'").get().c };
      // v6.1 入职/离职统计（年度《员工入职情况统计表》）：入职登记按创建时间、离职按离职日期
      const onboards = db.prepare('SELECT COUNT(*) c FROM onboardings WHERE deleted_at IS NULL AND created_at >= ? AND created_at <= ?').get(from + ' 00:00:00', today + ' 23:59:59');
      const onboardList = db.prepare('SELECT name, position, dept, entry_date, offer_status, bg_check, status, created_at FROM onboardings WHERE deleted_at IS NULL AND created_at >= ? AND created_at <= ? ORDER BY created_at').all(from + ' 00:00:00', today + ' 23:59:59');
      const offboards = db.prepare('SELECT COUNT(*) c FROM offboardings WHERE deleted_at IS NULL AND leave_date >= ? AND leave_date <= ?').get(from, today);
      const offboardList = db.prepare('SELECT name, leave_date, handover_person, note, status FROM offboardings WHERE deleted_at IS NULL AND leave_date >= ? AND leave_date <= ? ORDER BY leave_date').all(from, today);
      return ok(res, {
        year, from, today,
        onboards: { count: onboards.c, list: onboardList },
        offboards: { count: offboards.c, list: offboardList },
        trainings: { count: q1.c, persons: trainPersons, list: trainings.map((t) => ({ title: t.title, category: t.category, date: t.train_date, participants: t.participants })) },
        trainingPlans: { total: trainPlans.length, done: tPlanDone, remaining: trainPlans.length - tPlanDone, list: trainPlans.filter((x) => x.status !== 'done').map((x) => ({ title: x.title, category: x.category, date: x.plan_date })) },
        meetings: { count: meetings.c, actions, actionsDone, actionsOverdue },
        checkPlans: { total: checkPlans.length, done: planSummary.filter((x) => x.status === '已完成').length, list: planSummary },
        checks: { total: checkTotal, byType: checks },
        patrols,
        tasks: { total: tasks, done: tasksDone, remaining: tasks - tasksDone },
        leaves,
        rewards
      });
    }

    // ==================== v5.4 批量导入（仅运维/管理员） ====================
    if (p === '/api/import/batch' && req.method === 'POST') {
      if (typeLevel(u) < 4) return fail(res, 403, '权限不足：仅运维工程师/管理员可批量导入');
      const b = JSON.parse(await readBody(req));
      const type = b.type;
      const rows = Array.isArray(b.rows) ? b.rows : [];
      if (!rows.length) return fail(res, 400, '导入内容不能为空');
      const okRows = [], errRows = [];
      const parseLine = (line) => String(line).split(/[,，\t]+/).map((x) => x.trim());
      const insPlan = db.prepare('INSERT INTO check_plans (year,name,check_type,cycle,items_json,owner_id) VALUES (?,?,?,?,?,?)');
      const insTPlan = db.prepare('INSERT INTO training_plans (title,category,plan_date,target,hours) VALUES (?,?,?,?,?)');
      const insMt = db.prepare('INSERT INTO meetings (title,mtype,meet_date,host,attendees,summary,created_by) VALUES (?,?,?,?,?,?,?)');
      const insUser = db.prepare('INSERT INTO users (username,work_no,password_hash,salt,real_name,dept_id,role,user_type) VALUES (?,?,?,?,?,?,?,?)');
      const uidRow = db.prepare('SELECT id FROM users WHERE work_no=?');
      for (let i = 0; i < rows.length; i++) {
        const line = String(rows[i]);
        if (!line.trim()) continue;
        try {
          const f = parseLine(line);
          if (type === 'check_plans') {
            if (f.length < 4) throw new Error('需4列：年度,名称,类型,周期[,检查项(分号分隔)]');
            const items = f[4] ? String(f[4]).split(/[;；]+/).map((x) => x.trim()).filter(Boolean) : [];
            insPlan.run(Number(f[0]) || new Date().getFullYear(), f[1], f[2], f[3], JSON.stringify(items), u.id);
          } else if (type === 'training_plans') {
            if (f.length < 2) throw new Error('需2列：名称,类别[,计划日期,目标,学时]');
            insTPlan.run(f[0], f[1] || '综合', f[2] || '', f[3] || '', Number(f[4]) || 0);
          } else if (type === 'meetings') {
            if (f.length < 3) throw new Error('需3列：标题,类型,日期[,主持人,参会人,纪要]');
            insMt.run(f[0], f[1] || '例会', f[2], f[3] || '', f[4] || '', f[5] || '', u.id);
          } else if (type === 'users') {
            if (f.length < 2) throw new Error('需2列：姓名,工作证编号[,部门,类型]');
            const TYPE_MAP = { '新人': 'xinren', '在职': 'zaizhi', '班组长': 'banzuzhang', '部门领导': 'bumenlingdao', '运维工程师': 'weihu', '管理员': 'admin' };
            const ut = TYPE_MAP[f[3]] || 'xinren';
            const salt = crypto.randomBytes(16).toString('hex');
            const hash = hashPassword(f[1], salt);
            let deptId = null;
            if (f[2]) { let d = db.prepare('SELECT id FROM depts WHERE name=?').get(f[2]); if (!d) { db.prepare('INSERT INTO depts (name) VALUES (?)').run(f[2]); d = db.prepare('SELECT id FROM depts WHERE name=?').get(f[2]); } deptId = d.id; }
            const ex = uidRow.get(f[1]);
            if (ex) { db.prepare('UPDATE users SET real_name=?, user_type=? WHERE id=?').run(f[0], ut, ex.id); okRows.push('更新:' + f[1]); continue; }
            insUser.run(f[1], f[1], hash, salt, f[0], deptId, 'member', ut);
          } else { throw new Error('未知导入类型'); }
          okRows.push(line);
        } catch (e) { errRows.push('第' + (i + 1) + '行「' + String(line).slice(0, 20) + '」：' + e.message); }
      }
      return ok(res, { ok: okRows.length, err: errRows.length, errList: errRows });
    }

    // ==================== 人员档案批量导入（含照片；对齐 OIT 系统导出格式） ====================
    // 模板下载：标准 CSV 列头（与 OIT 人员档案对齐）
    if (p === '/api/import/personnel-template' && req.method === 'GET') {
      if (typeLevel(u) < 4) return fail(res, 403, '权限不足');
      const tpl = '姓名,工作证编号,部门,人员类型,性别,民族,出生日期,手机号,身份证号,政治面貌,学历,入职日期,职务\n' +
        '张三,9001,消防护卫部,在职,男,汉族,1990-01-01,13800000000,650000199001010011,中共党员,本科,2015-03-01,班组长\n';
      res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Content-Disposition': "attachment; filename=personnel_template.csv" });
      return res.end(tpl);
    }
    // 人员档案导入：上传 ZIP（内含 人员档案.csv + photos/<工作证编号>.jpg|png）
    if (p === '/api/import/personnel' && req.method === 'POST') {
      if (typeLevel(u) < 4) return fail(res, 403, '权限不足：仅运维工程师/管理员可导入');
      const b = JSON.parse(await readBody(req));
      const zipB64 = String(b.zipBase64 || '');
      if (!zipB64) return fail(res, 400, '请上传 ZIP 压缩包（内含人员档案.csv 与 photos/ 照片目录）');
      const tmpZip = path.join(DATA_DIR, 'tmp_import_' + Date.now() + '.zip');
      try {
        fs.writeFileSync(tmpZip, Buffer.from(zipB64, 'base64'));
        const entries = zipEntries(tmpZip);
        const csvEntry = entries.find((e) => /\.[cC][sS][vV]$/.test(e.name) && !e.name.startsWith('__MACOSX'));
        if (!csvEntry) return fail(res, 400, 'ZIP 内未找到 CSV 文件（人员档案.csv）');
        const csvTxt = zipReadEntry(tmpZip, csvEntry).toString('utf8');
        const photoMap = {};
        for (const e of entries) {
          const mx = e.name.match(/photos\/([^\/]+)\.(jpg|jpeg|png|webp)$/i);
          if (mx) photoMap[mx[1]] = { ext: mx[2].toLowerCase(), buf: zipReadEntry(tmpZip, e) };
        }
        const lines = csvTxt.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
        const TYPE_MAP = { '新人': 'xinren', '在职': 'zaizhi', '在职人员': 'zaizhi', '班组长': 'banzuzhang', '部门领导': 'bumenlingdao', '运维': 'weihu', '运维工程师': 'weihu', '管理员': 'admin' };
        const okRows = [], errRows = [], photos = [];
        let first = true;
        for (const line of lines) {
          if (first && line.includes('姓名') && line.includes('工作证编号')) { first = false; continue; }
          first = false;
          try {
            const f = line.split(/[,，]/).map((x) => x.trim());
            if (f.length < 2 || !f[0] || !f[1]) continue;
            const [name, workNo, deptName, typeName, gender, nation, birth, mobile, idCard, pol, edu, hire, job] = f;
            if (!/^\d+$/.test(workNo)) throw new Error('工作证编号需为数字');
            let deptId = null;
            if (deptName) { let d = db.prepare('SELECT id FROM depts WHERE name=?').get(deptName); if (!d) { db.prepare('INSERT INTO depts (name) VALUES (?)').run(deptName); d = db.prepare('SELECT id FROM depts WHERE name=?').get(deptName); } deptId = d.id; }
            const ut = TYPE_MAP[typeName] || 'xinren';
            // 照片落盘（photos/<工号>.<ext>）
            let photo = '';
            const ph = photoMap[workNo];
            if (ph) { const pn = workNo + '.' + ph.ext; fs.writeFileSync(path.join(PORTRAIT_DIR, pn), ph.buf); photo = pn; photos.push(pn); }
            const ex = db.prepare('SELECT id, photo FROM users WHERE work_no=? OR username=?').get(workNo, workNo);
            if (ex) {
              db.prepare('UPDATE users SET real_name=?, user_type=?, dept_id=?, gender=?, nation=?, birth_date=?, mobile=?, id_card=?, political_status=?, education=?, hire_date=?, job_title=?, photo=? WHERE id=?')
                .run(name, ut, deptId, gender || '', nation || '', birth || '', mobile || '', idCard || '', pol || '', edu || '', hire || '', job || '', photo || ex.photo, ex.id);
              okRows.push('更新:' + name + '(' + workNo + ')');
            } else {
              const salt = crypto.randomBytes(16).toString('hex');
              db.prepare('INSERT INTO users (username,work_no,password_hash,salt,real_name,dept_id,role,user_type,gender,nation,birth_date,mobile,id_card,political_status,education,hire_date,job_title,photo) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
                .run(workNo, workNo, hashPassword(workNo, salt), salt, name, deptId, 'member', ut, gender || '', nation || '', birth || '', mobile || '', idCard || '', pol || '', edu || '', hire || '', job || '', photo);
              okRows.push('新增:' + name + '(' + workNo + ')');
            }
          } catch (e) { errRows.push('「' + String(line).slice(0, 30) + '」：' + e.message); }
        }
        return ok(res, { ok: okRows.length, err: errRows.length, errList: errRows, photos: photos.length });
      } catch (e) { return fail(res, 400, '导入失败：' + e.message); }
      finally { try { fs.rmSync(tmpZip, { force: true }); } catch (e) { /* 忽略 */ } }
    }
    // 人员照片读取（登录即可见，用于通讯录/档案）
    if ((m = p.match(/^\/api\/users\/(\d+)\/photo$/)) && req.method === 'GET') {
      const usr = db.prepare('SELECT photo FROM users WHERE id=?').get(Number(m[1]));
      if (!usr || !usr.photo) return fail(res, 404, '无照片');
      const fp = path.join(PORTRAIT_DIR, usr.photo);
      if (!fs.existsSync(fp)) return fail(res, 404, '照片文件已丢失');
      const body = fs.readFileSync(fp);
      const ct = { 'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png', 'webp': 'image/webp' }[path.extname(usr.photo).slice(1).toLowerCase()] || 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': ct, 'Content-Length': body.length, 'Cache-Control': 'private, max-age=300' });
      return res.end(body);
    }

    // ==================== v4.0 检查管理（年度计划/日检/月检/自查/专项，多级审核） ====================
    if (p === '/api/check-plans' && req.method === 'GET') {
      if (typeLevel(u) < 1) return fail(res, 403, '新人暂未开通检查模块');
      const rows = db.prepare(`SELECT c.*, us.real_name AS owner_name FROM check_plans c LEFT JOIN users us ON c.owner_id=us.id WHERE c.deleted_at IS NULL ORDER BY c.year DESC, c.id DESC`).all();
      return ok(res, rows.map(r => ({ ...r, items: JSON.parse(r.items_json || '[]') })));
    }
    if (p === '/api/check-plans' && req.method === 'POST') {
      if (typeLevel(u) < 2) return fail(res, 403, '权限不足：班组长及以上可制定检查计划');
      const b = JSON.parse(await readBody(req));
      if (!b.year || !b.name || !b.check_type) return fail(res, 400, '年度/名称/检查类型必填');
      db.prepare('INSERT INTO check_plans (year,name,check_type,cycle,items_json,owner_id) VALUES (?,?,?,?,?,?)')
        .run(Number(b.year), b.name, b.check_type, b.cycle || '', JSON.stringify(Array.isArray(b.items) ? b.items : []), u.id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/check-plans\/(\d+)$/)) && req.method === 'PUT') {
      if (typeLevel(u) < 2) return fail(res, 403, '权限不足');
      const b = JSON.parse(await readBody(req));
      db.prepare('UPDATE check_plans SET year=?,name=?,check_type=?,cycle=?,items_json=?,status=? WHERE id=?')
        .run(Number(b.year), b.name, b.check_type, b.cycle || '', JSON.stringify(Array.isArray(b.items) ? b.items : []), b.status || 'active', Number(m[1]));
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/check-plans\/(\d+)$/)) && req.method === 'DELETE') {
      if (typeLevel(u) < 2) return fail(res, 403, '权限不足');
      softDel('check_plans', m[1]);
      return ok(res, {});
    }
    // 检查记录：上报 → 班组审核 → 部门领导审核
    if (p === '/api/check-records' && req.method === 'GET') {
      const rows = db.prepare(`SELECT c.*, us.real_name AS checker_name, ap.real_name AS approver_name, cp.name AS plan_name
        FROM check_records c LEFT JOIN users us ON c.checker_id=us.id LEFT JOIN users ap ON c.approver_id=ap.id
        LEFT JOIN check_plans cp ON c.plan_id=cp.id WHERE c.deleted_at IS NULL ORDER BY c.check_date DESC, c.id DESC`).all();
      let list = rows;
      if (typeLevel(u) < 2) list = rows.filter((r) => r.checker_id === u.id);
      return ok(res, list.map((r) => {
        const ch = (() => { try { return JSON.parse(r.chain_json || '[]'); } catch (e) { return []; } })();
        return { ...r, items: JSON.parse(r.items_json || '[]'), photos: JSON.parse(r.photos_json || '[]'), chain: chainLabels(r.chain_json), pending_level_name: r.status === 'pending' && r.level < ch.length ? LEVEL_NAMES[ch[r.level]] : '' };
      }));
    }
    if (p === '/api/check-records' && req.method === 'POST') {
      if (!checkWritePerm(u, 'POST', p, 'check_record')) return fail(res, 403, '暂无检查上报权限，请在「审批-发起申请」提交功能申请');
      if (!requireSig(u, res, '检查记录签字')) return;
      const b = JSON.parse(await readBody(req));
      if (!b.check_type || !b.check_date) return fail(res, 400, '检查类型/日期必填');
      const clName = b.checklist_id ? (db.prepare('SELECT name FROM checklists WHERE id=?').get(b.checklist_id) || {}).name || '' : (b.checklist_name || '');
      ensureColumn('check_records', 'checklist_no', "TEXT DEFAULT ''");
      db.prepare('INSERT INTO check_records (plan_id,check_type,check_date,area,items_json,result,summary,checker_id,chain_json,start_loc,end_loc,photos_json,start_time,end_time,checklist_id,checklist_name,checklist_no) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        .run(b.plan_id || null, b.check_type, b.check_date, b.area || '', JSON.stringify(Array.isArray(b.items) ? b.items : []), b.result || 'ok', b.summary || '', u.id, JSON.stringify([2, 3]), b.start_loc || '', b.end_loc || '', JSON.stringify(Array.isArray(b.photos) ? b.photos : []), b.start_time || '', b.end_time || '', b.checklist_id || null, clName, b.checklist_no || '');
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/check-records\/(\d+)\/approve$/)) && req.method === 'POST') {
      if (!requireSig(u, res, '检查审核签字')) return;
      const b = JSON.parse(await readBody(req));
      const id = Number(m[1]);
      const rec = db.prepare('SELECT * FROM check_records WHERE id=?').get(id);
      if (!rec) return fail(res, 404, '检查记录不存在');
      if (b.action === 'reject') {
        if (typeLevel(u) < 2) return fail(res, 403, '无权审批');
        rejectFlow(db, 'check_records', id, u, b);
        return ok(res, {});
      }
      if (!approveFlow(db, 'check_records', id, rec, b, u, res)) return;
      return ok(res, {});
    }
    // ---- 建议→确认→执行：智能回答/工作报告/建议条的"采纳"动作（人审查后生成） ----
    if (p === '/api/actions/apply' && req.method === 'POST') {
      const b = JSON.parse(await readBody(req));
      const type = b.type;
      if (type === 'task') {
        if (!b.title) return fail(res, 400, '任务标题必填');
        const due = String(b.due_date || '');
        const r = db.prepare('INSERT INTO tasks (title, content, assignee_id, creator_id, due_date, priority, status) VALUES (?,?,?,?,?,?,?)')
          .run(String(b.title).slice(0, 120), String(b.content || '').slice(0, 4000), u.id, u.id, due, 'normal', 'pending');
        return ok(res, { id: r.lastInsertRowid });
      }
      if (type === 'rectify') {
        if (typeLevel(u) < 2) return fail(res, 403, '仅班组长及以上可生成整改通知');
        const id = Number(b.issue_id);
        const issue = id ? db.prepare('SELECT * FROM check_issues WHERE id=?').get(id) : null;
        if (!issue) return fail(res, 404, '问题不存在');
        if (issue.issue_type !== 'rectify') return fail(res, 400, '当场整改问题无需下发通知');
        if (issue.notified_at) return fail(res, 400, '该问题已下发整改通知（' + (issue.notice_no || '') + '）');
        return ok(res, { jump: true, issue_id: id });
      }
      return fail(res, 400, '未知动作类型');
    }

    // ==================== v5.5 检查闭环：检查单库 / 检查问题 / 整改通知 / 整改报告 / 验收报告 / 个人档案 ====================
    if (p === '/api/checklists' && req.method === 'GET') {
      if (typeLevel(u) < 1) return fail(res, 403, '新人暂未开通检查模块');
      return ok(res, db.prepare('SELECT * FROM checklists WHERE deleted_at IS NULL ORDER BY name').all().map((c) => ({ ...c, items: JSON.parse(c.items_json || '[]') })));
    }
    if (p === '/api/checklists' && req.method === 'POST') {
      if (typeLevel(u) < 2) return fail(res, 403, '仅班组长及以上可维护检查单库');
      const b = JSON.parse(await readBody(req));
      if (!b.name) return fail(res, 400, '检查单名称必填');
      if (db.prepare('SELECT id FROM checklists WHERE name=?').get(b.name)) return fail(res, 400, '同名检查单已存在，请换名称');
      db.prepare('INSERT INTO checklists (name,items_json,created_by) VALUES (?,?,?)').run(b.name, JSON.stringify(Array.isArray(b.items) ? b.items : []), u.id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/checklists\/(\d+)$/)) && req.method === 'DELETE') {
      if (typeLevel(u) < 4) return fail(res, 403, '仅运维/管理员可删除检查单');
      softDel('checklists', m[1]);
      return ok(res, {});
    }

    // 检查问题列表（审批层可见全部；在职看自己检查上报的问题与被指派整改的问题；新人不可见）
    if (p === '/api/check-issues' && req.method === 'GET') {
      if (typeLevel(u) < 1) return fail(res, 403, '新人暂未开通检查模块');
      let sql = `SELECT ci.*, cr.check_type, cr.check_date, cr.area AS check_area, us.real_name AS assignee_name, crt.real_name AS creator_name,
        (SELECT COUNT(*) FROM check_records c2 WHERE c2.id=ci.check_record_id) AS rec_ok
        FROM check_issues ci LEFT JOIN check_records cr ON ci.check_record_id=cr.id LEFT JOIN users us ON ci.assigned_to=us.id LEFT JOIN users crt ON ci.created_by=crt.id WHERE ci.deleted_at IS NULL`;
      const rows = db.prepare(sql).all();
      let list = rows;
      if (typeLevel(u) < 2) list = rows.filter((r) => r.created_by === u.id || r.assigned_to === u.id);
      return ok(res, list);
    }
    // 登记检查问题：spot=当场整改（现场验收合格直接关闭）；rectify=限期整改（生成整改通知）
    if (p === '/api/check-issues' && req.method === 'POST') {
      if (typeLevel(u) < 1) return fail(res, 403, '新人暂未开通检查模块');
      if (!requireSig(u, res, '检查问题登记签字')) return;
      const b = JSON.parse(await readBody(req));
      if (!b.check_record_id || !b.content) return fail(res, 400, '检查记录与问题内容必填');
      const rec = db.prepare('SELECT * FROM check_records WHERE id=?').get(Number(b.check_record_id));
      if (!rec) return fail(res, 404, '检查记录不存在');
      const iType = b.issue_type === 'spot' ? 'spot' : 'rectify';
      const assignedTo = b.assigned_to ? Number(b.assigned_to) : null;
      const now = nowLocalStr();
      const noticeNo = 'XG' + now.replace(/[-: ]/g, '').slice(2, 14) + '-' + Math.floor(Math.random() * 90 + 10);
      const status = iType === 'spot' ? 'accepted' : 'open';
      const r = db.prepare('INSERT INTO check_issues (check_record_id,issue_type,content,location,assigned_to,rectify_deadline,notice_no,status,created_by,closed_at) VALUES (?,?,?,?,?,?,?,?,?,?)')
        .run(Number(b.check_record_id), iType, b.content, b.location || '', assignedTo, b.rectify_deadline || '', noticeNo, status, u.id, iType === 'spot' ? now : null);
      // v6.0 自动化规则：整改类问题创建后触发"自动整改通知"规则
      try {
        runAutoRules('issue_created', { issue: { id: Number(r.lastInsertRowid), content: b.content, assigned_to: assignedTo, deadline: b.rectify_deadline || '' } });
      } catch (e) { /* 规则执行异常不阻断登记 */ }
      return ok(res, { id: r.lastInsertRowid, notice_no: noticeNo, status });
    }
    // 下发整改通知（班组长以上签字签发；系统同步生成部门群内通报）
    if ((m = p.match(/^\/api\/check-issues\/(\d+)\/notice$/)) && req.method === 'POST') {
      if (typeLevel(u) < 2) return fail(res, 403, '仅班组长及以上可签发整改通知');
      if (!requireSig(u, res, '整改通知签发签字')) return;
      const id = Number(m[1]);
      const issue = db.prepare('SELECT * FROM check_issues WHERE id=?').get(id);
      if (!issue) return fail(res, 404, '问题不存在');
      if (issue.issue_type !== 'rectify') return fail(res, 400, '当场整改问题无需下发通知');
      const tpl = db.prepare("SELECT content FROM doc_templates WHERE ttype='rectify_notice'").get();
      const assignee = issue.assigned_to ? (db.prepare('SELECT real_name,work_no FROM users WHERE id=?').get(issue.assigned_to) || {}) : {};
      const rec = db.prepare('SELECT * FROM check_records WHERE id=?').get(issue.check_record_id);
      const text = fillTemplate(tpl ? tpl.content : '', {
        notice_no: issue.notice_no, name: assignee.real_name || '未指定人员', work_no: assignee.work_no || '',
        check_date: rec ? rec.check_date : '', check_type: rec ? rec.check_type : '', content: issue.content, location: issue.location,
        deadline: issue.rectify_deadline || '限期', signer: u.real_name, sign_date: nowLocalStr()
      });
      db.prepare("UPDATE check_issues SET notice_signed_at=?, notified_at=?, status=? WHERE id=?")
        .run(nowLocalStr(), nowLocalStr(), issue.status === 'open' ? 'open' : issue.status, id);
      // 同步部门群内通报（写入消息模块，全员可见）
      db.prepare("INSERT INTO messages (title,content,sender_id) VALUES (?,?,?)")
        .run('整改通报：' + issue.notice_no, '对「' + (rec ? rec.check_type : '检查') + '」发现的问题已下发整改通知（' + issue.notice_no + '），请相关责任人限期整改。', u.id);
      return ok(res, { notice: text, notice_no: issue.notice_no });
    }
    // 被整改人提交整改措施报告与证明材料
    if ((m = p.match(/^\/api\/check-issues\/(\d+)\/report$/)) && req.method === 'POST') {
      if (typeLevel(u) < 1) return fail(res, 403, '新人暂未开通检查模块');
      if (!requireSig(u, res, '整改报告提交签字')) return;
      const id = Number(m[1]);
      const issue = db.prepare('SELECT * FROM check_issues WHERE id=?').get(id);
      if (!issue) return fail(res, 404, '问题不存在');
      if (issue.assigned_to && issue.assigned_to !== u.id && typeLevel(u) < 2) return fail(res, 403, '仅被整改人本人或审批层可提交整改材料');
      const b = JSON.parse(await readBody(req));
      if (!b.report_content) return fail(res, 400, '整改措施报告必填');
      db.prepare("UPDATE check_issues SET report_content=?, evidence_note=?, status='submitted' WHERE id=?").run(b.report_content, b.evidence_note || '', id);
      return ok(res, {});
    }
    // 班组长验收：accept=验收合格（生成验收合格报告并签字留档）；reject=验收不合格退回
    if ((m = p.match(/^\/api\/check-issues\/(\d+)\/accept$/)) && req.method === 'POST') {
      if (typeLevel(u) < 2) return fail(res, 403, '仅班组长及以上可验收');
      if (!requireSig(u, res, '验收报告签字')) return;
      const id = Number(m[1]);
      const issue = db.prepare('SELECT * FROM check_issues WHERE id=?').get(id);
      if (!issue) return fail(res, 404, '问题不存在');
      const b = JSON.parse(await readBody(req));
      const now = nowLocalStr();
      if (b.accept === 'reject') {
        db.prepare("UPDATE check_issues SET accept_result=?, status='rejected' WHERE id=?").run(b.note || '验收不合格，退回重新整改', id);
        return ok(res, {});
      }
      const reportNo = 'YS' + now.replace(/[-: ]/g, '').slice(2, 14) + '-' + Math.floor(Math.random() * 90 + 10);
      const tpl = db.prepare("SELECT content FROM doc_templates WHERE ttype='accept_report'").get();
      const assignee = issue.assigned_to ? (db.prepare('SELECT real_name,work_no FROM users WHERE id=?').get(issue.assigned_to) || {}) : {};
      const text = fillTemplate(tpl ? tpl.content : '', {
        report_no: reportNo, content: issue.content, notice_no: issue.notice_no,
        name: assignee.real_name || '未指定人员', work_no: assignee.work_no || '',
        report_content: issue.report_content || '', evidence_note: issue.evidence_note || '',
        acceptor: u.real_name, accept_date: now
      });
      db.prepare("UPDATE check_issues SET accept_result=?, accept_report_no=?, accept_signed_at=?, status='accepted', closed_at=? WHERE id=?")
        .run(b.note || '验收合格', reportNo, now, now, id);
      return ok(res, { report_no: reportNo, report: text });
    }
    // 模板查看/更新（运维/管理员维护正式模板）
    if ((m = p.match(/^\/api\/templates\/([a-z_]+)$/)) && req.method === 'GET') {
      const t = db.prepare('SELECT * FROM doc_templates WHERE ttype=?').get(m[1]);
      return ok(res, t || null);
    }
    if ((m = p.match(/^\/api\/templates\/([a-z_]+)$/)) && req.method === 'PUT') {
      if (typeLevel(u) < 4) return fail(res, 403, '仅运维/管理员可维护正式模板');
      const b = JSON.parse(await readBody(req));
      if (!b.content) return fail(res, 400, '模板内容必填');
      db.prepare("UPDATE doc_templates SET content=?, name=?, updated_at=? WHERE ttype=?").run(b.content, b.name || '', nowLocalStr(), m[1]);
      return ok(res, {});
    }
    // 个人档案：培训档案（参加次数/成绩/合格）+ 检查整改档案
    if (p === '/api/archive/mine' && req.method === 'GET') {
      if (typeLevel(u) < 1) return fail(res, 403, '新人暂未开通档案模块');
      const uid = u.id;
      const trains = db.prepare(`SELECT t.title, t.category, t.train_date, t.hours, t.start_time, t.end_time, s.score, s.result
        FROM trainings t LEFT JOIN training_scores s ON s.training_id=t.id AND s.user_id=?
        WHERE t.id IN (SELECT training_id FROM training_signins WHERE user_id=?) OR t.participants LIKE ?
        ORDER BY t.train_date DESC`).all(uid, uid, '%' + u.real_name + '%');
      const total = trains.length;
      const tested = trains.filter((x) => x.score !== null);
      const pass = tested.filter((x) => (x.result === '合格' && x.score >= 60) || (x.result === '' && x.score >= 60) || x.result === '合格');
      const issues = db.prepare(`SELECT ci.*, cr.check_type, cr.check_date FROM check_issues ci LEFT JOIN check_records cr ON ci.check_record_id=cr.id
        WHERE ci.assigned_to=? OR ci.created_by=? ORDER BY ci.created_at DESC`).all(uid, uid);
      return ok(res, { trainings: { total, tested: tested.length, pass: pass.length, fail: tested.length - pass.length, list: trains }, issues: issues.map((x) => ({ ...x, status: x.status })) });
    }
    if (p === '/api/archive/stats' && req.method === 'GET') {
      const t = db.prepare('SELECT COUNT(*) c FROM trainings').get().c;
      const issues = db.prepare('SELECT COUNT(*) c FROM check_issues WHERE status != ?').get('accepted').c;
      return ok(res, { trainings: t, open_issues: issues });
    }

    // ==================== v4.0 巡逻（上报 → 班组审核 → 部门领导审核） ====================
    if (p === '/api/patrols' && req.method === 'GET') {
      const rows = db.prepare(`SELECT p.*, us.real_name AS patroler_name, ap.real_name AS approver_name
        FROM patrols p LEFT JOIN users us ON p.patroler_id=us.id LEFT JOIN users ap ON p.approver_id=ap.id
        WHERE p.deleted_at IS NULL ORDER BY p.patrol_date DESC, p.id DESC`).all();
      let list = rows;
      if (typeLevel(u) < 2) list = rows.filter((r) => r.patroler_id === u.id);
      return ok(res, list.map((r) => {
        const ch = (() => { try { return JSON.parse(r.chain_json || '[]'); } catch (e) { return []; } })();
        return { ...r, chain: chainLabels(r.chain_json), pending_level_name: r.status === 'pending' && r.level < ch.length ? LEVEL_NAMES[ch[r.level]] : '' };
      }));
    }
    if (p === '/api/patrols' && req.method === 'POST') {
      if (!checkWritePerm(u, 'POST', p, 'patrol')) return fail(res, 403, '暂无巡逻上报权限，请在「审批-发起申请」提交功能申请');
      if (!requireSig(u, res, '巡逻记录签字')) return;
      const b = JSON.parse(await readBody(req));
      if (!b.patrol_date || !b.area) return fail(res, 400, '巡逻日期/区域必填');
      db.prepare('INSERT INTO patrols (patrol_date,area,start_time,end_time,result,issues,patroler_id,chain_json,start_loc,end_loc) VALUES (?,?,?,?,?,?,?,?,?,?)')
        .run(b.patrol_date, b.area, b.start_time || '', b.end_time || '', b.result || 'ok', b.issues || '', u.id, JSON.stringify([2, 3]), b.start_loc || '', b.end_loc || '');
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/patrols\/(\d+)\/approve$/)) && req.method === 'POST') {
      if (!requireSig(u, res, '巡逻审核签字')) return;
      const b = JSON.parse(await readBody(req));
      const id = Number(m[1]);
      const rec = db.prepare('SELECT * FROM patrols WHERE id=?').get(id);
      if (!rec) return fail(res, 404, '巡逻记录不存在');
      if (b.action === 'reject') {
        if (typeLevel(u) < 2) return fail(res, 403, '无权审批');
        rejectFlow(db, 'patrols', id, u, b);
        return ok(res, {});
      }
      if (!approveFlow(db, 'patrols', id, rec, b, u, res)) return;
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/patrols\/(\d+)$/)) && req.method === 'DELETE') {
      const id = Number(m[1]);
      const ex = db.prepare('SELECT * FROM patrols WHERE id=?').get(id);
      if (!ex) return fail(res, 404, '巡逻记录不存在');
      if (!(ex.patroler_id === u.id || typeLevel(u) >= 3)) return fail(res, 403, '无权删除');
      softDel('patrols', id);
      return ok(res, {});
    }

    // 工作台统计
    if (p === '/api/stats' && req.method === 'GET') {      const n = (sql, ...args) => db.prepare(sql).get(...args).c;
      const isAdm = isAdmin(u);
      const isAppr = isApprover(u);
      const today = new Date().toISOString().slice(0, 10);
      const atd = db.prepare('SELECT check_in,check_out FROM attendance WHERE user_id=? AND day=?').get(u.id, today);
      const stats = {
        training_count: n('SELECT COUNT(*) AS c FROM trainings'),
        training_hours: db.prepare('SELECT COALESCE(SUM(hours),0) AS s FROM trainings').get().s,
        leave_pending: isAdm ? n("SELECT COUNT(*) AS c FROM leaves WHERE status='pending'") : 0,
        my_leave_count: n('SELECT COUNT(*) AS c FROM leaves WHERE user_id=?', u.id),
        my_unread: n('SELECT COUNT(*) AS c FROM messages') - n('SELECT COUNT(*) AS c FROM message_reads WHERE user_id=?', u.id),
        file_count: n('SELECT COUNT(*) AS c FROM files'),
        user_count: n('SELECT COUNT(*) AS c FROM users'),
        form_count: n('SELECT COUNT(*) AS c FROM forms'),
        approval_pending: isAppr ? n("SELECT COUNT(*) AS c FROM approvals WHERE status='pending'") : 0,
        my_approval_count: n('SELECT COUNT(*) AS c FROM approvals WHERE user_id=?', u.id),
        my_tasks_open: n("SELECT COUNT(*) AS c FROM tasks WHERE assignee_id=? AND status='open'", u.id),
        checked_in: atd ? 1 : 0,
        checked_out: atd && atd.check_out ? 1 : 0,
        issue_open: isAppr ? n("SELECT COUNT(*) AS c FROM audit_issues WHERE status!='closed'") : 0,
        duty_today: n('SELECT COUNT(*) AS c FROM duty_roster WHERE day=?', today),
        // v3.1
        onboarding_pending: isAppr ? n("SELECT COUNT(*) AS c FROM onboardings WHERE status='onboarding' AND (computer_ready=0 OR account_ready=0 OR train_ready=0)") : 0,
        onboarding_soon: isAppr ? n("SELECT COUNT(*) AS c FROM onboardings WHERE status='onboarding' AND entry_date IS NOT NULL AND entry_date <= date('now','localtime','+3 day') AND (computer_ready=0 OR account_ready=0 OR train_ready=0)") : 0,
        offboarding_pending: isAppr ? n("SELECT COUNT(*) AS c FROM offboardings WHERE status='offboarding' AND (project_handover=0 OR permission_reclaim=0 OR device_return=0 OR social_insurance=0)") : 0,
        meeting_count: n('SELECT COUNT(*) AS c FROM meetings'),
        meeting_action_overdue: n("SELECT COUNT(*) AS c FROM meeting_actions WHERE status!='已完成' AND due_date < date('now','localtime')"),
        // v4.0
        contract_confirm_pending: typeLevel(u) >= 3 ? n("SELECT COUNT(*) AS c FROM users WHERE user_type='xinren' AND contract_signed=1 AND contract_signed_at IS NOT NULL") : 0,
        contract_auto_soon: typeLevel(u) >= 3 ? n("SELECT COUNT(*) AS c FROM users WHERE user_type='xinren' AND contract_signed=1 AND contract_signed_at IS NOT NULL AND contract_signed_at <= datetime('now','localtime','-13 days')") : 0,
        xinren_count: n("SELECT COUNT(*) AS c FROM users WHERE user_type='xinren'"),
        check_plan_count: n('SELECT COUNT(*) AS c FROM check_plans'),
        check_record_pending: typeLevel(u) >= 2 ? n("SELECT COUNT(*) AS c FROM check_records WHERE status='pending'") : 0,
        my_check_count: n('SELECT COUNT(*) AS c FROM check_records WHERE checker_id=?', u.id),
        patrol_pending: typeLevel(u) >= 2 ? n("SELECT COUNT(*) AS c FROM patrols WHERE status='pending'") : 0,
        my_patrol_count: n('SELECT COUNT(*) AS c FROM patrols WHERE patroler_id=?', u.id)
      };
      return ok(res, stats);
    }

    // ---- v6.2 劳动合同 30 天签约预警（工作台卡片数据；管理员/负责人可见） ----
    if (p === '/api/contracts/warnings' && req.method === 'GET') {
      if (typeLevel(u) < 2) return fail(res, 403, '暂无权限查看签约预警');
      const cut30 = new Date(Date.now() - 30 * 86400000);
      const cut30Str = String(cut30.getFullYear()) + '-' + String(cut30.getMonth() + 1).padStart(2, '0') + '-' + String(cut30.getDate()).padStart(2, '0');
      const rows = db.prepare("SELECT id, real_name, work_no, job_title, created_at, contract_signed FROM users WHERE user_type='xinren' AND contract_signed=0 AND deleted_at IS NULL AND created_at != '' AND created_at < ? ORDER BY created_at ASC LIMIT 200")
        .all(cut30Str + ' 23:59:59');
      const list = rows.map((r) => {
        const days = Math.max(30, Math.floor((Date.now() - new Date(r.created_at).getTime()) / 86400000));
        return { id: r.id, real_name: r.real_name, work_no: r.work_no || '', position: r.job_title || '', hire: r.created_at.slice(0, 10), days };
      });
      return ok(res, { count: list.length, list });
    }

    // [需求9] /api/backup/* 路由已迁到 modules/backup.js（路由表统一分发）
    // [需求9] /api/recycle 列表已迁到 modules/recycle.js
    if (p === '/api/recycle/list' && req.method === 'GET') {
      if (!requireLevel(u, 4, res)) return;
      const table = String(url.searchParams.get('table') || '');
      const meta = RECYCLE_META[table];
      if (!meta) return fail(res, 400, '未知回收站类型');
      const rows = db.prepare(`SELECT id, ${meta.title} AS title, deleted_at FROM ${safeT(table)} WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC LIMIT 500`).all();
      return ok(res, { table, label: meta.label, rows });
    }
    if (p === '/api/recycle/restore' && req.method === 'POST') {
      if (!requireLevel(u, 4, res)) return;
      const b = JSON.parse(await readBody(req));
      if (!RECYCLE_META[b.table]) return fail(res, 400, '未知回收站类型');
      db.prepare(`UPDATE ${safeT(b.table)} SET deleted_at=NULL WHERE id=?`).run(Number(b.id));
      return ok(res, {});
    }
    if (p === '/api/recycle/purge' && req.method === 'POST') {
      if (!requireLevel(u, 4, res)) return;
      const b = JSON.parse(await readBody(req));
      if (!RECYCLE_META[b.table]) return fail(res, 400, '未知回收站类型');
      db.prepare(`DELETE FROM ${safeT(b.table)} WHERE id=?`).run(Number(b.id));
      return ok(res, {});
    }

    // ==================== v6.0 借鉴简道云：知识库 ====================
    if (p === '/api/kb/cats' && req.method === 'GET') {
      return ok(res, db.prepare("SELECT category, COUNT(*) c FROM kb_docs WHERE deleted_at IS NULL GROUP BY category ORDER BY c DESC").all());
    }
    if (p === '/api/kb/docs' && req.method === 'GET') {
      const cat = String(url.searchParams.get('cat') || '');
      const q = String(url.searchParams.get('q') || '').trim();
      let sql = `SELECT d.*, us.real_name AS uploader_name FROM kb_docs d LEFT JOIN users us ON d.uploader_id=us.id WHERE d.deleted_at IS NULL`;
      const args = [];
      if (cat) { sql += ' AND d.category=?'; args.push(cat); }
      if (q) { sql += ' AND (d.title LIKE ? OR d.category LIKE ?)'; args.push('%' + q + '%', '%' + q + '%'); }
      sql += ' ORDER BY d.created_at DESC LIMIT 500';
      return ok(res, db.prepare(sql).all(...args));
    }
    if (p === '/api/kb/docs' && req.method === 'POST') {
      if (typeLevel(u) < 2) return fail(res, 403, '班组长及以上可上传知识库资料');
      const b = JSON.parse(await readBody(req));
      const title = String(b.title || '').trim();
      if (!title || !b.file_path) return fail(res, 400, '标题与文件必填');
      const cat = String(b.category || '其他').slice(0, 30);
      const scope = b.scope === 'all' ? 'all' : 'dept';
      // 同名资料视为新版本：旧版本转入版本表
      const old = db.prepare('SELECT id, ver, file_path FROM kb_docs WHERE title=? AND category=? AND deleted_at IS NULL ORDER BY ver DESC LIMIT 1').get(title, cat);
      if (old) {
        db.prepare('INSERT INTO kb_versions (doc_id,file_path,file_size,ver,uploader_id) VALUES (?,?,?,?,?)').run(old.id, old.file_path, old.file_size || 0, old.ver, u.id);
        db.prepare('UPDATE kb_docs SET file_path=?, file_name=?, file_size=?, ver=ver+1, uploader_id=?, scope=?, created_at=? WHERE id=?')
          .run(b.file_path, String(b.file_name || title).slice(0, 120), Number(b.file_size) || 0, u.id, scope, nowLocalStr(), old.id);
        return ok(res, { id: old.id, ver: old.ver + 1 });
      }
      const r = db.prepare('INSERT INTO kb_docs (title,category,file_path,file_name,file_size,uploader_id,ver,scope) VALUES (?,?,?,?,?,?,1,?)')
        .run(title, cat, b.file_path, String(b.file_name || title).slice(0, 120), Number(b.file_size) || 0, u.id, scope);
      return ok(res, { id: Number(r.lastInsertRowid), ver: 1 });
    }
    if ((m = p.match(/^\/api\/kb\/docs\/(\d+)$/)) && req.method === 'DELETE') {
      db.prepare('UPDATE kb_docs SET deleted_at=? WHERE id=?').run(nowLocalStr(), Number(m[1]));
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/kb\/docs\/(\d+)\/restore$/)) && req.method === 'POST') {
      db.prepare('UPDATE kb_docs SET deleted_at=NULL WHERE id=?').run(Number(m[1]));
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/kb\/docs\/(\d+)\/versions$/)) && req.method === 'GET') {
      return ok(res, db.prepare('SELECT v.*, us.real_name AS uploader_name FROM kb_versions v LEFT JOIN users us ON v.uploader_id=us.id WHERE v.doc_id=? ORDER BY v.ver DESC').all(Number(m[1])));
    }
    if ((m = p.match(/^\/api\/kb\/files\/(\d+)\/download$/)) && req.method === 'GET') {
      const f = db.prepare('SELECT * FROM kb_docs WHERE id=? AND deleted_at IS NULL').get(Number(m[1]));
      if (!f) return fail(res, 404, '文件不存在');
      const fp = path.join(UPLOAD_DIR, f.file_path);
      if (!fs.existsSync(fp)) return fail(res, 404, '文件已丢失');
      res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Disposition': 'attachment; filename="' + encodeURIComponent(f.file_name || f.title) + '"', 'Content-Length': fs.statSync(fp).size });
      fs.createReadStream(fp).pipe(res);
      return;
    }

    // ==================== v6.0 借鉴简道云：自动化规则引擎 ====================
    if (p === '/api/auto-rules' && req.method === 'GET') {
      if (!requireLevel(u, 4, res)) return;
      return ok(res, db.prepare('SELECT * FROM auto_rules ORDER BY id').all());
    }
    if (p === '/api/auto-rules' && req.method === 'POST') {
      if (!requireLevel(u, 4, res)) return;
      const b = JSON.parse(await readBody(req));
      if (!b.name || !b.trigger_type) return fail(res, 400, '规则名称与触发类型必填');
      db.prepare('INSERT INTO auto_rules (name,trigger_type,cond_json,enabled) VALUES (?,?,?,?)').run(String(b.name).slice(0, 50), b.trigger_type, JSON.stringify(b.cond || {}), b.enabled === false ? 0 : 1);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/auto-rules\/(\d+)\/toggle$/)) && req.method === 'POST') {
      if (!requireLevel(u, 4, res)) return;
      const r = db.prepare('SELECT * FROM auto_rules WHERE id=?').get(Number(m[1]));
      if (!r) return fail(res, 404, '规则不存在');
      let en = r.enabled ? 0 : 1;
      try { const b = JSON.parse(await readBody(req)); if (b && typeof b.enabled === 'boolean') en = b.enabled ? 1 : 0; } catch (e) {}
      db.prepare('UPDATE auto_rules SET enabled=? WHERE id=?').run(en, r.id);
      return ok(res, { enabled: !!en });
    }
    // 规则动作：发消息（single 给某人 / all 全员）+ 建任务
    function ruleNotify(userId, title, content) {
      db.prepare("INSERT INTO messages (title, content, sender_id, send_type, target_user_id) VALUES (?,?,?,?,?)").run(title, content, u ? u.id : null, userId ? 'single' : 'all', userId || null);
    }
    // 显式触发：POST /api/auto-rules/run {trigger, id}
    if (p === '/api/auto-rules/run' && req.method === 'POST') {
      const b = JSON.parse(await readBody(req));
      const fired = runAutoRules(b.trigger || '', b.ctx || {});
      return ok(res, { fired });
    }

    // ==================== v6.0 借鉴简道云：Webhook 通知 ====================
    if (p === '/api/webhooks' && req.method === 'GET') {
      if (!requireLevel(u, 4, res)) return;
      return ok(res, db.prepare('SELECT * FROM webhooks ORDER BY id').all());
    }
    if (p === '/api/webhooks' && req.method === 'POST') {
      if (!requireLevel(u, 4, res)) return;
      const b = JSON.parse(await readBody(req));
      if (!b.name || !b.url) return fail(res, 400, '名称与回调地址必填');
      db.prepare('INSERT INTO webhooks (name,url,events_json,enabled) VALUES (?,?,?,?)').run(String(b.name).slice(0, 50), String(b.url).slice(0, 300), JSON.stringify(Array.isArray(b.events) ? b.events : []), b.enabled === false ? 0 : 1);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/webhooks\/(\d+)\/toggle$/)) && req.method === 'POST') {
      if (!requireLevel(u, 4, res)) return;
      const r = db.prepare('SELECT * FROM webhooks WHERE id=?').get(Number(m[1]));
      if (!r) return fail(res, 404, 'Webhook 不存在');
      let en = r.enabled ? 0 : 1;
      try { const b = JSON.parse(await readBody(req)); if (b && typeof b.enabled === 'boolean') en = b.enabled ? 1 : 0; } catch (e) {}
      db.prepare('UPDATE webhooks SET enabled=? WHERE id=?').run(en, r.id);
      return ok(res, { enabled: !!en });
    }
    // fireWebhooks / runAutoRules / 后台扫描定时器 已移至模块级（createServer 之前）定义

    // ==================== v6.0 借鉴简道云：工作台看板 ====================
    if (p === '/api/dashboard' && req.method === 'GET') {
      const today = new Date().toISOString().slice(0, 10);
      const n = (sql, ...args) => { try { return db.prepare(sql).get(...args).c; } catch (e) { return 0; } };
      const year = today.slice(0, 4);
      // 检查闭环率：已闭环问题 / 全部问题
      const chkTotal = n('SELECT COUNT(*) c FROM check_issues WHERE deleted_at IS NULL');
      const chkClosed = n("SELECT COUNT(*) c FROM check_issues WHERE deleted_at IS NULL AND status IN ('closed','accepted')");
      // 培训完成率：有签到的培训 / 全部培训（今年）
      const trTotal = n("SELECT COUNT(*) c FROM trainings WHERE deleted_at IS NULL AND train_date LIKE ?", year + '%');
      const trSigned = n("SELECT COUNT(DISTINCT training_id) c FROM training_signins s JOIN trainings t ON s.training_id=t.id WHERE t.deleted_at IS NULL AND t.train_date LIKE ?", year + '%');
      // 巡逻漏报：今日应巡未巡（按排班有 day=today 但无 patrol 记录）
      const patrolToday = n('SELECT COUNT(*) c FROM patrols WHERE deleted_at IS NULL AND patrol_date=?', today);
      const dutyToday = n('SELECT COUNT(*) c FROM duty_roster WHERE deleted_at IS NULL AND day=?', today);
      // 资产到期预警：报废日期 90 天内 或 维保到期 30 天内
      const assetWarn = n("SELECT COUNT(*) c FROM assets WHERE deleted_at IS NULL AND ((scrap_date IS NOT NULL AND scrap_date != '' AND scrap_date <= date('now','+90 days')) OR (maintain_date IS NOT NULL AND maintain_date != '' AND maintain_date <= date('now','+30 days')))");
      // 审批积压
      const apprPending = n("SELECT COUNT(*) c FROM approvals WHERE deleted_at IS NULL AND status='pending'");
      // 整改超期未闭环
      const issueOverdue = n("SELECT COUNT(*) c FROM check_issues WHERE deleted_at IS NULL AND status NOT IN ('closed','accepted') AND deadline IS NOT NULL AND deadline != '' AND deadline < ?", today);
      // 培训临期（7 天内）
      const trainSoon = n("SELECT COUNT(*) c FROM training_plans WHERE deleted_at IS NULL AND plan_date >= ? AND plan_date <= date('now','+7 days')", today);
      // 消息未读（本人）
      const unreadMsg = n('SELECT COUNT(*) c FROM messages m WHERE m.deleted_at IS NULL AND (m.send_type=\'all\' OR m.target_user_id=?) AND NOT EXISTS(SELECT 1 FROM message_reads mr WHERE mr.message_id=m.id AND mr.user_id=?)', u.id, u.id);
      return ok(res, {
        check: { total: chkTotal, closed: chkClosed, rate: chkTotal ? Math.round(chkClosed / chkTotal * 100) : 0 },
        training: { total: trTotal, signed: trSigned, rate: trTotal ? Math.round(trSigned / trTotal * 100) : 0 },
        patrol: { dutyToday, done: patrolToday, missed: Math.max(0, dutyToday - patrolToday) },
        assets: { warn: assetWarn },
        approval: { pending: apprPending },
        issue: { overdue: issueOverdue },
        plan: { soon: trainSoon },
        unread: unreadMsg
      });
    }

    // ==================== v6.0 借鉴简道云：跨表聚合指标 ====================
    if (p === '/api/stats/aggregate' && req.method === 'GET') {
      // 员工维度：培训学时 + 考核平均 + 检查参与 + 巡逻次数
      const persons = db.prepare('SELECT id, real_name, dept_id FROM users WHERE deleted_at IS NULL AND user_type!=\'admin\' ORDER BY id LIMIT 300').all();
      const depts = db.prepare('SELECT id, name FROM depts').all();
      const rows = persons.map((p2) => {
        const tr = db.prepare("SELECT COUNT(*) c, COALESCE(AVG(CAST(sc.score AS REAL)),0) avg FROM training_scores sc JOIN trainings t ON sc.training_id=t.id WHERE sc.user_id=? AND t.deleted_at IS NULL").get(p2.id);
        const chk = db.prepare('SELECT COUNT(*) c FROM check_records WHERE deleted_at IS NULL AND checker_id=?').get(p2.id).c;
        const ptl = db.prepare('SELECT COUNT(*) c FROM patrols WHERE deleted_at IS NULL AND patroler_id=?').get(p2.id).c;
        return { id: p2.id, name: p2.real_name, dept_id: p2.dept_id, dept_name: (depts.find(d => d.id === p2.dept_id) || {}).name || '', train_count: tr.c, train_avg: Number(tr.avg).toFixed(1), check_count: chk, patrol_count: ptl };
      });
      // 班组维度：整改闭环率 + 巡逻出勤
      const teams = depts.map((d) => {
        const mem = persons.filter((x) => x.dept_id === d.id).map((x) => x.id);
        const issues = db.prepare(`SELECT COUNT(*) c FROM check_issues WHERE deleted_at IS NULL AND created_by IN (${mem.length ? mem.join(',') : '0'})`).get().c;
        const closed = db.prepare(`SELECT COUNT(*) c FROM check_issues WHERE deleted_at IS NULL AND status IN ('closed','accepted') AND created_by IN (${mem.length ? mem.join(',') : '0'})`).get().c;
        const atd = db.prepare(`SELECT COUNT(*) c FROM attendance WHERE user_id IN (${mem.length ? mem.join(',') : '0'}) AND check_in IS NOT NULL`).get().c;
        return { id: d.id, name: d.name, members: mem.length, issues, closed, close_rate: issues ? Math.round(closed / issues * 100) : 0, attendance: atd };
      });
      return ok(res, { persons: rows, teams });
    }

    // ==================== v6.0 移动端待办角标 ====================
    if (p === '/api/unread-count' && req.method === 'GET') {
      const msg = db.prepare('SELECT COUNT(*) c FROM messages m WHERE m.deleted_at IS NULL AND (m.send_type=\'all\' OR m.target_user_id=?) AND NOT EXISTS(SELECT 1 FROM message_reads mr WHERE mr.message_id=m.id AND mr.user_id=?)').get(u.id, u.id).c;
      const todo = db.prepare("SELECT COUNT(*) c FROM tasks WHERE deleted_at IS NULL AND (assignee_id=? OR creator_id=?) AND status='pending'").get(u.id, u.id).c;
      const appr = db.prepare("SELECT COUNT(*) c FROM approvals WHERE deleted_at IS NULL AND status='pending' AND user_id=?").get(u.id).c;
      return ok(res, { messages: msg, todos: todo, approvals: appr, total: msg + todo + appr });
    }

    // ==================== v7.8 工作台门户卡片配置（借鉴云网OA门户，按用户持久化） ====================
    if (p === '/api/portal/cfg' && req.method === 'GET') {
      const row = db.prepare('SELECT v FROM configs WHERE k=?').get('portal_cfg_' + u.id);
      return ok(res, row ? JSON.parse(row.v) : null);
    }
    if (p === '/api/portal/cfg' && req.method === 'PUT') {
      const b = JSON.parse(await readBody(req));
      db.prepare('INSERT OR REPLACE INTO configs (k,v) VALUES (?,?)').run('portal_cfg_' + u.id, JSON.stringify(b.cfg || {}));
      return ok(res, {});
    }

    // ==================== v7.8 工作台图表数据（纯本地聚合、离线可用，借鉴云网OA数据可视化组件） ====================
    if (p === '/api/dashboard/charts' && req.method === 'GET') {
      const attendance = [];
      for (let i = 6; i >= 0; i--) {
        const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
        let c = 0;
        try { c = db.prepare('SELECT COUNT(DISTINCT user_id) c FROM attendance WHERE day=?').get(d).c; } catch (e) { c = 0; }
        attendance.push({ day: d.slice(5), c });
      }
      const check = { ok: 0, basic: 0, bad: 0, issue: 0 };
      try { for (const r of db.prepare("SELECT result, COUNT(*) c FROM check_records WHERE deleted_at IS NULL GROUP BY result").all()) { check[r.result] = (check[r.result] || 0) + r.c; } } catch (e) { /* 忽略 */ }
      const approval = { pending: 0, approved: 0, rejected: 0, cancelled: 0 };
      try { for (const r of db.prepare("SELECT status, COUNT(*) c FROM approvals WHERE deleted_at IS NULL GROUP BY status").all()) { approval[r.status] = (approval[r.status] || 0) + r.c; } } catch (e) { /* 忽略 */ }
      const depts = [];
      try { for (const r of db.prepare("SELECT d.name AS n, COUNT(u.id) AS c FROM users u LEFT JOIN depts d ON u.dept_id=d.id WHERE u.deleted_at IS NULL AND u.role!='admin' GROUP BY d.id ORDER BY c DESC").all()) { depts.push({ name: r.n || '未分配', c: r.c }); } } catch (e) { /* 忽略 */ }
      return ok(res, { attendance, check, approval, depts });
    }

    // ==================== v7.8 管理员模拟用户（流程试跑：一个账号测全流程、切换用户调试） ====================
    if (p === '/api/admin/impersonate' && req.method === 'POST') {
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      const b = JSON.parse(await readBody(req));
      const tgt = db.prepare('SELECT * FROM users WHERE id=?').get(Number(b.user_id));
      if (!tgt) return fail(res, 404, '用户不存在');
      const token = crypto.randomBytes(32).toString('hex');
      // v8.5.2 会话加固：模拟登录同样绑定设备 + 有效期（沿用管理员的 deviceId/过期口径）
      const devId = String(req.headers['x-device-id'] || '').trim();
      const expAt = Date.now() + 30 * 24 * 3600 * 1000;
      db.prepare('INSERT INTO sessions (token, user_id, device_id, expires_at) VALUES (?,?,?,?)').run(token, tgt.id, devId || null, expAt);
      db.prepare('INSERT OR REPLACE INTO configs (k,v) VALUES (?,?)').run('imp_' + token, JSON.stringify({ by: u.id, at: nowLocalStr(), by_name: u.real_name || '' }));
      return ok(res, { token, user: publicUser(Object.assign({}, tgt, { __imp: { by: u.id, by_name: u.real_name || '' } })) });
    }
    if (p === '/api/admin/impersonate/stop' && req.method === 'POST') {
      const h = req.headers['authorization'] || '';
      const token = h.startsWith('Bearer ') ? h.slice(7) : '';
      if (token) { db.prepare('DELETE FROM sessions WHERE token = ?').run(token); db.prepare('DELETE FROM configs WHERE k=?').run('imp_' + token); }
      return ok(res, {});
    }

    // ==================== v7.8 系统配置（审批超时天数等，仅管理员） ====================
    if (p === '/api/admin/config' && req.method === 'GET') {
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      const key = String(url.searchParams.get('key') || '');
      const row = db.prepare('SELECT v FROM configs WHERE k=?').get(key);
      return ok(res, row ? JSON.parse(row.v) : null);
    }
    if (p === '/api/admin/config' && req.method === 'PUT') {
      if (!isAdmin(u)) return fail(res, 403, '需要管理员权限');
      const b = JSON.parse(await readBody(req));
      if (!b.key) return fail(res, 400, '配置键必填');
      db.prepare('INSERT OR REPLACE INTO configs (k,v) VALUES (?,?)').run(String(b.key), JSON.stringify(b.val || {}));
      return ok(res, {});
    }

    // ==================== v6.0 通用导入模板增强 ====================
    if (p === '/api/import/templates' && req.method === 'GET') {
      return ok(res, [
        { type: 'trainings', label: '培训记录导入', fields: ['title', 'category', 'train_date', 'teacher', 'hours', 'participants'] },
        { type: 'assets', label: '资产台账导入', fields: ['no', 'name', 'category', 'location', 'owner', 'status'] },
        { type: 'check_records', label: '检查记录导入', fields: ['check_type', 'check_date', 'area', 'result', 'checker_name'] },
        { type: 'rewards', label: '奖励记录导入', fields: ['user_name', 'rdate', 'reason', 'kind'] }
      ]);
    }
    if (p === '/api/import/generic' && req.method === 'POST') {
      if (typeLevel(u) < 4) return fail(res, 403, '仅运维工程师/管理员可批量导入');
      const b = JSON.parse(await readBody(req));
      const rows = Array.isArray(b.rows) ? b.rows : [];
      if (!rows.length) return fail(res, 400, '导入数据为空');
      let okN = 0, skipN = 0;
      for (const r of rows) {
        if (!r || typeof r !== 'object') { skipN++; continue; }
        if (b.type === 'trainings') {
          if (!r.title || !r.train_date) { skipN++; continue; }
          db.prepare('INSERT INTO trainings (title, category, train_date, trainer, hours, participants, created_by) VALUES (?,?,?,?,?,?,?)').run(String(r.title).slice(0, 100), String(r.category || '日常培训').slice(0, 30), String(r.train_date).slice(0, 10), String(r.trainer || r.teacher || '').slice(0, 50), Number(r.hours) || 0, String(r.participants || ''), u.id);
          okN++;
        } else if (b.type === 'assets') {
          if (!r.name) { skipN++; continue; }
          db.prepare('INSERT INTO assets (no, name, category, location, owner, status) VALUES (?,?,?,?,?,?)').run(String(r.no || '').slice(0, 50), String(r.name).slice(0, 100), String(r.category || '其他').slice(0, 30), String(r.location || '').slice(0, 100), String(r.owner || '').slice(0, 50), String(r.status || '正常').slice(0, 20));
          okN++;
        } else if (b.type === 'check_records') {
          if (!r.check_type || !r.check_date) { skipN++; continue; }
          const checker = db.prepare('SELECT id FROM users WHERE real_name=? LIMIT 1').get(String(r.checker_name || ''));
          db.prepare('INSERT INTO check_records (check_type, check_date, area, result, checker_id, status) VALUES (?,?,?,?,?,?)').run(String(r.check_type).slice(0, 50), String(r.check_date).slice(0, 10), String(r.area || '').slice(0, 100), String(r.result || 'ok').slice(0, 20), checker ? checker.id : u.id, 'approved');
          okN++;
        } else if (b.type === 'rewards') {
          if (!r.reason || !r.rdate) { skipN++; continue; }
          const rw = db.prepare('SELECT id FROM users WHERE real_name=? LIMIT 1').get(String(r.user_name || ''));
          db.prepare('INSERT INTO rewards (user_id, rdate, reason, kind, created_by) VALUES (?,?,?,?,?)').run(rw ? rw.id : u.id, String(r.rdate).slice(0, 10), String(r.reason).slice(0, 200), String(r.kind || '奖励').slice(0, 20), u.id);
          okN++;
        } else { skipN++; }
      }
      return ok(res, { ok: okN, skip: skipN });
    }

    // ==================== v6.0 流程增强：催办/加签/回退 ====================
    if ((m = p.match(/^\/api\/approvals\/(\d+)\/remind$/)) && req.method === 'POST') {
      const ap = db.prepare('SELECT * FROM approvals WHERE id=? AND deleted_at IS NULL').get(Number(m[1]));
      if (!ap) return fail(res, 404, '审批单不存在');
      if (ap.status !== 'pending') return fail(res, 400, '该审批单已处理，无需催办');
      const cur = db.prepare('SELECT * FROM users WHERE id=?').get(ap.approver_id || 0);
      const note = String((JSON.parse(await readBody(req)) || {}).note || '').slice(0, 100);
      if (cur) db.prepare("INSERT INTO messages (title, content, sender_id, send_type, target_user_id) VALUES (?,?,?,?,?)").run('审批催办：' + ap.title, '您有一笔待审批事项已被催办' + (note ? '，附言：' + note : '') + '，请及时处理。', u.id, 'single', cur.id);
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/approvals\/(\d+)\/addsign$/)) && req.method === 'POST') {
      const ap = db.prepare('SELECT * FROM approvals WHERE id=? AND deleted_at IS NULL').get(Number(m[1]));
      if (!ap) return fail(res, 404, '审批单不存在');
      const b = JSON.parse(await readBody(req));
      const extraId = Number(b.extra_user_id || 0);
      if (!extraId) return fail(res, 400, '请选择加签人员');
      const extra = db.prepare('SELECT * FROM users WHERE id=?').get(extraId);
      if (!extra) return fail(res, 404, '加签人员不存在');
      db.prepare("INSERT INTO messages (title, content, sender_id, send_type, target_user_id) VALUES (?,?,?,?,?)").run('加签会签：' + ap.title, '请对审批单「' + ap.title + '」发表会签意见（在消息或系统管理-待办中处理）。', u.id, 'single', extraId);
      db.prepare('INSERT INTO tasks (title, assignee_id, creator_id, status, due_date, source) VALUES (?,?,?,?,?,?)').run('会签：' + ap.title, extraId, u.id, 'pending', b.due || new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 10), 'addsign');
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/approvals\/(\d+)\/reject$/)) && req.method === 'POST') {
      const ap = db.prepare('SELECT * FROM approvals WHERE id=? AND deleted_at IS NULL').get(Number(m[1]));
      if (!ap) return fail(res, 404, '审批单不存在');
      const b = JSON.parse(await readBody(req));
      const note = String(b.note || '未填写意见').slice(0, 200);
      db.prepare("UPDATE approvals SET status='rejected', approve_note=?, approve_at=? WHERE id=?").run(note, nowLocalStr(), ap.id);
      const owner = db.prepare('SELECT * FROM users WHERE id=?').get(ap.user_id);
      if (owner) db.prepare("INSERT INTO messages (title, content, sender_id, send_type, target_user_id) VALUES (?,?,?,?,?)").run('审批回退：' + ap.title, '您的审批单被退回，意见：' + note, u.id, 'single', owner.id);
      fireWebhooks('approval_rejected', { id: ap.id, title: ap.title, note });
      return ok(res, {});
    }

    // runAutoRules 与后台扫描定时器已移至模块级（createServer 之前）定义

    // ==================== v5.11 AI 智能体工作台 ====================
    // 思路来源：《企业AI智能体工作台+ERP落地协同方案》——自然语言取数 + 场景智能体做判断 + 动作闭环 + 全过程留痕
    // 三层架构映射：SQLite 业务库=数据源头（第一层）；本工作台=业务人员新入口（第二层）；
    //              预警顾问/AI问询=把数据翻译成能力（第三层）；链路：取数→分析→判断→推送预警/生成任务→人处理→闭环
    // ---- AI 问询留痕（全过程留痕：谁发起/何时/问了什么/系统返回什么）----
    if (p === '/api/ai/log' && req.method === 'POST') {
      const b = JSON.parse(await readBody(req));
      const q = String(b.q || '').slice(0, 200);
      const summary = String(b.summary || '').slice(0, 500);
      const kind = String(b.kind || 'ask').slice(0, 20);
      db.prepare('INSERT INTO ai_logs (user_id, q, kind, summary) VALUES (?,?,?,?)').run(u.id, q, kind, summary);
      return ok(res, {});
    }
    // ---- 问询日志：本人全见，管理员/运维可看全部（权限分级）----
    if (p === '/api/ai/logs' && req.method === 'GET') {
      const rows = typeLevel(u) >= 4
        ? db.prepare(`SELECT l.*, us.real_name AS user_name FROM ai_logs l LEFT JOIN users us ON l.user_id=us.id ORDER BY l.id DESC LIMIT 100`).all()
        : db.prepare(`SELECT l.*, us.real_name AS user_name FROM ai_logs l LEFT JOIN users us ON l.user_id=us.id WHERE l.user_id=? ORDER BY l.id DESC LIMIT 50`).all(u.id);
      return ok(res, rows);
    }
    // ---- 场景预警顾问：跨模块风险聚合（危险在哪/卡在谁手上/先催哪一件）----
    if (p === '/api/ai/alerts' && req.method === 'GET') {
      const lv = typeLevel(u);
      const now = new Date();
      const Y = now.getFullYear(), M = now.getMonth() + 1, D = now.getDate();
      const iso = (yy, mm, dd) => yy + '-' + String(mm).padStart(2, '0') + '-' + String(dd).padStart(2, '0');
      const today = iso(Y, M, D);
      const daysAgo = (n) => { const d = new Date(Y, M - 1, D - n); return iso(d.getFullYear(), d.getMonth() + 1, d.getDate()); };
      const soon7 = iso(Y, M, D + 7);
      const alerts = [];
      const ownerName = (id) => { if (!id) return ''; const w = db.prepare('SELECT real_name FROM users WHERE id=?').get(id); return w ? w.real_name : ''; };
      // 1) 整改问题超期未闭环（卡在整改责任人手上）
      if (lv >= 1) {
        const rows = db.prepare(`SELECT ci.*, cr.check_type, cr.check_date, cr.area FROM check_issues ci LEFT JOIN check_records cr ON ci.check_record_id=cr.id
          WHERE ci.status IN ('open','submitted') AND ci.rectify_deadline != '' AND ci.rectify_deadline < ? ORDER BY ci.rectify_deadline ASC LIMIT 30`).all(today);
        for (const r of rows) {
          const who = ownerName(r.assigned_to);
          alerts.push({
            key: 'check_overdue', level: 'high', kind: 'check_issue', id: r.id,
            title: '整改超期：' + String(r.content).slice(0, 24),
            detail: '限期 ' + r.rectify_deadline + '，至今未闭环；来源：' + (r.check_type || '检查') + ' · ' + (r.check_date || '') + (r.area ? ' · ' + r.area : ''),
            owner: who || '未指定整改人', page: 'check',
            action: { type: 'notify', label: '生成催办通知' }
          });
        }
      }
      // 2) 审计整改超期（部门领导及以上）
      if (lv >= 2) {
        const rows = db.prepare(`SELECT a.*, ac.project AS check_title FROM audit_issues a LEFT JOIN audit_checks ac ON a.check_id=ac.id
          WHERE a.status IN ('open','rectifying') AND a.deadline != '' AND a.deadline < ? ORDER BY a.deadline ASC LIMIT 20`).all(today);
        for (const r of rows) {
          alerts.push({
            key: 'audit_overdue', level: 'high', kind: 'audit_issue', id: r.id,
            title: '审计整改超期：' + String(r.problem).slice(0, 24),
            detail: '限期 ' + r.deadline + '，当前状态「' + (r.status === 'rectifying' ? '整改中' : '未整改') + '」；来源：' + (r.check_title || '审计检查'),
            owner: ownerName(r.owner_id) || '未指定责任人', page: 'audit',
            action: { type: 'notify', label: '生成催办通知' }
          });
        }
      }
      // 3) 培训计划临期未实施（未来 7 天）
      if (lv >= 1) {
        const rows = db.prepare(`SELECT * FROM training_plans WHERE status='planned' AND plan_date != '' AND plan_date >= ? AND plan_date <= ? ORDER BY plan_date ASC LIMIT 20`).all(today, soon7);
        for (const r of rows) {
          const days = Math.ceil((new Date(r.plan_date) - new Date()) / 86400000);
          alerts.push({
            key: 'train_plan_soon', level: days <= 2 ? 'high' : 'mid', kind: 'training_plan', id: r.id,
            title: '培训临期：' + String(r.title).slice(0, 24),
            detail: '计划日期 ' + r.plan_date + '（还有 ' + days + ' 天），当前未实施；' + (r.category || '') + ' · ' + r.hours + '学时' + (r.target ? ' · 对象：' + r.target : ''),
            owner: '培训负责人', page: 'train',
            action: { type: 'task', label: '生成实施任务' }
          });
        }
      }
      // 4) 会议任务超期（部门领导及以上看全部；普通人员只看自己的）
      if (lv >= 1) {
        const mine = lv < 2 ? ' AND t.assignee_id=' + u.id : '';
        const rows = db.prepare(`SELECT t.*, us.real_name AS assignee_name FROM tasks t LEFT JOIN users us ON t.assignee_id=us.id
          WHERE t.status != 'done' AND t.due_date != '' AND t.due_date < ?${mine} ORDER BY t.due_date ASC LIMIT 20`).all(today);
        for (const r of rows) {
          alerts.push({
            key: 'task_overdue', level: 'high', kind: 'task', id: r.id,
            title: '任务超期：' + String(r.title).slice(0, 24),
            detail: '应于 ' + r.due_date + ' 前完成，至今未办结；' + (r.priority === 'high' ? '优先级：高 · ' : '') + String(r.content || '').slice(0, 30),
            owner: r.assignee_name || '未指定负责人', page: 'task',
            action: { type: 'remind', label: '催办该任务' }
          });
        }
      }
      // 5) 资产维修超期（超过 7 天未完成）
      if (lv >= 1) {
        const rows = db.prepare(`SELECT ar.*, a.name AS asset_name, a.no AS asset_no FROM asset_repairs ar LEFT JOIN assets a ON ar.asset_id=a.id
          WHERE ar.status='维修中' AND ar.start_date != '' AND ar.start_date < ? ORDER BY ar.start_date ASC LIMIT 20`).all(daysAgo(7));
        for (const r of rows) {
          alerts.push({
            key: 'repair_overdue', level: 'mid', kind: 'asset_repair', id: r.id,
            title: '维修超期：' + (r.asset_name || '设备'),
            detail: (r.asset_no || '') + ' · ' + String(r.content).slice(0, 26) + '；开工 ' + r.start_date + '，已超 7 天未完成',
            owner: '设备管理员', page: 'asset',
            action: { type: 'task', label: '生成跟进任务' }
          });
        }
      }
      // 6) 审批积压（超过 48 小时未处理；普通人员只统计自己的申请）
      if (lv >= 1) {
        const stale = daysAgo(2) + ' 23:59:59';
        const rows = db.prepare(`SELECT a.*, us.real_name AS user_name FROM approvals a LEFT JOIN users us ON a.user_id=us.id
          WHERE a.status='pending' AND a.created_at < ? ORDER BY a.created_at ASC LIMIT 20`).all(stale);
        const mine = rows.filter((r) => lv >= 2 ? isApprover(r) : r.user_id === u.id);
        for (const r of mine.slice(0, 10)) {
          alerts.push({
            key: 'approval_stale', level: 'mid', kind: 'approval', id: r.id,
            title: '审批积压：[' + (r.type || '') + '] ' + String(r.title).slice(0, 20),
            detail: '提交于 ' + r.created_at + '，超过 48 小时未处理' + (lv >= 2 ? '；申请人 ' + (r.user_name || '') : ''),
            owner: lv >= 2 ? '待我审批' : '等待审批中', page: 'approval',
            action: { type: 'remind', label: '催办提醒' }
          });
        }
      }
      // 7) 今日巡逻记录缺失（截至现在无当日巡逻记录时提示）
      if (lv >= 1) {
        const c = db.prepare('SELECT COUNT(*) c FROM patrols WHERE patrol_date=?').get(today).c;
        if (c === 0) {
          alerts.push({
            key: 'patrol_missing', level: 'mid', kind: null, id: null,
            title: '今日尚未上报巡逻记录',
            detail: '按运行手册要求，当日巡逻应按时上报并留痕，请尽快补录。',
            owner: '值班/巡逻人员', page: 'patrol',
            action: { type: 'task', label: '生成补录任务' }
          });
        }
      }
      // 8) 今日值班（正常信息，低优先级展示）
      if (lv >= 1) {
        const rows = db.prepare(`SELECT * FROM duty_roster WHERE day=? ORDER BY id`).all(today);
        for (const r of rows) {
          alerts.push({
            key: 'duty_today', level: 'low', kind: 'duty', id: r.id,
            title: '今日值班：' + (r.user_name || ''),
            detail: (r.duty || '值班') + (r.shift ? ' · ' + r.shift : '') + (r.phone ? ' · ' + r.phone : ''),
            owner: r.user_name || '', page: 'duty', action: null
          });
        }
      }
      // 9) 未读消息提醒（最近通知）
      if (lv >= 1) {
        const rows = db.prepare(`SELECT m.*, us.real_name AS sender_name FROM messages m LEFT JOIN users us ON m.sender_id=us.id
          WHERE m.id NOT IN (SELECT message_id FROM message_reads WHERE user_id=?) ORDER BY m.id DESC LIMIT 3`).all(u.id);
        for (const r of rows) {
          alerts.push({
            key: 'unread_msg', level: 'low', kind: 'message', id: r.id,
            title: '未读消息：' + String(r.title).slice(0, 24),
            detail: '来自 ' + (r.sender_name || '系统') + ' · ' + r.created_at,
            owner: '', page: 'msg', action: null
          });
        }
      }
      return ok(res, { today, alerts });
    }
    // ---- AI 动作闭环：预警 → 人确认 → 执行（高风险动作保留人工关口；全过程留痕）----
    if (p === '/api/ai/action' && req.method === 'POST') {
      const b = JSON.parse(await readBody(req));
      const lv = typeLevel(u);
      const kind = String(b.kind || '');
      const id = Number(b.id || 0);
      const note = String(b.note || '').slice(0, 200);
      const act = String(b.action || '');
      let done = null;
      const nowS = nowLocalStr();
      if (act === 'notify') {
        // 生成催办/整改通知（发单人消息给责任人，并落整改通知号）
        if (lv < 2) return fail(res, 403, '需要班组长及以上权限');
        if (kind === 'check_issue' && id) {
          const it = db.prepare('SELECT * FROM check_issues WHERE id=?').get(id);
          if (!it) return fail(res, 404, '整改问题不存在');
          if (!it.notified_at) {
            const no = 'AI-' + it.id + '-' + nowS.slice(0, 10).replace(/-/g, '');
            db.prepare("UPDATE check_issues SET notified_at=?, notice_no=? WHERE id=?").run(nowS, no, id);
            db.prepare('INSERT INTO messages (title,content,sender_id,send_type,target_user_id) VALUES (?,?,?,?,?)')
              .run('【AI催办】整改超期：' + String(it.content).slice(0, 20), '本整改问题已超期（限期 ' + (it.rectify_deadline || '') + '），请尽快整改并在系统中提交闭环。\n问题：' + it.content + (it.location ? '\n位置：' + it.location : '') + (note ? '\n备注：' + note : ''), u.id, 'single', it.assigned_to || null);
            done = '已生成整改催办通知并发送给整改责任人（编号 ' + no + '）';
          } else done = '该问题已催办过（编号 ' + (it.notice_no || '') + '），可另行发送普通消息';
        } else if (kind === 'audit_issue' && id) {
          const it = db.prepare('SELECT * FROM audit_issues WHERE id=?').get(id);
          if (!it) return fail(res, 404, '审计整改问题不存在');
          db.prepare('INSERT INTO messages (title,content,sender_id,send_type,target_user_id) VALUES (?,?,?,?,?)')
            .run('【AI催办】审计整改超期：' + String(it.problem).slice(0, 20), '审计整改问题已超期（限期 ' + (it.deadline || '') + '），请尽快整改闭环。\n问题：' + it.problem + (note ? '\n备注：' + note : ''), u.id, 'single', it.owner_id || null);
          done = '已向责任人发送审计整改催办';
        } else return fail(res, 400, '催办对象不明确');
      } else if (act === 'remind') {
        // 催办任务/审批（发消息）
        if (kind === 'task' && id) {
          const t = db.prepare('SELECT * FROM tasks WHERE id=?').get(id);
          if (!t) return fail(res, 404, '任务不存在');
          db.prepare('INSERT INTO messages (title,content,sender_id,send_type,target_user_id) VALUES (?,?,?,?,?)')
            .run('【AI催办】任务已超期：' + String(t.title).slice(0, 20), '任务应于 ' + (t.due_date || '') + ' 前完成，请尽快办结并在系统中更新状态。\n' + String(t.content || '').slice(0, 100) + (note ? '\n备注：' + note : ''), u.id, 'single', t.assignee_id || null);
          done = '已向任务负责人发送催办';
        } else if (kind === 'approval' && id) {
          db.prepare('INSERT INTO messages (title,content,sender_id,send_type,target_user_id) VALUES (?,?,?,?,?)')
            .run('【AI提醒】审批积压', '该审批已积压超过 48 小时，请尽快处理。' + (note ? '\n备注：' + note : ''), u.id, 'all', null);
          done = '已发送审批积压提醒';
        } else return fail(res, 400, '催办对象不明确');
      } else if (act === 'task') {
        // 生成实施/跟进任务（AI 出草稿 → 人确认 → 落库）
        if (lv < 2 && kind !== 'task') return fail(res, 403, '需要班组长及以上权限');
        const title = String(b.title || '').slice(0, 80);
        const assignee = Number(b.assignee_id || 0) || null;
        const due = String(b.due || '').slice(0, 10);
        if (!title) return fail(res, 400, '任务标题必填');
        db.prepare('INSERT INTO tasks (title,content,assignee_id,creator_id,due_date,priority,status) VALUES (?,?,?,?,?,?,?)')
          .run(title, note || '由 AI 智能体工作台生成', assignee, u.id, due, String(b.priority || 'normal'), 'open');
        done = '已生成任务「' + title + '」';
      } else if (act === 'msg') {
        // 发送普通通知（全员或单人）
        if (lv < 2) return fail(res, 403, '需要班组长及以上权限');
        const title = String(b.title || '通知').slice(0, 60);
        const sendType = b.send_type === 'single' ? 'single' : 'all';
        const targetId = sendType === 'single' ? (Number(b.target_user_id) || null) : null;
        db.prepare('INSERT INTO messages (title,content,sender_id,send_type,target_user_id) VALUES (?,?,?,?,?)')
          .run(title, note || '', u.id, sendType, targetId);
        done = '已发送通知「' + title + '」';
      } else return fail(res, 400, '未知动作');
      // 动作留痕（全过程留痕：谁发起的、何时、做了什么）
      db.prepare('INSERT INTO ai_logs (user_id, q, kind, summary) VALUES (?,?,?,?)')
        .run(u.id, '[动作] ' + act + ':' + kind + ':' + id, 'action', done);
      return ok(res, { done });
    }
    // ---- AI 聚合详情：点击条目查看完整情况与闭环状态（查→看得到→可追踪）----
    if (p === '/api/ai/detail' && req.method === 'GET') {
      const kind = String(url.searchParams.get('kind') || '');
      const id = Number(url.searchParams.get('id') || 0);
      const lv = typeLevel(u);
      const ownerName = (x) => { if (!x) return ''; const w = db.prepare('SELECT real_name FROM users WHERE id=?').get(x); return w ? w.real_name : ''; };
      let d = { kind, id };
      if (kind === 'check_record') {
        const r = db.prepare('SELECT * FROM check_records WHERE id=?').get(id);
        if (!r) return fail(res, 404, '检查记录不存在');
        const issues = db.prepare('SELECT * FROM check_issues WHERE check_record_id=? ORDER BY id').all(id);
        let items = []; try { items = JSON.parse(r.items_json || '[]'); } catch (e) {}
        d = { kind, id, record: { ...r, checker_name: ownerName(r.checker_id) }, issues, items };
      } else if (kind === 'check_issue') {
        const it = db.prepare('SELECT * FROM check_issues WHERE id=?').get(id);
        if (!it) return fail(res, 404, '整改问题不存在');
        const cr = it.check_record_id ? db.prepare('SELECT * FROM check_records WHERE id=?').get(it.check_record_id) : null;
        d = { kind, id, issue: { ...it, assignee_name: ownerName(it.assigned_to), creator_name: ownerName(it.created_by) }, record: cr ? { ...cr, checker_name: ownerName(cr.checker_id) } : null };
      } else if (kind === 'audit_issue') {
        const it = db.prepare('SELECT * FROM audit_issues WHERE id=?').get(id);
        if (!it) return fail(res, 404, '审计整改问题不存在');
        d = { kind, id, issue: { ...it, owner_name: ownerName(it.owner_id) } };
      } else if (kind === 'task') {
        const t = db.prepare('SELECT * FROM tasks WHERE id=?').get(id);
        if (!t) return fail(res, 404, '任务不存在');
        d = { kind, id, task: { ...t, assignee_name: ownerName(t.assignee_id), creator_name: ownerName(t.creator_id) } };
      } else if (kind === 'train') {
        const t = db.prepare('SELECT * FROM trainings WHERE id=?').get(id);
        if (!t) return fail(res, 404, '培训记录不存在');
        d = { kind, id, train: t };
      } else if (kind === 'training_plan') {
        const t = db.prepare('SELECT * FROM training_plans WHERE id=?').get(id);
        if (!t) return fail(res, 404, '培训计划不存在');
        d = { kind, id, plan: t };
      } else if (kind === 'patrol') {
        const r = db.prepare('SELECT * FROM patrols WHERE id=?').get(id);
        if (!r) return fail(res, 404, '巡逻记录不存在');
        d = { kind, id, patrol: { ...r, patroler_name: ownerName(r.patroler_id), approver_name: ownerName(r.approver_id) } };
      } else if (kind === 'asset_repair') {
        const r = db.prepare('SELECT * FROM asset_repairs WHERE id=?').get(id);
        if (!r) return fail(res, 404, '维修记录不存在');
        const a = r.asset_id ? db.prepare('SELECT * FROM assets WHERE id=?').get(r.asset_id) : null;
        d = { kind, id, repair: { ...r, reporter_name: ownerName(r.reporter_id) }, asset: a };
      } else if (kind === 'asset') {
        const a = db.prepare('SELECT * FROM assets WHERE id=?').get(id);
        if (!a) return fail(res, 404, '资产不存在');
        const repairs = db.prepare('SELECT * FROM asset_repairs WHERE asset_id=? ORDER BY id DESC').all(id);
        d = { kind, id, asset: a, repairs };
      } else if (kind === 'approval') {
        const a = db.prepare('SELECT * FROM approvals WHERE id=?').get(id);
        if (!a) return fail(res, 404, '审批不存在');
        let form = {}; try { form = JSON.parse(a.form_json || '{}'); } catch (e) {}
        d = { kind, id, approval: { ...a, user_name: ownerName(a.user_id), approver_name: ownerName(a.approver_id) }, form };
      } else if (kind === 'duty') {
        const r = db.prepare('SELECT * FROM duty_roster WHERE id=?').get(id);
        if (!r) return fail(res, 404, '值班记录不存在');
        d = { kind, id, duty: r };
      } else if (kind === 'message') {
        const r = db.prepare('SELECT * FROM messages WHERE id=?').get(id);
        if (!r) return fail(res, 404, '消息不存在');
        d = { kind, id, message: { ...r, sender_name: ownerName(r.sender_id) } };
      } else {
        return fail(res, 400, '未知详情类型');
      }
      return ok(res, d);
    }
    // ==================== v8.0 OIT 对标：培训（外培/内培+详细记录+按人录/一键多人）====================
    // 数据模型对齐 OIT train_list：一条记录=一个人一次培训；train_service=内培/外培；含学时/费用/成绩/证书/教员/服务期
    // 字典（对齐 OIT app_dict_def）：train_service_type A内部培训/B委外培训；train_type 001非专业安保/002服务/004专项/005岗前/006机坪安全；train_method A集中/B视频
    const TRAIN_TYPE_MAP = { '001': '非专业安保人员培训', '002': '服务培训', '004': '专项/季节培训', '005': '岗前培训', '006': '机坪安全运行培训' };
    const empNameByWorkNo = (empId) => { if (!empId) return ''; const w = db.prepare('SELECT real_name FROM users WHERE work_no=? OR id=?').get(String(empId), Number(empId) || 0); return w ? w.real_name : ''; };
    // ---- 培训记录列表（可按人/内外培/关键词筛选；管理员/运维/班组长可见全部，员工见本人）----
    if (p === '/api/train/records' && req.method === 'GET') {
      const q = req.url.indexOf('?') >= 0 ? new URLSearchParams(req.url.split('?')[1]) : new URLSearchParams();
      let sql = 'SELECT * FROM train_records WHERE deleted_at IS NULL';
      const conds = [], args = [];
      if (q.get('emp_id')) { conds.push('emp_id=?'); args.push(q.get('emp_id')); }
      if (q.get('service')) { conds.push('train_service=?'); args.push(q.get('service')); }
      if (q.get('kw')) { conds.push('(class_info LIKE ? OR emp_name LIKE ? OR certificate_no LIKE ? OR teacher_name LIKE ?)'); const k = '%' + q.get('kw') + '%'; args.push(k, k, k, k); }
      const lv = typeLevel(u);
      if (lv < 2) { conds.push('emp_id=?'); args.push(String(u.work_no || u.id)); }
      if (conds.length) sql += ' AND ' + conds.join(' AND ');
      sql += ' ORDER BY beg_date DESC, id DESC LIMIT 1000';
      const rows = db.prepare(sql).all(...args).map(t => ({ ...t, train_type_name: TRAIN_TYPE_MAP[t.train_type] || t.train_type }));
      return ok(res, rows);
    }
    // ---- 培训统计（内外培人次/学时/费用，对齐 OIT 培训报表）----
    if (p === '/api/train/stats' && req.method === 'GET') {
      const q = req.url.indexOf('?') >= 0 ? new URLSearchParams(req.url.split('?')[1]) : new URLSearchParams();
      const all = db.prepare('SELECT * FROM train_records WHERE deleted_at IS NULL').all();
      const now = new Date(); const ym = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0');
      const s = { neibei: 0, waibei: 0, neibei_hours: 0, waibei_hours: 0, neibei_fee: 0, waibei_fee: 0, month_n: 0, month_hours: 0, people: 0, classes: {} };
      for (const t of all) {
        const isW = t.train_service === '外培';
        if (isW) { s.waibei++; s.waibei_hours += Number(t.hours) || 0; s.waibei_fee += Number(t.fee) || 0; } else { s.neibei++; s.neibei_hours += Number(t.hours) || 0; s.neibei_fee += Number(t.fee) || 0; }
        if ((t.beg_date || '').indexOf(ym) === 0) { s.month_n++; s.month_hours += Number(t.hours) || 0; }
        s.people = new Set(all.filter(x => x.emp_id).map(x => x.emp_id)).size;
        const k = t.train_type_name || t.train_type || '未分类';
        s.classes[k] = (s.classes[k] || 0) + 1;
      }
      return ok(res, { stat: s, types: TRAIN_TYPE_MAP });
    }
    // ---- 录培训：支持单人（POST /api/train/record）与一键多人（POST /api/train/records，emp_ids 数组）----
    async function insertTrainRecords(res2, b, u2) {
      const empIds = Array.isArray(b.emp_ids) ? b.emp_ids : (b.emp_id ? [b.emp_id] : []);
      if (!empIds.length) return fail(res2, 400, '请选择至少一名参训人员');
      const ins = db.prepare(`INSERT INTO train_records (emp_id,emp_name,train_service,train_type,train_method,class_info,beg_date,end_date,days,hours,fee,mark_grade,train_effect,certificate_no,lmt_service_date,teacher_id,teacher_name,corp_organize,corp_operate,note_info,create_user_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
      let n = 0;
      for (const eid of empIds) {
        const ename = empNameByWorkNo(eid);
        if (!ename) continue;
        ins.run(String(eid), ename, String(b.train_service || '内培').slice(0, 8), String(b.train_type || '').slice(0, 30), String(b.train_method || '').slice(0, 20), String(b.class_info || '').slice(0, 200), String(b.beg_date || '').slice(0, 10), String(b.end_date || '').slice(0, 10), Number(b.days) || 0, Number(b.hours) || 0, Number(b.fee) || 0, String(b.mark_grade || '').slice(0, 200), String(b.train_effect || '').slice(0, 30), String(b.certificate_no || '').slice(0, 60), String(b.lmt_service_date || '').slice(0, 10), Number(b.teacher_id) || 0, String(b.teacher_name || '').slice(0, 50), String(b.corp_organize || '').slice(0, 100), String(b.corp_operate || '').slice(0, 100), String(b.note_info || '').slice(0, 500), u2.id);
        n++;
      }
      addRun('train', 'ok', '培训录入：' + (b.class_info || '') + ' ×' + n + '人（' + (b.train_service || '内培') + '）');
      return ok(res2, { added: n });
    }
    if (p === '/api/train/records' && req.method === 'POST') { const b = JSON.parse(await readBody(req)); return insertTrainRecords(res, b, u); }
    if (p === '/api/train/record' && req.method === 'POST') { const b = JSON.parse(await readBody(req)); return insertTrainRecords(res, b, u); }
    // ---- 删除培训记录（管理员/运维）----
    if ((m = p.match(/^\/api\/train\/record\/(\d+)$/)) && req.method === 'DELETE') {
      if (typeLevel(u) < 4) return fail(res, 403, '仅管理员/运维可删除培训记录');
      db.prepare("UPDATE train_records SET deleted_at=datetime('now','localtime') WHERE id=?").run(Number(m[1]));
      return ok(res, {});
    }
    // ---- 教员库（对齐 OIT train_teacher）----
    if (p === '/api/train/teachers' && req.method === 'GET') {
      return ok(res, db.prepare('SELECT * FROM train_teachers WHERE deleted_at IS NULL ORDER BY id DESC').all());
    }
    if (p === '/api/train/teachers' && req.method === 'POST') {
      const b = JSON.parse(await readBody(req));
      if (!String(b.teacher_name || '').trim()) return fail(res, 400, '教员姓名必填');
      db.prepare(`INSERT INTO train_teachers (teacher_name,teacher_type,is_outer,skill_info,corporate_name,dept,dept_post,mobile_no,culture_degree,note_info) VALUES (?,?,?,?,?,?,?,?,?,?)`)
        .run(String(b.teacher_name).slice(0, 50), String(b.teacher_type || '').slice(0, 20), String(b.is_outer || 'N').slice(0, 2), String(b.skill_info || '').slice(0, 200), String(b.corporate_name || '').slice(0, 100), String(b.dept || '').slice(0, 50), String(b.dept_post || '').slice(0, 50), String(b.mobile_no || '').slice(0, 20), String(b.culture_degree || '').slice(0, 50), String(b.note_info || '').slice(0, 500));
      return ok(res, {});
    }
    if ((m = p.match(/^\/api\/train\/teachers\/(\d+)$/)) && req.method === 'DELETE') {
      db.prepare("UPDATE train_teachers SET deleted_at=datetime('now','localtime') WHERE id=?").run(Number(m[1]));
      return ok(res, {});
    }
    // ==================== v8.0 OIT 对标：考核记录 ====================
    if (p === '/api/assess-records' && req.method === 'GET') {
      const q = req.url.indexOf('?') >= 0 ? new URLSearchParams(req.url.split('?')[1]) : new URLSearchParams();
      let sql = 'SELECT * FROM assess_records WHERE deleted_at IS NULL';
      const conds = [], args = [];
      if (q.get('emp_id')) { conds.push('emp_id=?'); args.push(q.get('emp_id')); }
      if (q.get('kw')) { conds.push('(assess_name LIKE ? OR item_name LIKE ?)'); const k = '%' + q.get('kw') + '%'; args.push(k, k); }
      if (conds.length) sql += ' AND ' + conds.join(' AND ');
      sql += ' ORDER BY assess_date DESC, id DESC LIMIT 500';
      return ok(res, db.prepare(sql).all(...args));
    }
    if (p === '/api/assess-records' && req.method === 'POST') {
      const b = JSON.parse(await readBody(req));
      const empIds = Array.isArray(b.emp_ids) ? b.emp_ids : (b.emp_id ? [b.emp_id] : []);
      if (!empIds.length) return fail(res, 400, '请选择至少一名被考核人员');
      const ins = db.prepare(`INSERT INTO assess_records (emp_id,emp_name,assess_name,item_name,mark,grade,assessor_name,assess_date,note_info,create_user_id) VALUES (?,?,?,?,?,?,?,?,?,?)`);
      let n = 0;
      for (const eid of empIds) {
        const ename = empNameByWorkNo(eid);
        if (!ename) continue;
        ins.run(String(eid), ename, String(b.assess_name || '').slice(0, 100), String(b.item_name || '').slice(0, 100), Number(b.mark) || 0, String(b.grade || '').slice(0, 20), String(b.assessor_name || u.real_name).slice(0, 50), String(b.assess_date || '').slice(0, 10), String(b.note_info || '').slice(0, 500), u.id);
        n++;
      }
      addRun('assess', 'ok', '考核录入：' + (b.assess_name || '') + ' ×' + n + '人');
      return ok(res, { added: n });
    }
    if ((m = p.match(/^\/api\/assess-records\/(\d+)$/)) && req.method === 'DELETE') {
      if (typeLevel(u) < 4) return fail(res, 403, '仅管理员/运维可删除考核记录');
      db.prepare("UPDATE assess_records SET deleted_at=datetime('now','localtime') WHERE id=?").run(Number(m[1]));
      return ok(res, {});
    }
    // ==================== v8.0 OIT 对标：个人档案聚合（工作+培训+考核+检查）====================
    if (p === '/api/emp/archive' && req.method === 'GET') {
      const empId = req.url.indexOf('?') >= 0 ? new URLSearchParams(req.url.split('?')[1]).get('emp_id') : '';
      const tgt = empId ? (db.prepare('SELECT * FROM users WHERE work_no=? OR id=? OR real_name=?').get(String(empId), Number(empId) || 0, String(empId)) || null) : u;
      if (!tgt) return fail(res, 404, '未找到该员工');
      // [需求1] 个人档案可见范围：本人 / 管理员(运维及以上) / 同班组的班组长 可直接查看；
      // 跨班组查看他人档案须持已批准的「档案查看」申请（班组长及以上审批），杜绝全员互查隐私。
      if (tgt.id !== u.id) {
        const lv0 = typeLevel(u);
        const sameDept = tgt.dept_id != null && u.dept_id != null && String(tgt.dept_id) === String(u.dept_id);
        if (!(lv0 >= 4 || (lv0 >= 2 && sameDept))) {
          const aps = db.prepare("SELECT form_json FROM approvals WHERE user_id=? AND status='approved' AND deleted_at IS NULL AND type LIKE '%档案查看%'").all(u.id);
          const granted = aps.some((a) => {
            try { const f = JSON.parse(a.form_json || '{}'); return Number(f.target_id) === tgt.id || String(f.target || '') === String(tgt.work_no || '') || String(f.target || '') === String(tgt.real_name || ''); } catch (e) { return false; }
          });
          if (!granted) return fail(res, 403, '查看他人档案需审批：请在本页提交「档案查看」申请，班组长批准后即可查看');
        }
      }
      const uid = tgt.id;
      const workNo = String(tgt.work_no || uid);
      // 工作：考勤出勤天数/请假/值班/已办任务/超期整改
      const att = db.prepare("SELECT COUNT(*) n FROM attendance WHERE user_id=? AND check_in IS NOT NULL AND check_in!=''").get(uid) || { n: 0 };
      const leaves = db.prepare("SELECT COUNT(*) n FROM leaves WHERE user_id=? AND status='approved' AND deleted_at IS NULL").get(uid) || { n: 0 };
      const duty = db.prepare('SELECT COUNT(*) n FROM duty_roster WHERE user_name=? AND deleted_at IS NULL').get(tgt.real_name) || { n: 0 };
      const tasks = db.prepare("SELECT COUNT(*) n FROM tasks WHERE assignee_id=? AND status='done' AND deleted_at IS NULL").get(uid) || { n: 0 };
      const taskOpen = db.prepare("SELECT COUNT(*) n FROM tasks WHERE assignee_id=? AND status='open' AND deleted_at IS NULL").get(uid) || { n: 0 };
      // 培训：全部记录 + 汇总（emp_id 为空时按姓名兜底，兼容 OIT 采集数据）
      const trains = db.prepare('SELECT * FROM train_records WHERE (emp_id=? OR emp_name=?) AND deleted_at IS NULL ORDER BY beg_date DESC, id DESC LIMIT 200').all(workNo, tgt.real_name);
      const trainSum = {
        total: trains.length,
        hours: trains.reduce((s, t) => s + Number(t.hours || 0), 0),
        neibei: trains.filter(t => t.train_service === '内培').length,
        waibei: trains.filter(t => t.train_service === '外培').length,
        fee: trains.reduce((s, t) => s + Number(t.fee || 0), 0),
        cert: trains.filter(t => t.certificate_no).length
      };
      // 考核
      const assess = db.prepare('SELECT * FROM assess_records WHERE (emp_id=? OR emp_name=?) AND deleted_at IS NULL ORDER BY assess_date DESC, id DESC LIMIT 100').all(workNo, tgt.real_name);
      // 检查：作为检查人的检查记录 + 关联其整改的问题
      const checks = db.prepare('SELECT * FROM check_records WHERE checker_id=? AND deleted_at IS NULL ORDER BY check_date DESC LIMIT 50').all(uid);
      const issues = db.prepare('SELECT * FROM check_issues WHERE assigned_to=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 50').all(uid);
      // 工作明细：考勤/请假/值班/任务（供档案三级下钻）
      const attList = db.prepare("SELECT day, check_in, check_out FROM attendance WHERE user_id=? ORDER BY day DESC LIMIT 30").all(uid);
      const leaveList = db.prepare("SELECT type, reason, start_time, end_time, status, created_at FROM leaves WHERE user_id=? AND status='approved' AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 20").all(uid);
      const dutyList = db.prepare("SELECT day, shift, duty FROM duty_roster WHERE user_name=? AND deleted_at IS NULL ORDER BY day DESC LIMIT 20").all(tgt.real_name);
      const taskList = db.prepare("SELECT title, status, due_date, created_at FROM tasks WHERE assignee_id=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 20").all(uid);
      // v8.2 员工档案子模块：卡证 / 异动 / 奖惩（OIT emp_card / emp_post_move / emp_punishment+emp_prize）
      const cards = db.prepare('SELECT * FROM emp_cards WHERE emp_id=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 50').all(workNo);
      const moves = db.prepare('SELECT * FROM emp_moves WHERE emp_id=? AND deleted_at IS NULL ORDER BY move_date DESC, id DESC LIMIT 50').all(workNo);
      const rewards = db.prepare("SELECT * FROM emp_rewards WHERE emp_id=? AND deleted_at IS NULL ORDER BY r_date DESC, id DESC LIMIT 50").all(workNo);
      return ok(res, {
        user: { id: tgt.id, work_no: workNo, name: tgt.real_name, dept_id: tgt.dept_id, dept_name: tgt.dept_name || '', role: tgt.role, user_type: tgt.user_type || '', gender: tgt.gender || '', nation: tgt.nation || '', birth_date: tgt.birth_date || '', mobile: tgt.mobile || '', political_status: tgt.political_status || '', education: tgt.education || '', hire_date: tgt.hire_date || '', job_title: tgt.job_title || '', contract_signed: tgt.contract_signed || 0, contract_signed_at: tgt.contract_signed_at || '', created_at: tgt.created_at || '' },
        work: { attend_days: att.n, leaves: leaves.n, duty: duty.n, tasks_done: tasks.n, tasks_open: taskOpen.n, attendance: attList, leave_list: leaveList, duty_list: dutyList, task_list: taskList },
        train: { list: trains, sum: trainSum },
        assess: { list: assess, sum: assess.length },
        check: { checks, issues, sum: checks.length + issues.length },
        cards, moves, rewards,
        // v8.3 人事其他子表（OIT emp_contract/insurance/work_his/study_his/technical/family/med_check/job_hurt/dorm_use
        // 演示库多为 0 行：返回类别模板 + 空态，正式库导入后自动显示）
        hr: [
          { code: 'contract', name: '劳动合同', oit_table: 'emp_contract', count: 0 },
          { code: 'insurance', name: '社保/保险', oit_table: 'emp_insurance', count: 0 },
          { code: 'work_his', name: '工作经历', oit_table: 'emp_work_his', count: 0 },
          { code: 'study_his', name: '学习经历', oit_table: 'emp_study_his', count: 0 },
          { code: 'technical', name: '职称/技能证书', oit_table: 'emp_technical', count: 0 },
          { code: 'family', name: '家庭成员', oit_table: 'emp_family', count: 0 },
          { code: 'med_check', name: '体检记录', oit_table: 'emp_med_check', count: 0 },
          { code: 'job_hurt', name: '工伤记录', oit_table: 'emp_job_hurt', count: 0 },
          { code: 'dorm', name: '宿舍', oit_table: 'emp_dorm_use', count: 0 }
        ]
      });
    }
    // ==================== v8.0 OIT 数据导入（采集器 v1.3：培训记录/教员/考核，幂等）====================
    if (p === '/api/train/import' && req.method === 'POST') {
      const btok = req.headers['authorization'] || '';
      let authed = false;
      if (btok.startsWith('Bearer ')) {
        const ck = clCfg().key;
        if (ck && btok === 'Bearer ' + sha256hex(ck)) authed = true;
      }
      if (!authed && typeLevel(u) < 4) return fail(res, 403, '仅管理员/运维可导入');
      const body = JSON.parse(await readBody(req));
      let n = 0, nt = 0, na = 0;
      const insT = db.prepare(`INSERT INTO train_records (emp_id,emp_name,train_service,train_type,train_method,class_info,beg_date,end_date,days,hours,fee,mark_grade,train_effect,certificate_no,lmt_service_date,teacher_id,teacher_name,corp_organize,corp_operate,note_info,create_user_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
      const chk = db.prepare("SELECT id FROM train_records WHERE emp_id=? AND class_info=? AND beg_date=? AND train_service=? AND deleted_at IS NULL");
      const upd = db.prepare("UPDATE train_records SET mark_grade=?,hours=?,fee=?,train_effect=?,certificate_no=?,teacher_name=?,end_date=?,note_info=? WHERE id=?");
      if (Array.isArray(body.trains)) for (const t of body.trains) {
        const service = t.train_service === '外培' || t.train_service === 'B' ? '外培' : '内培';
        const cls = String(t.class_info || '').slice(0, 200);
        const beg = String(t.beg_date || '').slice(0, 10);
        const ename = empNameByWorkNo(t.emp_id);
        if (!t.emp_id || !cls || !ename) continue;
        const exist = chk.get(String(t.emp_id), cls, beg, service);
        if (exist) {
          upd.run(String(t.mark_grade || ''), Number(t.hours) || 0, Number(t.fee) || 0, String(t.train_effect || ''), String(t.certificate_no || ''), String(t.teacher_name || ''), String(t.end_date || '').slice(0, 10), String(t.note_info || ''), exist.id);
        } else {
          insT.run(String(t.emp_id), ename, service, String(t.train_type || '').slice(0, 30), String(t.train_method || '').slice(0, 20), cls, beg, String(t.end_date || '').slice(0, 10), Number(t.days) || 0, Number(t.hours) || 0, Number(t.fee) || 0, String(t.mark_grade || ''), String(t.train_effect || ''), String(t.certificate_no || ''), String(t.lmt_service_date || '').slice(0, 10), Number(t.teacher_id) || 0, String(t.teacher_name || '').slice(0, 50), String(t.corp_organize || '').slice(0, 100), String(t.corp_operate || '').slice(0, 100), String(t.note_info || '').slice(0, 500), u.id);
        }
        n++;
      }
      if (Array.isArray(body.teachers)) for (const t of body.teachers) {
        if (!String(t.teacher_name || '').trim()) continue;
        const ex = db.prepare('SELECT id FROM train_teachers WHERE teacher_name=? AND deleted_at IS NULL').get(String(t.teacher_name));
        if (ex) { db.prepare("UPDATE train_teachers SET teacher_type=?,is_outer=?,skill_info=?,corporate_name=?,dept=?,dept_post=?,mobile_no=?,culture_degree=?,note_info=? WHERE id=?").run(String(t.teacher_type || ''), String(t.is_outer || 'N').slice(0, 2), String(t.skill_info || ''), String(t.corporate_name || ''), String(t.dept || ''), String(t.dept_post || ''), String(t.mobile_no || ''), String(t.culture_degree || ''), String(t.note_info || ''), ex.id); }
        else { db.prepare(`INSERT INTO train_teachers (teacher_name,teacher_type,is_outer,skill_info,corporate_name,dept,dept_post,mobile_no,culture_degree,note_info) VALUES (?,?,?,?,?,?,?,?,?,?)`).run(String(t.teacher_name).slice(0, 50), String(t.teacher_type || ''), String(t.is_outer || 'N').slice(0, 2), String(t.skill_info || ''), String(t.corporate_name || ''), String(t.dept || ''), String(t.dept_post || ''), String(t.mobile_no || ''), String(t.culture_degree || ''), String(t.note_info || '')); }
        nt++;
      }
      if (Array.isArray(body.assess)) for (const t of body.assess) {
        const ename = empNameByWorkNo(t.emp_id);
        if (!t.emp_id || !ename) continue;
        db.prepare(`INSERT INTO assess_records (emp_id,emp_name,assess_name,item_name,mark,grade,assessor_name,assess_date,note_info,create_user_id) VALUES (?,?,?,?,?,?,?,?,?,?)`).run(String(t.emp_id), ename, String(t.assess_name || '').slice(0, 100), String(t.item_name || '').slice(0, 100), Number(t.mark) || 0, String(t.grade || '').slice(0, 20), String(t.assessor_name || '').slice(0, 50), String(t.assess_date || '').slice(0, 10), String(t.note_info || '').slice(0, 500), u.id);
        na++;
      }
      if (n + nt + na > 0) addRun('oit', 'ok', 'OIT培训对标导入（培训' + n + ' 教员' + nt + ' 考核' + na + '）');
      return ok(res, { trains: n, teachers: nt, assess: na });
    }
    // 静态页面
    if (p.startsWith('/api/')) return fail(res, 404, '接口不存在');
    return serveStatic(req, res, p);
  } catch (e) {
    errorLog('route ' + req.method + ' ' + p, e);
    if (!res.headersSent) fail(res, 500, '服务器错误: ' + e.message);
  }
});

function publicUser(u) {
  const grants = db.prepare('SELECT feature FROM user_grants WHERE user_id=?').all(u.id).map((g) => g.feature);
  const base = {
    id: u.id, username: u.username, work_no: u.work_no || '', real_name: u.real_name,
    dept_id: u.dept_id, role: u.role, user_type: utype(u), user_type_name: TYPE_NAMES[utype(u)] || utype(u),
    contract_signed: u.contract_signed || 0, contract_signed_at: u.contract_signed_at || '',
    grants, type_level: typeLevel(u)
  };
  if (u.__imp) base.impersonating = { by: u.__imp.by || 0, at: u.__imp.at || '', by_name: u.__imp.by_name || '' };
  return base;
}

// ============================================================
// v7.9-cloud 云端异步备份同步模块
// 主服务器（办公电脑/与 OIT 系统同机）定期将 SQLite 全库快照
// 加密（AES-256-GCM）推送到云端异步备份服务器；云端仅做接收、
// 落盘、保留 30 份，不参与业务。借鉴 litestream 持续备份思路：
// 定期全量快照 + 版本保留 + 异地存储；OIT 地址未知时，
// 管理员可用「导出本地备份包」先取资料再手动上传。
// ============================================================
function clCfg() {
  const g = k => { const r = db.prepare('SELECT v FROM configs WHERE k=?').get(k); return r ? r.v : ''; };
  const s = (k, v) => db.prepare('INSERT INTO configs (k,v) VALUES (?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v').run(k, v);
  return {
    url: g('cloud_url'), key: g('cloud_key'), intervalMin: parseInt(g('cloud_interval') || '360', 10),
    bizUrl: g('cloud_biz_url'), bizUrl2: g('cloud_biz_url2') || g('cloud_biz_url'), oitTimes: g('oit_times') || '08:00,12:00,18:00', oitScript: g('oit_script') || '',
    oitLast: g('oit_last') || '', oitLastRun: parseInt(g('oit_last_run_ts') || '0', 10),
    get last() { return g('cloud_last'); }, get lastTs() { return parseInt(g('cloud_last_ts') || '0', 10); },
    get seq() { return parseInt(g('cloud_seq') || '0', 10); },
    set last(v) { s('cloud_last', v); }, set lastTs(v) { s('cloud_last_ts', String(v)); },
    set seq(v) { s('cloud_seq', String(v)); },
    get state() { return g('cloud_state') || ''; }, set state(v) { s('cloud_state', v); },
    get lastError() { return g('cloud_err') || ''; }, set lastError(v) { s('cloud_err', v); },
    setVal: s
  };
}
// 生成加密备份包：gzip(db 全量) + AES-256-GCM；头部 = IV(16) + TAG(16) + metaLen(4BE) + metaJson + 密文
function clPack(cfg) {
  // WAL 模式下主文件可能不含最近提交 → 先强制 checkpoint(TRUNCATE) 合并 WAL 再读文件，保证备份一致
  try { db.exec('PRAGMA wal_checkpoint(TRUNCATE)'); } catch (e) { /* checkpoint 失败仍可备份（尽力而为） */ }
  const dbBytes = fs.readFileSync(DB_FILE);
  const gz = zlib.gzipSync(dbBytes);
  const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all()
    .map(t => t.name)
    .filter(n => { try { return db.prepare('SELECT COUNT(*) c FROM "' + n.replace(/"/g, '""') + '"').get().c !== undefined; } catch (e) { return false; } })
    .map(n => ({ name: n, count: db.prepare('SELECT COUNT(*) c FROM "' + n.replace(/"/g, '""') + '"').get().c }));
  const meta = {
    v: 790, seq: cfg.seq + 1, ts: new Date().toISOString(),
    dbBytes: dbBytes.length, gzBytes: gz.length, tables,
    note: 'dept-system 主库全量加密备份（AES-256-GCM）'
  };
  const key = crypto.createHash('sha256').update(cfg.key || 'dept-sync-default').digest();
  const iv = crypto.randomBytes(16);
  const cip = crypto.createCipheriv('aes-256-gcm', key, iv);
  const metaJson = Buffer.from(JSON.stringify(meta), 'utf8');
  const head = Buffer.alloc(4); head.writeUInt32BE(metaJson.length, 0);
  const body = Buffer.concat([cip.update(gz), cip.final()]);
  const tag = cip.getAuthTag();
  return { buf: Buffer.concat([iv, tag, head, metaJson, body]), meta };
}
// 推送到云端异步备份服务器
// ==================== v7.9-cloud OIT 自动采集与分发（云端业务/备份服务器共用组件调度端） ====================
// 采集器产出 OIT 数据包：{source,exported_at,depts:[{name}],users:[{code,name,dept,type}]}
function oitImportData(body) {
  const OIT_TYPE_MAP = { '新人': 'xinren', '在职': 'zaizhi', '在职人员': 'zaizhi', '班组长': 'banzuzhang', '部门领导': 'bumenlingdao', '运维': 'weihu', '运维工程师': 'weihu', '管理员': 'admin' };
  let addedD = 0, addedU = 0, updU = 0, skipAdmin = 0;
  const deptIds = {};
  if (Array.isArray(body.depts)) {
    for (const d of body.depts) {
      const name = String(d.name || '').trim();
      if (!name) continue;
      let row = db.prepare('SELECT id FROM depts WHERE name=?').get(name);
      if (!row) { const r = db.prepare('INSERT INTO depts (name) VALUES (?)').run(name); row = { id: r.lastInsertRowid }; addedD++; }
      deptIds[name] = row.id;
    }
  }
  if (Array.isArray(body.users)) {
    for (const u2 of body.users) {
      const code = String(u2.code || '').trim(), name = String(u2.name || '').trim();
      if (!code || !name) continue;
      if (code === 'admin' || code === 'admin1' || code === 'admin2') { skipAdmin++; continue; }
      const did = deptIds[String(u2.dept_name || u2.dept || '').trim()] || null;
      // v1.2 全字段映射：岗位名称 → 用户类型（OIT 无新人/在职概念，按岗位层级映射）
      let ut = 'zaizhi';
      const pn = String(u2.post_name || '').trim();
      if (pn.includes('班组长')) ut = 'banzuzhang';
      else if (pn.includes('经理') || pn.includes('主管')) ut = 'bumenlingdao';
      else if (pn.includes('运维')) ut = 'weihu';
      if (u2.is_admin === true || u2.is_admin === 'T' || u2.is_admin === 'true') ut = 'admin';
      // 离职（OIT state=F 已离职）→ 标记停用
      const resigned = String(u2.state || '').trim() === 'F' || String(u2.state || '').trim() === 'H';
      const now = "datetime('now','localtime')";
      const phone = String(u2.mobile || '').trim() || String(u2.telephone || '').trim();
      const ex = db.prepare('SELECT id FROM users WHERE username=? OR work_no=?').get(code, code);
      if (ex) {
        db.prepare('UPDATE users SET real_name=?, dept_id=?, user_type=?, work_no=?, job_title=?, mobile=?, id_card=?, gender=?, birth_date=?, hire_date=?, nation=?, political_status=?, education=?, updated_at=' + now + (resigned ? ', deleted_at=' + now : ', deleted_at=COALESCE(deleted_at,NULL)') + ' WHERE id=?')
          .run(name, did, ut, code,
            String(u2.post_name || '').trim(), phone, String(u2.id_card || '').trim(),
            String(u2.gender || '').trim(), String(u2.birthday || '').trim(), String(u2.hire_date || '').trim(),
            String(u2.nation || '').trim(), String(u2.polity || '').trim(), String(u2.education || '').trim(), ex.id);
        updU++;
      } else {
        const salt = crypto.randomBytes(16).toString('hex');
        const hash = hashPassword(code, salt);
        db.prepare('INSERT INTO users (username,password_hash,salt,real_name,dept_id,role,user_type,work_no,job_title,mobile,id_card,gender,birth_date,hire_date,nation,political_status,education,deleted_at,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,' + (resigned ? now : 'NULL') + ',' + now + ')')
          .run(code, hash, salt, name, did, 'member', ut, code,
            String(u2.post_name || '').trim(), phone, String(u2.id_card || '').trim(),
            String(u2.gender || '').trim(), String(u2.birthday || '').trim(), String(u2.hire_date || '').trim(),
            String(u2.nation || '').trim(), String(u2.polity || '').trim(), String(u2.education || '').trim());
        addedU++;
      }
    }
  }
  return { depts_added: addedD, users_added: addedU, users_updated: updU, admin_skipped: skipAdmin };
}

// 本机执行采集器（办公电脑）：PowerShell 读 oit_setup MDB → 写 OIT 数据包
function oitRunLocalScript(cfg) {
  let script = String(cfg.oitScript || '');
  if (!script || !fs.existsSync(script)) {
    // v7.9.12 自动探测部署包内采集器（解压路径不固定，免配置）
    for (const c of [path.join(__dirname, 'OIT数据采集器-v1.2.ps1'), path.join(__dirname, 'OIT数据采集器.ps1'), path.join(__dirname, '..', 'OIT数据采集器-v1.2.ps1')]) {
      if (fs.existsSync(c)) { script = c; break; }
    }
  }
  if (!script || !fs.existsSync(script)) return null;
  try {
    const out = child_process.execFileSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', script, '-Auto', '-Out', path.join(__dirname, 'data', 'oit-latest.json')], { encoding: 'utf8', timeout: 180000, windowsHide: true });
    const fp = path.join(__dirname, 'data', 'oit-latest.json');
    if (fs.existsSync(fp)) {
      try { return JSON.parse(fs.readFileSync(fp, 'utf8')); } catch (e) { return null; }
    }
  } catch (e) { return null; }
  return null;
}

// OIT 数据包 HTTP 分发（云端业务 + 备份端，Bearer=同步密钥）
function oitDispatch(pkt) {
  const cfg = clCfg();
  const results = [];
  if (cfg.bizUrl && pkt) {
    try {
      const r = httpPostJson(cfg.bizUrl.replace(/\/$/, '') + '/api/oit/import', pkt, { Authorization: 'Bearer ' + sha256hex(cfg.key) }, 20000);
      results.push('云端业务导入:' + (r && r.ok ? '✓' : '失败'));
    } catch (e) { results.push('云端业务推送失败:' + e.message); }
  }
  if (cfg.url && cfg.key && pkt) {
    try {
      const r = httpPostJson(cfg.url.replace(/\/$/, '') + '/api/backup/import', pkt, { Authorization: 'Bearer ' + sha256hex(cfg.key) }, 20000);
      results.push('备份端归档:' + (r && r.ok ? '✓' : '失败'));
    } catch (e) { results.push('备份端推送失败:' + e.message); }
  }
  return results.join('；');
}

// httpPostJson 已迁至 modules/util.js（[需求9]）

// OIT 定时检查（到点执行采集+导入+分发）
function oitTick() {
  try {
    const cfg = clCfg();
    const times = String(cfg.oitTimes || '').split(',').map(t => t.trim()).filter(Boolean);
    if (!times.length) return;
    const now = new Date();
    const hm = String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0');
    const today = now.toLocaleDateString('en-CA');
    if (!times.includes(hm)) return;
    if (cfg.oitLastRun > 0 && today === cfg.oitLast.slice(0, 10)) return; // 今天已采过
    let pkt = oitRunLocalScript(cfg);
    if (!pkt) {
      // 无脚本/脚本失败：使用最近一次采集器上传的数据包（data/oit-latest.json）
      const fp = path.join(__dirname, 'data', 'oit-latest.json');
      if (fs.existsSync(fp)) { try { pkt = JSON.parse(fs.readFileSync(fp, 'utf8')); } catch (e) { pkt = null; } }
    }
    if (pkt) {
      const r = oitImportData(pkt);
      cfg.setVal('oit_last', nowLocalStr()); cfg.setVal('oit_last_run_ts', String(Date.now()));
      const dist = oitDispatch(pkt);
      addRun('oit', 'ok', '自动采集导入（部门+' + r.depts_added + ' 新增+' + r.users_added + ' 更新+' + r.users_updated + '）' + (dist ? ' | ' + dist : ''));
    } else {
      addRun('oit', 'warn', '到点未取得 OIT 数据（脚本未配置或采集失败）');
    }
  } catch (e) { addRun('oit', 'err', '采集异常:' + e.message); }
}

// 备份前整合：到点或存在未分发的新 OIT 包 → 采集/导入（保证推送云端的备份含最新 OIT 数据）
function oitMergeBeforeBackup() {
  try {
    const cfg = clCfg();
    const fp = path.join(__dirname, 'data', 'oit-latest.json');
    let pkt = oitRunLocalScript(cfg);
    if (!pkt && fs.existsSync(fp)) { try { pkt = JSON.parse(fs.readFileSync(fp, 'utf8')); } catch (e) { pkt = null; } }
    if (!pkt) return;
    const r = oitImportData(pkt);
    if (r.users_added + r.users_updated + r.depts_added > 0) addRun('oit', 'ok', '备份前整合 OIT（新增+' + r.users_added + ' 更新+' + r.users_updated + '）');
  } catch (e) {}
}

// 云端一致性自检：云端最后收到的 seq 落后 → 自动重推；判断备份是否需要恢复
function cloudConsistencyCheck() {
  const cfg = clCfg();
  if (!cfg.url || !cfg.key) return;
  const u = cfg.url.replace(/\/$/, '') + '/api/sync/consistency';
  try {
    const mod = u.startsWith('https:') ? https : http;
    const req = mod.get(u, { headers: { Authorization: 'Bearer ' + sha256hex(cfg.key) }, timeout: 15000 }, (res) => {
      let b = ''; res.on('data', (c) => { b += c; }); res.on('end', () => {
        try {
          const d = JSON.parse(b);
          if (d && d.ok && d.data) {
            const cloudSeq = d.data.lastSeq || 0;
            if (cloudSeq < cfg.seq) {
              cloudBackup(); // 云端落后 → 重推（自愈）
              addRun('consistency', 'warn', '云端最后备份 seq=' + cloudSeq + ' < 本地 ' + cfg.seq + ' → 已自动重新推送');
            } else {
              addRun('consistency', 'ok', '与云端备份一致（seq=' + cloudSeq + '）');
            }
          } else if (d && d.ok === false) {
            addRun('consistency', 'err', '云端校验失败:' + (d.error || ''));
          }
        } catch (e) {}
      });
    });
    req.on('error', () => {}); req.on('timeout', () => { req.destroy(); });
  } catch (e) {}
}

function clPush(cfg, pkg) {
  return new Promise((resolve, reject) => {
    const u = new URL(cfg.url.replace(/\/+$/, '') + '/api/sync/push');
    const token = crypto.createHash('sha256').update(cfg.key || '').digest('hex').slice(0, 32);
    const lib = u.protocol === 'https:' ? https : http;
    const req = lib.request(u, {
      method: 'POST',
      headers: { 'Content-Type': 'application/octet-stream', 'Authorization': 'Bearer ' + token, 'Content-Length': pkg.buf.length, 'X-Sync-Src': 'dept-main' }
    }, r => {
      let b = ''; r.on('data', d => b += d); r.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ ok: false, error: '云端响应异常:' + b.slice(0, 80) }); } });
    });
    req.on('error', e => reject(e));
    req.setTimeout(15000, () => { req.destroy(new Error('连接云端超时（15s）')); });
    req.write(pkg.buf); req.end();
  });
}
// 执行一次云备份：打包 → 推送 → 记录状态
function cloudBackup() {
  const cfg = clCfg();
  oitMergeBeforeBackup(); // v7.9-cloud：备份前自动获取/整合最新 OIT 数据，保证推送到云端的备份含最新人员资料
  if (!cfg.url || !cfg.key) return Promise.resolve({ ok: false, error: '未配置云端地址或同步密钥' });
  try {
    const pkg = clPack(cfg);
    return clPush(cfg, pkg).then(r => {
      if (r && r.ok) {
        cfg.seq = cfg.seq + 1; cfg.last = nowLocalStr(); cfg.lastTs = Date.now(); cfg.state = 'ok';
        cfg.lastError = '';
        return { ok: true, data: { seq: cfg.seq, at: cfg.last, remote: r.data || {} } };
      }
      cfg.state = 'err'; cfg.lastError = (r && r.error) || '云端返回失败';
      return { ok: false, error: cfg.lastError };
    }).catch(e => { cfg.state = 'err'; cfg.lastError = String(e.message || e); return { ok: false, error: cfg.lastError }; });
  } catch (e) {
    cfg.state = 'err'; cfg.lastError = String(e.message || e);
    return Promise.resolve({ ok: false, error: cfg.lastError });
  }
}
// 云端定时任务：按配置间隔自动备份（默认 6 小时；每分钟检查一次是否到期）
setInterval(() => {
  try {
    const cfg = clCfg();
    // ---- v7.9-cloud OIT 定时自动采集（按时间段，默认 08:00/20:00，办公电脑本机执行）----
    oitTick();
    // ---- v7.9-cloud 云端一致性自检：云端最后收到的 seq 落后于本地 → 自动重推（自愈）----
    if (cfg.url && cfg.key && cfg.lastTs > 0) {
      if (Date.now() - cfg.lastTs > 10 * 60 * 1000) cloudConsistencyCheck(); // 距上次推送超 10 分钟才自检，避免频繁
    }
    if (!cfg.url || !cfg.key) return;
    if (Date.now() - cfg.lastTs < cfg.intervalMin * 60000) return; // 未到间隔
    cloudBackup();
  } catch (e) { /* 定时失败不中断服务 */ }
}, 60000); // 每分钟检查一次间隔
// ===== v8.1 AI 助手：本地意图引擎 + 大模型调用 =====
// 本地意图引擎：未配置大模型时的兜底回答，可直接查业务库给出事实性答复
function aiLocalReply(u, ask) {
  const a = String(ask || '');
  const has = (re) => re.test(a);
  const names = db.prepare("SELECT id,work_no,real_name,dept_id,job_title,mobile FROM users WHERE deleted_at IS NULL").all();
  // 1) 查某人档案
  const mPerson = a.match(/(?:查|看|找|谁|了解).{0,4}(?:的)?(?:档案|资料|信息)/) || (a.length <= 8 && names.some(n => a.includes(n.real_name)));
  const hitName = names.find(n => a.includes(n.real_name));
  if (has(/档案/) && hitName) {
    const tr = db.prepare("SELECT COUNT(*) c FROM train_records WHERE emp_id=? AND deleted_at IS NULL").get(hitName.id);
    const lv = db.prepare("SELECT COUNT(*) c FROM leaves WHERE user_id=? AND deleted_at IS NULL").get(hitName.id);
    const dept = hitName.dept_id ? (db.prepare('SELECT name FROM depts WHERE id=?').get(hitName.dept_id) || {}).name : '';
    return `${hitName.real_name}（工号 ${hitName.work_no||'—'}，${dept||'未分组'}，${hitName.job_title||''}）：培训 ${tr.c} 条、请假 ${lv.c} 条。点「个人档案」可看全部明细。`;
  }
  // 2) 培训统计（内培/外培）
  if (has(/培训|外培|内培/)) {
    const inner = db.prepare("SELECT COUNT(*) c,COALESCE(SUM(hours),0) h FROM train_records WHERE train_service='内培' AND deleted_at IS NULL").get();
    const outer = db.prepare("SELECT COUNT(*) c,COALESCE(SUM(hours),0) h FROM train_records WHERE train_service='外培' AND deleted_at IS NULL").get();
    if (hitName) {
      const th = db.prepare("SELECT train_service s,COUNT(*) c,COALESCE(SUM(hours),0) h FROM train_records WHERE emp_id=? AND deleted_at IS NULL GROUP BY train_service").all(hitName.id);
      const line = th.map(t => `${t.s}${t.c}条/${t.h}学时`).join('、') || '暂无';
      return `${hitName.real_name} 的培训记录：${line}。点「培训」页可按人查明细。`;
    }
    return `全部门培训统计：内培 ${inner.c} 条（${inner.h} 学时），外培 ${outer.c} 条（${outer.h} 学时）。`;
  }
  // 3) 部门/班组人数
  if (has(/人数|多少|统计|班组|部门/) && !has(/培训|档案/)) {
    const deps = db.prepare("SELECT d.name dn,COUNT(*) c FROM users u LEFT JOIN depts d ON d.id=u.dept_id WHERE u.deleted_at IS NULL GROUP BY d.name").all();
    if (!deps.length) return '当前暂无在职人员数据。';
    return '各班组在职人数：' + deps.map(d => `${d.dn||'未分组'} ${d.c}人`).join('、') + '。';
  }
  // 4) 今日/最近检查
  if (has(/检查|整改/)) {
    const cks = db.prepare("SELECT check_date,project,area,checker,result,summary FROM audit_checks WHERE deleted_at IS NULL ORDER BY check_date DESC LIMIT 3").all();
    if (!cks.length) return '暂无检查记录。';
    return '最近检查：' + cks.map(c => `${c.check_date} ${c.project}（${c.area||''}）${c.result}`).join('；');
  }
  // 5) 待办提示
  if (has(/待办|有什么要|工作/)) {
    const todo = db.prepare("SELECT COUNT(*) c FROM approvals WHERE status='pending' AND (approver_id=? OR ?)").get(u.id, u.role === 'admin' ? 1 : 0);
    return `你有 ${todo.c} 条待审批。也可以问我：某人工档、培训统计、检查记录等。`;
  }
  // 兜底
  return '我可以帮你：查个人档案（培训/考核/检查）、统计培训、看检查记录、查班组人数。也可以说「录培训」进行智能录入。管理员配置大模型 API 后，我能回答更复杂的问题。';
}

// 智能录入本地解析：自然语言 → 结构化（培训/检查）
function aiParseLocal(text) {
  const t = String(text || '');
  // 培训：识别 人名+课程+日期+学时
  const names = db.prepare("SELECT id,real_name FROM users WHERE deleted_at IS NULL").all();
  const hit = names.find(n => t.includes(n.real_name));
  const beg = (t.match(/\d{4}[-/年]\d{1,2}(?:[-/月]\d{1,2})?/) || [''])[0].replace(/[年月]/g, '-').replace(/日/g, '').replace(/(\d)$/, '');
  const hrs = (t.match(/(\d+(?:\.\d+)?)\s*学时/) || ['', ''])[1];
  const svc = /外培|外出/.test(t) ? '外培' : '内培';
  if (hit) return { kind: 'training', emp_id: hit.id, emp_name: hit.real_name, train_service: svc, class_info: (t.match(/[（(](.*?)[)）]/) || ['', t.replace(new RegExp(hit.real_name, 'g'), '').replace(/\d{4}[-/年]\d{1,2}[-/月]\d{1,2}/g, '').slice(0, 60)])[1] || '', beg_date: beg, hours: Number(hrs) || 0, confirm: true };
  // 检查
  if (/检查|排查|巡查/.test(t)) {
    const area = (t.match(/候机楼|机坪|围界|道口|车库|办公室|食堂|停车场/) || [''])[0];
    const resM = /不合格|隐患|问题/.test(t) ? '不合格' : '合格';
    return { kind: 'check', project: '消防安全检查', result: resM, check_date: beg || new Date().toISOString().slice(0, 10), area: area || '候机楼', summary: t.slice(0, 200), confirm: true };
  }
  return { kind: 'text', raw: t.slice(0, 300), confirm: false };
}

// 大模型调用（OpenAI 兼容协议）
// ==================== [需求8] 系统提示词泄露防护（2026-11-10） ====================
// 背景：系统提示词是"资产"，一旦被诱导复述就等于把内部指令交出去；同时要防"忽略以上指令"类注入。
// 三层：① 提示词只存在服务端常量，任何接口不下发；② 输入侧注入拦截（命中即不调模型、只回固定话术+审计）；
//       ③ 输出侧指纹擦除（模型若复述提示词原文，落库/回显前替换为 [已隐藏]）。
const AI_SYS_GENERAL = '你是部门综合管理系统的 AI 助手，回答要简洁、准确、友好：';
const AI_SYS_WRITE = '你是部门写作专家，请根据部门综合管理系统的业务特点，为以下需求给出结构化的写作/报告建议：';
const AI_PROMPT_FP = [
  '你是部门综合管理系统的 AI 助手',
  '你是部门写作专家',
  '部门综合管理系统的业务特点',
  '回答要简洁、准确、友好',
];
function aiInjectCheck(text) {
  const pats = [
    /(忽略|无视|忘记|绕过|重置|取消)(以上|之前|前面|上面|所有|全部)?(的)?(指令|规则|设定|限制|提示|约束)/i,
    /(系统|初始|预设|开发者|内置|你的)\s*(提示词|prompt|指令|人设|设定)/i,
    /(repeat|print|show|输出|打印|告诉我|展示|复述).{0,16}(system|prompt|提示词|设定|指令)/i,
    /(你是什么模型|你的模型|底层模型|哪个模型|什么大模型|developer mode|开发者模式|jailbreak|越狱|\bDAN\b)/i,
  ];
  return pats.some(function (re) { return re.test(text); });
}
function aiScrubOut(reply) {
  let s = String(reply == null ? '' : reply);
  AI_PROMPT_FP.forEach(function (fp) { s = s.split(fp).join('[已隐藏]'); });
  return s;
}

// [需求3/4] 大模型多 provider 兜底链：主通道失败自动切备用通道（可填商汤日日新等 OpenAI 兼容端点），
// 单一上游断流时 AI 工作台不整体掉线；每次切换写一条日志，便于事后核对是哪条通道在扛。
function aiCfgOne(k) { try { const r = db.prepare('SELECT v FROM configs WHERE k=?').get(k); return r ? r.v : ''; } catch (e) { return ''; } }
async function aiLLMCallAny(prompt) {
  const chain = [
    { name: '主通道', base: aiCfgOne('aiBaseUrl'), key: aiCfgOne('aiKey'), model: aiCfgOne('aiModel') },
    { name: '备用通道', base: aiCfgOne('aiBackupBase'), key: aiCfgOne('aiBackupKey'), model: aiCfgOne('aiBackupModel') }
  ].filter((x) => x.base && x.key);
  for (const p of chain) {
    const r = await aiLLMCall(p.base, p.key, p.model, prompt);
    if (r) { if (p.name !== '主通道') console.log('[AI] 主通道不可用，已切 ' + p.name + ' 完成本次回答'); return r; }
    console.warn('[AI] ' + p.name + ' 调用失败');
  }
  return null;
}
async function aiLLMCall(baseUrl, apiKey, model, prompt) {
  try {
    const url = (baseUrl || '').replace(/\/$/, '') + (baseUrl && baseUrl.includes('/v1') ? '/chat/completions' : '/v1/chat/completions');
    const ctrl = new AbortController(); const tm = setTimeout(() => ctrl.abort(), 30000);
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey }, body: JSON.stringify({ model: model || 'gpt-4o-mini', messages: [{ role: 'system', content: '你是部门综合管理系统的 AI 助手，回答要简洁、准确、友好。' }, { role: 'user', content: prompt }], temperature: 0.4 }), signal: ctrl.signal });
    clearTimeout(tm);
    const j = await r.json();
    return (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || null;
  } catch (e) { return null; }
}

// ===== v8.7 OneBox 融合：数桥（受控取数）/ 知识库出处 / 操作审计 / 用量统计 =====
// 数桥白名单数据资产：表 → 业务标签 + 可查字段（字段别名数组，含脱敏标记）
const BRIDGE_TABLES = {
  users: { label: '员工', alias: ['员工', '人员', '人事'], mineCol: 'id', deptCol: 'dept_id', rows: () => 'deleted_at IS NULL', fields: {
    id: ['工号', 'id'], real_name: ['姓名', '名字'], work_no: ['编号', '工号'], job_title: ['岗位', '职务', '职位'],
    mobile: ['手机', '电话', '联系方式', { m: 1 }], dept_id: ['部门'], user_type: ['类型', '身份'] } },
  depts: { label: '部门', alias: ['部门', '组织'], rows: () => '1=1', fields: { id: ['部门'], name: ['名称', '部门名'], leader: ['负责人', '主管'] } },
  train_records: { label: '培训记录', alias: ['培训', '学时', '成绩'], mineCol: 'emp_id', rows: () => 'deleted_at IS NULL', fields: {
    emp_id: ['员工', '人', '培训人'], train_service: ['内培', '外培', '培训类型'], class_info: ['课程', '培训内容', '内容'],
    beg_date: ['日期', '时间', '开始'], hours: ['学时', '时长', '小时'], mark_grade: ['成绩', '分数'] } },
  trainings: { label: '培训计划', alias: ['培训计划', '计划'], rows: () => '1=1', fields: { name: ['名称', '计划'], category: ['类别', '类型'], hours: ['学时'], begin_date: ['日期'] } },
  audit_checks: { label: '检查记录', alias: ['检查', '排查'], rows: () => 'deleted_at IS NULL', fields: {
    check_date: ['检查日期', '日期', '时间'], project: ['项目', '检查项目'], area: ['区域', '地点', '部位'],
    checker: ['检查人', '人员'], result: ['结果', '结论'], summary: ['摘要', '内容', '问题'] } },
  check_issues: { label: '整改问题', alias: ['整改', '问题', '隐患'], mineCol: 'created_by', rows: () => 'deleted_at IS NULL', fields: {
    issue: ['问题', '内容', '事项'], area: ['区域', '地点'], status: ['状态', '闭环', '整改'], due_date: ['期限', '截止', '日期'],
    level: ['等级', '级别'], owner: ['责任人', '负责人'] } },
  tasks: { label: '待办任务', alias: ['任务', '待办'], mineCol: 'assignee_id', rows: () => 'deleted_at IS NULL', fields: {
    title: ['任务', '名称', '内容'], assignee_id: ['负责人', '人员'], due_date: ['期限', '截止', '日期'], status: ['状态'] } },
  approvals: { label: '审批', alias: ['审批', '签批'], mineCol: 'user_id', rows: () => 'deleted_at IS NULL', fields: {
    title: ['事项', '标题', '内容'], type: ['类型'], status: ['状态', '结果'], created_at: ['时间', '日期'], user_id: ['申请人'] } },
  leaves: { label: '请假', alias: ['请假', '休假', '事假', '病假'], mineCol: 'user_id', rows: () => 'deleted_at IS NULL', fields: {
    leave_type: ['类型', '事由'], start_date: ['开始', '起'], end_date: ['结束', '止'], days: ['天数'], reason: ['原因', '事由'], status: ['状态'] } },
  meetings: { label: '会议', alias: ['会议', '例会', '纪要'], mineCol: 'creator_id', rows: () => 'deleted_at IS NULL', fields: {
    title: ['主题', '名称'], meeting_date: ['日期', '时间'], location: ['地点'], attendee_summary: ['参会', '人员'] } },
  assets: { label: '车辆资产', alias: ['车辆', '资产', '设备', '台账'], rows: () => 'deleted_at IS NULL', fields: {
    name: ['名称', '车辆'], plate_no: ['车牌', '号牌'], type: ['类型'], status: ['状态'], keeper: ['保管', '责任人'] } },
  patrols: { label: '巡逻记录', alias: ['巡逻', '巡查'], mineCol: 'user_id', rows: () => 'deleted_at IS NULL', fields: {
    patrol_date: ['日期', '时间'], area: ['区域', '地点'], result: ['结果'], note: ['备注', '内容'] } },
  rewards: { label: '奖惩', alias: ['奖惩', '奖励', '处罚'], rows: () => 'deleted_at IS NULL', fields: {
    emp_name: ['人员', '员工'], type: ['奖励', '处罚', '类型'], reason: ['事由', '原因'], amount: ['金额'], date: ['日期'] } },
  duty_roster: { label: '值班', alias: ['值班', '排班'], rows: () => 'deleted_at IS NULL', fields: {
    duty_date: ['日期', '时间'], shift: ['班次'], emp_name: ['值班人', '人员'], post: ['岗位', '地点'] } }
};
// 敏感会话：命中即强制本地处理（不调用外部大模型）
const SENSITIVE_WORDS = ['身份证', '手机号', '手机号码', '电话', '工资', '薪资', '密码', '密钥', 'token', '卡号', '账号', '余额', 'api_key'];
function isSensitiveAsk(q) { const s = String(q || ''); return SENSITIVE_WORDS.some(function (w) { return s.indexOf(w) >= 0; }); }
// 操作审计留痕（记录操作者/时间/动作/结果）
function auditLog(u, action, target, detail, result, ip) {
  try {
    db.prepare('INSERT INTO audit_logs (user_id,user_name,action,target,detail,result,ip) VALUES (?,?,?,?,?,?,?)')
      .run(u ? u.id : 0, u ? (u.real_name || u.utype || '') : '', String(action || '').slice(0, 50), String(target || '').slice(0, 100), String(detail || '').slice(0, 2000), result || 'ok', String(ip || '').slice(0, 64));
  } catch (e) {}
}
// maskPhone2 / maskIdCard2 / maskField 已迁至 modules/util.js（[需求9]）
// 时间范围解析（数桥用，与全局检索口径一致）
function bridgeTimeRange(a) {
  const now = new Date(); const Y = now.getFullYear(); const M = now.getMonth() + 1; const D = now.getDate();
  const iso = (yy, mm, dd) => yy + '-' + String(mm).padStart(2, '0') + '-' + String(dd).padStart(2, '0');
  const today = iso(Y, M, D);
  if (/今天|今日/.test(a)) return [today, today];
  if (/昨天/.test(a)) { const d = new Date(Y, M - 1, D - 1); return [iso(d.getFullYear(), d.getMonth() + 1, d.getDate()), iso(d.getFullYear(), d.getMonth() + 1, d.getDate())]; }
  if (/本月|这个月/.test(a)) return [iso(Y, M, 1), iso(Y, M, 31)];
  if (/上月|上个月/.test(a)) { const d0 = new Date(Y, M - 2, 1); const d1 = new Date(Y, M - 1, 0); return [iso(d0.getFullYear(), d0.getMonth() + 1, 1), iso(d1.getFullYear(), d1.getMonth() + 1, d1.getDate())]; }
  if (/今年|本年度|年度/.test(a)) return [iso(Y, 1, 1), iso(Y, 12, 31)];
  if (/去年/.test(a)) return [iso(Y - 1, 1, 1), iso(Y - 1, 12, 31)];
  const mm = a.match(/(\d{1,2})月/);
  if (mm) { const mn = Math.min(12, Math.max(1, parseInt(mm[1], 10))); return [iso(Y, mn, 1), iso(Y, mn, 31)]; }
  const dt = a.match(/(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (dt) { const d2 = iso(+dt[1], +dt[2], +dt[3]); return [d2, d2]; }
  const dn = a.match(/近(\d+)天/);
  if (dn) { const n = parseInt(dn[1], 10); const d0 = new Date(Y, M - 1, D - n + 1); return [iso(d0.getFullYear(), d0.getMonth() + 1, d0.getDate()), today]; }
  const dm = a.match(/近(\d+)个月/);
  if (dm) { const n = parseInt(dm[1], 10); const d0 = new Date(Y, M - 1 - n, 1); return [iso(d0.getFullYear(), d0.getMonth() + 1, 1), today]; }
  return null;
}
// 数桥：自然语言 → 受控 SQL 执行计划（白名单表 + 字段授权 + 行级过滤 + 安全字符校验）
function bridgePlan(ask, u) {
  const a = String(ask || '');
  const tr = bridgeTimeRange(a);
  // 1) 语义层优先：semantic_fields 命中业务词 → 表/列
  let table = null; const sCols = [];
  const sfs = db.prepare('SELECT * FROM semantic_fields').all();
  for (const f of sfs) { if (a.indexOf(f.biz_term) >= 0) { if (!table) table = f.table_name; if (f.column_name && sCols.indexOf(f.column_name) < 0) sCols.push(f.column_name); } }
  // 2) 关键词兜底：按表标签/字段别名/业务别名命中
  if (!table) {
    const hits = Object.keys(BRIDGE_TABLES).filter(function (t) {
      const def = BRIDGE_TABLES[t];
      if (a.indexOf(def.label) >= 0) return true;
      if (def.alias && def.alias.some(function (w) { return a.indexOf(w) >= 0; })) return true;
      return Object.keys(def.fields).some(function (c) { return (def.fields[c] || []).some(function (l) { return typeof l === 'string' && a.indexOf(l) >= 0; }); });
    });
    if (hits.length) table = hits[0];
  }
  if (!table || !BRIDGE_TABLES[table]) return null;
  const def = BRIDGE_TABLES[table];
  // 3) 列过滤：字段别名/语义层列命中；未指定用默认前6列
  const colLabels = {};
  for (const c in def.fields) { for (const l of def.fields[c]) { if (typeof l === 'string') colLabels[l] = c; } }
  for (const f of sfs) { if (f.table_name === table && f.column_name) colLabels[f.column_label || f.column_name] = f.column_name; }
  let selCols = Object.keys(colLabels).filter(function (l) { return a.indexOf(l) >= 0; }).map(function (l) { return colLabels[l]; }).filter(function (v, i, arr) { return arr.indexOf(v) === i; });
  if (!selCols.length) selCols = Object.keys(def.fields).slice(0, 6);
  // 4) WHERE：时间范围 + 数据自身过滤 + 行级授权
  const where = [];
  const timeCol = ['beg_date', 'check_date', 'created_at', 'due_date', 'start_date', 'patrol_date', 'duty_date', 'meeting_date', 'date'].find(function (c) { return def.fields[c]; });
  if (tr && timeCol) where.push("datetime(" + timeCol + ") >= datetime('" + tr[0] + "') AND datetime(" + timeCol + ") <= datetime('" + tr[1] + " 23:59:59')");
  const rowsCond = def.rows ? def.rows(u) : '1=1';
  if (rowsCond) where.push(rowsCond);
  const grants = db.prepare('SELECT * FROM data_grants WHERE table_name=? AND enabled=1').all(table);
  for (const g of grants) {
    if (g.row_scope === 'mine' && def.mineCol) where.push(def.mineCol + '=' + Number(u.id));
    if (g.row_scope === 'dept' && def.deptCol && u.dept_id) where.push(def.deptCol + ' IN (SELECT id FROM depts WHERE id=' + Number(u.dept_id) + ')');
  }
  // 5) 列授权：禁用列剔除
  const forbid = db.prepare('SELECT column_name FROM data_grants WHERE table_name=? AND enabled=0').all(table).map(function (r) { return r.column_name; });
  selCols = selCols.filter(function (c) { return forbid.indexOf(c) < 0; });
  if (!selCols.length) return null;
  const safeCols = selCols.map(function (c) { return table + '.' + c; }).join(',');
  const sql = 'SELECT ' + safeCols + ' FROM ' + table + ' WHERE ' + where.join(' AND ') + ' LIMIT 50';
  if (!/^SELECT [a-zA-Z0-9_,.\s]+ FROM [a-zA-Z0-9_]+ WHERE [a-zA-Z0-9_'()<>=,\s.\-:]+ LIMIT \d+$/.test(sql)) return null;
  return { sql: sql, cols: selCols, table: table, timeRange: tr };
}
// 数桥：受控执行 + 脱敏
function bridgeExec(plan, u) {
  try {
    const rows = db.prepare(plan.sql).all();
    const out = rows.map(function (r) {
      const o = {};
      for (const c of plan.cols) { let v = r[c]; if (maskField(c, v) !== v) v = maskField(c, v); o[plan.table + '.' + c] = v; }
      return o;
    });
    return { rows: out, count: out.length, sql: plan.sql };
  } catch (e) { return { error: '受控查询执行失败：' + e.message }; }
}
// 知识库：文件文本抽取（pdftotext / pandoc / soffice，数据不出内网）
function kbExtractText(fp) {
  const ext = path.extname(fp || '').toLowerCase();
  try {
    if (['.txt', '.md', '.csv', '.json', '.log'].indexOf(ext) >= 0) return fs.readFileSync(fp, 'utf8').slice(0, 200000);
    if (ext === '.pdf') {
      try { return child_process.execSync('pdftotext ' + JSON.stringify(fp) + ' -', { encoding: 'utf8', timeout: 20000 }).slice(0, 200000); } catch (e) { return ''; }
    }
    if (['.docx', '.doc', '.xlsx', '.xls', '.pptx', '.ppt'].indexOf(ext) >= 0) {
      const out = fp + '.txt';
      try { child_process.execSync('pandoc -t plain ' + JSON.stringify(fp) + ' -o ' + JSON.stringify(out), { timeout: 40000 }); } catch (e) {
        try { child_process.execSync('soffice --headless --convert-to txt:Text --outdir ' + JSON.stringify(path.dirname(fp)) + ' ' + JSON.stringify(fp), { timeout: 90000 }); } catch (e2) { return ''; }
      }
      let t = ''; if (fs.existsSync(out)) { t = fs.readFileSync(out, 'utf8'); try { fs.unlinkSync(out); } catch (e) {} }
      return t.slice(0, 200000);
    }
  } catch (e) { return ''; }
  return '';
}
// 知识库：分块入库（每块 ≤800 字）
function kbChunkize(text, title, docId, filePath, fileName, cat) {
  try {
    db.prepare('UPDATE kb_chunks SET deleted_at=? WHERE doc_id=?').run(nowLocalStr(), docId);
    const paras = String(text || '').split(/\n{2,}|。|\n/).map(function (s) { return s.trim(); }).filter(function (s) { return s.length >= 10; });
    let buf = ''; const blocks = [];
    for (const p of paras) { if ((buf + p).length > 800) { if (buf) blocks.push(buf); buf = p; } else { buf += p; } }
    if (buf) blocks.push(buf);
    const ins = db.prepare('INSERT INTO kb_chunks (doc_id,title,category,chunk_text,file_path,file_name) VALUES (?,?,?,?,?,?)');
    for (const b of blocks.slice(0, 200)) ins.run(docId, title, cat, b, filePath || '', fileName || title);
    return blocks.length;
  } catch (e) { return 0; }
}
// 知识库：检索（标题加权 + 分块内容命中，返回出处）
function kbSearch(q) {
  const tokens = String(q || '').split(/[\s,，。;；:：\/]+/).map(function (x) { return x.trim(); }).filter(function (x) { return x.length >= 2; });
  if (!tokens.length) return [];
  const rows = db.prepare('SELECT * FROM kb_chunks WHERE deleted_at IS NULL').all();
  const scored = [];
  for (const r of rows) {
    let s = 0;
    for (const t of tokens) { if ((r.title || '').indexOf(t) >= 0) s += 3; if ((r.chunk_text || '').indexOf(t) >= 0) s += 1; }
    if (s > 0) scored.push({ id: r.id, title: r.title, category: r.category, snippet: String(r.chunk_text || '').slice(0, 180), file_name: r.file_name, file_path: r.file_path, doc_id: r.doc_id, score: s });
  }
  return scored.sort(function (a, b) { return b.score - a.score; }).slice(0, 6);
}
// 写作专家本地模板（无大模型时的兜底，按检索结果生成报告骨架）
function aiWriteReply(u, ask) {
  const hits = kbSearch(ask);
  const src = hits.length ? '（依据知识库 ' + hits.length + ' 条原文，见下方出处）' : '';
  return '写作专家：可按「全局检索」整理素材，生成上月工作报告/纪要模板。要点：① 现状与数据（可让数据专家取数）② 问题与风险 ③ 下月计划。' + src;
}

server.listen(PORT, '0.0.0.0', () => {
  autoUpgradeNewbies();
  // 按用户要求：不生成任何运行文档记录，启动不输出日志
});
function localIP() {
  const os = require('os');
  const ifs = os.networkInterfaces();
  for (const k of Object.keys(ifs)) {
    for (const i of ifs[k] || []) {
      if (i.family === 'IPv4' && !i.internal) return i.address;
    }
  }
  return '127.0.0.1';
}
