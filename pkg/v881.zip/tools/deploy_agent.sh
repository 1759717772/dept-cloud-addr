#!/bin/sh
# ============================================================
# 部门综合管理系统 · 运行期自主部署代理 v3（目录级原子切换）
# 用法: sh deploy_agent.sh <服务目录> <新版本目录> <端口>
#   例: sh deploy_agent.sh /app/working/dept /app/working/dept.next 8090
#
# v1 事故教训（务必遵守）：
#   1) 备份绝不能放在 data/ 里 —— 目录替换时 data 被整体搬走，备份连带失效；
#   2) 回滚只做“还原”，禁止 rm -rf 生产目录；
#   3) 多条件判断禁用 `&&` 短路，否则“把 data 放回去”会被静默跳过；
#   4) 替换前必须先停旧进程，否则端口冲突会挡住验证。
#
# v3 与 v2 的差别：不再“搬 data + 逐文件覆盖”，改为
#   「新目录先接管 data 副本 → 整目录 mv 换位 → 失败整目录 mv 换回」，
#   任何一步失败都只做“换回”，不做删除，生产目录始终是完整的一棵。
# ============================================================
set -u

DEPT=${1:-}
NEXT=${2:-}
PORT=${3:-8090}
TS=$(date +%Y%m%d%H%M%S)
LOG="${DEPT}.deploy.log"
OLD="${DEPT}.old.${TS}"
BAK="${DEPT}.bak.${TS}"
NEXTAK="${DEPT}.next.${TS}"      # 新版本目录的临时落位（与生产目录同级，保证同一文件系统可 mv）

log() { echo "[$(date '+%F %T')] $*" >> "$LOG"; echo "$*"; }
die() { log "中止：$*"; exit 1; }

# ---------- 前置校验 ----------
[ -n "$DEPT" ] || die "缺少服务目录参数"
[ -n "$NEXT" ] || die "缺少新版本目录参数"
[ -d "$DEPT" ] || die "服务目录不存在: $DEPT"
[ -d "$NEXT" ] || die "新版本目录不存在: $NEXT"
log "========== 部署开始 port=$PORT dept=$DEPT next=$NEXT =========="

# ---------- 1. 新版本自检（不合格直接拒绝，生产目录一个字节都不碰） ----------
if [ ! -f "$NEXT/server.js" ]; then die "新版本缺少 server.js"; fi
if [ ! -f "$NEXT/public/app.js" ]; then die "新版本缺少 public/app.js"; fi
if ! node --check "$NEXT/server.js" >/dev/null 2>&1; then die "新版本 server.js 语法检查不通过"; fi
log "新版本自检通过（server.js / public/app.js / node --check）"

# ---------- 2. 数据保护：新目录必须带上现有 data，否则升级会丢真实数据 ----------
if [ ! -d "$NEXT/data" ]; then
  mkdir -p "$NEXT/data" || die "无法创建 $NEXT/data"
fi
if [ -d "$DEPT/data" ] && [ -f "$DEPT/data/system.db" ]; then
  cp -a "$DEPT/data/." "$NEXT/data/" 2>>"$LOG"
  if [ -f "$NEXT/data/system.db" ]; then
    log "已接管现有 data/system.db（$(wc -c < "$NEXT/data/system.db") 字节）"
  else
    die "data 接管失败：新目录没有 system.db"
  fi
fi

# ---------- 3. 备份（同级目录，绝不放 data 内） ----------
cp -a "$DEPT" "$BAK" 2>>"$LOG"
if [ ! -d "$BAK" ]; then die "备份失败，终止且未改动生产目录"; fi
log "已备份到 $BAK（$(du -sh "$BAK" 2>/dev/null | cut -f1)）"

# 找监听指定端口的 PID：容器内 `ss` 常不带 pid 信息（本次容器实测就踩了这个坑，
# 导致旧进程没被杀、新进程抢不到端口，而探测又打到旧进程的 200 → 假成功）。
# 因此按 ss → lsof → /proc 三级回退，并在停止后**校验端口确已释放**，否则拒绝继续。
port_pids() {
  R=$(ss -ltnp 2>/dev/null | grep ":${PORT}" | grep -o 'pid=[0-9]*' | cut -d= -f2 | sort -u)
  if [ -z "$R" ]; then
    R=$(lsof -iTCP:"${PORT}" -sTCP:LISTEN -Pn 2>/dev/null | awk 'NR>1{print $2}' | sort -u)
  fi
  if [ -z "$R" ]; then
    for f in /proc/[0-9]*/cmdline; do
      [ -r "$f" ] || continue
      if tr '\000' ' ' < "$f" 2>/dev/null | grep -q "node.*server\.js"; then
        R="$R $(echo "$f" | cut -d/ -f3)"
      fi
    done
  fi
  echo $R
}

kill_node() {
  ROUND=0
  while [ $ROUND -lt 3 ]; do
    PIDS=$(port_pids)
    if [ -z "$PIDS" ]; then break; fi
    for p in $PIDS; do
      [ -n "$p" ] || continue
      kill "$p" 2>/dev/null && log "已停止旧进程 pid=$p"
    done
    sleep 3
    LEFT=$(port_pids)
    for p in $LEFT; do kill -9 "$p" 2>/dev/null && log "强制停止残留 pid=$p"; done
    ROUND=$((ROUND + 1))
    sleep 2
  done
  if [ -n "$(port_pids)" ]; then
    log "端口 ${PORT} 仍被占用（PID: $(port_pids)），拒绝继续，避免假成功"
    return 1
  fi
  log "端口 ${PORT} 已释放"
  return 0
}

start_node() {
  ( cd "$DEPT" && setsid nohup node "$DEPT/server.js" >> "${DEPT}.runtime.log" 2>&1 & )
  sleep 2
  if ss -ltnp 2>/dev/null | grep -q ":${PORT}"; then log "node 已启动并监听 $PORT"; else log "node 启动后未监听 $PORT"; fi
}

probe() {
  i=0
  while [ $i -lt 10 ]; do
    CODE=$(curl -s -m 3 -o /dev/null -w '%{http_code}' "http://127.0.0.1:${PORT}/api/version" 2>/dev/null)
    if [ "$CODE" = "200" ]; then
      local_ver=$(curl -s -m 3 "http://127.0.0.1:${PORT}/api/version" 2>/dev/null)
      log "探测成功（第 $((i + 1)) 次）HTTP 200，响应: $local_ver"
      return 0
    fi
    i=$((i + 1))
    sleep 2
  done
  log "探测失败：10 次轮询内 /api/version 未返回 200"
  return 1
}

do_rollback() {
  log "!! 进入回滚流程"
  if [ ! -d "$OLD" ]; then
    log "回滚中止：找不到旧目录 $OLD（不做任何删除，请人工介入）"
    return 1
  fi
  kill_node || log "回滚阶段端口未释放，仍尝试换回旧目录"
  if [ -d "$DEPT" ]; then
    mv "$DEPT" "${DEPT}.failed.${TS}" 2>>"$LOG" && log "失败版本已留档 ${DEPT}.failed.${TS}"
  fi
  mv "$OLD" "$DEPT" 2>>"$LOG"
  if [ ! -d "$DEPT" ]; then log "回滚失败：旧目录未能换回"; return 1; fi
  start_node
  if probe; then log "!! 回滚成功，服务恢复（备份仍在 $BAK）"; return 0; fi
  log "!! 回滚后仍不通，需人工介入；现场：$DEPT / 备份：$BAK"
  return 1
}

# ---------- 4. 新目录落到同级临时位 ----------
if ! kill_node; then die "端口未释放，部署中止（生产目录未改动）"; fi
mv "$NEXT" "$NEXTAK" 2>>"$LOG"
if [ ! -d "$NEXTAK" ]; then
  log "新目录落位失败（可能跨文件系统），改为复制方式"
  mkdir -p "$NEXTAK" || die "无法创建临时落位目录"
  cp -a "$NEXT/." "$NEXTAK/" 2>>"$LOG"
  if [ ! -d "$NEXTAK" ]; then start_node; die "新目录复制失败，已重启旧版本"; fi
fi

# ---------- 5. 原子切换 ----------
mv "$DEPT" "$OLD" 2>>"$LOG"
if [ ! -d "$OLD" ]; then
  log "旧目录让位失败，恢复启动"
  start_node
  die "切换失败，生产目录未改动"
fi
mv "$NEXTAK" "$DEPT" 2>>"$LOG"
if [ ! -d "$DEPT" ]; then
  log "新目录就位失败"
  mv "$OLD" "$DEPT" 2>>"$LOG"
  start_node
  die "切换失败，已恢复旧版本"
fi
log "目录切换完成（旧版留档 $OLD）"

# ---------- 6. 启动并验证 ----------
start_node
if probe; then
  log "========== 部署成功 =========="
  exit 0
fi
do_rollback || exit 9
